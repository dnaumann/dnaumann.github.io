Require Import Classical.
Require Import FunctionalExtensionality.
Require Import PropExtensionality.
Require Import Arith.
Require Import Lia.
Require Import List. Import ListNotations.

(* Classical least-witness: any satisfiable nat predicate has a least witness. *)
Lemma least_witness : forall (P : nat -> Prop) n, P n ->
  exists m, P m /\ forall k, k < m -> ~ P k.
Proof.
  intros P.
  induction n as [n IH] using (well_founded_induction lt_wf).
  intros Hn.
  destruct (classic (exists k, k < n /\ P k)) as [[k [Hlt Hk]] | Hno].
  - apply (IH k Hlt Hk).
  - exists n. split; [exact Hn |].
    intros k Hlt HPk. apply Hno. exists k. split; assumption.
Qed.



(* A nat-valued function bounded by B attains a maximum. *)
Lemma nat_bounded_fun_has_max : forall (f : nat -> nat) (B : nat),
  (forall N, f N <= B) ->
  exists M, forall N, f N <= f M.
Proof.
  intros f B. revert f. induction B as [|B IH]; intros f Hb.
  - exists 0. intros N. assert (f N = 0) by (specialize (Hb N); lia).
    assert (f 0 = 0) by (specialize (Hb 0); lia). lia.
  - destruct (classic (exists N, f N = S B)) as [[N0 HN0] | Hno].
    + exists N0. intros N. rewrite HN0. apply Hb.
    + apply IH. intros N. specialize (Hb N).
      destruct (Nat.eq_dec (f N) (S B)) as [He | Hne].
      * exfalso. apply Hno. exists N. exact He.
      * lia.
Qed.

(* A decidable predicate on nat with a witness has a least witness. *)
Lemma decidable_least_witness : forall (P : nat -> Prop),
  (forall n, {P n} + {~ P n}) ->
  (exists n, P n) ->
  exists m, P m /\ forall k, k < m -> ~ P k.
Proof.
  intros P Hdec [n Hn].
  induction n as [n IH] using (well_founded_induction lt_wf).
  destruct (classic (exists k, k < n /\ P k)) as [[k [Hk HPk]] | Hno].
  - apply (IH k Hk HPk).
  - exists n. split; [exact Hn |].
    intros k Hkn HPk. apply Hno. exists k. split; [exact Hkn | exact HPk].
Qed.



(* -------------------------------------------------------- *)
(* list stuff  *)
(* -------------------------------------------------------- *)

Definition list_prefix {A : Type} (xs ys : list A) : Prop :=
  exists zs, ys = xs ++ zs.

Definition list_strict_prefix {A : Type} (xs ys : list A) : Prop :=
  list_prefix xs ys /\ xs <> ys.

Lemma list_prefix_refl : forall A (xs : list A), list_prefix xs xs.
Proof. intros A xs. exists []. rewrite app_nil_r. reflexivity. Qed.

Lemma last_cons : forall (A : Type) (x : A) (l : list A) d,
  l <> [] -> last (x :: l) d = last l d.
Proof.
  intros A x l d Hne. destruct l as [|y l'].
  - exfalso. apply Hne. reflexivity.
  - reflexivity.
Qed.

Lemma last_nth_def : forall (A : Type) (l : list A) (d : A),
  last l d = nth (length l - 1) l d.
Proof.
  intros A l d. induction l as [|x xs IH].
  - reflexivity.
  - destruct xs as [|y ys].
    + reflexivity.
    + rewrite (last_cons A x (y :: ys) d) by discriminate.
      rewrite IH. cbn [length].
      replace (S (length ys) - 1) with (length ys) by lia.
      replace (S (S (length ys)) - 1) with (S (length ys)) by lia.
      cbn [nth]. reflexivity.
Qed.

Lemma last_app_nonempty : forall (A : Type) (l1 l2 : list A) d,
  l2 <> [] -> last (l1 ++ l2) d = last l2 d.
Proof.
  intros A l1 l2 d Hne. induction l1 as [|x xs IH].
  - reflexivity.
  - cbn [app]. rewrite last_cons by
      (intro Hc; apply app_eq_nil in Hc; destruct Hc as [_ Hl2]; apply Hne; exact Hl2).
    exact IH.
Qed.

Lemma ga_firstn_map : forall (A B : Type) (f : A -> B) n l,
  map f (firstn n l) = firstn n (map f l).
Proof.
  intros A B f. induction n as [|n IH]; intros l.
  - reflexivity.
  - destruct l as [|x xs]; [reflexivity | cbn [firstn map]; rewrite IH; reflexivity].
Qed.

Lemma ga_nth_firstn : forall (A : Type) (d : A) n l m,
  m < n -> nth m (firstn n l) d = nth m l d.
Proof.
  intros A d n. induction n as [|n IH]; intros l m Hm; [lia |].
  destruct l as [|x xs]; cbn [firstn].
  - destruct m; reflexivity.
  - destruct m as [|m]; cbn [nth]; [reflexivity | apply IH; lia].
Qed.

Lemma ga_app_nth_plus : forall (A : Type) (l l' : list A) j d,
  nth (length l + j) (l ++ l') d = nth j l' d.
Proof.
  intros A l. induction l as [|x xs IH]; intros l' j d.
  - reflexivity.
  - cbn [length app plus]. cbn [nth]. apply IH.
Qed.

Lemma list_prefix_length : forall A (xs ys : list A),
  list_prefix xs ys -> length xs <= length ys.
Proof. intros A xs ys [zs ->]. rewrite length_app. lia. Qed.

Lemma list_prefix_eq_length : forall A (xs ys : list A),
  list_prefix xs ys -> length ys = length xs -> xs = ys.
Proof.
  intros A xs ys [zs ->] Hlen. rewrite length_app in Hlen.
  assert (length zs = 0) as Hz by lia.
  apply length_zero_iff_nil in Hz. subst zs. rewrite app_nil_r. reflexivity.
Qed.

Lemma list_prefix_app_l : forall A (p xs ys : list A),
  list_prefix xs ys -> list_prefix (p ++ xs) (p ++ ys).
Proof. intros A p xs ys [zs ->]. exists zs. rewrite app_assoc. reflexivity. Qed.

Lemma list_prefix_map : forall A B (f : A -> B) (xs ys : list A),
  list_prefix xs ys -> list_prefix (map f xs) (map f ys).
Proof. intros A B f xs ys [zs ->]. exists (map f zs). rewrite map_app. reflexivity. Qed.


Lemma firstn_prefix : forall (A : Type) (hs rest : list A) n,
  n <= length hs -> firstn n (hs ++ rest) = firstn n hs.
Proof.
  intros A hs rest n Hn. rewrite firstn_app.
  replace (n - length hs) with 0 by lia. simpl. rewrite app_nil_r. reflexivity.
Qed.

Lemma nth_firstn : forall (A : Type) (d : A) n l m,
  m < n -> nth m (firstn n l) d = nth m l d.
Proof.
  intros A d n. induction n as [|n IH]; intros l m Hm; [lia |].
  destruct l as [|x xs]; simpl.
  - destruct m; reflexivity.
  - destruct m as [|m]; simpl; [reflexivity | apply IH; lia].
Qed.

Lemma list_prefix_trans : forall (A : Type) (a b c : list A),
  list_prefix a b -> list_prefix b c -> list_prefix a c.
Proof.
  intros A a b c [z1 H1] [z2 H2]. exists (z1 ++ z2).
  rewrite H2, H1, app_assoc. reflexivity.
Qed.

Lemma firstn_app1 : forall (A : Type) (xs : list A) g n,
  n <= length xs -> firstn n (xs ++ [g]) = firstn n xs.
Proof.
  intros A xs g n Hn. rewrite firstn_app.
  replace (n - length xs) with 0 by lia. simpl. apply app_nil_r.
Qed.

(* Split a list at the (|ys1|+1)-th element that passes the filter predicate *)

Lemma filter_split_at : forall (A : Type) (p : A -> bool) (xs ys1 ys2 : list A) (y : A),
  filter p xs = ys1 ++ y :: ys2 ->
  exists a b, xs = a ++ y :: b /\ filter p a = ys1 /\ filter p b = ys2.
Proof.
  induction xs as [|x xs' IH]; intros ys1 ys2 y Hf.
  - simpl in Hf. destruct ys1; discriminate.
  - simpl in Hf. destruct (p x) eqn:Hpx.
    + destruct ys1 as [|y0 ys1'].
      * simpl in Hf. injection Hf as Hxy Hrest. subst x.
        exists [], xs'. simpl. split; [reflexivity | split; [reflexivity | exact Hrest]].
      * simpl in Hf. injection Hf as Hxy0 Hrest. subst x.
        apply IH in Hrest. destruct Hrest as [a [b [Hxs' [Hfa Hfb]]]].
        exists (y0 :: a), b. split.
        -- simpl. rewrite Hxs'. reflexivity.
        -- split; [simpl; rewrite Hpx, Hfa; reflexivity | exact Hfb].
    + apply IH in Hf. destruct Hf as [a [b [Hxs' [Hfa Hfb]]]].
      exists (x :: a), b. split.
      * simpl. rewrite Hxs'. reflexivity.
      * split; [simpl; rewrite Hpx; exact Hfa | exact Hfb].
Qed.

Lemma list_prefix_app_weaken : forall A (a b c : list A),
  list_prefix (a ++ b) c -> list_prefix a c.
Proof. 
  intros A a b c [z Hz]. exists (b ++ z). rewrite Hz, app_assoc. reflexivity. 
Qed.

Lemma list_prefix_snoc_det : forall A (a c : list A) x y,
  list_prefix (a ++ [x]) c -> list_prefix (a ++ [y]) c -> x = y.
Proof.
  intros A a c x y [zx Hx] [zy Hy]. subst c.
  rewrite <- !app_assoc in Hy. apply app_inv_head in Hy.
  injection Hy as Hxy _. exact Hxy.
Qed.

(* Filters of an initial segment with pointwise-equal predicates have equal length. *)
Lemma filter_seq_ext_length : forall (p q : nat -> bool) N,
  (forall i, i < N -> p i = q i) ->
  length (filter p (seq 0 N)) = length (filter q (seq 0 N)).
Proof.
  induction N as [|N' IH]; intros Hpq; [reflexivity |].
  rewrite seq_S, !filter_app, !length_app.
  assert (Hsub : forall i, i < N' -> p i = q i) by (intros i Hi; apply Hpq; lia).
  rewrite (IH Hsub). simpl. rewrite (Hpq N' ltac:(lia)). reflexivity.
Qed.
