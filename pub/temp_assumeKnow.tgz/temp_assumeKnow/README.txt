Files basin2.v and basin3.v are each a machine checked
development for this paper:
https://arxiv.org/abs/2608.00882

The difference is concerned with a technical point 
that's glossed over in the paper, i.e., designating
control points at which annotation commands appear.

basin2.v was the development at the time version 1 of the 
paper was posted in arXiv.  It does not directly formalize
unique occurrences of annotations as required for the 
key notion of proper alignment.  Instead it relies on two
axioms:
Hypothesis KludgeHyp : handler_entry_dispatched /\ aligned_annot_same_cmd_hyp
where these two conjuncts express key consequences of
uniqueness.  

basin3.v is an improved development that directly formalizes
unique occurrences using tags in the program syntax.  It
proves both handler_entry_dispatched and aligned_annot_same_cmd_hyp
as lemmas.  

