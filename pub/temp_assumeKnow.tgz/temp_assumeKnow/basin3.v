(** Mechanization of the paper "Assuming You Knew..." 
developed with assistance from Claude code as
documented in the paper. *)

(** Tested using Rocq 8.20 *) 

(** ALERT: The results in the paper are fully machine
checked.  But many formulations in the following
are inelegant or redundant.  It needs cleanup. 
*)

(** Note:  In the paper, the notions of semi-proper and proper are 
meant to refer to unique occurrences of annotation commands but 
this is left informal.  In this file, the syntax includes numeric
tags and the definition of well_specified includes that tags are 
unique.  Which precisely captures the intent of the paper. *)


(* Intended convention: 'Fact' is used for uninteresting lemmas,
so Lemma indicates at least a modicum of interest. But Claude
used Lemma for everything and I haven't fixed all yet.  *)

Require Import Classical.
Require Import FunctionalExtensionality.
Require Import PropExtensionality.
Require Import Arith.
Require Import ZArith.
Require Import Lia.
Require Import Relations.
Require Import Relation_Operators.
Require Import Operators_Properties.
Require Import List. Import ListNotations.

(* ad hoc library, separate file to reduce token count for claude *) 
Require Import MyLibrary. 

Module Poset.
Parameter T : Type.
(* Note: for this development, T should not be instantiated 
   with an uncountable type.  That would be inconsistent with 
   the assumption prog_spec that the program is well_specified
   for reasons noted near that assumption.  (See lev_tag_inj.)
   Since there's a handler for every level, a practical 
   instantiation will have T finite. *)
Parameter lleq : T -> T -> Prop.
Parameter lleq_refl    : forall l, lleq l l.
Parameter lleq_trans   : forall a b c, lleq a b -> lleq b c -> lleq a c.
Parameter lleq_antisym : forall a b, lleq a b -> lleq b a -> a = b.
Parameter lleq_dec     : forall a b, {lleq a b} + {~ lleq a b}.
End Poset.

Definition Lev := Poset.T.
Definition lleq := Poset.lleq.
Definition lleq_dec := Poset.lleq_dec.

Section Entire_development_for_now.

(* -------------------------------------------------------- *)
(* events *)
(* -------------------------------------------------------- *)
(* Convention: an event sequence (list event) is written in temporal order,
   earliest first. So [ev1; ev2; ev3] means ev1 preceded ev2 preceded ev3. *) 

Inductive event : Type :=
| Ein   : Lev -> Z -> event
| Eout  : Lev -> Z -> event
| Etick : event.

(* Events visible to observers at level l or below *)

Definition VIn (l : Lev) (ev : event) : Prop :=
  exists l' n, ev = Ein l' n /\ lleq l' l.

Definition VOut (l : Lev) (ev : event) : Prop :=
  exists l' n, ev = Eout l' n /\ lleq l' l.

Definition Vev (l : Lev) (ev : event) : Prop := VIn l ev \/ VOut l ev.

Definition visible_atb (l : Lev) (ev : event) : bool :=
  match ev with
  | Ein  l' _ => if lleq_dec l' l then true else false
  | Eout l' _ => if lleq_dec l' l then true else false
  | Etick     => false
  end.

Definition vis (l : Lev) (evs : list event) : list event :=
  filter (visible_atb l) evs.

Fact visible_atb_spec : forall l ev, visible_atb l ev = true <-> Vev l ev.
Proof.
  intros l ev. destruct ev as [l' n | l' n | ]; simpl.
  - destruct (lleq_dec l' l) as [Hle | Hnle].
    + split.
      * intros _. left. exists l', n. split; [reflexivity | exact Hle].
      * intros _. reflexivity.
    + split.
      * discriminate.
      * intros [[l'' [n' [Heq Hle]]] | [l'' [n' [Heq _]]]]; inversion Heq; subst; contradiction.
  - destruct (lleq_dec l' l) as [Hle | Hnle].
    + split.
      * intros _. right. exists l', n. split; [reflexivity | exact Hle].
      * intros _. reflexivity.
    + split.
      * discriminate.
      * intros [[l'' [n' [Heq _]]] | [l'' [n' [Heq Hle]]]]; inversion Heq; subst; contradiction.
  - split.
    + discriminate.
    + intros [[l'' [n' [Heq _]]] | [l'' [n' [Heq _]]]]; discriminate.
Qed.

Fact vis_nil : forall l, vis l [] = [].
Proof. intros l. reflexivity. Qed.

Fact vis_app : forall l evs1 evs2, vis l (evs1 ++ evs2) = vis l evs1 ++ vis l evs2.
Proof. intros l evs1 evs2. unfold vis. apply filter_app. Qed.

Fact vis_cons_visible : forall l ev evs,
  Vev l ev -> vis l (ev :: evs) = ev :: vis l evs.
Proof.
  intros l ev evs H. unfold vis. simpl.
  destruct (visible_atb_spec l ev) as [_ Hbw].
  rewrite (Hbw H). reflexivity.
Qed.

Fact vis_cons_invisible : forall l ev evs,
  ~ Vev l ev -> vis l (ev :: evs) = vis l evs.
Proof.
  intros l ev evs H. unfold vis. simpl.
  destruct (visible_atb l ev) eqn:Hb.
  - exfalso. apply H. destruct (visible_atb_spec l ev) as [Hfw _]. apply Hfw. exact Hb.
  - reflexivity.
Qed.

Fact vis_tick : forall l evs, vis l (Etick :: evs) = vis l evs.
Proof. intros l evs. unfold vis. reflexivity. Qed.

(* -------------------------------------------------------- *)
(* Program syntax *) 
(* -------------------------------------------------------- *)

Definition Vars := nat.

(* A single binary operator: addition. *)
Inductive binop : Set := Badd.

Definition binop_denote (op : binop) : Z -> Z -> Z :=
  match op with Badd => Z.add end.

Inductive expr : Type :=
| EConst : Z -> expr
| EVar   : Vars -> expr
| EBinop : binop -> expr -> expr -> expr
| ENot   : expr -> expr.

Inductive state_pred : Type :=
| Pexpr   : expr -> state_pred
| Por     : state_pred -> state_pred -> state_pred
| Pnot    : state_pred -> state_pred
| Pforall : Vars -> state_pred -> state_pred.

Inductive rel_form : Type :=
| Ragr  : expr -> rel_form                    (* <e>  : agreement on e *)
| Rboth : state_pred -> rel_form              (* [phi] : both states satisfy phi *)
| Rimp  : state_pred -> expr -> rel_form      (* [phi] => <e> *)
| Rand  : rel_form -> rel_form -> rel_form.

Inductive cmd : Type :=
| Cskip   : cmd
| Cassign : Vars -> expr -> cmd
| Cout    : Lev -> expr -> cmd
| Cif     : expr -> cmd -> cmd -> cmd
| Cwhile  : expr -> cmd -> cmd
| Cseq    : cmd -> cmd -> cmd
| Cassert : Lev -> nat -> rel_form -> cmd    
| Cassume : Lev -> nat -> rel_form -> cmd.   
(* Different from the paper, Cassert and Cassume have a nat that serves
as a tag to uniquely designate the annotation.  See tags_unique. *)

Record handler : Type := Hinput {
  h_var  : Vars;
  h_body : cmd
}.

Definition program : Type := Lev -> handler.

(* An l-assumption is an assume whose annotation level is below l. *)
Definition is_l_assume (l : Lev) (c : cmd) : Prop :=
  match c with
  | Cassume l' _ _ => lleq l' l
  | _            => False
  end.

(* An l-assert is an assert whose annotation level is below l. *)
Definition is_l_assert (l : Lev) (c : cmd) : Prop :=
  match c with
  | Cassert l' _ _ => lleq l' l
  | _            => False
  end.

Definition is_l_annotation (l : Lev) (c : cmd) : Prop :=
  is_l_assume l c \/ is_l_assert l c.

(* -------------------------------------------------------- *)
(* Program semantics: fixed program, states, configurations, step relation *)
(* -------------------------------------------------------- *)

Variable prog : program.

Definition state : Type := Vars -> Z.

Definition initState : state := fun _ => 0%Z.

Definition update (s : state) (x : Vars) (n : Z) : state :=
  fun y => if Nat.eq_dec x y then n else s y.

Fact update_eq : forall s x n, update s x n x = n.
Proof.
  intros s x n. unfold update.
  destruct (Nat.eq_dec x x) as [_ | Hne]; [reflexivity | exfalso; apply Hne; reflexivity].
Qed.

Fact update_neq : forall s x y n, x <> y -> update s x n y = s y.
Proof.
  intros s x y n Hne. unfold update.
  destruct (Nat.eq_dec x y) as [Heq | _]; [contradiction | reflexivity].
Qed.

Fixpoint eval_expr (s : state) (e : expr) : Z :=
  match e with
  | EConst n      => n
  | EVar x        => s x
  | EBinop op a b => binop_denote op (eval_expr s a) (eval_expr s b)
  | ENot a        => if Z.eqb (eval_expr s a) 0 then 1%Z else 0%Z
  end.

Inductive config : Type :=
| Receptive : state -> config
| Active    : cmd -> state -> config.

Inductive step : config -> event -> config -> Prop :=
| Step_input : forall l n s,
    step (Receptive s) (Ein l n)
         (Active (h_body (prog l)) (update s (h_var (prog l)) n))
| Step_skip : forall s,
    step (Active Cskip s) Etick (Receptive s)
| Step_output : forall l e s,
    step (Active (Cout l e) s) (Eout l (eval_expr s e)) (Active Cskip s)
| Step_if_true : forall e c d s,
    eval_expr s e <> 0%Z ->
    step (Active (Cif e c d) s) Etick (Active c s)
| Step_if_false : forall e c d s,
    eval_expr s e = 0%Z ->
    step (Active (Cif e c d) s) Etick (Active d s)
| Step_while_true : forall e c s,
    eval_expr s e <> 0%Z ->
    step (Active (Cwhile e c) s) Etick (Active (Cseq c (Cwhile e c)) s)
| Step_while_false : forall e c s,
    eval_expr s e = 0%Z ->
    step (Active (Cwhile e c) s) Etick (Active Cskip s)
| Step_assign : forall x e s,
    step (Active (Cassign x e) s) Etick (Active Cskip (update s x (eval_expr s e)))
| Step_assume : forall l tk Phi s,
    step (Active (Cassume l tk Phi) s) Etick (Active Cskip s)
| Step_assert : forall l tk Phi s,
    step (Active (Cassert l tk Phi) s) Etick (Active Cskip s)
| Step_skip_seq : forall c s,
    step (Active (Cseq Cskip c) s) Etick (Active c s)
| Step_seq : forall c c' d s s' ev,
    step (Active c s) ev (Active c' s') ->
    step (Active (Cseq c d) s) ev (Active (Cseq c' d) s').

Definition is_receptive (g : config) : Prop := exists s, g = Receptive s.

Definition is_active (g : config) : Prop := exists c s, g = Active c s.

Definition cfg_cmd (g : config) : option cmd := (* The active command of a config, if any. *)
  match g with Active c _ => Some c | Receptive _ => None end.

Fact step_determ_recv : forall s ev h1 h2,
  step (Receptive s) ev h1 ->
  step (Receptive s) ev h2 ->
  h1 = h2.
Proof.
  intros s ev h1 h2 H1 H2.
  inversion H1; subst. inversion H2; subst. reflexivity.
Qed.

Fact step_determ_active : forall c s ev1 h1 ev2 h2,
  step (Active c s) ev1 h1 ->
  step (Active c s) ev2 h2 ->
  ev1 = ev2 /\ h1 = h2.
Proof.
  induction c; intros s ev1 h1 ev2 h2 H1 H2.
  - (* Cskip *)
    inversion H1; subst. inversion H2; subst. split; reflexivity.
  - (* Cassign *)
    inversion H1; subst. inversion H2; subst. split; reflexivity.
  - (* Cout *)
    inversion H1; subst. inversion H2; subst. split; reflexivity.
  - (* Cif *)
    inversion H1; subst; inversion H2; subst;
      try (split; reflexivity); try congruence.
  - (* Cwhile *)
    inversion H1; subst; inversion H2; subst;
      try (split; reflexivity); try congruence.
  - (* Cseq *)
    inversion H1; subst.
    + (* H1 by Step_skip_seq, so first child was Cskip *)
      inversion H2; subst.
      * split; reflexivity.
      * (* H2 by Step_seq; sub-step from Cskip cannot reach Active *)
        match goal with H : step (Active Cskip _) _ (Active _ _) |- _ => inversion H end.
    + (* H1 by Step_seq *)
      inversion H2; subst.
      * (* H2 by Step_skip_seq, but H1's sub-step is from Cskip to Active — impossible *)
        match goal with H : step (Active Cskip _) _ (Active _ _) |- _ => inversion H end.
      * (* both Step_seq: apply IHc1 to the two sub-steps *)
        match goal with
        | HA : step (Active c1 _) ev1 _,
          HB : step (Active c1 _) ev2 _ |- _ =>
            destruct (IHc1 _ _ _ _ _ HA HB) as [Hev Hac];
            subst; inversion Hac; subst; split; reflexivity
        end.
  - (* Cassert *)
    inversion H1; subst. inversion H2; subst. split; reflexivity.
  - (* Cassume *)
    inversion H1; subst. inversion H2; subst. split; reflexivity.
Qed.

(* -------------------------------------------------------- *)
(* Pre-runs and event traces *)
(* -------------------------------------------------------- *)

Definition last_cfg (gs : list config) : config := last gs (Receptive initState).

Definition is_input_b (ev : event) : bool :=
  match ev with
  | Ein _ _ => true
  | _       => false
  end.

Definition is_input (ev : event) : Prop := exists l n, ev = Ein l n.

Fact is_input_b_spec : forall ev, is_input_b ev = true <-> is_input ev.
Proof.
  intros ev. destruct ev as [l n | l n | ]; simpl.
  - split.
    + intros _. exists l, n. reflexivity.
    + intros _. reflexivity.
  - split; [discriminate | intros [l' [n' Heq]]; discriminate].
  - split; [discriminate | intros [l [n Heq]]; discriminate].
Qed.

Definition inputs (evs : list event) : list event := filter is_input_b evs.

Fact Forall_is_input_inputs : forall evs, Forall is_input (inputs evs).
Proof.
  intros evs. unfold inputs. induction evs as [|e es IH]; simpl.
  - constructor.
  - destruct (is_input_b e) eqn:Hb.
    + constructor; [apply is_input_b_spec; exact Hb | exact IH].
    + exact IH.
Qed.

(* gs admits trace evs *)
Inductive admits_trace : list config -> list event -> Prop :=
| AT_init : admits_trace [Receptive initState] []
| AT_step : forall gs evs ev g,
    admits_trace gs evs ->
    step (last_cfg gs) ev g ->
    admits_trace (gs ++ [g]) (evs ++ [ev]).

Lemma admits_trace_nonempty : forall gs evs,
  admits_trace gs evs -> gs <> [].
Proof.
  intros gs evs H. induction H.
  - discriminate.
  - intros Heq. destruct gs; simpl in Heq; discriminate.
Qed.

Fact admits_trace_length : forall gs evs,
  admits_trace gs evs -> length gs = S (length evs).
Proof.
  intros gs evs H. induction H.
  - reflexivity.
  - rewrite !length_app. simpl. lia.
Qed.

Definition pre_run (gs : list config) : Prop := exists evs, admits_trace gs evs.

Lemma pre_run_nonempty : forall gs, pre_run gs -> gs <> [].
Proof.
  intros gs [evs Hat]. exact (admits_trace_nonempty gs evs Hat).
Qed.

Fact pre_run_singleton_init : pre_run [Receptive initState].
Proof. exists []. apply AT_init. Qed.

(* pr_inputs hs ih : hs is a prerun that admits a trace with inputs ih *)
(* Under well-specification, the trace, hence ih, is unique (traceDetEv). *)
Definition pr_inputs (hs : list config) (ih : list event) : Prop :=
  exists th, admits_trace hs th /\ inputs th = ih.

(* -------------------------------------------------------- *)
(* The program is well specified *)
(* -------------------------------------------------------- *)

(* output commands are immediately preceded by corresponding assertions *)
Inductive outputs_asserted : cmd -> Prop :=
| OP_skip : outputs_asserted Cskip
| OP_assign : forall x e, outputs_asserted (Cassign x e)
| OP_if : forall e c1 c2,
    outputs_asserted c1 -> outputs_asserted c2 -> outputs_asserted (Cif e c1 c2)
| OP_while : forall e c,
    outputs_asserted c -> outputs_asserted (Cwhile e c)
| OP_assert : forall l tk rf, outputs_asserted (Cassert l tk rf)
| OP_assume : forall l tk rf, outputs_asserted (Cassume l tk rf)
| OP_seq_terminal : forall l tk e,
    outputs_asserted (Cseq (Cassert l tk (Ragr e)) (Cout l e))
| OP_seq_other : forall c1 c2,
    outputs_asserted c1 -> outputs_asserted c2 ->
    outputs_asserted (Cseq c1 c2).

(* The tags of the annotation occurrences of a command, in textual order. *)
Fixpoint annot_tags (c : cmd) : list nat :=
  match c with
  | Cskip         => []
  | Cassign _ _   => []
  | Cout _ _      => []
  | Cif _ c1 c2   => annot_tags c1 ++ annot_tags c2
  | Cwhile _ c1   => annot_tags c1
  | Cseq c1 c2    => annot_tags c1 ++ annot_tags c2
  | Cassert _ t _ => [t]
  | Cassume _ t _ => [t]
  end.

(* Global uniqueness of annotation tags: the tags of a handler are 
   unique and no two handlers have tags in common.  This loses no
   generality since any program can be given unique tags and tags
   have no influence on semantics.  The condition makes sense even     
   if there are countably many labels, but not more; see lev_tag_inj. *)
Definition tags_unique : Prop :=
  (forall l, NoDup (annot_tags (h_body (prog l)))) /\
  (forall l l' t,
     In t (annot_tags (h_body (prog l))) ->
     In t (annot_tags (h_body (prog l'))) -> l = l').

(* Every handler body starts with the boilerplate assume^l <x> for its level
   l and bound variable x.  And outputs are preceded by matching asserts. *)
Definition handlers_well_formed : Prop :=
  forall l, exists tk d,
    h_body (prog l) = Cseq (Cassume l tk (Ragr (EVar (h_var (prog l))))) d /\
    outputs_asserted d.

Definition well_specified : Prop := handlers_well_formed /\ tags_unique.

Hypothesis prog_spec : well_specified.

(* the two conjuncts, by name *)
Definition prog_well_specified : handlers_well_formed := proj1 prog_spec.
Definition prog_tags_unique : tags_unique := proj2 prog_spec.

(* CAUTION -- well_specified is INCONSISTENT when Lev is uncountable.  Every
   handler owns the tag of its entry assume, and tags_unique makes those 
   tags pairwise distinct, which entails an injection of Lev into nat
   (lev_tag_inj below).  Hence for uncountable Lev no program satisfies 
   the hypothesis prog_spec and the main theorems become vacuous. *)
Lemma lev_tag_inj : forall l l' tk tk' d d',
  h_body (prog l)  = Cseq (Cassume l  tk  (Ragr (EVar (h_var (prog l ))))) d  ->
  h_body (prog l') = Cseq (Cassume l' tk' (Ragr (EVar (h_var (prog l'))))) d' ->
  tk = tk' -> l = l'.
Proof.
  intros l l' tk tk' d d' Hb Hb' Heq. subst tk'.
  destruct prog_tags_unique as [_ Hcross].
  apply (Hcross l l' tk); [rewrite Hb | rewrite Hb']; simpl; left; reflexivity.
Qed.


(* -------------------------------------------------------- *)
(* Residuals: the commands a command can turn into          *)
(* -------------------------------------------------------- *)

(* [residual c c'] : some (possibly empty) run of active steps starting from
   [c] leaves [c'] still to be executed.  The state is quantified away -- it
   influences only WHICH residual is chosen (at Cif/Cwhile), never the shape of
   the residuals available -- so residual-hood is a purely syntactic relation on
   commands, and by construction it is closed under stepping.  It is the notion
   in which the run invariant below is stated: the active command of a reachable
   config is a residual of the body of the handler that is running. *)
Inductive residual : cmd -> cmd -> Prop :=
| Resid_refl : forall c, residual c c
| Resid_step : forall c c' c'' s s' ev,
    residual c c' -> step (Active c' s) ev (Active c'' s') -> residual c c''.

Lemma residual_trans : forall c c' c'',
  residual c c' -> residual c' c'' -> residual c c''.
Proof.
  intros c c' c'' H1 H2. induction H2 as [| a b d s s' ev Hres IH Hstep].
  - exact H1.
  - exact (Resid_step c b d s s' ev (IH H1) Hstep).
Qed.

Lemma residual_one : forall c c' s s' ev,
  step (Active c s) ev (Active c' s') -> residual c c'.
Proof.
  intros c c' s s' ev Hstep.
  exact (Resid_step c c c' s s' ev (Resid_refl c) Hstep).
Qed.

(* A step never invents an annotation: the tags of the residual were already
   among the tags of the command it came from.  (Cwhile duplicates the loop
   body's tags, which is why this is stated as [incl] on the tag LISTS and not
   as a sublist or a length inequality.) *)
Lemma step_annot_tags : forall c s ev c' s',
  step (Active c s) ev (Active c' s') -> incl (annot_tags c') (annot_tags c).
Proof.
  intros c. induction c; intros s ev c' s' Hstep;
    inversion Hstep; subst; simpl;
    try (intros t Ht; exact Ht);
    try (intros t Ht; simpl in Ht; contradiction).
  - (* Cif, true branch *) intros t Ht. apply in_or_app. left. exact Ht.
  - (* Cif, false branch *) intros t Ht. apply in_or_app. right. exact Ht.
  - (* Cwhile, unrolled: the body's tags occur twice, but as a SET they are the
       body's tags *)
    intros t Ht. apply in_app_or in Ht. destruct Ht as [Ht | Ht]; exact Ht.
  - (* Cseq, congruence in the left component *)
    intros t Ht.
    match goal with
    | H : step (Active c1 _) _ (Active _ _) |- _ =>
        pose proof (IHc1 _ _ _ _ H) as Hincl
    end.
    apply in_app_or in Ht. apply in_or_app.
    destruct Ht as [Ht | Ht]; [left; apply Hincl; exact Ht | right; exact Ht].
Qed.

Lemma residual_annot_tags : forall c c',
  residual c c' -> incl (annot_tags c') (annot_tags c).
Proof.
  intros c c' H. induction H as [| a b d s s' ev Hres IH Hstep].
  - apply incl_refl.
  - intros t Ht. apply IH. exact (step_annot_tags b s ev d s' Hstep t Ht).
Qed.

(* The tag of an annotation command. *)
Definition annot_tag_of (c : cmd) : option nat :=
  match c with
  | Cassert _ t _ => Some t
  | Cassume _ t _ => Some t
  | _             => None
  end.

Lemma is_l_annotation_tag : forall l c,
  is_l_annotation l c -> exists t, annot_tag_of c = Some t.
Proof.
  intros l c H.
  destruct c as [ | x e | lo e | e c1 c2 | e c1 | c1 c2 | la ta Pa | la ta Pa ];
    simpl in H; try (destruct H as [H | H]; contradiction).
  - exists ta. reflexivity.
  - exists ta. reflexivity.
Qed.

(* [redex_annot_tag_in], which locates an annotation redex among a command's
   annotation occurrences, needs [redex_cmd] and so appears with it below. *)


(* ---- A structural presentation of residual-hood ----

   [residual] is defined by the steps that produce it, which is what makes it
   trivially step-closed but useless for induction on the COMMAND.  The
   following inductive says the same thing by cases on the shape of the command
   being run; every residual satisfies it (residual_resid_struct).  Only that
   direction is needed, so nothing here has to be exact: [resid_struct] may in
   principle relate more pairs than [residual] does, and the determinacy result
   proved from it is correspondingly stronger.

   The clause to look at is RS_while: unrolling a loop leaves the loop itself
   appended after the body's residual, so the continuation of a residual inside
   a loop still records where the loop is -- which is why an annotation inside a
   loop body determines a unique residual, once per iteration though it runs. *)
Inductive resid_struct : cmd -> cmd -> Prop :=
| RS_refl  : forall c, resid_struct c c
| RS_skip  : forall c, resid_struct c Cskip
| RS_if1   : forall e c1 c2 c', resid_struct c1 c' -> resid_struct (Cif e c1 c2) c'
| RS_if2   : forall e c1 c2 c', resid_struct c2 c' -> resid_struct (Cif e c1 c2) c'
| RS_while : forall e c c',
    resid_struct c c' -> resid_struct (Cwhile e c) (Cseq c' (Cwhile e c))
| RS_seq1  : forall c d c', resid_struct c c' -> resid_struct (Cseq c d) (Cseq c' d)
| RS_seq2  : forall c d d', resid_struct d d' -> resid_struct (Cseq c d) d'.

(* Case analysis on a residual of a compound command. *)
Lemma resid_struct_if_inv : forall e a b z,
  resid_struct (Cif e a b) z ->
  z = Cif e a b \/ z = Cskip \/ resid_struct a z \/ resid_struct b z.
Proof.
  intros e a b z H. inversion H; subst.
  - left. reflexivity.
  - right; left. reflexivity.
  - right; right; left. assumption.
  - right; right; right. assumption.
Qed.

Lemma resid_struct_while_inv : forall e a z,
  resid_struct (Cwhile e a) z ->
  z = Cwhile e a \/ z = Cskip \/
  (exists a', resid_struct a a' /\ z = Cseq a' (Cwhile e a)).
Proof.
  intros e a z H. inversion H; subst.
  - left. reflexivity.
  - right; left. reflexivity.
  - right; right. eexists. split; [eassumption | reflexivity].
Qed.

Lemma resid_struct_seq_inv : forall a b z,
  resid_struct (Cseq a b) z ->
  z = Cskip \/ (exists a', resid_struct a a' /\ z = Cseq a' b) \/ resid_struct b z.
Proof.
  intros a b z H. inversion H; subst.
  - right; left. exists a. split; [apply RS_refl | reflexivity].
  - left. reflexivity.
  - right; left. eexists. split; [eassumption | reflexivity].
  - right; right. assumption.
Qed.

Lemma resid_struct_trans : forall a b,
  resid_struct a b -> forall z, resid_struct b z -> resid_struct a z.
Proof.
  intros a b H.
  induction H as [ a | a | e a1 a2 b Hb IH | e a1 a2 b Hb IH
                 | e a b Hb IH | a d b Hb IH | a d b Hb IH ];
    intros z Hz.
  - exact Hz.
  - inversion Hz; subst; apply RS_skip.
  - apply RS_if1. apply IH. exact Hz.
  - apply RS_if2. apply IH. exact Hz.
  - (* the loop was unrolled; a further residual either stays inside the
       unrolled body or has come back out to the loop *)
    inversion Hz; subst.
    + apply RS_while. exact Hb.
    + apply RS_skip.
    + apply RS_while. apply IH. assumption.
    + assumption.
  - inversion Hz; subst.
    + apply RS_seq1. exact Hb.
    + apply RS_skip.
    + apply RS_seq1. apply IH. assumption.
    + apply RS_seq2. assumption.
  - apply RS_seq2. apply IH. exact Hz.
Qed.

Lemma step_resid_struct : forall c s ev c' s',
  step (Active c s) ev (Active c' s') -> resid_struct c c'.
Proof.
  intros c. induction c; intros s ev c' s' Hstep; inversion Hstep; subst;
    try (apply RS_skip).
  - apply RS_if1. apply RS_refl.
  - apply RS_if2. apply RS_refl.
  - apply RS_while. apply RS_refl.
  - apply RS_seq2. apply RS_refl.
  - apply RS_seq1.
    match goal with
    | H : step (Active c1 _) _ (Active _ _) |- _ => exact (IHc1 _ _ _ _ H)
    end.
Qed.

Lemma residual_resid_struct : forall c c', residual c c' -> resid_struct c c'.
Proof.
  intros c c' H. induction H as [| a b d s s' ev Hres IH Hstep].
  - apply RS_refl.
  - exact (resid_struct_trans a b IH d (step_resid_struct b s ev d s' Hstep)).
Qed.

Lemma resid_struct_annot_tags : forall c c',
  resid_struct c c' -> incl (annot_tags c') (annot_tags c).
Proof.
  intros c c' H.
  induction H as [ a | a | e a1 a2 b Hb IH | e a1 a2 b Hb IH
                 | e a b Hb IH | a d b Hb IH | a d b Hb IH ];
    intros t Ht; simpl in *.
  - exact Ht.
  - contradiction.
  - apply in_or_app. left. apply IH. exact Ht.
  - apply in_or_app. right. apply IH. exact Ht.
  - apply in_app_or in Ht. destruct Ht as [Ht | Ht]; [apply IH; exact Ht | exact Ht].
  - apply in_app_or in Ht. apply in_or_app.
    destruct Ht as [Ht | Ht]; [left; apply IH; exact Ht | right; exact Ht].
  - apply in_or_app. right. apply IH. exact Ht.
Qed.

(* Three facts about NoDup and append, used to keep tag occurrences in different
   subcommands apart. *)
Lemma NoDup_app_l : forall (l1 l2 : list nat), NoDup (l1 ++ l2) -> NoDup l1.
Proof.
  induction l1 as [| a l1 IH]; intros l2 H; simpl in H.
  - apply NoDup_nil.
  - rewrite NoDup_cons_iff in H. destruct H as [Hni Hnd].
    apply NoDup_cons.
    + intros Hin. apply Hni. apply in_or_app. left. exact Hin.
    + exact (IH l2 Hnd).
Qed.

Lemma NoDup_app_r : forall (l1 l2 : list nat), NoDup (l1 ++ l2) -> NoDup l2.
Proof.
  induction l1 as [| a l1 IH]; intros l2 H; simpl in H.
  - exact H.
  - rewrite NoDup_cons_iff in H. destruct H as [_ Hnd]. exact (IH l2 Hnd).
Qed.

Lemma NoDup_app_disj : forall (l1 l2 : list nat) t,
  NoDup (l1 ++ l2) -> In t l1 -> In t l2 -> False.
Proof.
  induction l1 as [| a l1 IH]; intros l2 t H H1 H2; simpl in *.
  - exact H1.
  - rewrite NoDup_cons_iff in H. destruct H as [Hni Hnd].
    destruct H1 as [Heq | H1].
    + subst a. apply Hni. apply in_or_app. right. exact H2.
    + exact (IH l2 t Hnd H1 H2).
Qed.


(* -------------------------------------------------------- *)
(* Knowledge *)
(* -------------------------------------------------------- *)

(* know l evs ins: the input sequence ins is consistent with the l-observation
   evs -- some admitted trace us has inputs ins and an l-visible projection that
   EXTENDS vis l evs. Using list_prefix (not equality) makes knowledge monotone
   under appending l-visible events, so knowlSame_b holds. *)
Definition know (l : Lev) (evs : list event) (ins : list event) : Prop :=
  exists gs us, admits_trace gs us /\ list_prefix (vis l evs) (vis l us) /\ ins = inputs us.

Lemma knowlSame_a : forall l evs ev,
  ~ Vev l ev ->
  forall ins, know l (evs ++ [ev]) ins <-> know l evs ins.
Proof.
  intros l evs ev Hinvis ins.
  assert (Hvis : vis l (evs ++ [ev]) = vis l evs).
  { rewrite vis_app.
    rewrite vis_cons_invisible by exact Hinvis.
    rewrite vis_nil. apply app_nil_r. }
  unfold know. rewrite Hvis. reflexivity.
Qed.

(* Appending an l-visible event only extends the visible projection, so the same
   witness (gs, us) still works -- the prefix obligation merely weakens. *)
Lemma knowlSame_b : forall l evs ev,
  Vev l ev ->
  forall ins, know l (evs ++ [ev]) ins -> know l evs ins.
Proof.
  intros l evs ev Hout ins H.
  destruct H as [gs [us [Hat [Hpre Hins]]]].
  exists gs, us. split; [exact Hat | split; [| exact Hins]].
  apply (list_prefix_trans _ (vis l evs) (vis l (evs ++ [ev])) (vis l us)).
  - exists (vis l [ev]). apply vis_app.
  - exact Hpre.
Qed.


Fact admits_trace_snoc_inv : forall hs us ev,
  admits_trace hs (us ++ [ev]) ->
  exists hs_pre g, hs = hs_pre ++ [g] /\ admits_trace hs_pre us.
Proof.
  intros hs us ev H. inversion H; subst.
  - (* AT_init: trace is [] but should be us ++ [ev] *)
    destruct us; discriminate.
  - (* AT_step: peel off the last step *)
    match goal with
    | Heq : _ ++ [_] = _ ++ [_] |- _ =>
      apply app_inj_tail in Heq; destruct Heq; subst
    end.
    eexists. eexists. split; [reflexivity | eassumption].
Qed.

(* pknow l evs ins: progress knowledge -- some admitted trace reaches an
   l-visible event [ev] (whose preceding l-visible events extend vis l evs) and
   then CONTINUES with a suffix [vs]; ins are the inputs of the WHOLE trace
   [inputs (us ++ [ev] ++ vs)]. *) 
Definition pknow (l : Lev) (evs : list event) (ins : list event) : Prop :=
  exists hs us ev vs,
    Vev l ev /\
    admits_trace hs (us ++ [ev] ++ vs) /\
    list_prefix (vis l evs) (vis l us) /\
    ins = inputs (us ++ [ev] ++ vs).

(* Progress knowledge entails knowledge: the FULL witness trace
   [us ++ [ev] ++ vs] is itself a know witness *)
Lemma knowPknow_a : forall l evs ins,
  pknow l evs ins -> know l evs ins.
Proof.
  intros l evs ins Hpknow.
  destruct Hpknow as [hs [us [ev [vs [Hv [Hat [Hpre Hins]]]]]]].
  exists hs, (us ++ [ev] ++ vs).
  split; [exact Hat | split; [| exact Hins]].
  apply (list_prefix_trans _ (vis l evs) (vis l us) (vis l (us ++ [ev] ++ vs))).
  - exact Hpre.
  - exists (vis l ([ev] ++ vs)). apply vis_app.
Qed.

(* Knowledge just after an l-visible output yields progress knowledge before
   it: locate the visible event matching [ev] inside the know witness trace
   (filter_split_at) and split there -- the part before is [us] (its visible
   projection is exactly vis l evs), [ev] is the predicted event, and the rest is
   the suffix [vs] carrying any trailing inputs; whole-trace inputs are
   unchanged, so they still equal [ins]. *)
Lemma knowPknow_b : forall l evs ev,
  Vev l ev ->
  forall ins, know l (evs ++ [ev]) ins -> pknow l evs ins.
Proof.
  intros l evs ev0 Hvev ins H.
  destruct H as [gs [us0 [Hat [Hpre Hins]]]].
  assert (Hve0 : vis l (evs ++ [ev0]) = vis l evs ++ [ev0]).
  { rewrite vis_app. rewrite (vis_cons_visible l ev0 [] Hvev). rewrite vis_nil. reflexivity. }
  rewrite Hve0 in Hpre.
  destruct Hpre as [zs Hzs].
  rewrite <- app_assoc in Hzs. cbn [app] in Hzs.
  unfold vis in Hzs.
  apply filter_split_at in Hzs.
  destruct Hzs as [a [b [Hus0 [Hfa _]]]].
  exists gs, a, ev0, b.
  split; [exact Hvev | split; [| split]].
  - rewrite Hus0 in Hat. exact Hat.
  - unfold vis. rewrite Hfa. apply list_prefix_refl.
  - rewrite Hins, Hus0. reflexivity.
Qed.



(* -------------------------------------------------------- *)
(* determinacy *)
(* -------------------------------------------------------- *)

(* A step out of a Receptive config is an input step; its event and target are
   the handler dispatch for some level l and value n. *)
Lemma step_receptive_inv : forall s ev g,
  step (Receptive s) ev g ->
  exists l n, ev = Ein l n /\ g = Active (h_body (prog l)) (update s (h_var (prog l)) n).
Proof. intros s ev g H. inversion H; subst. exists l, n. split; reflexivity. Qed.

Lemma step_event_determ : forall g ev1 ev2 h,
  step g ev1 h -> step g ev2 h -> ev1 = ev2.
Proof.
  intros g ev1 ev2  h H1 H2.
  destruct g as [s | cc s].
  - apply step_receptive_inv in H1. apply step_receptive_inv in H2.
    destruct H1 as [l1 [n1 [Hev1 Hg1]]]. destruct H2 as [l2 [n2 [Hev2 Hg2]]].
    subst ev1 ev2. rewrite Hg1 in Hg2. injection Hg2 as Hbody Hstate.
    destruct (prog_well_specified l1) as [wtag [d1 [Hb1 _]]].
    destruct (prog_well_specified l2) as [wtag2 [d2 [Hb2 _]]].
    assert (Hl : l1 = l2).
    { apply (f_equal (fun c => match c with Cseq (Cassume lv _ _) _ => Some lv | _ => None end)) in Hbody.
      rewrite Hb1, Hb2 in Hbody. simpl in Hbody. injection Hbody as Hl. exact Hl. }
    subst l2.
    assert (Hn : n1 = n2).
    { apply (f_equal (fun f => f (h_var (prog l1)))) in Hstate.
      rewrite !update_eq in Hstate. exact Hstate. }
    subst n2. reflexivity.
  - destruct (step_determ_active cc s ev1 h ev2 h H1 H2) as [Hev _]. exact Hev.
Qed.

(* lem:traceDetEv in the paper: the configuration list determines the trace. *)
Lemma traceDetEv : forall gs ts ts',
  admits_trace gs ts -> admits_trace gs ts' -> ts = ts'.
Proof.
  intros gs ts ts' H. revert ts'.
  induction H as [| gs0 evs ev g Hat IH Hstep]; intros ts' H'.
  - inversion H' as [| gs2 evs2 ev2 g2 Hat2 Hstep2 Hgeq Hteq]; subst.
    + reflexivity.
    + exfalso. symmetry in Hgeq. destruct gs2 as [|y ys].
      * apply admits_trace_nonempty in Hat2. apply Hat2. reflexivity.
      * simpl in Hgeq. injection Hgeq as _ Htl. destruct ys; discriminate.
  - inversion H' as [Hgeq0 Hteq0 | gs2 evs2 ev2 g2 Hat2 Hstep2 Hgeq Hteq]; subst.
    + exfalso. symmetry in Hgeq0. destruct gs0 as [|y ys].
      * apply admits_trace_nonempty in Hat. apply Hat. reflexivity.
      * simpl in Hgeq0. injection Hgeq0 as _ Htl. destruct ys; discriminate.
    + apply app_inj_tail in Hgeq. destruct Hgeq as [Hgs Hg2]. subst.
      assert (Hev : ev = ev2) by
        (apply (step_event_determ (last_cfg gs0) ev ev2 g Hstep Hstep2)).
      subst. f_equal. apply IH. exact Hat2.
Qed.


(* -------------------------------------------------------- *)
(* Semantics of relational formulas (sigma | sigma' |= Phi). *) 
(* -------------------------------------------------------- *)

Fixpoint sat_pred (s : state) (phi : state_pred) : Prop :=
  match phi with
  | Pexpr e      => eval_expr s e <> 0%Z
  | Por p1 p2    => sat_pred s p1 \/ sat_pred s p2
  | Pnot p       => ~ sat_pred s p
  | Pforall x p  => forall n, sat_pred (update s x n) p
  end.

(* The relational judgment over two states. Rimp phi e is the paper's
   [phi] ==> <e>: both states satisfy phi implies they agree on e. *)
Fixpoint models (s s' : state) (Phi : rel_form) : Prop :=
  match Phi with
  | Ragr e     => eval_expr s e = eval_expr s' e
  | Rboth phi  => sat_pred s phi /\ sat_pred s' phi
  | Rimp phi e => (sat_pred s phi /\ sat_pred s' phi) -> eval_expr s e = eval_expr s' e
  | Rand P0 P1 => models s s' P0 /\ models s s' P1
  end.

Definition cfg_state (g : config) : state :=
  match g with
  | Receptive s => s
  | Active _ s  => s
  end.

(* Abbreviation gs | hs |= Phi : compares the states of the last configs. *)
Definition models_prerun (gs hs : list config) (Phi : rel_form) : Prop :=
  models (cfg_state (last_cfg gs)) (cfg_state (last_cfg hs)) Phi.

(* -------------------------------------------------------- *)
(* Assumption with the effect that annotations commands are 
   uniquely determined by their formula.  This avoids the need 
   to label control points.  *)
(* -------------------------------------------------------- *)

(* The redex of an active configuration: the leftmost command, digging through
   left-nested sequencing (Cseq recurses left in the step relation). *)
Fixpoint redex_cmd (c : cmd) : cmd :=
  match c with
  | Cseq c1 _ => redex_cmd c1
  | _         => c
  end.

Definition redex_of (g : config) : option cmd :=
  match g with
  | Active c _  => Some (redex_cmd c)
  | Receptive _ => None
  end.

(* redex is assume visible at level l *)
Definition redex_is_l_assume (l : Lev) (g : config) : Prop :=
  match redex_of g with
  | Some c => is_l_assume l c
  | None   => False
  end.

(* redex is assert visible at level l *)
Definition redex_is_l_assert (l : Lev) (g : config) : Prop :=
  match redex_of g with
  | Some c => is_l_assert l c
  | None   => False
  end.

(* redex is annotation visible at level l *)
Definition redex_is_l_annotation (l : Lev) (g : config) : Prop :=
  match redex_of g with
  | Some c => is_l_annotation l c
  | None   => False
  end.

(* redex is an output command visible at level l (its step emits an l-output). *)
Definition redex_is_l_output (l : Lev) (g : config) : Prop :=
  match redex_of g with
  | Some (Cout l' _) => lleq l' l
  | _                => False
  end.

(* An annotation redex is one of the command's annotation occurrences. *)
Lemma redex_annot_tag_in : forall c t,
  annot_tag_of (redex_cmd c) = Some t -> In t (annot_tags c).
Proof.
  induction c; simpl; intros t Ht; try discriminate.
  - (* Cseq *) apply in_or_app. left. apply IHc1. exact Ht.
  - (* Cassert *) injection Ht as Ht. subst. left. reflexivity.
  - (* Cassume *) injection Ht as Ht. subst. left. reflexivity.
Qed.

(* THE SYNTACTIC COMPANION OF THE RUN INVARIANT.  If a command's annotation tags
   are distinct, then an annotation redex pins down the residual it is the redex
   of: there is only one way for a run of [c] to be sitting at the annotation
   labelled [t].  Note this is a statement about the whole residual, not just
   about the redex -- the continuation is determined too, which is what makes
   two runs stopped at the same annotation be at the same control point.  The
   loop case is the interesting one: unrolling re-appends the loop, so the
   residual still records that it is inside it. *)
Lemma resid_struct_redex_det : forall c z1 z2 t,
  NoDup (annot_tags c) ->
  resid_struct c z1 -> resid_struct c z2 ->
  annot_tag_of (redex_cmd z1) = Some t ->
  annot_tag_of (redex_cmd z2) = Some t ->
  z1 = z2.
Proof.
  intros c.
  induction c as [ | x e | lo e | e ca IHa cb IHb | e ca IHa | ca IHa cb IHb
                 | la ta Pa | la ta Pa ];
    intros z1 z2 t Hnd H1 H2 Ht1 Ht2.
  - (* Cskip: no annotation redex *)
    inversion H1; subst; simpl in Ht1; discriminate.
  - (* Cassign *) inversion H1; subst; simpl in Ht1; discriminate.
  - (* Cout *) inversion H1; subst; simpl in Ht1; discriminate.
  - (* Cif: both residuals come from the same branch, else the tag would occur
       in both branches *)
    simpl in Hnd.
    destruct (resid_struct_if_inv e ca cb z1 H1) as [Hz1 | [Hz1 | [Hz1 | Hz1]]];
      try (subst z1; simpl in Ht1; discriminate);
    destruct (resid_struct_if_inv e ca cb z2 H2) as [Hz2 | [Hz2 | [Hz2 | Hz2]]];
      try (subst z2; simpl in Ht2; discriminate).
    + exact (IHa z1 z2 t (NoDup_app_l _ _ Hnd) Hz1 Hz2 Ht1 Ht2).
    + exfalso. apply (NoDup_app_disj (annot_tags ca) (annot_tags cb) t Hnd).
      * apply (resid_struct_annot_tags ca z1 Hz1). apply redex_annot_tag_in. exact Ht1.
      * apply (resid_struct_annot_tags cb z2 Hz2). apply redex_annot_tag_in. exact Ht2.
    + exfalso. apply (NoDup_app_disj (annot_tags ca) (annot_tags cb) t Hnd).
      * apply (resid_struct_annot_tags ca z2 Hz2). apply redex_annot_tag_in. exact Ht2.
      * apply (resid_struct_annot_tags cb z1 Hz1). apply redex_annot_tag_in. exact Ht1.
    + exact (IHb z1 z2 t (NoDup_app_r _ _ Hnd) Hz1 Hz2 Ht1 Ht2).
  - (* Cwhile: both residuals are inside the unrolled body, with the same loop
       re-appended, so the body's residuals determine them *)
    simpl in Hnd.
    destruct (resid_struct_while_inv e ca z1 H1) as [Hz1 | [Hz1 | [a1 [Ha1 Hz1]]]];
      try (subst z1; simpl in Ht1; discriminate).
    destruct (resid_struct_while_inv e ca z2 H2) as [Hz2 | [Hz2 | [a2 [Ha2 Hz2]]]];
      try (subst z2; simpl in Ht2; discriminate).
    subst z1 z2. simpl in Ht1, Ht2. f_equal.
    exact (IHa a1 a2 t Hnd Ha1 Ha2 Ht1 Ht2).
  - (* Cseq: either both residuals are still in the first component (with the
       same continuation) or both are past it *)
    simpl in Hnd.
    assert (Hsplit : forall z, resid_struct (Cseq ca cb) z ->
              annot_tag_of (redex_cmd z) = Some t ->
              (exists a', resid_struct ca a' /\ z = Cseq a' cb /\
                          annot_tag_of (redex_cmd a') = Some t)
              \/ resid_struct cb z).
    { intros z Hz Htz.
      destruct (resid_struct_seq_inv ca cb z Hz) as [Hzc | [[a' [Ha' Hzc]] | Hzc]].
      - subst z. simpl in Htz. discriminate.
      - left. exists a'. subst z. simpl in Htz.
        split; [exact Ha' | split; [reflexivity | exact Htz]].
      - right. exact Hzc. }
    destruct (Hsplit z1 H1 Ht1) as [[a1 [Ha1 [Hz1 Ht1']]] | Hz1];
    destruct (Hsplit z2 H2 Ht2) as [[a2 [Ha2 [Hz2 Ht2']]] | Hz2].
    + subst z1 z2. f_equal.
      exact (IHa a1 a2 t (NoDup_app_l _ _ Hnd) Ha1 Ha2 Ht1' Ht2').
    + exfalso. apply (NoDup_app_disj (annot_tags ca) (annot_tags cb) t Hnd).
      * apply (resid_struct_annot_tags ca a1 Ha1). apply redex_annot_tag_in. exact Ht1'.
      * apply (resid_struct_annot_tags cb z2 Hz2). apply redex_annot_tag_in. exact Ht2.
    + exfalso. apply (NoDup_app_disj (annot_tags ca) (annot_tags cb) t Hnd).
      * apply (resid_struct_annot_tags ca a2 Ha2). apply redex_annot_tag_in. exact Ht2'.
      * apply (resid_struct_annot_tags cb z1 Hz1). apply redex_annot_tag_in. exact Ht1.
    + exact (IHb z1 z2 t (NoDup_app_r _ _ Hnd) Hz1 Hz2 Ht1 Ht2).
  - (* Cassert: the only residual with an annotation redex is the assert itself *)
    inversion H1; subst; simpl in Ht1; try discriminate;
      inversion H2; subst; simpl in Ht2; try discriminate; reflexivity.
  - (* Cassume *)
    inversion H1; subst; simpl in Ht1; try discriminate;
      inversion H2; subst; simpl in Ht2; try discriminate; reflexivity.
Qed.

Definition cfg_at (gs : list config) (i : nat) : config :=
  nth i gs (Receptive initState).

Fact cfg_at_firstn : forall n l m,
  m < n -> cfg_at (firstn n l) m = cfg_at l m.
Proof. intros n l m Hm. unfold cfg_at. apply nth_firstn. exact Hm. Qed.

Fact cfg_at_prefix : forall hs rest j,
  j < length hs -> cfg_at (hs ++ rest) j = cfg_at hs j.
Proof. intros hs rest j Hj. unfold cfg_at. apply app_nth1. exact Hj. Qed.



(* -------------------------------------------------------- *)
(* semantic definitions and results, especially to extend a pre_run to reach the next annotation (grow_to_annotation) *) 
(* -------------------------------------------------------- *)

(* Generalize admits_trace to a segment starting from an arbitrary  configuration. *) 

Inductive seg : config -> list config -> list event -> Prop :=
| Seg_init : forall g, seg g [g] []
| Seg_step : forall g0 gs evs ev g',
    seg g0 gs evs ->
    step (last_cfg gs) ev g' ->
    seg g0 (gs ++ [g']) (evs ++ [ev]).

Lemma seg_nonempty : forall g0 gs evs, seg g0 gs evs -> gs <> [].
Proof.
  intros g0 gs evs H. induction H as [g | g1 gs1 evs1 ev g' Hseg IH Hstep].
  - discriminate.
  - intros Heq. destruct gs1; simpl in Heq; discriminate.
Qed.

Lemma seg_head : forall g0 gs evs, seg g0 gs evs -> exists rest, gs = g0 :: rest.
Proof.
  intros g0 gs evs H. induction H as [g | g1 gs1 evs1 ev g' Hseg IH Hstep].
  - exists []. reflexivity.
  - destruct IH as [rest Hr]. exists (rest ++ [g']). rewrite Hr. reflexivity.
Qed.

(* admits_trace is exactly the segment rooted at the initial configuration. *)
Lemma seg_root_admits : forall g0 gs evs,
  seg g0 gs evs -> g0 = Receptive initState -> admits_trace gs evs.
Proof.
  intros g0 gs evs H. induction H as [g | g1 gs1 evs1 ev g' Hseg IH Hstep]; intros Hg0.
  - subst g. apply AT_init.
  - apply AT_step; [ apply IH; exact Hg0 | exact Hstep ].
Qed.

Lemma admits_trace_seg : forall gs evs,
  admits_trace gs evs <-> seg (Receptive initState) gs evs.
Proof.
  intros gs evs. split.
  - intros H. induction H as [ | gs0 evs0 ev g Hat IH Hstep].
    + apply Seg_init.
    + apply Seg_step; [ exact IH | exact Hstep ].
  - intros H. exact (seg_root_admits (Receptive initState) gs evs H eq_refl).
Qed.


Lemma last_cfg_glue : forall hs g0 rest,
  last_cfg hs = g0 -> last_cfg (hs ++ rest) = last_cfg (g0 :: rest).
Proof.
  intros hs g0 rest Hlast. unfold last_cfg in *. destruct rest as [|r rs].
  - rewrite app_nil_r. exact Hlast.
  - rewrite (last_app_nonempty config hs (r :: rs) (Receptive initState)) by discriminate.
    reflexivity.
Qed.

(* Glue a forward segment from last(hs) onto the pre-run hs: the shared boundary
   config (= last_cfg hs = g0, the head of ks) is dropped from ks via tl. *)
Lemma seg_glue : forall g0 ks evs2, seg g0 ks evs2 ->
  forall hs eh, admits_trace hs eh -> last_cfg hs = g0 ->
  admits_trace (hs ++ tl ks) (eh ++ evs2).
Proof.
  intros g0 ks evs2 H.
  induction H as [g | g1 ks0 evs0 ev g' Hseg IH Hstep]; intros hs eh Hat Hlast.
  - simpl. rewrite !app_nil_r. exact Hat.
  - destruct (seg_head g1 ks0 evs0 Hseg) as [rest0 Hrest0].
    assert (Htl : tl (ks0 ++ [g']) = tl ks0 ++ [g']).
    { rewrite Hrest0. reflexivity. }
    rewrite Htl.
    rewrite (app_assoc hs (tl ks0) [g']).
    rewrite (app_assoc eh evs0 [ev]).
    apply AT_step.
    + apply IH; [exact Hat | exact Hlast].
    + assert (Hlk : last_cfg (hs ++ tl ks0) = last_cfg ks0).
      { rewrite Hrest0. replace (tl (g1 :: rest0)) with rest0 by reflexivity.
        apply last_cfg_glue. exact Hlast. }
      rewrite Hlk. exact Hstep.
Qed.

(* Progress for active configs: a non-skip active config steps to another active
   config (only Cskip steps to a Receptive config). *)
Fact step_nonskip_active : forall c s ev g,
  c <> Cskip -> step (Active c s) ev g -> is_active g.
Proof.
  intros c s ev g Hne Hstep.
  inversion Hstep; subst; try (eexists; eexists; reflexivity); congruence.
Qed.

(* Every active config can take a step (totality of the active semantics). *)
Lemma active_can_step : forall c s, exists ev g, step (Active c s) ev g.
Proof.
  induction c; intros s.
  - exists Etick, (Receptive s). apply Step_skip.
  - exists Etick, (Active Cskip (update s v (eval_expr s e))). apply Step_assign.
  - exists (Eout l (eval_expr s e)), (Active Cskip s). apply Step_output.
  - destruct (Z.eq_dec (eval_expr s e) 0%Z) as [Hz | Hnz].
    + exists Etick, (Active c2 s). apply Step_if_false. exact Hz.
    + exists Etick, (Active c1 s). apply Step_if_true. exact Hnz.
  - destruct (Z.eq_dec (eval_expr s e) 0%Z) as [Hz | Hnz].
    + exists Etick, (Active Cskip s). apply Step_while_false. exact Hz.
    + exists Etick, (Active (Cseq c (Cwhile e c)) s). apply Step_while_true. exact Hnz.
  - destruct c1;
    first [ (exists Etick, (Active c2 s); apply Step_skip_seq)
          | (destruct (IHc1 s) as [ev1 [g1 Hs1]];
             assert (Hact : is_active g1) by
               (refine (step_nonskip_active _ s ev1 g1 _ Hs1); discriminate);
             destruct Hact as [c1' [s1 Hg1]]; subst g1;
             exists ev1, (Active (Cseq c1' c2) s1); apply Step_seq; exact Hs1) ].
  - exists Etick, (Active Cskip s). apply Step_assert.
  - exists Etick, (Active Cskip s). apply Step_assume.
Qed.

(* Functional active step. astep computes the unique transition of an active
   configuration (the computable twin of active_can_step). 
   seq_lift threads the step of the head of a sequence through the Cseq frame. *)
Definition seq_lift (p : event * config) (d : cmd) : event * config :=
  match p with
  | (ev, Active c' s') => (ev, Active (Cseq c' d) s')
  | (ev, Receptive s') => (ev, Active d s')   (* unreachable when head <> Cskip *)
  end.

Fixpoint astep (c : cmd) (s : state) : event * config :=
  match c with
  | Cskip        => (Etick, Receptive s)
  | Cassign x e  => (Etick, Active Cskip (update s x (eval_expr s e)))
  | Cout lv e    => (Eout lv (eval_expr s e), Active Cskip s)
  | Cif e c1 c2  => if Z.eq_dec (eval_expr s e) 0%Z
                    then (Etick, Active c2 s) else (Etick, Active c1 s)
  | Cwhile e c1  => if Z.eq_dec (eval_expr s e) 0%Z
                    then (Etick, Active Cskip s)
                    else (Etick, Active (Cseq c1 (Cwhile e c1)) s)
  | Cseq c1 c2   => match c1 with
                    | Cskip => (Etick, Active c2 s)
                    | _     => seq_lift (astep c1 s) c2
                    end
  | Cassert lv tk P => (Etick, Active Cskip s)
  | Cassume lv tk P => (Etick, Active Cskip s)
  end.

Lemma seq_lift_sound : forall c1 c2 s,
  c1 <> Cskip ->
  step (Active c1 s) (fst (astep c1 s)) (snd (astep c1 s)) ->
  step (Active (Cseq c1 c2) s) (fst (seq_lift (astep c1 s) c2))
                               (snd (seq_lift (astep c1 s) c2)).
Proof.
  intros c1 c2 s Hne Hstep.
  destruct (astep c1 s) as [ev g'] eqn:E. simpl in Hstep.
  assert (Hact : is_active g') by exact (step_nonskip_active c1 s ev g' Hne Hstep).
  destruct Hact as [c1' [s' ->]]. simpl. apply Step_seq. exact Hstep.
Qed.

Lemma astep_sound : forall c s,
  step (Active c s) (fst (astep c s)) (snd (astep c s)).
Proof.
  induction c; intros s.
  - apply Step_skip.
  - apply Step_assign.
  - apply Step_output.
  - simpl. destruct (Z.eq_dec (eval_expr s e) 0%Z) as [Hz | Hnz].
    + apply Step_if_false; exact Hz.
    + apply Step_if_true; exact Hnz.
  - simpl. destruct (Z.eq_dec (eval_expr s e) 0%Z) as [Hz | Hnz].
    + apply Step_while_false; exact Hz.
    + apply Step_while_true; exact Hnz.
  - destruct c1; try (apply seq_lift_sound; [discriminate | apply IHc1]).
    simpl. apply Step_skip_seq.
  - apply Step_assert.
  - apply Step_assume.
Qed.

Lemma astep_determ : forall c s ev g,
  step (Active c s) ev g -> astep c s = (ev, g).
Proof.
  intros c s ev g Hstep.
  pose proof (astep_sound c s) as Hs.
  destruct (astep c s) as [ev' g'] eqn:E. simpl in Hs.
  destruct (step_determ_active c s ev g ev' g' Hstep Hs) as [He Hg].
  rewrite He, Hg. reflexivity.
Qed.

(* Prepending a step to a segment: if g steps to the root g0 of a segment, then
   g :: that segment is itself a segment rooted at g. By induction on the segment
   derivation (seg's root index is fixed, so the step hypothesis survives). *)
Lemma seg_prepend : forall g ev g0 ks evs,
  step g ev g0 -> seg g0 ks evs -> seg g (g :: ks) (ev :: evs).
Proof.
  intros g ev g0 ks evs Hstep Hseg. revert Hstep.
  induction Hseg as [g1 | g1 ks0 evs0 ev0 g0' Hseg0 IH Hstep0]; intros Hstep.
  - apply (Seg_step g [g] [] ev g1); [apply Seg_init | simpl; exact Hstep].
  - apply (Seg_step g (g :: ks0) (ev :: evs0) ev0 g0'); [apply IH; exact Hstep |].
    assert (Hne : ks0 <> []) by exact (seg_nonempty g1 ks0 evs0 Hseg0).
    assert (Hlc : last_cfg (g :: ks0) = last_cfg ks0) by
      (unfold last_cfg; apply last_cons; exact Hne).
    rewrite Hlc. exact Hstep0.
Qed.

(* The deterministic forward run: from config g, with remaining input supply rem,
   take up to n steps. Active configs step via astep (consuming no input);
   receptive configs consume the next input from rem (if it is an input event);
   a receptive config with no available input is a stuck terminal state (the run
   stops, returning a shorter list). Returns the list of (event, config) pairs
   produced (not including g). *)
Fixpoint frun (g : config) (rem : list event) (n : nat) : list (event * config) :=
  match n with
  | 0 => []
  | S k =>
      match g with
      | Active c s => astep c s :: frun (snd (astep c s)) rem k
      | Receptive s =>
          match rem with
          | Ein lv m :: rem' =>
              let g' := Active (h_body (prog lv)) (update s (h_var (prog lv)) m) in
              (Ein lv m, g') :: frun g' rem' k
          | _ => []
          end
      end
  end.

(* The forward run from g is a segment rooted at g. *)
Lemma frun_seg : forall n g rem,
  seg g (g :: map snd (frun g rem n)) (map fst (frun g rem n)).
Proof.
  induction n as [|k IH]; intros g rem.
  - apply Seg_init.
  - destruct g as [s | c s].
    + destruct rem as [| e rem'].
      * apply Seg_init.
      * destruct e as [lv m | lv m | ].
        -- replace (frun (Receptive s) (Ein lv m :: rem') (S k))
             with ((Ein lv m,
                    Active (h_body (prog lv)) (update s (h_var (prog lv)) m))
                   :: frun (Active (h_body (prog lv)) (update s (h_var (prog lv)) m)) rem' k)
             by reflexivity.
           simpl.
           apply (seg_prepend (Receptive s) (Ein lv m)
                    (Active (h_body (prog lv)) (update s (h_var (prog lv)) m))).
           ++ apply Step_input.
           ++ apply IH.
        -- apply Seg_init.
        -- apply Seg_init.
    + replace (frun (Active c s) rem (S k))
        with (astep c s :: frun (snd (astep c s)) rem k) by reflexivity.
      destruct (astep c s) as [ev g'] eqn:E. simpl.
      apply (seg_prepend (Active c s) ev g').
      * pose proof (astep_sound c s) as Hs. rewrite E in Hs. simpl in Hs. exact Hs.
      * apply IH.
Qed.

(* astep never emits an input event (active steps produce Etick or Eout), so the
   only inputs in a forward run are those consumed at receptive configs. *)
Lemma seq_lift_fst : forall p c, fst (seq_lift p c) = fst p.
Proof. intros [ev g] c. destruct g; reflexivity. Qed.

Lemma astep_event_not_input : forall c s, is_input_b (fst (astep c s)) = false.
Proof.
  induction c; intros s; simpl;
    try reflexivity;
    try (destruct (Z.eq_dec (eval_expr s e) 0%Z); reflexivity).
  destruct c1; try reflexivity; rewrite seq_lift_fst; apply IHc1.
Qed.

(* The inputs consumed by a forward run are a prefix of the available supply rem. *)
Lemma frun_inputs_prefix : forall n g rem,
  list_prefix (inputs (map fst (frun g rem n))) rem.
Proof.
  induction n as [|k IH]; intros g rem.
  - exists rem. reflexivity.
  - destruct g as [s | c s].
    + destruct rem as [| e rem'].
      * exists []. reflexivity.
      * destruct e as [lv m | lv m | ].
        -- set (g' := Active (h_body (prog lv)) (update s (h_var (prog lv)) m)).
           replace (frun (Receptive s) (Ein lv m :: rem') (S k))
             with ((Ein lv m, g') :: frun g' rem' k) by reflexivity.
           change (inputs (map fst ((Ein lv m, g') :: frun g' rem' k)))
             with (Ein lv m :: inputs (map fst (frun g' rem' k))).
           destruct (IH g' rem') as [zs Hzs].
           set (P := inputs (map fst (frun g' rem' k))) in *.
           exists zs. rewrite Hzs. reflexivity.
        -- exists (Eout lv m :: rem'). reflexivity.
        -- exists (Etick :: rem'). reflexivity.
    + replace (frun (Active c s) rem (S k))
        with (astep c s :: frun (snd (astep c s)) rem k) by reflexivity.
      replace (inputs (map fst (astep c s :: frun (snd (astep c s)) rem k)))
        with (inputs (map fst (frun (snd (astep c s)) rem k))).
      * apply IH.
      * unfold inputs. simpl. rewrite astep_event_not_input. reflexivity.
Qed.

(* Gluing the forward run onto a pre-run: if hs admits eh, then the grown list
   hs ++ (configs of the forward run from last(hs)) admits the concatenated
   trace.  Direct from seg_glue applied to frun_seg (the shared boundary config
   g0 = last_cfg hs is the head of the segment list, dropped by tl). *)
Lemma frun_admits : forall n hs eh rem,
  admits_trace hs eh ->
  admits_trace (hs ++ map snd (frun (last_cfg hs) rem n))
               (eh ++ map fst (frun (last_cfg hs) rem n)).
Proof.
  intros n hs eh rem Hat.
  pose proof (frun_seg n (last_cfg hs) rem) as Hseg.
  pose proof (seg_glue (last_cfg hs)
                (last_cfg hs :: map snd (frun (last_cfg hs) rem n))
                (map fst (frun (last_cfg hs) rem n)) Hseg
                hs eh Hat eq_refl) as H.
  simpl in H. exact H.
Qed.

Lemma frun_pre_run : forall n hs rem,
  pre_run hs ->
  pre_run (hs ++ map snd (frun (last_cfg hs) rem n)).
Proof.
  intros n hs rem [eh Hat].
  exists (eh ++ map fst (frun (last_cfg hs) rem n)).
  apply frun_admits. exact Hat.
Qed.

Lemma frun_pr_inputs : forall n hs eh rem,
  admits_trace hs eh ->
  pr_inputs (hs ++ map snd (frun (last_cfg hs) rem n))
            (inputs eh ++ inputs (map fst (frun (last_cfg hs) rem n))).
Proof.
  intros n hs eh rem Hat. unfold pr_inputs.
  exists (eh ++ map fst (frun (last_cfg hs) rem n)). split.
  - apply frun_admits. exact Hat.
  - unfold inputs. rewrite filter_app. reflexivity.
Qed.

(* The forward run takes at most n steps. *)
Lemma frun_length : forall n g rem, length (frun g rem n) <= n.
Proof.
  induction n as [|k IH]; intros g rem.
  - simpl. lia.
  - destruct g as [s | c s].
    + destruct rem as [| e rem'].
      * simpl. lia.
      * destruct e as [lv m | lv m | ].
        -- replace (frun (Receptive s) (Ein lv m :: rem') (S k))
             with ((Ein lv m,
                    Active (h_body (prog lv)) (update s (h_var (prog lv)) m))
                   :: frun (Active (h_body (prog lv)) (update s (h_var (prog lv)) m)) rem' k)
             by reflexivity.
           cbn [length].
           specialize (IH (Active (h_body (prog lv)) (update s (h_var (prog lv)) m)) rem'). lia.
        -- simpl. lia.
        -- simpl. lia.
    + replace (frun (Active c s) rem (S k))
        with (astep c s :: frun (snd (astep c s)) rem k) by reflexivity.
      cbn [length]. specialize (IH (snd (astep c s)) rem). lia.
Qed.

(* The first k steps of an n-step run (k <= n) are exactly the k-step run:
   firstn commutes with the step budget.  Holds even when the run stops early
   (both sides then coincide with the shorter halted list). *)
Lemma frun_firstn : forall n k g rem, k <= n ->
  firstn k (frun g rem n) = frun g rem k.
Proof.
  induction n as [|n IH]; intros k g rem Hk.
  - assert (k = 0) as -> by lia. reflexivity.
  - destruct k as [| k'].
    + reflexivity.
    + destruct g as [s | c s].
      * destruct rem as [| e rem'].
        -- reflexivity.
        -- destruct e as [lv m | lv m | ].
           ++ replace (frun (Receptive s) (Ein lv m :: rem') (S n))
                with ((Ein lv m,
                       Active (h_body (prog lv)) (update s (h_var (prog lv)) m))
                      :: frun (Active (h_body (prog lv)) (update s (h_var (prog lv)) m)) rem' n)
                by reflexivity.
              replace (frun (Receptive s) (Ein lv m :: rem') (S k'))
                with ((Ein lv m,
                       Active (h_body (prog lv)) (update s (h_var (prog lv)) m))
                      :: frun (Active (h_body (prog lv)) (update s (h_var (prog lv)) m)) rem' k')
                by reflexivity.
              cbn [firstn]. rewrite IH by lia. reflexivity.
           ++ reflexivity.
           ++ reflexivity.
      * replace (frun (Active c s) rem (S n))
          with (astep c s :: frun (snd (astep c s)) rem n) by reflexivity.
        replace (frun (Active c s) rem (S k'))
          with (astep c s :: frun (snd (astep c s)) rem k') by reflexivity.
        cbn [firstn]. rewrite IH by lia. reflexivity.
Qed.

(* ---- Small list / config helpers  ---- *)

Fact inputs_cons_noninput : forall ev evs,
  is_input_b ev = false -> inputs (ev :: evs) = inputs evs.
Proof. intros ev evs H. unfold inputs. cbn [filter]. rewrite H. reflexivity. Qed.

Fact inputs_cons_input : forall ev evs,
  is_input_b ev = true -> inputs (ev :: evs) = ev :: inputs evs.
Proof. intros ev evs H. unfold inputs. cbn [filter]. rewrite H. reflexivity. Qed.

Fact inputs_app : forall xs ys, inputs (xs ++ ys) = inputs xs ++ inputs ys.
Proof. intros xs ys. unfold inputs. apply filter_app. Qed.

Fact not_active_receptive : forall g, is_active g -> is_receptive g -> False.
Proof.
  intros g [c [s ->]] [s' Heq]. discriminate.
Qed.

Fact annotation_active : forall l g, redex_is_l_annotation l g -> is_active g.
Proof.
  intros l g H. destruct g as [s | c s].
  - unfold redex_is_l_annotation in H. simpl in H. contradiction.
  - exists c, s. reflexivity.
Qed.

(* config after k forward steps from g0 (or the halt config, if the run stops). *)
Definition frcfg (g0 : config) (rem : list event) (k : nat) : config :=
  last_cfg (g0 :: map snd (frun g0 rem k)).

(* last_cfg of the grown list is the forward config after n steps. *)
Lemma frcfg_last : forall hs rem n,
  last_cfg (hs ++ map snd (frun (last_cfg hs) rem n)) = frcfg (last_cfg hs) rem n.
Proof.
  intros hs rem n. unfold frcfg. apply last_cfg_glue. reflexivity.
Qed.

(* When the run stops early (fewer than n steps), all of rem has been consumed
   (every element of rem is an input, so a receptive config never stalls on a
   non-input; it stops only when rem is exhausted). *)
Lemma frun_inputs_exact : forall n g rem, Forall is_input rem ->
  length (frun g rem n) < n -> inputs (map fst (frun g rem n)) = rem.
Proof.
  induction n as [|k IH]; intros g rem Hrem Hlt.
  - simpl in Hlt. lia.
  - destruct g as [s | c s].
    + destruct rem as [| e rem'].
      * reflexivity.
      * pose proof (Forall_inv Hrem) as Hin.
        destruct e as [lv m | lv m | ].
        -- set (g' := Active (h_body (prog lv)) (update s (h_var (prog lv)) m)).
           replace (frun (Receptive s) (Ein lv m :: rem') (S k))
             with ((Ein lv m, g') :: frun g' rem' k) in Hlt |- * by reflexivity.
           cbn [length] in Hlt.
           cbn [map].
           rewrite inputs_cons_input by reflexivity.
           f_equal. apply IH; [exact (Forall_inv_tail Hrem) | lia].
        -- destruct Hin as [l0 [n0 Hbad]]; discriminate.
        -- destruct Hin as [l0 [n0 Hbad]]; discriminate.
    + replace (frun (Active c s) rem (S k))
        with (astep c s :: frun (snd (astep c s)) rem k) in Hlt |- * by reflexivity.
      cbn [length] in Hlt. cbn [map].
      rewrite inputs_cons_noninput by apply astep_event_not_input.
      apply IH; [exact Hrem | lia].
Qed.

(* When the run stops early, the halt config is receptive. *)
Lemma frun_halt_receptive : forall n g rem, Forall is_input rem ->
  length (frun g rem n) < n -> is_receptive (frcfg g rem n).
Proof.
  induction n as [|k IH]; intros g rem Hrem Hlt.
  - simpl in Hlt. lia.
  - destruct g as [s | c s].
    + destruct rem as [| e rem'].
      * exists s. reflexivity.
      * pose proof (Forall_inv Hrem) as Hin.
        destruct e as [lv m | lv m | ].
        -- set (g' := Active (h_body (prog lv)) (update s (h_var (prog lv)) m)).
           unfold frcfg.
           replace (frun (Receptive s) (Ein lv m :: rem') (S k))
             with ((Ein lv m, g') :: frun g' rem' k) in Hlt |- * by reflexivity.
           cbn [length] in Hlt.
           cbn [map].
           unfold last_cfg. rewrite last_cons by discriminate.
           change (is_receptive (last_cfg (g' :: map snd (frun g' rem' k)))).
           apply (IH g' rem'); [exact (Forall_inv_tail Hrem) | lia].
        -- destruct Hin as [l0 [n0 Hbad]]; discriminate.
        -- destruct Hin as [l0 [n0 Hbad]]; discriminate.
    + unfold frcfg.
      replace (frun (Active c s) rem (S k))
        with (astep c s :: frun (snd (astep c s)) rem k) in Hlt |- * by reflexivity.
      cbn [length] in Hlt.
      cbn [map].
      unfold last_cfg. rewrite last_cons by discriminate.
      change (is_receptive (last_cfg (snd (astep c s) :: map snd (frun (snd (astep c s)) rem k)))).
      apply (IH (snd (astep c s)) rem); [exact Hrem | lia].
Qed.

(* The config at forward-run index j of the grown list is frcfg at step S j. *)
Lemma frun_nth_snd : forall n j g rem, S j <= length (frun g rem n) ->
  nth j (map snd (frun g rem n)) (Receptive initState) = frcfg g rem (S j).
Proof.
  intros n j g rem Hj.
  assert (Hjn : S j <= n) by (pose proof (frun_length n g rem) as Hl; lia).
  unfold frcfg.
  rewrite <- (frun_firstn n (S j) g rem Hjn).
  rewrite ga_firstn_map.
  set (M := map snd (frun g rem n)).
  assert (HlenM : length M = length (frun g rem n)) by (unfold M; apply length_map).
  assert (Hpos : S j <= length M) by lia.
  unfold last_cfg.
  rewrite last_cons by
    (intro Hc; apply (f_equal (@length config)) in Hc;
     rewrite firstn_length_le in Hc by lia; simpl in Hc; lia).
  rewrite last_nth_def.
  rewrite firstn_length_le by lia.
  replace (S j - 1) with j by lia.
  symmetry. apply ga_nth_firstn. lia.
Qed.

(* The inputs consumed by the k-step run are a prefix of those by the n-step run
   (k <= n): the forward run consumes inputs monotonically. *)
Lemma frun_inputs_mono : forall k n g rem, k <= n ->
  list_prefix (inputs (map fst (frun g rem k))) (inputs (map fst (frun g rem n))).
Proof.
  intros k n g rem Hkn.
  rewrite <- (frun_firstn n k g rem Hkn).
  rewrite ga_firstn_map.
  unfold inputs, list_prefix.
  exists (filter is_input_b (skipn k (map fst (frun g rem n)))).
  rewrite <- filter_app. rewrite firstn_skipn. reflexivity.
Qed.

Lemma frun_prefix : forall k n g rem, k <= n ->
  list_prefix (frun g rem k) (frun g rem n).
Proof.
  intros k n g rem H. rewrite <- (frun_firstn n k g rem H).
  exists (skipn k (frun g rem n)). rewrite firstn_skipn. reflexivity.
Qed.

(* The only step out of a receptive config consumes an input. *)
Lemma step_receptive_input : forall s ev g',
  step (Receptive s) ev g' -> is_input_b ev = true.
Proof. intros s ev g' H. inversion H; subst; reflexivity. Qed.

(* The "last step" view of the forward run: when the (S p)-step run reaches its
   full length, it is the p-step run with one more (ev,g') appended, and that
   step is taken from frcfg g rem p (the config after p steps). *) 
Lemma frun_snoc : forall p g rem, length (frun g rem (S p)) = S p ->
  exists ev g', frun g rem (S p) = frun g rem p ++ [(ev, g')]
             /\ step (frcfg g rem p) ev g'.
Proof.
  induction p as [|p IH]; intros g rem Hlen.
  - destruct g as [s | c s].
    + destruct rem as [| e rem'].
      * simpl in Hlen. lia.
      * destruct e as [lv m | lv m | ].
        -- exists (Ein lv m),
                  (Active (h_body (prog lv)) (update s (h_var (prog lv)) m)).
           split.
           ++ reflexivity.
           ++ unfold frcfg. cbn [frun map last_cfg last]. apply Step_input.
        -- simpl in Hlen. lia.
        -- simpl in Hlen. lia.
    + exists (fst (astep c s)), (snd (astep c s)). split.
      * change (frun (Active c s) rem 1) with ([astep c s]).
        change (frun (Active c s) rem 0 ++ [(fst (astep c s), snd (astep c s))])
          with ([(fst (astep c s), snd (astep c s))]).
        rewrite <- surjective_pairing. reflexivity.
      * unfold frcfg. cbn [frun map last_cfg last].
        apply astep_sound.
  - destruct g as [s | c s].
    + destruct rem as [| e rem'].
      * simpl in Hlen. lia.
      * destruct e as [lv m | lv m | ].
        -- set (g1 := Active (h_body (prog lv)) (update s (h_var (prog lv)) m)).
           assert (Hlen1 : length (frun g1 rem' (S p)) = S p).
           { replace (frun (Receptive s) (Ein lv m :: rem') (S (S p)))
               with ((Ein lv m, g1) :: frun g1 rem' (S p)) in Hlen by reflexivity.
             cbn [length] in Hlen. lia. }
           destruct (IH g1 rem' Hlen1) as [ev [g' [Heq Hstep]]].
           exists ev, g'. split.
           ++ replace (frun (Receptive s) (Ein lv m :: rem') (S (S p)))
                with ((Ein lv m, g1) :: frun g1 rem' (S p)) by reflexivity.
              replace (frun (Receptive s) (Ein lv m :: rem') (S p))
                with ((Ein lv m, g1) :: frun g1 rem' p) by reflexivity.
              rewrite Heq. reflexivity.
           ++ assert (Hfc : frcfg (Receptive s) (Ein lv m :: rem') (S p) = frcfg g1 rem' p).
              { unfold frcfg.
                replace (frun (Receptive s) (Ein lv m :: rem') (S p))
                  with ((Ein lv m, g1) :: frun g1 rem' p) by reflexivity.
                cbn [map]. unfold last_cfg. rewrite last_cons by discriminate. reflexivity. }
              rewrite Hfc. exact Hstep.
        -- simpl in Hlen. lia.
        -- simpl in Hlen. lia.
    + assert (Hlen1 : length (frun (snd (astep c s)) rem (S p)) = S p).
      { replace (frun (Active c s) rem (S (S p)))
          with (astep c s :: frun (snd (astep c s)) rem (S p)) in Hlen by reflexivity.
        cbn [length] in Hlen. lia. }
      destruct (IH (snd (astep c s)) rem Hlen1) as [ev [g' [Heq Hstep]]].
      exists ev, g'. split.
      * replace (frun (Active c s) rem (S (S p)))
          with (astep c s :: frun (snd (astep c s)) rem (S p)) by reflexivity.
        replace (frun (Active c s) rem (S p))
          with (astep c s :: frun (snd (astep c s)) rem p) by reflexivity.
        rewrite Heq. reflexivity.
      * assert (Hfc : frcfg (Active c s) rem (S p) = frcfg (snd (astep c s)) rem p).
        { unfold frcfg.
          replace (frun (Active c s) rem (S p))
            with (astep c s :: frun (snd (astep c s)) rem p) by reflexivity.
          cbn [map]. unfold last_cfg. rewrite last_cons by discriminate. reflexivity. }
        rewrite Hfc. exact Hstep.
Qed.

(* -------------------------------------------------------- *)
(* Extending a pre-run to next annotation if there is one.
   See the paper's lemma lem:traceFromInput. *)
(* -------------------------------------------------------- *)

(* The growth-to-annotation executor. 
   From a pre-run hs whose consumed inputs ih are a prefix of ins, grow forward by
   appending a segment hs' (so the grown pre-run is hs ++ hs'), maintaining
   inputs <= ins, until one of:
   (1) an l-annotation at the last config (no earlier l-annotation in the growth);
   (2) ins exhausted at a receptive config (no l-annotation in the growth); or
   (3) divergence: an annotation-free pre-run of every length n >= |hs| (inputs
       between ih and ins; not necessarily active -- it may sit receptive
       mid-handler on a non-visible input). *) 

Lemma grow_to_annotation : forall l ins hs ih,
  Forall is_input ins ->
  pre_run hs -> pr_inputs hs ih -> list_prefix ih ins ->
  (exists hs' ih',
     pre_run (hs ++ hs') /\
     pr_inputs (hs ++ hs') (ih ++ ih') /\
     list_prefix (ih ++ ih') ins /\
     redex_is_l_annotation l (last_cfg (hs ++ hs')) /\
     (forall k, length hs <= k -> k < length (hs ++ hs') - 1 ->
        ~ redex_is_l_annotation l (cfg_at (hs ++ hs') k)))
  \/
  (exists hs' ih',
     pre_run (hs ++ hs') /\
     pr_inputs (hs ++ hs') (ih ++ ih') /\
     ih ++ ih' = ins /\
     is_receptive (last_cfg (hs ++ hs')) /\
     (forall k, length hs <= k -> k < length (hs ++ hs') ->
        ~ redex_is_l_annotation l (cfg_at (hs ++ hs') k)))
  \/
  (forall n, n >= length hs ->
     exists hs' ih',
       length hs' = n /\
       pr_inputs hs' ih' /\
       list_prefix ih ih' /\ list_prefix ih' ins /\
       ~ redex_is_l_annotation l (last_cfg hs')).
Proof.
  intros l ins hs ih Hins Hpre Hpri Hpreih.
  destruct Hpri as [eh [Heh Hihe]].
  destruct Hpreih as [rem Hrem_eq].
  assert (Hrem_forall : Forall is_input rem).
  { rewrite Hrem_eq in Hins. apply Forall_app in Hins. destruct Hins as [_ Hr]. exact Hr. }
  set (g0 := last_cfg hs).
  pose (ihn := fun n => inputs (map fst (frun g0 rem n))).
  assert (Hpren : forall n, pre_run (hs ++ map snd (frun g0 rem n))).
  { intro n. apply (frun_pre_run n hs rem Hpre). }
  assert (Hprin : forall n, pr_inputs (hs ++ map snd (frun g0 rem n)) (ih ++ ihn n)).
  { intro n. unfold ihn. rewrite <- Hihe. apply (frun_pr_inputs n hs eh rem Heh). }
  assert (Hpfn : forall n, list_prefix (ih ++ ihn n) ins).
  { intro n. rewrite Hrem_eq. apply list_prefix_app_l. unfold ihn.
    apply (frun_inputs_prefix n g0 rem). }
  assert (Hlast : forall n, last_cfg (hs ++ map snd (frun g0 rem n)) = frcfg g0 rem n).
  { intro n. apply frcfg_last. }
  pose (Reached := fun n => redex_is_l_annotation l (frcfg g0 rem n)
                            \/ (is_receptive (frcfg g0 rem n) /\ ihn n = rem)).
  destruct (classic (exists n, Reached n)) as [HA | HB].
  - (* CASE A: the forward run reaches an annotation or exhausts inputs. *)
    destruct HA as [nw Hnw].
    destruct (least_witness Reached nw Hnw) as [n0 [Hn0 Hmin]].
    unfold Reached in Hn0. destruct Hn0 as [Hann | [Hrec Hexh]].
    + (* A1: annotation at frcfg n0 -> outcome 1. *)
      assert (HL : length (frun g0 rem n0) = n0).
      { destruct (Nat.lt_ge_cases (length (frun g0 rem n0)) n0) as [Hlt | Hge].
        - exfalso. apply (not_active_receptive (frcfg g0 rem n0)).
          + apply (annotation_active l). exact Hann.
          + apply (frun_halt_receptive n0 g0 rem Hrem_forall Hlt).
        - pose proof (frun_length n0 g0 rem). lia. }
      left. exists (map snd (frun g0 rem n0)), (ihn n0).
      split. { apply Hpren. }
      split. { apply Hprin. }
      split. { apply Hpfn. }
      split. { rewrite Hlast. exact Hann. }
      intros k Hk1 Hk2.
      assert (Hlenhs' : length (hs ++ map snd (frun g0 rem n0)) = length hs + n0).
      { rewrite length_app, length_map, HL. reflexivity. }
      rewrite Hlenhs' in Hk2.
      set (j := k - length hs).
      assert (Hkj : k = length hs + j) by (unfold j; lia).
      assert (Hjlt : S j <= length (frun g0 rem n0)) by (rewrite HL; lia).
      unfold cfg_at. rewrite Hkj, ga_app_nth_plus, (frun_nth_snd n0 j g0 rem Hjlt).
      intro Hbad. apply (Hmin (S j)).
      * lia.
      * left. exact Hbad.
    + (* A2: receptive config with all inputs consumed -> outcome 2. *)
      right. left. exists (map snd (frun g0 rem n0)), (ihn n0).
      split. { apply Hpren. }
      split. { apply Hprin. }
      split. { rewrite Hexh, Hrem_eq. reflexivity. }
      split. { rewrite Hlast. exact Hrec. }
      intros k Hk1 Hk2.
      assert (HLle : length (frun g0 rem n0) <= n0) by apply frun_length.
      assert (Hlenhs' : length (hs ++ map snd (frun g0 rem n0))
                        = length hs + length (frun g0 rem n0)).
      { rewrite length_app, length_map. reflexivity. }
      rewrite Hlenhs' in Hk2.
      set (j := k - length hs).
      assert (Hkj : k = length hs + j) by (unfold j; lia).
      assert (Hjlt : S j <= length (frun g0 rem n0)) by lia.
      unfold cfg_at. rewrite Hkj, ga_app_nth_plus, (frun_nth_snd n0 j g0 rem Hjlt).
      intro Hbad. destruct (Nat.eq_dec (S j) n0) as [Heq | Hne].
      * rewrite Heq in Hbad.
        apply (not_active_receptive (frcfg g0 rem n0));
          [ apply (annotation_active l); exact Hbad | exact Hrec ].
      * apply (Hmin (S j)); [ lia | left; exact Hbad ].
  - (* CASE B: never reached -> divergence (outcome 3). The forward run never
       reaches an annotation or exhausts inputs, so every prefix hs ++ frun(p) of
       the requested length n is annotation-free at its last config (it may be
       receptive, mid-handler on a non-visible input; activeness is not needed). *)
    assert (HnotR : forall n, ~ Reached n).
    { intros n Hr. apply HB. exists n. exact Hr. }
    assert (Hfull : forall n, length (frun g0 rem n) = n).
    { intro n. destruct (Nat.lt_ge_cases (length (frun g0 rem n)) n) as [Hlt | Hge].
      - exfalso. apply (HnotR n). right. split.
        + apply (frun_halt_receptive n g0 rem Hrem_forall Hlt).
        + apply (frun_inputs_exact n g0 rem Hrem_forall Hlt).
      - pose proof (frun_length n g0 rem). lia. }
    right. right.
    intros n Hn_ge.
    set (p := n - length hs).
    assert (Hnp : n = length hs + p) by (unfold p; lia).
    exists (hs ++ map snd (frun g0 rem p)), (ih ++ ihn p).
    split. { rewrite length_app, length_map, Hfull. lia. }
    split. { apply Hprin. }
    split. { exists (ihn p). reflexivity. }
    split. { apply Hpfn. }
    assert (Hla : last_cfg (hs ++ map snd (frun g0 rem p)) = frcfg g0 rem p) by apply Hlast.
    rewrite Hla. intro Hbad. apply (HnotR p). left. exact Hbad.
Qed.


(* -------------------------------------------------------- *)
(* SAFETY DEFINITIONS *)
(* -------------------------------------------------------- *)

(* -------------------------------------------------------- *)
(* alignment and semi-conformance *) 
(* -------------------------------------------------------- *)

Definition align_dom (alpha : nat -> nat -> Prop) (i : nat) : Prop := exists j, alpha i j.
Definition align_rng (alpha : nat -> nat -> Prop) (j : nat) : Prop := exists i, alpha i j.

(* alpha is an alignment from gs to hs: a relation on their index domains that
   is (a) monotone and (b) has prefix-closed domain and range. *)
Definition alignment (gs hs : list config) (alpha : nat -> nat -> Prop) : Prop :=
  (forall i j, alpha i j -> i < length gs /\ j < length hs) /\
  (* (a) monotone *)
  (forall i j k l, alpha i j -> alpha k l -> (i < k -> j <= l) /\ (j < l -> i <= k)) /\
  (* (b) prefix-closed domain and range *)
  (forall i j, align_dom alpha i -> j < i -> align_dom alpha j) /\
  (forall i j, align_rng alpha i -> j < i -> align_rng alpha j).

Definition covers_dom (gs : list config) (alpha : nat -> nat -> Prop) : Prop :=
  forall i, i < length gs -> align_dom alpha i.

Definition covers_rng (hs : list config) (alpha : nat -> nat -> Prop) : Prop :=
  forall j, j < length hs -> align_rng alpha j.

(* semi-proper for l: at aligned positions, if either redex is an
   l-assumption then the two redexes coincide. NOTE: the paper intends
   "same occurrence in the program text" (it suggests labelling annotation
   occurrences); we approximate this with structural equality of the redex
   command, which conflates textually identical assumes at distinct points. 
   When it matters, we apply aligned_annot_same_cmd for the effect of "same
   occurrence"; tags now make that genuine, since a tag names an occurrence. *)
Definition semi_proper (l : Lev) (gs hs : list config)
                         (alpha : nat -> nat -> Prop) : Prop :=
  alignment gs hs alpha /\
  (forall i j, alpha i j ->
     redex_is_l_assume l (cfg_at gs i) \/ redex_is_l_assume l (cfg_at hs j) ->
     redex_of (cfg_at gs i) = redex_of (cfg_at hs j)).

Definition semi_l_aligned_pair (l : Lev) (gs hs : list config)
                          (alpha : nat -> nat -> Prop) : Prop :=
  pre_run gs /\ pre_run hs /\ semi_proper l gs hs alpha.


(* -------------------------------------------------------- *)
(* SECURITY DEFINITIONS *)
(* -------------------------------------------------------- *)

(* -------------------------------------------------------- *)
(* release policy, based on semi-conformance   *)
(* -------------------------------------------------------- *)

(* SC^l(gs,hs,alpha) in the paper.
   An l-aligned pair where alpha covers both pre-runs and, at 
   every aligned position whose major redex is an l-assumption 
   Phi, the two prefixes satisfy Phi. *)
Definition semi_conformance (l : Lev) (gs hs : list config)
                            (alpha : nat -> nat -> Prop) : Prop :=
  semi_l_aligned_pair l gs hs alpha /\
  covers_dom gs alpha /\
  covers_rng hs alpha /\
  (forall i j l' tk Phi,
     alpha i j ->
     redex_of (cfg_at gs i) = Some (Cassume l' tk Phi) ->
     lleq l' l ->
     models (cfg_state (cfg_at gs i)) (cfg_state (cfg_at hs j)) Phi). 

(* RP^l(gs): the set of input lists of minor pre-runs semi-conformant to gs. *)
Definition release_policy (l : Lev) (gs : list config) (ins : list event) : Prop :=
  exists hs alpha us,
    semi_conformance l gs hs alpha /\
    admits_trace hs us /\
    ins = inputs us.

(* -------------------------------------------------------- *)
(* security *) 
(* -------------------------------------------------------- *)

(* The step from last(hs) to g is secure at l: at any non-visible-input
   extension t of a trace ts of hs, knowledge after t is no smaller than
   progress-knowledge intersected with the release policy. 
   Recall that ts and t are uniquely determined by hs and g (Lemma traceDetEv). *)
Definition step_secure (l : Lev) (hs : list config) (g : config) : Prop :=
  forall ts t,
    admits_trace hs ts ->
    admits_trace (hs ++ [g]) (ts ++ [t]) ->
    forall ins,
      pknow l ts ins ->
      release_policy l (hs ++ [g]) ins ->
      know l (ts ++ [t]) ins.

Definition secure_for_level (l : Lev) (gs : list config) : Prop :=
  forall hs g,
    hs <> [] ->
    list_prefix (hs ++ [g]) gs ->
    step_secure l hs g.

Definition secure (gs : list config) : Prop :=
    forall l, secure_for_level l gs.

(* -------------------------------------------------------- *)
(* SAFETY DEFINITIONS *)
(* -------------------------------------------------------- *)

(* -------------------------------------------------------- *)
(* classification of aligned major-minor run pairs. *) 
(* Informally, the classes (conformance, assumption fiat, etc)
   are defined for input lists, but we refrain from defining
   a subtype of event lists and instead state definitions 
   for event lists with the constraint that all events are 
   inputs. *)
(* -------------------------------------------------------- *)

Definition proper (l : Lev) (gs hs : list config)
                         (alpha : nat -> nat -> Prop) : Prop :=
  alignment gs hs alpha /\
  (forall i j, alpha i j ->
     redex_is_l_annotation l (cfg_at gs i) \/ redex_is_l_annotation l (cfg_at hs j) ->
     redex_of (cfg_at gs i) = redex_of (cfg_at hs j)).

Definition l_aligned_pair (l : Lev) (gs hs : list config)
                          (alpha : nat -> nat -> Prop) : Prop :=
  pre_run gs /\ pre_run hs /\ proper l gs hs alpha.

(* alignment_below alpha i j : the alignment alpha restricted to indices before i, j *)
Definition alignment_below (alpha : nat -> nat -> Prop) (i j : nat) : nat -> nat -> Prop :=
  fun k l => alpha k l /\ k < i /\ l < j.

(* Conformance. Like semi_conformance but with agreement 
   on l-asserts as well as l-assumes, covers hs, and either 
   covers gs or hs has consumed all of ins and reached a receptive configuration. *)
Definition conformance (l : Lev) (ins : list event)
                       (gs hs : list config) (alpha : nat -> nat -> Prop) : Prop :=
  l_aligned_pair l gs hs alpha /\
  (exists ih, pr_inputs hs ih /\ list_prefix ih ins /\
     (covers_dom gs alpha \/ (ih = ins /\ is_receptive (last_cfg hs)))) /\
  covers_rng hs alpha /\
  (forall i j l' tk Phi,
     alpha i j ->
     (redex_of (cfg_at gs i) = Some (Cassume l' tk Phi) \/
      redex_of (cfg_at gs i) = Some (Cassert l' tk Phi)) ->
     lleq l' l ->
     models (cfg_state (cfg_at gs i)) (cfg_state (cfg_at hs j)) Phi) /\
  Forall is_input ins.

(* Extract the input-list condition carried by a conformance. *)
Fact conformance_inputs : forall l ins gs hs alpha,
  conformance l ins gs hs alpha -> Forall is_input ins.
Proof. intros l ins gs hs alpha H. destruct H as [_ [_ [_ [_ Hinp]]]]. exact Hinp. Qed.

Definition conformance_below (l : Lev) (ins : list event)
                             (gs hs : list config) (alpha : nat -> nat -> Prop)
                             (i j : nat) : Prop :=
  conformance l ins (firstn i gs) (firstn j hs) (alignment_below alpha i j) /\
  covers_dom (firstn i gs) (alignment_below alpha i j).

(* assumption fiat and assertion failure, located at the major index i
   where the offending assume/assert occurs. They differ only in assume vs
   assert at gs_i *)
Definition assumption_fiat_at (i : nat) (l : Lev) (ins : list event)
                             (gs hs : list config) (alpha : nat -> nat -> Prop) : Prop :=
  l_aligned_pair l gs hs alpha /\
  (exists ih, pr_inputs hs ih /\ list_prefix ih ins) /\
  covers_rng hs alpha /\
  (exists j l' tk Phi,
     i < length gs /\
     j = length hs - 1 /\
     alpha i j /\
     redex_of (cfg_at gs i) = Some (Cassume l' tk Phi) /\
     lleq l' l /\
     ~ models (cfg_state (cfg_at gs i)) (cfg_state (cfg_at hs j)) Phi /\
     conformance_below l ins gs hs alpha i j) /\
  Forall is_input ins.

Definition assumption_fiat (l : Lev) (ins : list event)
                          (gs hs : list config) (alpha : nat -> nat -> Prop) : Prop :=
  exists i, assumption_fiat_at i l ins gs hs alpha.

Definition assertion_failure_at (i : nat) (l : Lev) (ins : list event)
                               (gs hs : list config) (alpha : nat -> nat -> Prop) : Prop :=
  l_aligned_pair l gs hs alpha /\
  (exists ih, pr_inputs hs ih /\ list_prefix ih ins) /\
  covers_rng hs alpha /\
  (exists j l' tk Phi,
     i < length gs /\
     j = length hs - 1 /\
     alpha i j /\
     redex_of (cfg_at gs i) = Some (Cassert l' tk Phi) /\
     lleq l' l /\
     ~ models (cfg_state (cfg_at gs i)) (cfg_state (cfg_at hs j)) Phi /\
     conformance_below l ins gs hs alpha i j) /\
  Forall is_input ins.

Definition assertion_failure (l : Lev) (ins : list event)
                            (gs hs : list config) (alpha : nat -> nat -> Prop) : Prop :=
  exists i, assertion_failure_at i l ins gs hs alpha.

(* alignment failure *) 
Definition alignment_failure_at (i : nat) (l : Lev) (ins : list event)
                               (gs hs : list config) (alpha : nat -> nat -> Prop) : Prop :=
  (exists ih, pr_inputs hs ih /\ list_prefix ih ins) /\
  (exists j,
     i < length gs /\
     j = length hs - 1 /\
     redex_is_l_annotation l (cfg_at gs i) /\
     redex_is_l_annotation l (cfg_at hs j) /\
     redex_of (cfg_at hs j) <> redex_of (cfg_at gs i) /\
     conformance_below l ins gs hs alpha i j) /\
  Forall is_input ins.

Definition alignment_failure (l : Lev) (ins : list event)
                            (gs hs : list config) (alpha : nat -> nat -> Prop) : Prop :=
  exists i, alignment_failure_at i l ins gs hs alpha.

(* Divergence fiat *) 
(* Note subtlety that the point of last observable may be an output
   which should be in correspondence like a conformance, but that isn't
   handled by conformance per se. *) 
   
Definition divergence_fiat_at (i k : nat) (l : Lev) (ins : list event)
                             (gs hs : list config) (alpha : nat -> nat -> Prop) : Prop :=
  Forall is_input ins /\
  i < k /\ k < length gs /\
  l_aligned_pair l gs hs alpha /\
  redex_is_l_annotation l (cfg_at gs k) /\
  exists j, j = length hs - 1 /\
    alpha i j /\
    ((i = 0 /\ j = 0) \/ redex_is_l_annotation l (cfg_at gs i)
                       \/ (redex_is_l_output l (cfg_at gs i) /\
                           redex_is_l_output l (cfg_at hs j))) /\
    (forall m, i < m -> m < k -> ~ redex_is_l_annotation l (cfg_at gs m)) /\
    conformance l ins (firstn (i+1) gs) hs alpha /\
    (exists ih, pr_inputs hs ih /\ list_prefix ih ins /\
    (exists H : nat -> list config,
     forall n, length (H n) = n /\
     (forall m, m < n -> ~ redex_is_l_annotation l (cfg_at (H n) m) /\
                         ~ redex_is_l_output l (cfg_at (H n) m)) /\
      (exists ih',
        pr_inputs (hs ++ H n) ih' /\
        list_prefix ih' ins))).


Definition divergence_fiat (l : Lev) (ins : list event)
                          (gs hs : list config) (alpha : nat -> nat -> Prop) : Prop :=
  exists i k, divergence_fiat_at i k l ins gs hs alpha.

Lemma divergence_fiat_at_cover : forall i k l ins gs hs alpha,
  divergence_fiat_at i k l ins gs hs alpha ->
  covers_dom (firstn (i+1) gs) alpha /\ covers_rng hs alpha.
Proof.
  intros i k l ins gs hs alpha H.
  destruct H as [Hinp [Hik [Hklt [Hlap [Hannk Hexj]]]]].
  destruct Hexj as [j [Hjeq [Haij [Hicase [Hnogrow [Hconf Hex]]]]]].
  assert (Hdi : align_dom alpha i) by (unfold align_dom; exists j; exact Haij).
  destruct Hlap as [HpreG [HpreH [Halgn _]]].
  destruct Halgn as [Hbound [Hmono [Hpcd Hpcr]]].
  split.
  - intros m Hm.
    assert (Hmlen : length (firstn (i + 1) gs) = i + 1) by (apply firstn_length_le; lia).
    rewrite Hmlen in Hm.
    destruct (Nat.eq_dec m i) as [-> | Hne].
    + exact Hdi.
    + apply (Hpcd i m Hdi). lia.
  - destruct Hconf as [_ [_ [Hcrng _]]]. exact Hcrng.
Qed.

(* -------------------------------------------------------- *)
(* safety *) 
(* -------------------------------------------------------- *)

Definition safe_for (l : Lev) (ins : list event) (gs : list config) : Prop :=
  exists hs alpha,
    conformance l ins gs hs alpha \/
    assumption_fiat l ins gs hs alpha \/
    divergence_fiat l ins gs hs alpha.

Definition safe_for_level (l : Lev) (gs : list config) : Prop :=
  forall ins, Forall is_input ins -> safe_for l ins gs.

Definition safe (gs : list config) : Prop :=
  forall l, safe_for_level l gs.

(* -------------------------------------------------------- *)
(* Annotations uniquely determine control points *)
(* -------------------------------------------------------- *)
(* These two facts used to be posited together, as a Hypothesis called KludgeHyp,
standing in for an assumption that no annotation occurs twice in the program.
That assumption is now part of [well_specified]: the [tags_unique] conjunct says
no tag labels two annotation occurrences (accessor [prog_tags_unique]).  Both
facts are now LEMMAS derived from it -- [handler_entry_dispatched_lem] and
[aligned_annot_same_cmd], proved below where the semantic machinery they need is
available.  They are still stated here as Definitions because they are used as
named properties in what follows.

Both derivations go through the run invariant [run_cmd_inv]: the active command
of a reachable config is a residual of the body of the handler that is running.
For the first, a residual past a body's entry assume has lost that assume's tag,
so only a just-dispatched config can carry a whole body.  For the second, the
tag of an annotation redex identifies its handler (cross-handler uniqueness) and
then, within that body, identifies the residual (resid_struct_redex_det, using
the body's NoDup) -- so two runs stopped at the same annotation are at the same
control point, continuation and all. *)

(* Because a residual past the entry assume no longer carries that assume's tag,
   a config whose active command is a full handler body [h_body (prog l')] can
   only have been produced by consuming the corresponding l'-input -- its
   predecessor step is that input event. *)
Definition handler_entry_dispatched :=
  forall gs ts q l' s, 
    admits_trace gs ts -> q < length gs ->
    cfg_at gs q = Active (h_body (prog l')) s ->
    0 < q /\ nth (q - 1) ts Etick = Ein l' (eval_expr s (EVar (h_var (prog l')))).

(* The other consequence.  Because distinct annotation occurrences carry distinct
   tags, an annotation's redex pins down the unique program
   point -- hence the full active command -- at which it occurs.  So at an aligned
   pair whose major side is an l-annotation, [proper]'s redex-coincidence upgrades
   to full command coincidence: the two configs are at the same control point.
   Stated only for aligned pairs of an [l_aligned_pair] (rather than for arbitrary
   pairs of commands sharing an annotation redex, which would be inconsistent).
   The two configs must be REACHABLE for the argument to run -- an arbitrary list
   of configs may hold commands that no run can produce -- which is why the
   hypothesis is [l_aligned_pair] (= both sides pre-runs, plus [proper]) and not
   just [proper]. *)
Definition aligned_annot_same_cmd_hyp :=
  forall l gs hs alpha i j,
    l_aligned_pair l gs hs alpha -> alpha i j ->
    redex_is_l_annotation l (cfg_at gs i) ->
    cfg_cmd (cfg_at gs i) = cfg_cmd (cfg_at hs j).


(* -------------------------------------------------------- *)
(* Forward closure of fiats and failures (lem:extendFail in
   the paper). 
   The same kind of fiat or failure, at the same major index, 
   persists when major run is extended. *)
(* -------------------------------------------------------- *)

Fact cfg_at_app1 : forall gs g i,
  i < length gs -> cfg_at (gs ++ [g]) i = cfg_at gs i.
Proof.
  intros gs g i Hi. unfold cfg_at. apply app_nth1. exact Hi.
Qed.

Fact alignment_extend : forall gs g hs alpha,
  alignment gs hs alpha -> alignment (gs ++ [g]) hs alpha.
Proof.
  intros gs g hs alpha [Hb [Hmono [Hpd Hpr]]].
  split; [| split; [exact Hmono | split; [exact Hpd | exact Hpr]]].
  intros i j Hij. destruct (Hb i j Hij) as [Hi Hj].
  split; [rewrite length_app; simpl; lia | exact Hj].
Qed.

Fact semi_proper_extend : forall l gs g hs alpha,
  semi_proper l gs hs alpha -> semi_proper l (gs ++ [g]) hs alpha.
Proof.
  intros l gs g hs alpha [Halign Hmatch].
  split; [apply alignment_extend; exact Halign |].
  intros i j Hij Hdisj.
  destruct Halign as [Hb _]. destruct (Hb i j Hij) as [Hi _].
  rewrite (cfg_at_app1 gs g i Hi) in Hdisj |- *.
  apply Hmatch; assumption.
Qed.

Fact semi_l_aligned_pair_extend : forall l gs g hs alpha,
  pre_run (gs ++ [g]) ->
  semi_l_aligned_pair l gs hs alpha -> semi_l_aligned_pair l (gs ++ [g]) hs alpha.
Proof.
  intros l gs g hs alpha Hpre [Hpg [Hph Hwp]].
  split; [exact Hpre | split; [exact Hph | apply semi_proper_extend; exact Hwp]].
Qed.

Fact proper_extend : forall l gs g hs alpha,
  proper l gs hs alpha -> proper l (gs ++ [g]) hs alpha.
Proof.
  intros l gs g hs alpha [Halign Hmatch].
  split; [apply alignment_extend; exact Halign |].
  intros i j Hij Hdisj.
  destruct Halign as [Hb _]. destruct (Hb i j Hij) as [Hi _].
  rewrite (cfg_at_app1 gs g i Hi) in Hdisj |- *.
  apply Hmatch; assumption.
Qed.

Fact l_aligned_pair_extend : forall l gs g hs alpha,
  pre_run (gs ++ [g]) ->
  l_aligned_pair l gs hs alpha -> l_aligned_pair l (gs ++ [g]) hs alpha.
Proof.
  intros l gs g hs alpha Hpre [Hpg [Hph Hp]].
  split; [exact Hpre | split; [exact Hph | apply proper_extend; exact Hp]].
Qed.

Lemma assumption_fiat_at_extend : forall i l ins gs g hs alpha,
  pre_run (gs ++ [g]) ->
  assumption_fiat_at i l ins gs hs alpha ->
  assumption_fiat_at i l ins (gs ++ [g]) hs alpha.
Proof.
  intros i l ins gs g hs alpha Hpre HAF.
  destruct HAF as [Hlap [Hih [Hcov [Hex Hinp]]]].
  destruct Hex as [j [l' [tk [Phi [Hi [Hj [Haij [Hred [Hle [Hnm Hcb]]]]]]]]]].
  split; [apply (l_aligned_pair_extend l gs g hs alpha Hpre Hlap) |].
  split; [exact Hih |].
  split; [exact Hcov |].
  split; [| exact Hinp].
  exists j, l', tk, Phi.
  split; [rewrite length_app; simpl; lia |].
  split; [exact Hj |].
  split; [exact Haij |].
  split; [rewrite (cfg_at_app1 gs g i Hi); exact Hred |].
  split; [exact Hle |].
  split.
  - rewrite (cfg_at_app1 gs g i Hi). exact Hnm.
  - unfold conformance_below in *.
    rewrite (firstn_app1 _ gs g i ltac:(lia)). exact Hcb.
Qed.

Lemma assertion_failure_at_extend : forall i l ins gs g hs alpha,
  pre_run (gs ++ [g]) ->
  assertion_failure_at i l ins gs hs alpha ->
  assertion_failure_at i l ins (gs ++ [g]) hs alpha.
Proof.
  intros i l ins gs g hs alpha Hpre HAF.
  destruct HAF as [Hlap [Hih [Hcov [Hex Hinp]]]].
  destruct Hex as [j [l' [tk [Phi [Hi [Hj [Haij [Hred [Hle [Hnm Hcb]]]]]]]]]].
  split; [apply (l_aligned_pair_extend l gs g hs alpha Hpre Hlap) |].
  split; [exact Hih |].
  split; [exact Hcov |].
  split; [| exact Hinp].
  exists j, l', tk, Phi.
  split; [rewrite length_app; simpl; lia |].
  split; [exact Hj |].
  split; [exact Haij |].
  split; [rewrite (cfg_at_app1 gs g i Hi); exact Hred |].
  split; [exact Hle |].
  split.
  - rewrite (cfg_at_app1 gs g i Hi). exact Hnm.
  - unfold conformance_below in *.
    rewrite (firstn_app1 _ gs g i ltac:(lia)). exact Hcb.
Qed.

Lemma alignment_failure_at_extend : forall i l ins gs g hs alpha,
  pre_run (gs ++ [g]) ->
  alignment_failure_at i l ins gs hs alpha ->
  alignment_failure_at i l ins (gs ++ [g]) hs alpha.
Proof.
  intros i l ins gs g hs alpha Hpre HAF.
  destruct HAF as [Hih [Hex Hinp]].
  destruct Hex as [j [Hi [Hj [Hann [Hannh [Hneq Hcb]]]]]].
  split; [exact Hih |].
  split; [| exact Hinp].
  exists j.
  split; [rewrite length_app; simpl; lia |].
  split; [exact Hj |].
  split; [rewrite (cfg_at_app1 gs g i Hi); exact Hann |].
  split; [exact Hannh |].
  split.
  - rewrite (cfg_at_app1 gs g i Hi). exact Hneq.
  - unfold conformance_below in *.
    rewrite (firstn_app1 _ gs g i ltac:(lia)). exact Hcb.
Qed.

Lemma divergence_fiat_at_extend : forall i k l ins gs g hs alpha,
  pre_run (gs ++ [g]) ->
  divergence_fiat_at i k l ins gs hs alpha ->
  divergence_fiat_at i k l ins (gs ++ [g]) hs alpha.
Proof.
  intros i k l ins gs g hs alpha Hpre HDF.
  unfold divergence_fiat_at in *.
  destruct HDF as [Hinp [Hik [Hk [Hlap [Hredk [j [Hj [Halpha [Hor [Hmid [Hconf Hex]]]]]]]]]]].
  assert (Hi : i < length gs) by lia.
  split; [exact Hinp |].
  split; [exact Hik |].
  split; [rewrite length_app; simpl; lia |].
  split; [apply (l_aligned_pair_extend l gs g hs alpha Hpre Hlap) |].
  split; [rewrite (cfg_at_app1 gs g k Hk); exact Hredk |].
  exists j.
  split; [exact Hj |].
  split; [exact Halpha |].
  split; [rewrite (cfg_at_app1 gs g i Hi); exact Hor |].
  split; [intros m Hm1 Hm2; rewrite (cfg_at_app1 gs g m ltac:(lia)); apply Hmid; assumption |].
  split; [rewrite (firstn_app1 _ gs g (i+1) ltac:(lia)); exact Hconf |].
  exact Hex.
Qed.

(* -------------------------------------------------------- *)
(* Technical results for classification of major-minor pairs. *)
(* -------------------------------------------------------- *)

(* The four fiat/failure kinds, dispatched by a tag so extendFail can state
   "the same kind persists" in one lemma. *)
Inductive failkind : Type := FK_assumF | FK_assertF | FK_alignF | FK_divF.

Definition fiat_or_failure_at (fk : failkind) (i : nat) (l : Lev) (ins : list event)
                             (gs hs : list config) (alpha : nat -> nat -> Prop) : Prop :=
  match fk with
  | FK_assumF  => assumption_fiat_at   i l ins gs hs alpha
  | FK_assertF => assertion_failure_at i l ins gs hs alpha
  | FK_alignF  => alignment_failure_at i l ins gs hs alpha
  | FK_divF    => exists k, divergence_fiat_at i k l ins gs hs alpha
  end.

Lemma extendFail : forall fk i l ins gs g hs alpha,
  pre_run (gs ++ [g]) ->
  fiat_or_failure_at fk i l ins gs hs alpha ->
  fiat_or_failure_at fk i l ins (gs ++ [g]) hs alpha.
Proof.
  intros fk i l ins gs g hs alpha Hpre H. destruct fk; simpl in *.
  - apply assumption_fiat_at_extend;   assumption.
  - apply assertion_failure_at_extend; assumption.
  - apply alignment_failure_at_extend; assumption.
  - destruct H as [k H]. exists k. apply divergence_fiat_at_extend;   assumption.
Qed.

Inductive category : Type :=
| Cat_conf    : category
| Cat_assertF : category
| Cat_alignF  : category
| Cat_assumF  : category
| Cat_divF    : category.

Definition in_category (cat : category) (l : Lev) (ins : list event)
                       (gs hs : list config) (alpha : nat -> nat -> Prop) : Prop :=
  match cat with
  | Cat_conf    => conformance l ins gs hs alpha
  | Cat_assertF => assertion_failure l ins gs hs alpha
  | Cat_alignF  => alignment_failure l ins gs hs alpha
  | Cat_assumF  => assumption_fiat l ins gs hs alpha
  | Cat_divF    => divergence_fiat l ins gs hs alpha
  end.


(* Base case of classification_exists: the singleton initial pre-run is a
   conformance (trivial alignment {(0,0)}). *)
Lemma classif_base : forall l ins,
  Forall is_input ins ->
  conformance l ins [Receptive initState] [Receptive initState]
              (fun i j => i = 0 /\ j = 0).
Proof.
  intros l ins Hinp. unfold conformance. split.
  - unfold l_aligned_pair. split; [apply pre_run_singleton_init |].
    split; [apply pre_run_singleton_init |].
    unfold proper. split.
    + unfold alignment. split; [| split; [| split]].
      * intros i j [Hi Hj]. subst. simpl. split; lia.
      * intros i j k m [Hi Hj] [Hk Hm]. subst. split; intros; lia.
      * intros i j [j' [Hi Hj']] Hlt. subst. exfalso; lia.
      * intros i j [i' [Hi' Hj]] Hlt. subst. exfalso; lia.
    + intros i j [Hi Hj] _. subst. reflexivity.
  - split.
    + exists []. split; [| split].
      * unfold pr_inputs. exists []. split; [apply AT_init | reflexivity].
      * exists ins. reflexivity.
      * left. unfold covers_dom. intros i Hi. simpl in Hi.
        assert (i = 0) as -> by lia. exists 0. split; reflexivity.
    + split.
      * unfold covers_rng. intros j Hj. simpl in Hj.
        assert (j = 0) as -> by lia. exists 0. split; reflexivity.
      * split.
        -- intros i j l' tk Phi [Hi Hj] Hred Hle. subst. simpl in Hred.
           destruct Hred as [Hr | Hr]; discriminate.
        -- exact Hinp.
Qed.

(* Case A of the classification_exists induction step: extend a conformance that
   is in the "inputs exhausted at a receptive minor" mode by one more major
   config g. The exhausted disjunct does not mention the majors, so it survives
   appending g; the models condition transfers because alpha only relates majors
   below length fs, where reads into fs ++ [g] agree with reads into fs. *)
Lemma conformance_extend_receptive : forall l ins fs g hs alpha,
  pre_run (fs ++ [g]) ->
  conformance l ins fs hs alpha ->
  (exists ih, pr_inputs hs ih /\ ih = ins) ->
  is_receptive (last_cfg hs) ->
  conformance l ins (fs ++ [g]) hs alpha.
Proof.
  intros l ins fs g hs alpha Hpre Hconf Hexh Hrec.
  destruct Hconf as [Hlap [Hih [Hcrng [Hmod Hinp]]]].
  assert (Hbound : forall i j, alpha i j -> i < length fs /\ j < length hs).
  { destruct Hlap as [_ [_ [Halgn _]]]. destruct Halgn as [Hb _]. exact Hb. }
  unfold conformance. split; [| split; [| split; [| split]]].
  - apply (l_aligned_pair_extend l fs g hs alpha Hpre Hlap).
  - destruct Hexh as [ih [Hpr Heq]]. subst ih.
    exists ins. split; [exact Hpr | split].
    + apply list_prefix_refl.
    + right. split; [reflexivity | exact Hrec].
  - exact Hcrng.
  - intros i j l' tk Phi Haij Hred Hle.
    destruct (Hbound i j Haij) as [Hi Hj].
    rewrite (cfg_at_app1 fs g i Hi) in Hred |- *.
    apply (Hmod i j l' tk Phi Haij Hred Hle).
  - exact Hinp.
Qed.

(* The four fiat/failure categories of fs all extend to fs ++ [g]: each is an
   existential over the located version, discharged by the matching *_at_extend
   lemma (the unindexed packaging of lem:extendFail for the induction step). *)
Lemma fiatfail_extend : forall l ins fs g hs alpha,
  pre_run (fs ++ [g]) ->
  (assertion_failure l ins fs hs alpha \/
   alignment_failure l ins fs hs alpha \/
   assumption_fiat l ins fs hs alpha \/
   divergence_fiat l ins fs hs alpha) ->
  (assertion_failure l ins (fs ++ [g]) hs alpha \/
   alignment_failure l ins (fs ++ [g]) hs alpha \/
   assumption_fiat l ins (fs ++ [g]) hs alpha \/
   divergence_fiat l ins (fs ++ [g]) hs alpha).
Proof.
  intros l ins fs g hs alpha Hpre H.
  destruct H as [HF | [HF | [HF | HF]]].
  - left. destruct HF as [i Hat]. exists i.
    apply assertion_failure_at_extend; assumption.
  - right; left. destruct HF as [i Hat]. exists i.
    apply alignment_failure_at_extend; assumption.
  - right; right; left. destruct HF as [i Hat]. exists i.
    apply assumption_fiat_at_extend; assumption.
  - right; right; right. destruct HF as [i [k Hat]]. exists i. exists k.
    apply divergence_fiat_at_extend; assumption.
Qed.


Fact cfg_at_app2 : forall gs g, cfg_at (gs ++ [g]) (length gs) = g.
Proof.
  intros gs g. unfold cfg_at. rewrite app_nth2 by lia.
  rewrite Nat.sub_diag. reflexivity.
Qed.

Fact last_eq_cfg_at : forall hs, hs <> [] -> cfg_at hs (length hs - 1) = last_cfg hs.
Proof.
  intros hs Hne. destruct (exists_last Hne) as [l' [a Ha]]. subst hs.
  unfold cfg_at, last_cfg. rewrite last_last. rewrite length_app. simpl.
  replace (length l' + 1 - 1) with (length l') by lia.
  rewrite app_nth2 by lia. rewrite Nat.sub_diag. reflexivity.
Qed.

Fact redex_assume_annotation : forall l g,
  redex_is_l_assume l g -> redex_is_l_annotation l g.
Proof.
  intros l g H. unfold redex_is_l_assume, redex_is_l_annotation, is_l_annotation in *.
  destruct (redex_of g); [left; exact H | exact H].
Qed.

Fact redex_assert_annotation : forall l g,
  redex_is_l_assert l g -> redex_is_l_annotation l g.
Proof.
  intros l g H. unfold redex_is_l_assert, redex_is_l_annotation, is_l_annotation in *.
  destruct (redex_of g); [right; exact H | exact H].
Qed.

(* Cases B of the classification_exists induction step (paper lines 1088-1096):
   when last(fs) is receptive with a non-visible input, or active with a
   non-l-annotation redex, the major run extends by g and we pair the new major
   index |fs| with the existing top minor index |hs|-1. Both cases reduce to:
   extend a conformance covering fs by the top-corner pair (|fs|, |hs|-1), given
   that g's redex is not an l-annotation (so the new pair imposes no new model
   obligation) and the new pair is assume-compatible (semi-proper). The two
   local side-conditions are discharged by the caller from the case hypotheses. *)
Lemma conformance_extend_pair : forall l ins fs g hs alpha,
  pre_run (fs ++ [g]) ->
  conformance l ins fs hs alpha ->
  covers_dom fs alpha ->
  ~ redex_is_l_annotation l g ->
  ~ redex_is_l_annotation l (last_cfg hs) ->
  conformance l ins (fs ++ [g]) hs
    (fun i j => alpha i j \/ (i = length fs /\ j = length hs - 1)).
Proof.
  intros l ins fs g hs alpha Hpre Hconf Hcov Hnotann Hnotannh.
  destruct Hconf as [Hlap [Hih [Hcrng [Hmod Hinp]]]].
  destruct Hlap as [Hprefs [Hprehs Hwp]].
  destruct Hwp as [[Hbound [Hmono [Hpcd Hpcr]]] Hcoin].
  assert (Hhspos : 0 < length hs) by
    (destruct hs; [exfalso; apply (pre_run_nonempty _ Hprehs); reflexivity | simpl; lia]).
  assert (Hlast : cfg_at hs (length hs - 1) = last_cfg hs) by
    (apply last_eq_cfg_at; destruct hs; [simpl in Hhspos; lia | discriminate]).
  unfold conformance. split; [| split; [| split; [| split]]].
  - (* l_aligned_pair *)
    split; [exact Hpre | split; [exact Hprehs |]].
    split.
    + (* alignment *)
      split; [| split; [| split]].
      * (* bound *)
        intros i j [Ha | [Hi Hj]].
        -- destruct (Hbound i j Ha) as [Hbi Hbj]. rewrite length_app; simpl; lia.
        -- subst. rewrite length_app; simpl; lia.
      * (* monotone *)
        intros i j k m [Ha | [Hi Hj]] [Hb | [Hk Hl]].
        -- apply (Hmono i j k m Ha Hb).
        -- subst k m. destruct (Hbound i j Ha) as [Hbi Hbj].
           split; intros; [lia | lia].
        -- subst i j. destruct (Hbound k m Hb) as [Hbk Hbm].
           split; intros; [lia | lia].
        -- subst. split; intros; lia.
      * (* prefix-closed domain *)
        intros i j [m Hbim] Hlt.
        assert (Hile : i <= length fs).
        { destruct Hbim as [Ha | [Hi _]]; [destruct (Hbound i m Ha); lia | lia]. }
        assert (Hjf : j < length fs) by lia.
        destruct (Hcov j Hjf) as [m' Ham']. exists m'. left. exact Ham'.
      * (* prefix-closed range *)
        intros i j [k Hbki] Hlt.
        assert (Hile : i < length hs).
        { destruct Hbki as [Ha | [_ Hi]]; [destruct (Hbound k i Ha); lia | lia]. }
        assert (Hjh : j < length hs) by lia.
        destruct (Hcrng j Hjh) as [k' Hak']. exists k'. left. exact Hak'.
    + (* proper: redex coincidence at aligned pairs *)
      intros i j Hij Hdisj.
      destruct Hij as [Ha | [Hi Hj]].
      * destruct (Hbound i j Ha) as [Hbi Hbj].
        rewrite (cfg_at_app1 fs g i Hbi) in Hdisj |- *.
        apply (Hcoin i j Ha Hdisj).
      * subst i j. exfalso.
        rewrite (cfg_at_app2 fs g) in Hdisj. rewrite Hlast in Hdisj.
        destruct Hdisj as [H | H].
        -- apply Hnotann. exact H.
        -- apply Hnotannh. exact H.
  - (* inputs clause: use the covers_dom alternative *)
    destruct Hih as [ih [Hpr [Hpre_ins _]]].
    exists ih. split; [exact Hpr | split; [exact Hpre_ins |]].
    left. intros i Hi. rewrite length_app in Hi; simpl in Hi.
    assert (i < length fs \/ i = length fs) as [Hlt | Heq] by lia.
    + destruct (Hcov i Hlt) as [m Ham]. exists m. left. exact Ham.
    + exists (length hs - 1). right. split; [exact Heq | reflexivity].
  - (* covers_rng *)
    intros j Hj. destruct (Hcrng j Hj) as [k Hak]. exists k. left. exact Hak.
  - (* models clause *)
    intros i j l' tk Phi [Ha | [Hi Hj]] Hred Hle.
    + destruct (Hbound i j Ha) as [Hbi Hbj].
      rewrite (cfg_at_app1 fs g i Hbi) in Hred |- *.
      apply (Hmod i j l' tk Phi Ha Hred Hle).
    + subst i j. rewrite (cfg_at_app2 fs g) in Hred.
      exfalso. apply Hnotann. unfold redex_is_l_annotation.
      destruct Hred as [Hr | Hr]; rewrite Hr; simpl; [left | right]; exact Hle.
  - exact Hinp.
Qed.


(* extending a conformance.  
   When growing the minor run hs
   to Hs (hs prefix of Hs) exhausts ins at a receptive last(Hs) WITHOUT passing
   an l-annotation, and last(fs) is receptive, the major index |fs|-1 "stutters"
   to align with every new minor config j in [|hs|, |Hs|). The result is a
   conformance for (fs++[g], Hs) using the inputs-exhausted alternative (g at the
   top major index |fs| is left uncovered). The growth carries no l-assumption,
   so the stutter pairs impose no semi-proper or model obligation. *)
Lemma conformance_extend_stutter : forall l ins fs g hs Hs alpha,
  pre_run (fs ++ [g]) ->
  conformance l ins fs hs alpha ->
  covers_dom fs alpha ->
  ~ redex_is_l_annotation l (cfg_at fs (length fs - 1)) ->
  pre_run Hs ->
  list_prefix hs Hs ->
  pr_inputs Hs ins ->
  is_receptive (last_cfg Hs) ->
  (forall j, length hs <= j -> j < length Hs -> ~ redex_is_l_annotation l (cfg_at Hs j)) ->
  conformance l ins (fs ++ [g]) Hs
    (fun i j => alpha i j \/ (i = length fs - 1 /\ length hs <= j /\ j < length Hs)).
Proof.
  intros l ins fs g hs Hs alpha Hpre Hconf Hcov Hnotannfs HpreHs Hpref Hpr Hrec Hgrowth.
  destruct Hconf as [Hlap [Hih [Hcrng [Hmod Hinp]]]].
  destruct Hlap as [Hprefs [Hprehs Hwp]].
  destruct Hwp as [[Hbound [Hmono [Hpcd Hpcr]]] Hcoin].
  assert (Hhspos : 0 < length hs) by
    (destruct hs; [exfalso; apply (pre_run_nonempty _ Hprehs); reflexivity | simpl; lia]).
  assert (Hfspos : 0 < length fs) by
    (destruct fs; [exfalso; apply (pre_run_nonempty _ Hprefs); reflexivity | simpl; lia]).
  destruct Hpref as [rest HHs].
  assert (Hlenle : length hs <= length Hs) by (rewrite HHs, length_app; lia).
  assert (Hminread : forall j, j < length hs -> cfg_at Hs j = cfg_at hs j) by
    (intros j Hj; rewrite HHs; apply cfg_at_prefix; exact Hj).
  assert (Hminfirstn : forall n, n <= length hs -> firstn n Hs = firstn n hs) by
    (intros n Hn; rewrite HHs; apply firstn_prefix; exact Hn).
  unfold conformance. split; [| split; [| split; [| split]]].
  - (* l_aligned_pair *)
    split; [exact Hpre | split; [exact HpreHs |]].
    split.
    + (* alignment *)
      split; [| split; [| split]].
      * (* bound *)
        intros i j [Ha | [Hi [Hj1 Hj2]]].
        -- destruct (Hbound i j Ha) as [Hbi Hbj]. rewrite length_app; simpl. split; lia.
        -- subst i. rewrite length_app; simpl. split; lia.
      * (* monotone *)
        intros i j k m [Ha | [Hi [Hj1 Hj2]]] [Hb | [Hk [Hm1 Hm2]]].
        -- apply (Hmono i j k m Ha Hb).
        -- subst k. destruct (Hbound i j Ha) as [Hbi Hbj]. split; intros; lia.
        -- subst i. destruct (Hbound k m Hb) as [Hbk Hbm]. split; intros; lia.
        -- subst i k. split; intros; lia.
      * (* prefix-closed domain *)
        intros i j [w Hbiw] Hlt.
        assert (Hile : i <= length fs - 1).
        { destruct Hbiw as [Ha | [Hi _]]; [destruct (Hbound i w Ha); lia | lia]. }
        assert (Hjf : j < length fs) by lia.
        destruct (Hcov j Hjf) as [m' Ham']. exists m'. left. exact Ham'.
      * (* prefix-closed range *)
        intros i j [w Hbwi] Hlt.
        destruct Hbwi as [Ha | [_ [Hi1 Hi2]]].
        -- destruct (Hbound w i Ha) as [_ Hbi].
           assert (Hjh : j < length hs) by lia.
           destruct (Hcrng j Hjh) as [k' Hak']. exists k'. left. exact Hak'.
        -- destruct (le_lt_dec (length hs) j) as [Hjge | Hjlt].
           ++ exists (length fs - 1). right. split; [reflexivity | split; [exact Hjge | lia]].
           ++ destruct (Hcrng j Hjlt) as [k' Hak']. exists k'. left. exact Hak'.
    + (* proper: redex coincidence at aligned pairs *)
      intros i j Hij Hdisj.
      destruct Hij as [Ha | [Hi [Hj1 Hj2]]].
      * destruct (Hbound i j Ha) as [Hbi Hbj].
        rewrite (cfg_at_app1 fs g i Hbi) in Hdisj |- *.
        rewrite (Hminread j Hbj) in Hdisj |- *.
        apply (Hcoin i j Ha Hdisj).
      * subst i. exfalso.
        rewrite (cfg_at_app1 fs g (length fs - 1) ltac:(lia)) in Hdisj.
        destruct Hdisj as [H | H].
        -- apply Hnotannfs. exact H.
        -- apply (Hgrowth j Hj1 Hj2). exact H.
  - (* inputs clause: exhausted alternative *)
    exists ins. split; [exact Hpr | split; [apply list_prefix_refl |]].
    right. split; [reflexivity | exact Hrec].
  - (* covers_rng *)
    intros j Hj. destruct (le_lt_dec (length hs) j) as [Hjge | Hjlt].
    + exists (length fs - 1). right. split; [reflexivity | split; [exact Hjge | exact Hj]].
    + destruct (Hcrng j Hjlt) as [k Hak]. exists k. left. exact Hak.
  - (* models clause *)
    intros i j l' tk Phi [Ha | [Hi [Hj1 Hj2]]] Hred Hle.
    + destruct (Hbound i j Ha) as [Hbi Hbj].
      rewrite (cfg_at_app1 fs g i Hbi) in Hred |- *.
      rewrite (Hminread j Hbj).
      apply (Hmod i j l' tk Phi Ha Hred Hle).
    + subst i. rewrite (cfg_at_app1 fs g (length fs - 1) ltac:(lia)) in Hred.
      exfalso. apply Hnotannfs. unfold redex_is_l_annotation.
      destruct Hred as [Hr | Hr]; rewrite Hr; simpl; [left | right]; exact Hle.
  - exact Hinp.
Qed.

(* extending a conformance to one with a matched annotation *) 
Lemma conformance_extend_annot : forall l ins fs g hs Hs alpha,
  pre_run (fs ++ [g]) ->
  conformance l ins fs hs alpha ->
  covers_dom fs alpha ->
  ~ redex_is_l_annotation l (cfg_at fs (length fs - 1)) ->
  pre_run Hs ->
  list_prefix hs Hs ->
  (exists ih, pr_inputs Hs ih /\ list_prefix ih ins) ->
  (forall j, length hs <= j -> j < length Hs - 1 -> ~ redex_is_l_annotation l (cfg_at Hs j)) ->
  redex_of g = redex_of (last_cfg Hs) ->
  (forall l' tk Phi, (redex_of g = Some (Cassume l' tk Phi) \/ redex_of g = Some (Cassert l' tk Phi)) ->
     lleq l' l -> models_prerun (fs ++ [g]) Hs Phi) ->
  conformance l ins (fs ++ [g]) Hs
    (fun i j => alpha i j
                \/ (i = length fs - 1 /\ length hs <= j /\ j < length Hs - 1)
                \/ (i = length fs /\ j = length Hs - 1)).
Proof.
  intros l ins fs g hs Hs alpha Hpre Hconf Hcov Hnotannfs HpreHs Hpref Hinputs
         Hgrowth Hredeq Htopmodels.
  destruct Hconf as [Hlap [Hih [Hcrng [Hmod Hinp]]]].
  destruct Hlap as [Hprefs [Hprehs Hwp]].
  destruct Hwp as [[Hbound [Hmono [Hpcd Hpcr]]] Hcoin].
  assert (Hhspos : 0 < length hs) by
    (destruct hs; [exfalso; apply (pre_run_nonempty _ Hprehs); reflexivity | simpl; lia]).
  assert (Hfspos : 0 < length fs) by
    (destruct fs; [exfalso; apply (pre_run_nonempty _ Hprefs); reflexivity | simpl; lia]).
  assert (HHsne : Hs <> []) by (apply pre_run_nonempty; exact HpreHs).
  assert (HHspos : 0 < length Hs) by (destruct Hs; [contradiction | simpl; lia]).
  destruct Hpref as [rest HHs].
  assert (Hlenle : length hs <= length Hs) by (rewrite HHs, length_app; lia).
  assert (Hminread : forall j, j < length hs -> cfg_at Hs j = cfg_at hs j) by
    (intros j Hj; rewrite HHs; apply cfg_at_prefix; exact Hj).
  assert (Hminfirstn : forall n, n <= length hs -> firstn n Hs = firstn n hs) by
    (intros n Hn; rewrite HHs; apply firstn_prefix; exact Hn).
  assert (Hlastread : cfg_at Hs (length Hs - 1) = last_cfg Hs) by
    (apply last_eq_cfg_at; exact HHsne).
  unfold conformance. split; [| split; [| split; [| split]]].
  - (* l_aligned_pair *)
    split; [exact Hpre | split; [exact HpreHs |]].
    split.
    + (* alignment *)
      split; [| split; [| split]].
      * (* bound *)
        intros i j [Ha | [[Hi [Hja Hjb]] | [Hi Hj]]].
        -- destruct (Hbound i j Ha) as [Hbi Hbj]. rewrite length_app; simpl. split; lia.
        -- subst i. rewrite length_app; simpl. split; lia.
        -- subst i j. rewrite length_app; simpl. split; lia.
      * (* monotone *)
        intros i j k m HG1 HG2.
        destruct HG1 as [Ha1 | [[Hi1 [Hja1 Hjb1]] | [Hi1 Hj1]]];
        destruct HG2 as [Ha2 | [[Hi2 [Hja2 Hjb2]] | [Hi2 Hj2]]];
        try (apply (Hmono i j k m Ha1 Ha2));
        repeat match goal with
               | [ H : alpha ?x ?y |- _ ] => apply Hbound in H; destruct H
               end;
        subst; split; intros; lia.
      * (* prefix-closed domain *)
        intros i j [w Hbiw] Hlt.
        assert (Hile : i <= length fs).
        { destruct Hbiw as [Ha | [[Hi _] | [Hi _]]];
            [destruct (Hbound i w Ha); lia | lia | lia]. }
        assert (Hjf : j < length fs) by lia.
        destruct (Hcov j Hjf) as [m' Ham']. exists m'. left. exact Ham'.
      * (* prefix-closed range *)
        intros i j [w Hbwi] Hlt.
        assert (Hii : i < length Hs).
        { destruct Hbwi as [Ha | [[_ [_ Hi2]] | [_ Hi2]]];
            [destruct (Hbound w i Ha); lia | lia | lia]. }
        destruct (le_lt_dec (length hs) j) as [Hjge | Hjlt].
        -- exists (length fs - 1). right. left. split; [reflexivity | split; [exact Hjge | lia]].
        -- destruct (Hcrng j Hjlt) as [k' Hak']. exists k'. left. exact Hak'.
    + (* proper: redex coincidence at aligned pairs *)
      intros i j Hij Hdisj.
      destruct Hij as [Ha | [[Hi [Hja Hjb]] | [Hi Hj]]].
      * destruct (Hbound i j Ha) as [Hbi Hbj].
        rewrite (cfg_at_app1 fs g i Hbi) in Hdisj |- *.
        rewrite (Hminread j Hbj) in Hdisj |- *.
        apply (Hcoin i j Ha Hdisj).
      * subst i. exfalso.
        rewrite (cfg_at_app1 fs g (length fs - 1) ltac:(lia)) in Hdisj.
        destruct Hdisj as [H | H].
        -- apply Hnotannfs. exact H.
        -- apply (Hgrowth j Hja Hjb). exact H.
      * subst i j. rewrite (cfg_at_app2 fs g). rewrite Hlastread. exact Hredeq.
  - (* inputs clause: covers_dom alternative (the new alignment covers fs++[g]) *)
    destruct Hinputs as [ih [Hpr Hpre_ins]].
    exists ih. split; [exact Hpr | split; [exact Hpre_ins |]].
    left. intros i Hi. rewrite length_app in Hi; simpl in Hi.
    destruct (le_lt_dec (length fs) i) as [Hge | Hlt].
    + exists (length Hs - 1). right. right. split; [lia | reflexivity].
    + destruct (Hcov i Hlt) as [m Ham]. exists m. left. exact Ham.
  - (* covers_rng *)
    intros j Hj. destruct (le_lt_dec (length hs) j) as [Hjge | Hjlt].
    + destruct (le_lt_dec (length Hs - 1) j) as [Htop | Hstut].
      * exists (length fs). right. right. split; [reflexivity | lia].
      * exists (length fs - 1). right. left. split; [reflexivity | split; [exact Hjge | exact Hstut]].
    + destruct (Hcrng j Hjlt) as [k Hak]. exists k. left. exact Hak.
  - (* models clause *)
    intros i j l' tk Phi [Ha | [[Hi [Hja Hjb]] | [Hi Hj]]] Hred Hle.
    + destruct (Hbound i j Ha) as [Hbi Hbj].
      rewrite (cfg_at_app1 fs g i Hbi) in Hred |- *.
      rewrite (Hminread j Hbj).
      apply (Hmod i j l' tk Phi Ha Hred Hle).
    + subst i. rewrite (cfg_at_app1 fs g (length fs - 1) ltac:(lia)) in Hred.
      exfalso. apply Hnotannfs. unfold redex_is_l_annotation.
      destruct Hred as [Hr | Hr]; rewrite Hr; simpl; [left | right]; exact Hle.
    + subst i j. rewrite (cfg_at_app2 fs g) in Hred.
      assert (Hglast : cfg_at (fs ++ [g]) (length fs) = last_cfg (fs ++ [g])) by
        (rewrite cfg_at_app2; unfold last_cfg; rewrite last_last; reflexivity).
      rewrite Hglast, Hlastread.
      exact (Htopmodels l' tk Phi Hred Hle).
  - exact Hinp.
Qed.

Fact admits_trace_firstn : forall gs evs n,
  admits_trace gs evs -> 0 < n -> n <= length gs -> pre_run (firstn n gs).
Proof.
  intros gs evs n H. revert n. induction H as [| gs evs ev g Hat IH Hstep];
    intros n Hn Hnle.
  - simpl in Hnle. assert (n = 1) by lia. subst n. exists []. apply AT_init.
  - rewrite length_app in Hnle. simpl in Hnle.
    destruct (Nat.le_gt_cases n (length gs)) as [Hle | Hgt].
    + rewrite (firstn_app1 config gs g n Hle). apply IH; [exact Hn | exact Hle].
    + assert (Hneq : n = length (gs ++ [g])) by (rewrite length_app; simpl; lia).
      rewrite Hneq, firstn_all. exists (evs ++ [ev]). apply AT_step; assumption.
Qed.

Fact pre_run_firstn : forall gs n,
  pre_run gs -> 0 < n -> n <= length gs -> pre_run (firstn n gs).
Proof.
  intros gs n [evs Hat] Hn Hnle. apply (admits_trace_firstn gs evs n Hat Hn Hnle).
Qed.

(* Divergent family: an annotation-free pre-run extension of every length. *)
Definition diverge_family (l : Lev) (ins : list event)
                          (hs : list config) (ih : list event) : Prop :=
  exists (E : nat -> list config) (ihe : nat -> list event),
    forall n,
      length (E n) = n /\
      pre_run (hs ++ E n) /\
      pr_inputs (hs ++ E n) (ih ++ ihe n) /\
      list_prefix (ih ++ ihe n) ins /\
      (forall m, m < n -> ~ redex_is_l_annotation l (cfg_at (E n) m) /\
                          ~ redex_is_l_output l (cfg_at (E n) m)).

(* Restricting a proper alignment to major indices <= i, then reading the major
   from a list X that agrees with fs below i+1, is still proper. *)
Lemma proper_restrict_le : forall l fs hs alpha i (X : list config),
  proper l fs hs alpha ->
  i < length fs ->
  (forall a, a <= i -> a < length X) ->
  (forall a, a <= i -> cfg_at X a = cfg_at fs a) ->
  proper l X hs (fun a b => alpha a b /\ a <= i).
Proof.
  intros l fs hs alpha i X [Halgn Hcoin] Hilt HXlen Hread.
  destruct Halgn as [Hbound [Hmono [Hpcd Hpcr]]].
  split.
  - split; [| split; [| split]].
    + intros a b [Hab Hai]. split.
      * apply HXlen; exact Hai.
      * exact (proj2 (Hbound a b Hab)).
    + intros a b c d [Hab Hai] [Hcd Hci]. apply (Hmono a b c d Hab Hcd).
    + intros a c Hda Hca. destruct Hda as [b [Hab Hai]].
      assert (Hci : c <= i) by lia.
      destruct (Hpcd a c (ex_intro _ b Hab) Hca) as [d Hcd].
      exists d. split; [exact Hcd | exact Hci].
    + intros b d Hrb Hdb. destruct Hrb as [a [Hab Hai]].
      destruct (Hpcr b d (ex_intro _ a Hab) Hdb) as [c Hcd].
      assert (Hcle : c <= a) by (apply (proj2 (Hmono c d a b Hcd Hab)); exact Hdb).
      exists c. split; [exact Hcd | lia].
  - intros a b [Hab Hai] Hannot.
    rewrite (Hread a Hai) in Hannot.
    rewrite (Hread a Hai).
    apply (Hcoin a b Hab). exact Hannot.
Qed.


(* The initial segment dropping the last config of a pre-run is a pre-run. *)
Lemma pre_run_firstn_pred : forall Hs,
  pre_run Hs -> 1 < length Hs -> pre_run (firstn (length Hs - 1) Hs).
Proof.
  intros Hs [evs Hat] Hlen.
  assert (Hevlen : length evs = length Hs - 1) by (apply admits_trace_length in Hat; lia).
  assert (Hne : evs <> []) by (intro Hc; subst evs; simpl in Hevlen; lia).
  destruct (exists_last Hne) as [evs' [ev Hevs]]. subst evs.
  apply admits_trace_snoc_inv in Hat.
  destruct Hat as [Hs_pre [gg [HHs Hatpre]]].
  assert (Hlenpre : length Hs - 1 = length Hs_pre) by
    (subst Hs; rewrite length_app; simpl; lia).
  rewrite Hlenpre, HHs.
  rewrite (firstn_app1 config Hs_pre gg (length Hs_pre)) by lia.
  rewrite firstn_all. exists evs'. exact Hatpre.
Qed.

(* extending a conformance towards an alignment failure *) 
Lemma conformance_below_annot : forall l ins fs hs Hs alpha,
  conformance l ins fs hs alpha ->
  covers_dom fs alpha ->
  ~ redex_is_l_annotation l (cfg_at fs (length fs - 1)) ->
  pre_run Hs ->
  list_prefix hs Hs ->
  1 < length Hs ->
  length hs <= length Hs - 1 ->
  (exists ih, pr_inputs (firstn (length Hs - 1) Hs) ih /\ list_prefix ih ins) ->
  (forall m, length hs <= m -> m < length Hs - 1 -> ~ redex_is_l_annotation l (cfg_at Hs m)) ->
  conformance l ins fs (firstn (length Hs - 1) Hs)
    (fun k m => (alpha k m /\ m < length Hs - 1)
                \/ (k = length fs - 1 /\ length hs <= m /\ m < length Hs - 1))
  /\ covers_dom fs
    (fun k m => (alpha k m /\ m < length Hs - 1)
                \/ (k = length fs - 1 /\ length hs <= m /\ m < length Hs - 1)).
Proof.
  intros l ins fs hs Hs alpha Hconf Hcov Hnotannfs HpreHs Hpref Hbig Hgrow Hinputs Hgrowth.
  destruct Hconf as [Hlap [Hih0 [Hcrng [Hmod Hinp]]]].
  destruct Hlap as [Hprefs [Hprehs Hwp]].
  destruct Hwp as [[Hbound [Hmono [Hpcd Hpcr]]] Hcoin].
  assert (Hfspos : 0 < length fs) by
    (destruct fs; [exfalso; apply (pre_run_nonempty _ Hprefs); reflexivity | simpl; lia]).
  assert (HMlen : length (firstn (length Hs - 1) Hs) = length Hs - 1) by
    (apply firstn_length_le; lia).
  assert (HpreMs : pre_run (firstn (length Hs - 1) Hs)) by
    (apply pre_run_firstn_pred; [exact HpreHs | exact Hbig]).
  destruct Hpref as [rest HHs].
  assert (Hread : forall m, m < length hs ->
            cfg_at (firstn (length Hs - 1) Hs) m = cfg_at hs m).
  { intros m Hm. rewrite cfg_at_firstn by lia. rewrite HHs. apply cfg_at_prefix. exact Hm. }
  assert (Hreadgrow : forall m, m < length Hs - 1 ->
            cfg_at (firstn (length Hs - 1) Hs) m = cfg_at Hs m).
  { intros m Hm. apply cfg_at_firstn. exact Hm. }
  assert (Hfst : forall n, n <= length hs ->
            firstn n (firstn (length Hs - 1) Hs) = firstn n hs).
  { intros n Hn. rewrite firstn_firstn. replace (min n (length Hs - 1)) with n by lia.
    rewrite HHs. apply firstn_prefix. exact Hn. }
  assert (Hcovs : covers_dom fs
            (fun k m => (alpha k m /\ m < length Hs - 1)
                        \/ (k = length fs - 1 /\ length hs <= m /\ m < length Hs - 1))).
  { intros k Hk. destruct (Hcov k Hk) as [m Hm]. destruct (Hbound k m Hm) as [_ Hmb].
    exists m. left. split; [exact Hm | lia]. }
  split.
  - (* conformance l ins fs (firstn ..) sigma *)
    unfold conformance. split; [| split; [| split; [| split]]].
    + (* l_aligned_pair *)
      split; [exact Hprefs | split; [exact HpreMs |]].
      split.
      * (* alignment *)
        split; [| split; [| split]].
        -- (* bound *)
           intros a b Hab. rewrite HMlen.
           destruct Hab as [[Ha Hb] | [Hi [Hj1 Hj2]]].
           ++ destruct (Hbound a b Ha) as [Hba Hbb]. split; lia.
           ++ subst a. split; lia.
        -- (* monotone *)
           intros a b c d HG1 HG2.
           destruct HG1 as [[Ha1 Hb1] | [Hi1 [Hj1a Hj1b]]];
           destruct HG2 as [[Ha2 Hb2] | [Hi2 [Hj2a Hj2b]]];
           try (apply (Hmono a b c d Ha1 Ha2));
           repeat match goal with
                  | [ H : alpha ?x ?y |- _ ] => apply Hbound in H; destruct H
                  end;
           subst; split; intros; lia.
        -- (* prefix-closed domain *)
           intros a b [w Hw] Hlt.
           assert (Hale : a < length fs) by
             (destruct Hw as [[Ha _] | [Hi _]]; [apply Hbound in Ha; lia | lia]).
           exact (Hcovs b ltac:(lia)).
        -- (* prefix-closed range *)
           intros a b [w Hw] Hlt.
           assert (Hai : a < length Hs - 1) by
             (destruct Hw as [[_ Hb] | [_ [_ Hb]]]; lia).
           destruct (le_lt_dec (length hs) b) as [Hge | Hlt2].
           ++ exists (length fs - 1). right. split; [reflexivity | split; [exact Hge | lia]].
           ++ destruct (Hcrng b Hlt2) as [k Hk]. exists k. left. split; [exact Hk | lia].
      * (* proper: redex coincidence at aligned pairs *)
        intros a b Hab Hdisj.
        destruct Hab as [[Ha Hb] | [Hi [Hj1 Hj2]]].
        -- destruct (Hbound a b Ha) as [Hba Hbb].
           rewrite (Hread b Hbb) in Hdisj |- *.
           apply (Hcoin a b Ha Hdisj).
        -- subst a. exfalso.
           rewrite (Hreadgrow b Hj2) in Hdisj.
           destruct Hdisj as [H | H].
           ++ apply Hnotannfs. exact H.
           ++ apply (Hgrowth b Hj1 Hj2). exact H.
    + (* inputs clause *)
      destruct Hinputs as [ih [Hpr Hpre_ins]].
      exists ih. split; [exact Hpr | split; [exact Hpre_ins | left; exact Hcovs]].
    + (* covers_rng *)
      intros b Hb. rewrite HMlen in Hb.
      destruct (le_lt_dec (length hs) b) as [Hge | Hlt].
      * exists (length fs - 1). right. split; [reflexivity | split; [exact Hge | exact Hb]].
      * destruct (Hcrng b Hlt) as [k Hk]. exists k. left. split; [exact Hk | lia].
    + (* models clause *)
      intros a b l' tk Phi Hab Hred Hle.
      destruct Hab as [[Ha Hb] | [Hi [Hj1 Hj2]]].
      * destruct (Hbound a b Ha) as [Hba Hbb].
        rewrite (Hread b Hbb).
        apply (Hmod a b l' tk Phi Ha Hred Hle).
      * subst a. exfalso. apply Hnotannfs. unfold redex_is_l_annotation.
        destruct Hred as [Hr | Hr]; rewrite Hr; simpl; [left | right]; exact Hle.
    + exact Hinp.
  - exact Hcovs.
Qed.

(* The inputs of the truncated pre-run are a prefix of the inputs of the whole. *)
Lemma pr_inputs_firstn_pred : forall Hs ih,
  1 < length Hs -> pr_inputs Hs ih ->
  exists ih', pr_inputs (firstn (length Hs - 1) Hs) ih' /\ list_prefix ih' ih.
Proof.
  intros Hs ih Hbig [th [Hat Hin]].
  assert (Hthlen : length th = length Hs - 1) by (apply admits_trace_length in Hat; lia).
  assert (Hne : th <> []) by (intro Hc; subst th; simpl in Hthlen; lia).
  destruct (exists_last Hne) as [th' [ev Hth]]. subst th.
  apply admits_trace_snoc_inv in Hat. destruct Hat as [Hs_pre [gg [HHs Hatpre]]].
  assert (Hlenpre : length Hs - 1 = length Hs_pre) by
    (subst Hs; rewrite length_app; simpl; lia).
  exists (inputs th'). split.
  - rewrite Hlenpre, HHs.
    rewrite (firstn_app1 config Hs_pre gg (length Hs_pre)) by lia. rewrite firstn_all.
    exists th'. split; [exact Hatpre | reflexivity].
  - exists (filter is_input_b [ev]). rewrite <- Hin. unfold inputs. rewrite filter_app. reflexivity.
Qed.

Lemma annot_aligned : forall l ins fs g hs Hs alpha,
  pre_run (fs ++ [g]) ->
  conformance l ins fs hs alpha ->
  covers_dom fs alpha ->
  ~ redex_is_l_annotation l (cfg_at fs (length fs - 1)) ->
  pre_run Hs ->
  list_prefix hs Hs ->
  0 < length Hs ->
  (forall j, length hs <= j -> j < length Hs - 1 -> ~ redex_is_l_annotation l (cfg_at Hs j)) ->
  redex_of g = redex_of (last_cfg Hs) ->
  l_aligned_pair l (fs ++ [g]) Hs
    (fun i j => alpha i j
                \/ (i = length fs - 1 /\ length hs <= j /\ j < length Hs - 1)
                \/ (i = length fs /\ j = length Hs - 1))
  /\ covers_rng Hs
    (fun i j => alpha i j
                \/ (i = length fs - 1 /\ length hs <= j /\ j < length Hs - 1)
                \/ (i = length fs /\ j = length Hs - 1)).
Proof.
  intros l ins fs g hs Hs alpha Hpre Hconf Hcov Hnotannfs HpreHs Hpref HHspos
         Hgrowth Hredeq.
  destruct Hconf as [Hlap [Hih [Hcrng [Hmod _]]]].
  destruct Hlap as [Hprefs [Hprehs Hwp]].
  destruct Hwp as [[Hbound [Hmono [Hpcd Hpcr]]] Hcoin].
  assert (Hfspos : 0 < length fs) by
    (destruct fs; [exfalso; apply (pre_run_nonempty _ Hprefs); reflexivity | simpl; lia]).
  assert (HHsne : Hs <> []) by (apply pre_run_nonempty; exact HpreHs).
  destruct Hpref as [rest HHs].
  assert (Hlenle : length hs <= length Hs) by (rewrite HHs, length_app; lia).
  assert (Hminread : forall j, j < length hs -> cfg_at Hs j = cfg_at hs j) by
    (intros j Hj; rewrite HHs; apply cfg_at_prefix; exact Hj).
  assert (Hlastread : cfg_at Hs (length Hs - 1) = last_cfg Hs) by
    (apply last_eq_cfg_at; exact HHsne).
  split.
  - (* l_aligned_pair *)
    split; [exact Hpre | split; [exact HpreHs |]].
    split.
    + (* alignment *)
      split; [| split; [| split]].
      * intros i j [Ha | [[Hi [Hja Hjb]] | [Hi Hj]]].
        -- destruct (Hbound i j Ha) as [Hbi Hbj]. rewrite length_app; simpl. split; lia.
        -- subst i. rewrite length_app; simpl. split; lia.
        -- subst i j. rewrite length_app; simpl. split; lia.
      * intros i j k m HG1 HG2.
        destruct HG1 as [Ha1 | [[Hi1 [Hja1 Hjb1]] | [Hi1 Hj1]]];
        destruct HG2 as [Ha2 | [[Hi2 [Hja2 Hjb2]] | [Hi2 Hj2]]];
        try (apply (Hmono i j k m Ha1 Ha2));
        repeat match goal with
               | [ H : alpha ?x ?y |- _ ] => apply Hbound in H; destruct H
               end;
        subst; split; intros; lia.
      * intros i j [w Hbiw] Hlt.
        assert (Hile : i <= length fs).
        { destruct Hbiw as [Ha | [[Hi _] | [Hi _]]];
            [destruct (Hbound i w Ha); lia | lia | lia]. }
        assert (Hjf : j < length fs) by lia.
        destruct (Hcov j Hjf) as [m' Ham']. exists m'. left. exact Ham'.
      * intros i j [w Hbwi] Hlt.
        assert (Hii : i < length Hs).
        { destruct Hbwi as [Ha | [[_ [_ Hi2]] | [_ Hi2]]];
            [destruct (Hbound w i Ha); lia | lia | lia]. }
        destruct (le_lt_dec (length hs) j) as [Hjge | Hjlt].
        -- exists (length fs - 1). right. left. split; [reflexivity | split; [exact Hjge | lia]].
        -- destruct (Hcrng j Hjlt) as [k' Hak']. exists k'. left. exact Hak'.
    + (* proper: redex coincidence at aligned pairs *)
      intros i j Hij Hdisj.
      destruct Hij as [Ha | [[Hi [Hja Hjb]] | [Hi Hj]]].
      * destruct (Hbound i j Ha) as [Hbi Hbj].
        rewrite (cfg_at_app1 fs g i Hbi) in Hdisj |- *.
        rewrite (Hminread j Hbj) in Hdisj |- *.
        apply (Hcoin i j Ha Hdisj).
      * subst i. exfalso.
        rewrite (cfg_at_app1 fs g (length fs - 1) ltac:(lia)) in Hdisj.
        destruct Hdisj as [H | H].
        -- apply Hnotannfs. exact H.
        -- apply (Hgrowth j Hja Hjb). exact H.
      * subst i j. rewrite (cfg_at_app2 fs g). rewrite Hlastread. exact Hredeq.
  - (* covers_rng *)
    intros j Hj. destruct (le_lt_dec (length hs) j) as [Hjge | Hjlt].
    + destruct (le_lt_dec (length Hs - 1) j) as [Htop | Hstut].
      * exists (length fs). right. right. split; [reflexivity | lia].
      * exists (length fs - 1). right. left. split; [reflexivity | split; [exact Hjge | exact Hstut]].
    + destruct (Hcrng j Hjlt) as [k Hak]. exists k. left. exact Hak.
Qed.

Lemma annot_conformance_below : forall l ins fs g hs Hs alpha,
  conformance l ins fs hs alpha ->
  covers_dom fs alpha ->
  ~ redex_is_l_annotation l (cfg_at fs (length fs - 1)) ->
  pre_run Hs ->
  list_prefix hs Hs ->
  1 < length Hs ->
  length hs <= length Hs - 1 ->
  (exists ih, pr_inputs Hs ih /\ list_prefix ih ins) ->
  (forall j, length hs <= j -> j < length Hs - 1 -> ~ redex_is_l_annotation l (cfg_at Hs j)) ->
  conformance_below l ins (fs ++ [g]) Hs
    (fun i j => alpha i j
                \/ (i = length fs - 1 /\ length hs <= j /\ j < length Hs - 1)
                \/ (i = length fs /\ j = length Hs - 1))
    (length fs) (length Hs - 1).
Proof.
  intros l ins fs g hs Hs alpha Hconf Hcov Hnotannfs HpreHs Hpref Hbig Hgrow Hinputs Hgrowth.
  assert (Hfspos : 0 < length fs).
  { destruct Hconf as [[Hpf _] _]. destruct fs;
      [exfalso; apply (pre_run_nonempty _ Hpf); reflexivity | simpl; lia]. }
  assert (Hbound : forall a b, alpha a b -> a < length fs /\ b < length hs).
  { destruct Hconf as [[_ [_ [[Hb _] _]]] _]. exact Hb. }
  assert (Hinputs' : exists ih, pr_inputs (firstn (length Hs - 1) Hs) ih /\ list_prefix ih ins).
  { destruct Hinputs as [ih [Hpr Hple]].
    destruct (pr_inputs_firstn_pred Hs ih Hbig Hpr) as [ih' [Hpr' Hple']].
    exists ih'. split; [exact Hpr' | apply (list_prefix_trans _ ih' ih ins Hple' Hple)]. }
  assert (Hff : firstn (length fs) (fs ++ [g]) = fs).
  { rewrite (firstn_app1 config fs g (length fs)) by lia. apply firstn_all. }
  assert (Hbeq : alignment_below (fun i j => alpha i j
                   \/ (i = length fs - 1 /\ length hs <= j /\ j < length Hs - 1)
                   \/ (i = length fs /\ j = length Hs - 1)) (length fs) (length Hs - 1)
                 = (fun k m => (alpha k m /\ m < length Hs - 1)
                               \/ (k = length fs - 1 /\ length hs <= m /\ m < length Hs - 1))).
  { apply functional_extensionality; intro a.
    apply functional_extensionality; intro b.
    apply propositional_extensionality. unfold alignment_below. split.
    - intros [Hg [Hak Hbm]]. destruct Hg as [Ha | [Hst | [Htop1 Htop2]]].
      + left. split; [exact Ha | exact Hbm].
      + right. exact Hst.
      + lia.
    - intros [[Ha Hbm] | [Hk [Hm1 Hm2]]].
      + destruct (Hbound a b Ha) as [Hak _].
        split; [left; exact Ha | split; [exact Hak | exact Hbm]].
      + split; [right; left; split; [exact Hk | split; [exact Hm1 | exact Hm2]] | split; lia]. }
  unfold conformance_below. rewrite Hff, Hbeq.
  apply conformance_below_annot; assumption.
Qed.

Lemma conformance_extend_assumefail : forall l ins fs g hs Hs alpha l0 tk Phi,
  pre_run (fs ++ [g]) ->
  conformance l ins fs hs alpha ->
  covers_dom fs alpha ->
  ~ redex_is_l_annotation l (cfg_at fs (length fs - 1)) ->
  pre_run Hs ->
  list_prefix hs Hs ->
  1 < length Hs ->
  length hs <= length Hs - 1 ->
  (exists ih, pr_inputs Hs ih /\ list_prefix ih ins) ->
  (forall j, length hs <= j -> j < length Hs - 1 -> ~ redex_is_l_annotation l (cfg_at Hs j)) ->
  redex_of g = redex_of (last_cfg Hs) ->
  redex_of g = Some (Cassume l0 tk Phi) ->
  lleq l0 l ->
  ~ models_prerun (fs ++ [g]) Hs Phi ->
  assumption_fiat l ins (fs ++ [g]) Hs
    (fun i j => alpha i j
                \/ (i = length fs - 1 /\ length hs <= j /\ j < length Hs - 1)
                \/ (i = length fs /\ j = length Hs - 1)).
Proof.
  intros l ins fs g hs Hs alpha l0 tk Phi Hpre Hconf Hcov Hnotannfs HpreHs Hpref Hbig Hgrow
         Hinputs Hgrowth Hredeq Hredg Hle Hnm.
  assert (Hinp : Forall is_input ins) by (apply (conformance_inputs l ins fs hs alpha); exact Hconf).
  assert (HHspos : 0 < length Hs) by lia.
  destruct (annot_aligned l ins fs g hs Hs alpha Hpre Hconf Hcov Hnotannfs HpreHs Hpref
              HHspos Hgrowth Hredeq) as [Hlapg Hcrngg].
  exists (length fs).
  split; [exact Hlapg |].
  split; [exact Hinputs |].
  split; [exact Hcrngg |].
  split; [| exact Hinp].
  exists (length Hs - 1), l0, tk, Phi.
  split; [rewrite length_app; simpl; lia |].
  split; [reflexivity |].
  split; [right; right; split; reflexivity |].
  split; [rewrite (cfg_at_app2 fs g); exact Hredg |].
  split; [exact Hle |].
  split.
  - rewrite (cfg_at_app2 fs g).
    assert (HHsne : Hs <> []) by (intro Hc; rewrite Hc in HHspos; simpl in HHspos; lia).
    rewrite (last_eq_cfg_at Hs HHsne).
    unfold models_prerun in Hnm.
    assert (Hlfg : last_cfg (fs ++ [g]) = g) by (unfold last_cfg; rewrite last_last; reflexivity).
    rewrite Hlfg in Hnm. exact Hnm.
  - apply (annot_conformance_below l ins fs g hs Hs alpha Hconf Hcov Hnotannfs HpreHs
             Hpref Hbig Hgrow Hinputs Hgrowth).
Qed.

Lemma conformance_extend_assertfail : forall l ins fs g hs Hs alpha l0 tk Phi,
  pre_run (fs ++ [g]) ->
  conformance l ins fs hs alpha ->
  covers_dom fs alpha ->
  ~ redex_is_l_annotation l (cfg_at fs (length fs - 1)) ->
  pre_run Hs ->
  list_prefix hs Hs ->
  1 < length Hs ->
  length hs <= length Hs - 1 ->
  (exists ih, pr_inputs Hs ih /\ list_prefix ih ins) ->
  (forall j, length hs <= j -> j < length Hs - 1 -> ~ redex_is_l_annotation l (cfg_at Hs j)) ->
  redex_of g = redex_of (last_cfg Hs) ->
  redex_of g = Some (Cassert l0 tk Phi) ->
  lleq l0 l ->
  ~ models_prerun (fs ++ [g]) Hs Phi ->
  assertion_failure l ins (fs ++ [g]) Hs
    (fun i j => alpha i j
                \/ (i = length fs - 1 /\ length hs <= j /\ j < length Hs - 1)
                \/ (i = length fs /\ j = length Hs - 1)).
Proof.
  intros l ins fs g hs Hs alpha l0 tk Phi Hpre Hconf Hcov Hnotannfs HpreHs Hpref Hbig Hgrow
         Hinputs Hgrowth Hredeq Hredg Hle Hnm.
  assert (Hinp : Forall is_input ins) by (apply (conformance_inputs l ins fs hs alpha); exact Hconf).
  assert (HHspos : 0 < length Hs) by lia.
  destruct (annot_aligned l ins fs g hs Hs alpha Hpre Hconf Hcov Hnotannfs HpreHs Hpref
              HHspos Hgrowth Hredeq) as [Hlapg Hcrngg].
  exists (length fs).
  split; [exact Hlapg |].
  split; [exact Hinputs |].
  split; [exact Hcrngg |].
  split; [| exact Hinp].
  exists (length Hs - 1), l0, tk, Phi.
  split; [rewrite length_app; simpl; lia |].
  split; [reflexivity |].
  split; [right; right; split; reflexivity |].
  split; [rewrite (cfg_at_app2 fs g); exact Hredg |].
  split; [exact Hle |].
  split.
  - rewrite (cfg_at_app2 fs g).
    assert (HHsne : Hs <> []) by (intro Hc; rewrite Hc in HHspos; simpl in HHspos; lia).
    rewrite (last_eq_cfg_at Hs HHsne).
    unfold models_prerun in Hnm.
    assert (Hlfg : last_cfg (fs ++ [g]) = g) by (unfold last_cfg; rewrite last_last; reflexivity).
    rewrite Hlfg in Hnm. exact Hnm.
  - apply (annot_conformance_below l ins fs g hs Hs alpha Hconf Hcov Hnotannfs HpreHs
             Hpref Hbig Hgrow Hinputs Hgrowth).
Qed.


Lemma conformance_extend_alignfail : forall l ins fs g hs Hs alpha,
  pre_run (fs ++ [g]) ->
  conformance l ins fs hs alpha ->
  covers_dom fs alpha ->
  ~ redex_is_l_annotation l (cfg_at fs (length fs - 1)) ->
  pre_run Hs ->
  list_prefix hs Hs ->
  1 < length Hs ->
  length hs <= length Hs - 1 ->
  (exists ih, pr_inputs Hs ih /\ list_prefix ih ins) ->
  (forall j, length hs <= j -> j < length Hs - 1 -> ~ redex_is_l_annotation l (cfg_at Hs j)) ->
  redex_is_l_annotation l g ->
  redex_is_l_annotation l (last_cfg Hs) ->
  redex_of (last_cfg Hs) <> redex_of g ->
  alignment_failure l ins (fs ++ [g]) Hs
    (fun i j => alpha i j
                \/ (i = length fs - 1 /\ length hs <= j /\ j < length Hs - 1)
                \/ (i = length fs /\ j = length Hs - 1)).
Proof.
  intros l ins fs g hs Hs alpha Hpre Hconf Hcov Hnotannfs HpreHs Hpref Hbig Hgrow
         Hinputs Hgrowth Hanng Hannh Hneq.
  assert (Hinp : Forall is_input ins) by (apply (conformance_inputs l ins fs hs alpha); exact Hconf).
  assert (Hlastread : cfg_at Hs (length Hs - 1) = last_cfg Hs) by
    (apply last_eq_cfg_at; apply pre_run_nonempty; exact HpreHs).
  exists (length fs).
  split; [exact Hinputs |].
  split; [| exact Hinp].
  exists (length Hs - 1).
  split; [rewrite length_app; simpl; lia |].
  split; [reflexivity |].
  split; [rewrite (cfg_at_app2 fs g); exact Hanng |].
  split; [rewrite Hlastread; exact Hannh |].
  split.
  - rewrite Hlastread, (cfg_at_app2 fs g). exact Hneq.
  - apply (annot_conformance_below l ins fs g hs Hs alpha Hconf Hcov Hnotannfs HpreHs
             Hpref Hbig Hgrow Hinputs Hgrowth).
Qed.

Lemma conformance_last_paired : forall l ins fs hs alpha,
  conformance l ins fs hs alpha ->
  covers_dom fs alpha ->
  alpha (length fs - 1) (length hs - 1).
Proof.
  intros l ins fs hs alpha Hconf Hcov.
  destruct Hconf as [Hlap [_ [Hcrng _]]].
  destruct Hlap as [Hprefs [Hprehs Hwp]].
  destruct Hwp as [[Hbound [Hmono _]] _].
  assert (Hfspos : 0 < length fs) by
    (destruct fs; [exfalso; apply (pre_run_nonempty _ Hprefs); reflexivity | simpl; lia]).
  assert (Hhspos : 0 < length hs) by
    (destruct hs; [exfalso; apply (pre_run_nonempty _ Hprehs); reflexivity | simpl; lia]).
  destruct (Hcov (length fs - 1) ltac:(lia)) as [j Haj].
  destruct (Hcrng (length hs - 1) ltac:(lia)) as [i Hai].
  destruct (Hbound (length fs - 1) j Haj) as [_ Hjlt].
  destruct (Hbound i (length hs - 1) Hai) as [Hilt _].
  destruct (Nat.eq_dec i (length fs - 1)) as [Heq | Hne].
  - subst i. exact Hai.
  - destruct (Hmono i (length hs - 1) (length fs - 1) j Hai Haj) as [Hm1 _].
    assert (Hle : length hs - 1 <= j) by (apply Hm1; lia).
    assert (j = length hs - 1) by lia. subst j. exact Haj.
Qed.

(* Decidability of the redex predicates, used to dispatch the cases below. *)
Fact redex_is_l_assume_dec : forall l g,
  {redex_is_l_assume l g} + {~ redex_is_l_assume l g}.
Proof.
  intros l g. unfold redex_is_l_assume, is_l_assume.
  destruct (redex_of g) as [c |]; [| right; auto].
  destruct c; try (right; intro H; exact H).
  destruct (lleq_dec l0 l); [left; assumption | right; assumption].
Qed.

Fact redex_is_l_annotation_dec : forall l g,
  {redex_is_l_annotation l g} + {~ redex_is_l_annotation l g}.
Proof.
  intros l g. unfold redex_is_l_annotation, is_l_annotation, is_l_assume, is_l_assert.
  destruct (redex_of g) as [c |]; [| right; intros []].
  destruct c; try (right; intros [H | H]; exact H).
  - destruct (lleq_dec l0 l); [left; right; assumption | right; intros [H | H]; auto].
  - destruct (lleq_dec l0 l); [left; left; assumption | right; intros [H | H]; auto].
Qed.

(* Stepping a config whose redex is an annotation produces a config whose redex is
   skip (annotations are checked in the step where they become redex; afterwards the
   redex is skip). By induction on the command, digging through Cseq. *)
Fact step_redex_annotation_skip : forall c s ev g,
  step (Active c s) ev g ->
  match redex_cmd c with Cassume _ _ _ => True | Cassert _ _ _ => True | _ => False end ->
  redex_of g = Some Cskip.
Proof.
  induction c; intros s ev g Hstep Hann; simpl in Hann; try contradiction.
  - (* Cseq *)
    inversion Hstep; subst.
    + simpl in Hann. contradiction.
    + simpl.
      match goal with H : step (Active c1 _) _ _ |- _ => specialize (IHc1 _ _ _ H Hann) end.
      simpl in IHc1. injection IHc1 as Hcs. rewrite Hcs. reflexivity.
  - (* Cassert *) inversion Hstep; subst. reflexivity.
  - (* Cassume *) inversion Hstep; subst. reflexivity.
Qed.

(* Consequence: if the post-step config's redex is an l-annotation, the pre-step
   config's redex was not (else the post-step redex would be skip). This gives the
   "~ annotation at last fs" side-condition for the grow-to-annotation cases. *)
Lemma step_to_annot_not_annot : forall c0 ev g l,
  step c0 ev g -> redex_is_l_annotation l g -> ~ redex_is_l_annotation l c0.
Proof.
  intros c0 ev g l Hstep Hg Hc0.
  destruct c0 as [s | c s].
  - unfold redex_is_l_annotation in Hc0. simpl in Hc0. exact Hc0.
  - assert (Hskip : redex_of g = Some Cskip).
    { apply (step_redex_annotation_skip c s ev g Hstep).
      unfold redex_is_l_annotation, is_l_annotation, is_l_assume, is_l_assert in Hc0.
      simpl in Hc0. destruct (redex_cmd c); simpl in Hc0; try exact I;
        destruct Hc0 as [H | H]; exact H. }
    unfold redex_is_l_annotation, is_l_annotation, is_l_assume, is_l_assert in Hg.
    rewrite Hskip in Hg. simpl in Hg. destruct Hg as [H | H]; exact H.
Qed.

(* A config whose redex is an annotation can take an (internal Etick) step. Used
   to advance the minor run by one step past a now-unmatched pending annotation. *)
Fact annot_redex_steps : forall c s,
  match redex_cmd c with Cassume _ _ _ => True | Cassert _ _ _ => True | _ => False end ->
  exists g, step (Active c s) Etick g.
Proof.
  induction c; intros s Hann; simpl in Hann; try contradiction.
  - (* Cseq *)
    destruct (IHc1 s Hann) as [g1 Hstep1].
    assert (Hskip : redex_of g1 = Some Cskip) by
      (apply (step_redex_annotation_skip c1 s Etick g1 Hstep1); exact Hann).
    destruct g1 as [s1 | c1' s1]; [simpl in Hskip; discriminate |].
    exists (Active (Cseq c1' c2) s1). apply Step_seq. exact Hstep1.
  - (* Cassert *) exists (Active Cskip s). apply Step_assert.
  - (* Cassume *) exists (Active Cskip s). apply Step_assume.
Qed.

(* Pair-extension when last(hs) is a now-unmatched pending annotation and g is not
   an annotation: advance the minor one (internal Etick) step past its annotation
   to gm (redex skip), and pair g with gm. The result is a conformance whose minor
   no longer ends at an annotation (maintaining the minor-phase invariant). *)
Lemma conformance_extend_pair_advance : forall l ins fs g hs alpha,
  pre_run (fs ++ [g]) ->
  conformance l ins fs hs alpha ->
  covers_dom fs alpha ->
  ~ redex_is_l_annotation l g ->
  redex_is_l_annotation l (last_cfg hs) ->
  exists hs' alpha',
    conformance l ins (fs ++ [g]) hs' alpha' /\
    ~ redex_is_l_annotation l (last_cfg hs').
Proof.
  intros l ins fs g hs alpha Hpre Hconf Hcov Hnotann Hlastann.
  destruct Hconf as [Hlap [Hih [Hcrng [Hmod Hinp]]]].
  destruct Hlap as [Hprefs [Hprehs Halgn]].
  destruct Halgn as [[Hbound [Hmono [Hpcd Hpcr]]] Hcoin].
  assert (Hhspos : 0 < length hs) by (destruct hs; [contradiction | simpl; lia]).
  destruct (last_cfg hs) as [shs | chs shs] eqn:Elast.
  { exfalso. unfold redex_is_l_annotation in Hlastann.
    simpl in Hlastann. exact Hlastann. }
  assert (Hannmatch : match redex_cmd chs with
                      | Cassume _ _ _ => True | Cassert _ _ _ => True | _ => False end).
  { unfold redex_is_l_annotation in Hlastann. simpl in Hlastann.
    unfold is_l_annotation, is_l_assume, is_l_assert in Hlastann.
    destruct (redex_cmd chs); simpl in Hlastann; try exact I;
      destruct Hlastann as [H | H]; exact H. }
  destruct (annot_redex_steps chs shs Hannmatch) as [gm Hstepm].
  assert (Hgmskip : redex_of gm = Some Cskip) by
    (apply (step_redex_annotation_skip chs shs Etick gm Hstepm); exact Hannmatch).
  assert (Hnotanngm : ~ redex_is_l_annotation l gm) by
    (unfold redex_is_l_annotation, is_l_annotation, is_l_assume, is_l_assert;
     rewrite Hgmskip; simpl; intros [H | H]; exact H).
  destruct Hih as [ih [Hpr [Hple _]]].
  destruct Hpr as [th0 [Hat0 Hin0]].
  set (hs1 := hs ++ [gm]).
  assert (Hat1 : admits_trace hs1 (th0 ++ [Etick])) by
    (apply AT_step; [exact Hat0 | rewrite Elast; exact Hstepm]).
  assert (Hpre1 : pre_run hs1) by (exists (th0 ++ [Etick]); exact Hat1).
  assert (Hlen1 : length hs1 = S (length hs)) by (unfold hs1; rewrite length_app; simpl; lia).
  assert (Hlast1 : last_cfg hs1 = gm) by
    (unfold hs1, last_cfg; rewrite (last_app_nonempty config hs [gm] (Receptive initState))
       by discriminate; reflexivity).
  assert (Hfirst1 : forall n, n <= length hs -> firstn n hs1 = firstn n hs) by
    (intros n Hn; unfold hs1; apply firstn_prefix; exact Hn).
  exists hs1, (fun i j => alpha i j \/ (i = length fs /\ j = length hs)).
  split.
  - unfold conformance. split; [| split; [| split; [| split]]].
    + split; [exact Hpre | split; [exact Hpre1 |]].
      split.
      * (* alignment *)
        split; [| split; [| split]].
        -- intros i j [Ha | [Hi Hj]].
           ++ destruct (Hbound i j Ha) as [Hbi Hbj]. rewrite length_app; simpl; rewrite Hlen1.
              split; lia.
           ++ subst i j. rewrite length_app; simpl; rewrite Hlen1. split; lia.
        -- intros i j k m [Ha | [Hi Hj]] [Hb | [Hk Hl]].
           ++ apply (Hmono i j k m Ha Hb).
           ++ subst k m. destruct (Hbound i j Ha) as [Hbi Hbj]. split; intros; lia.
           ++ subst i j. destruct (Hbound k m Hb) as [Hbk Hbm]. split; intros; lia.
           ++ subst i j k m. split; intros; lia.
        -- intros i j [m Hbim] Hlt.
           assert (Hile : i <= length fs) by
             (destruct Hbim as [Ha | [Hi _]]; [destruct (Hbound i m Ha); lia | lia]).
           destruct (Hcov j ltac:(lia)) as [m' Ham']. exists m'. left. exact Ham'.
        -- intros i j [k Hbki] Hlt.
           assert (Hile : i <= length hs) by
             (destruct Hbki as [Ha | [_ Hi]]; [destruct (Hbound k i Ha); lia | lia]).
           destruct (Hcrng j ltac:(lia)) as [k' Hak']. exists k'. left. exact Hak'.
      * (* proper: redex coincidence at aligned pairs *)
        intros i j Hij Hdisj.
        destruct Hij as [Ha | [Hi Hj]].
        -- destruct (Hbound i j Ha) as [Hbi Hbj].
           unfold hs1 in Hdisj |- *.
           rewrite (cfg_at_app1 fs g i Hbi) in Hdisj |- *.
           rewrite (cfg_at_app1 hs gm j Hbj) in Hdisj |- *.
           apply (Hcoin i j Ha Hdisj).
        -- subst i j. exfalso.
           assert (Hhsgm : cfg_at hs1 (length hs) = gm) by (unfold hs1; apply cfg_at_app2).
           rewrite (cfg_at_app2 fs g), Hhsgm in Hdisj.
           destruct Hdisj as [H | H].
           ++ apply Hnotann. exact H.
           ++ apply Hnotanngm. exact H.
    + exists ih. split.
      * exists (th0 ++ [Etick]). split; [exact Hat1 |].
        unfold inputs in *. rewrite filter_app. simpl. rewrite app_nil_r. exact Hin0.
      * split; [exact Hple |].
        left. intros i Hi. rewrite length_app in Hi; simpl in Hi.
        destruct (le_lt_dec (length fs) i) as [Hge | Hlt].
        -- exists (length hs). right. split; [lia | reflexivity].
        -- destruct (Hcov i Hlt) as [m Ham]. exists m. left. exact Ham.
    + intros j Hj. rewrite Hlen1 in Hj.
      destruct (le_lt_dec (length hs) j) as [Hge | Hlt].
      * assert (j = length hs) by lia. subst j. exists (length fs). right. split; reflexivity.
      * destruct (Hcrng j Hlt) as [k Hak]. exists k. left. exact Hak.
    + 
intros i j l' tk Phi [Ha | [Hi Hj]] Hred Hle.
      * destruct (Hbound i j Ha) as [Hbi Hbj].
        rewrite (cfg_at_app1 fs g i Hbi) in Hred |- *.
        unfold hs1. rewrite (cfg_at_app1 hs gm j Hbj).
        apply (Hmod i j l' tk Phi Ha Hred Hle).
      * subst i j. rewrite (cfg_at_app2 fs g) in Hred.
        exfalso. apply Hnotann. unfold redex_is_l_annotation.
        destruct Hred as [Hr | Hr]; rewrite Hr; simpl; [left | right]; exact Hle.
    + exact Hinp.
  - rewrite Hlast1. unfold redex_is_l_annotation, is_l_annotation, is_l_assume, is_l_assert.
    rewrite Hgmskip. simpl. intros [H | H]; exact H.
Qed.

(* A minor-phase invariant: the minor pre-run ends at an l-annotation only when
   the major pre-run does (i.e. no unmatched pending annotation in the minor). The
   conformance output of the classification carries this; it gives the strict
   growth that grow_to_annotation needs (last hs not an annotation). *)
Definition minor_phase_ok (l : Lev) (gs hs : list config) : Prop :=
  redex_is_l_annotation l (last_cfg hs) -> redex_is_l_annotation l (last_cfg gs).

(* Determinacy of the step target for a fixed source config and event. *)
Fact step_determ_cfg : forall c ev g1 g2,
  step c ev g1 -> step c ev g2 -> g1 = g2.
Proof.
  intros [s | cc s] ev g1 g2 H1 H2.
  - exact (step_determ_recv s ev g1 g2 H1 H2).
  - destruct (step_determ_active cc s ev g1 ev g2 H1 H2) as [_ Hg]. exact Hg.
Qed.

(* A pre-run's configuration list is determined by its trace: admits_trace is
   functional in the configs (the initial config is fixed and each step target is
   unique). The converse (trace determined by configs) is traceDetEv. 
Note that ts is a full trace including ticks, so it exactly forces the run.
*)
Lemma admits_trace_det_configs : forall hs1 ts,
  admits_trace hs1 ts -> forall hs2, admits_trace hs2 ts -> hs1 = hs2.
Proof.
  intros hs1 ts H1. induction H1 as [| gs1 evs ev g1 Hgs1 IH Hstep1]; intros hs2 H2.
  - inversion H2; subst; [reflexivity | destruct evs; discriminate].
  - inversion H2 as [| gs2 evs2 ev2 g2 Hgs2 Hstep2 Hgseq Heq]; subst.
    + destruct evs; discriminate.
    + apply app_inj_tail in Heq. destruct Heq as [Hevs Hev]. subst evs2 ev2.
      specialize (IH gs2 Hgs2). subst gs2.
      assert (g1 = g2) by exact (step_determ_cfg (last_cfg gs1) ev g1 g2 Hstep1 Hstep2).
      subst g2. reflexivity.
Qed.

(* ====================================================================== *)
(* Annotation counting / rank: annot_count l gs k = number of l-annotation *)
(* configs among indices 0..k-1; is_nth_annot l gs n i says gs_i is the    *)
(* (0-indexed) n-th l-annotation. Used to state annot_rank_match and the   *)
(* equal-count corollary, and to discharge divF_alignF_reach.          *)
(* ====================================================================== *)
Fixpoint annot_count (l : Lev) (gs : list config) (k : nat) : nat :=
  match k with
  | 0 => 0
  | S k' => annot_count l gs k' +
            (if redex_is_l_annotation_dec l (cfg_at gs k') then 1 else 0)
  end.

Definition is_nth_annot (l : Lev) (gs : list config) (n i : nat) : Prop :=
  i < length gs /\ redex_is_l_annotation l (cfg_at gs i) /\ annot_count l gs i = n.

Fact annot_count_annot_S : forall l gs k,
  redex_is_l_annotation l (cfg_at gs k) ->
  annot_count l gs (S k) = S (annot_count l gs k).
Proof.
  intros l gs k Hann. simpl.
  destruct (redex_is_l_annotation_dec l (cfg_at gs k)); [lia | contradiction].
Qed.

Fact annot_count_nonannot_S : forall l gs k,
  ~ redex_is_l_annotation l (cfg_at gs k) ->
  annot_count l gs (S k) = annot_count l gs k.
Proof.
  intros l gs k Hn. simpl.
  destruct (redex_is_l_annotation_dec l (cfg_at gs k)); [contradiction | lia].
Qed.

Fact annot_count_mono : forall l gs k1 k2,
  k1 <= k2 -> annot_count l gs k1 <= annot_count l gs k2.
Proof.
  intros l gs k1 k2 H. induction H; [lia |].
  simpl. destruct (redex_is_l_annotation_dec l (cfg_at gs m)); lia.
Qed.

Fact is_nth_annot_unique : forall l gs n i i',
  is_nth_annot l gs n i -> is_nth_annot l gs n i' -> i = i'.
Proof.
  intros l gs n i i' [Hi [Hai Hci]] [Hi' [Hai' Hci']].
  destruct (Nat.lt_trichotomy i i') as [Hlt | [Heq | Hgt]]; [| exact Heq |].
  - exfalso.
    assert (Hle : annot_count l gs (S i) <= annot_count l gs i') by (apply annot_count_mono; lia).
    rewrite (annot_count_annot_S l gs i Hai) in Hle. lia.
  - exfalso.
    assert (Hle : annot_count l gs (S i') <= annot_count l gs i) by (apply annot_count_mono; lia).
    rewrite (annot_count_annot_S l gs i' Hai') in Hle. lia.
Qed.

Fact annot_count_ext : forall l g1 g2 k,
  (forall m, m < k -> cfg_at g1 m = cfg_at g2 m) ->
  annot_count l g1 k = annot_count l g2 k.
Proof.
  intros l g1 g2 k. induction k as [|k IH]; intros Hext; [reflexivity |].
  simpl. rewrite IH by (intros m Hm; apply Hext; lia).
  rewrite (Hext k ltac:(lia)). reflexivity.
Qed.

Fact annot_count_firstn : forall l gs n k,
  k <= n -> annot_count l (firstn n gs) k = annot_count l gs k.
Proof.
  intros l gs n k Hk. apply annot_count_ext. intros m Hm. apply cfg_at_firstn. lia.
Qed.

Fact annot_index_lt_length : forall l gs m,
  redex_is_l_annotation l (cfg_at gs m) -> m < length gs.
Proof.
  intros l gs m H. destruct (Nat.lt_ge_cases m (length gs)) as [Hlt | Hge]; [exact Hlt |].
  exfalso. unfold cfg_at in H. rewrite nth_overflow in H by exact Hge.
  unfold redex_is_l_annotation in H. simpl in H. exact H.
Qed.

Fact annot_count_gives_nth : forall l gs c m,
  c < annot_count l gs m -> exists i, i < m /\ is_nth_annot l gs c i.
Proof.
  intros l gs c m. induction m as [|m IH]; intros Hc; [simpl in Hc; lia |].
  destruct (redex_is_l_annotation_dec l (cfg_at gs m)) as [Hann | Hnann].
  - rewrite (annot_count_annot_S l gs m Hann) in Hc.
    destruct (Nat.lt_ge_cases c (annot_count l gs m)) as [Hlt | Hge].
    + destruct (IH Hlt) as [i [Him Hnth]]. exists i. split; [lia | exact Hnth].
    + exists m. split; [lia |]. unfold is_nth_annot.
      split; [apply (annot_index_lt_length l gs m Hann) | split; [exact Hann | lia]].
  - rewrite (annot_count_nonannot_S l gs m Hnann) in Hc.
    destruct (IH Hc) as [i [Him Hnth]]. exists i. split; [lia | exact Hnth].
Qed.

Fact is_nth_annot_firstn : forall l gs n c i,
  i < n -> is_nth_annot l (firstn n gs) c i -> is_nth_annot l gs c i.
Proof.
  intros l gs n c i Hin [Hi [Hai Hci]].
  rewrite (cfg_at_firstn n gs i Hin) in Hai.
  unfold is_nth_annot. split; [apply (annot_index_lt_length l gs i Hai) | split; [exact Hai |]].
  rewrite <- (annot_count_firstn l gs n i ltac:(lia)). exact Hci.
Qed.

(* A proper alignment relates an annotation only to an annotation (either side). *)
Fact proper_annot_both : forall l gs hs alpha a b,
  proper l gs hs alpha -> alpha a b ->
  redex_is_l_annotation l (cfg_at gs a) ->
  redex_is_l_annotation l (cfg_at hs b).
Proof.
  intros l gs hs alpha a b [_ Hcoin] Hab Hann.
  assert (Hco : redex_of (cfg_at gs a) = redex_of (cfg_at hs b))
    by (apply (Hcoin a b Hab); left; exact Hann).
  unfold redex_is_l_annotation in *. rewrite <- Hco. exact Hann.
Qed.

(* Annotation-rank matching: in a proper alignment covering both runs, the n-th
   l-annotation of gs is aligned to the n-th l-annotation of hs. (Proof: induction
   on n using monotonicity + properness -- a body strictly between two consecutive
   annotations cannot align to an annotation, so the rank correspondence is
   forced.) Subsumes minor_annot_cfg_det / major_annot_cfg_det / alignF_offense. *)
(* In a pre-run, consecutive configs are related by a step. *)
Lemma pre_run_step_adj : forall gs k,
  pre_run gs -> S k < length gs ->
  exists ev, step (cfg_at gs k) ev (cfg_at gs (S k)).
Proof.
  intros gs k [evs Hat]. revert k. induction Hat as [| gs evs ev g Hat IH Hstep]; intros k Hk.
  - simpl in Hk. lia.
  - rewrite length_app in Hk. simpl in Hk.
    assert (Hne : gs <> []) by (apply (admits_trace_nonempty gs evs Hat)).
    assert (Hgs0 : 0 < length gs) by (destruct gs; [contradiction | simpl; lia]).
    destruct (Nat.lt_ge_cases (S k) (length gs)) as [Hlt | Hge].
    + rewrite (cfg_at_app1 gs g k ltac:(lia)). rewrite (cfg_at_app1 gs g (S k) Hlt). apply (IH k Hlt).
    + assert (HSk : S k = length gs) by lia. rewrite HSk. rewrite (cfg_at_app2 gs g).
      rewrite (cfg_at_app1 gs g k ltac:(lia)). replace k with (length gs - 1) by lia.
      rewrite (last_eq_cfg_at gs Hne). exists ev. exact Hstep.
Qed.

(* No two consecutive configs of a pre-run are both l-annotations. *)
Lemma no_adj_annot : forall l gs k,
  pre_run gs ->
  redex_is_l_annotation l (cfg_at gs (S k)) ->
  ~ redex_is_l_annotation l (cfg_at gs k).
Proof.
  intros l gs k Hpre HannS Hannk.
  assert (HSk : S k < length gs) by (apply (annot_index_lt_length l gs (S k) HannS)).
  destruct (pre_run_step_adj gs k Hpre HSk) as [ev Hstep].
  apply (step_to_annot_not_annot (cfg_at gs k) ev (cfg_at gs (S k)) l Hstep HannS). exact Hannk.
Qed.

(* Reverse of proper_annot_both: an annotation on the minor side forces one on
   the major side at an aligned pair. *)
Fact proper_annot_rev : forall l gs hs alpha a b,
  proper l gs hs alpha -> alpha a b ->
  redex_is_l_annotation l (cfg_at hs b) ->
  redex_is_l_annotation l (cfg_at gs a).
Proof.
  intros l gs hs alpha a b [_ Hcoin] Hab Hann.
  assert (Hco : redex_of (cfg_at gs a) = redex_of (cfg_at hs b))
    by (apply (Hcoin a b Hab); right; exact Hann).
  unfold redex_is_l_annotation in *. rewrite Hco. exact Hann.
Qed.

(* A major annotation aligns to a unique minor config. *)
Fact annot_img_unique : forall l gs hs alpha a b1 b2,
  l_aligned_pair l gs hs alpha -> covers_rng hs alpha ->
  alpha a b1 -> alpha a b2 ->
  redex_is_l_annotation l (cfg_at gs a) -> b1 = b2.
Proof.
  intros l gs hs alpha a b1 b2 Hlap Hcrng Hab1 Hab2 Hann.
  destruct Hlap as [Hpregs [Hprehs Hproper]].
  assert (Hbound : forall i j, alpha i j -> i < length gs /\ j < length hs)
    by (destruct Hproper as [[Hb _] _]; exact Hb).
  assert (Hmono : forall i j k m, alpha i j -> alpha k m -> (i<k -> j<=m) /\ (j<m -> i<=k))
    by (destruct Hproper as [[_ [Hm _]] _]; exact Hm).
  assert (Hkey : forall c d, alpha a c -> alpha a d -> c < d -> False) by
    (intros c d Hac Had Hcd;
     assert (Hannc : redex_is_l_annotation l (cfg_at hs c))
       by (apply (proper_annot_both l gs hs alpha a c Hproper Hac Hann));
     assert (HaSc : alpha a (S c)) by
       (destruct (Nat.eq_dec (S c) d) as [Heq | Hne];
        [ rewrite Heq; exact Had
        | assert (HScd : S c < d) by lia;
          assert (HScl : S c < length hs) by (destruct (Hbound a d Had); lia);
          destruct (Hcrng (S c) HScl) as [a' Ha'];
          assert (Ha_le : a <= a') by (apply (proj2 (Hmono a c a' (S c) Hac Ha')); lia);
          assert (Ha'_le : a' <= a) by (apply (proj2 (Hmono a' (S c) a d Ha' Had)); lia);
          assert (Heqa : a' = a) by lia; subst a'; exact Ha' ]);
     assert (HannSc : redex_is_l_annotation l (cfg_at hs (S c)))
       by (apply (proper_annot_both l gs hs alpha a (S c) Hproper HaSc Hann));
     apply (no_adj_annot l hs c Hprehs HannSc); exact Hannc).
  destruct (Nat.lt_trichotomy b1 b2) as [Hlt | [Heq | Hgt]];
    [ exfalso; apply (Hkey b1 b2 Hab1 Hab2 Hlt)
    | exact Heq
    | exfalso; apply (Hkey b2 b1 Hab2 Hab1 Hgt) ].
Qed.

(* A minor annotation aligns to a unique major config. *)
Fact annot_preimg_unique : forall l gs hs alpha a1 a2 b,
  l_aligned_pair l gs hs alpha -> covers_dom gs alpha ->
  alpha a1 b -> alpha a2 b ->
  redex_is_l_annotation l (cfg_at hs b) -> a1 = a2.
Proof.
  intros l gs hs alpha a1 a2 b Hlap Hcov Hab1 Hab2 Hann.
  destruct Hlap as [Hpregs [Hprehs Hproper]].
  assert (Hbound : forall i j, alpha i j -> i < length gs /\ j < length hs)
    by (destruct Hproper as [[Hb _] _]; exact Hb).
  assert (Hmono : forall i j k m, alpha i j -> alpha k m -> (i<k -> j<=m) /\ (j<m -> i<=k))
    by (destruct Hproper as [[_ [Hm _]] _]; exact Hm).
  assert (Hkey : forall c d, alpha c b -> alpha d b -> c < d -> False) by
    (intros c d Hcb Hdb Hcd;
     assert (Hannc : redex_is_l_annotation l (cfg_at gs c))
       by (apply (proper_annot_rev l gs hs alpha c b Hproper Hcb Hann));
     assert (HaSc : alpha (S c) b) by
       (destruct (Nat.eq_dec (S c) d) as [Heq | Hne];
        [ rewrite Heq; exact Hdb
        | assert (HScd : S c < d) by lia;
          assert (HScl : S c < length gs) by (destruct (Hbound d b Hdb); lia);
          destruct (Hcov (S c) HScl) as [b' Hb'];
          assert (Hb_le : b <= b') by (apply (proj1 (Hmono c b (S c) b' Hcb Hb')); lia);
          assert (Hb'_le : b' <= b) by (apply (proj1 (Hmono (S c) b' d b Hb' Hdb)); lia);
          assert (Heqb : b' = b) by lia; subst b'; exact Hb' ]);
     assert (HannSc : redex_is_l_annotation l (cfg_at gs (S c)))
       by (apply (proper_annot_rev l gs hs alpha (S c) b Hproper HaSc Hann));
     apply (no_adj_annot l gs c Hpregs HannSc); exact Hannc).
  destruct (Nat.lt_trichotomy a1 a2) as [Hlt | [Heq | Hgt]];
    [ exfalso; apply (Hkey a1 a2 Hab1 Hab2 Hlt)
    | exact Heq
    | exfalso; apply (Hkey a2 a1 Hab2 Hab1 Hgt) ].
Qed.

(* No annotation lies strictly between two consecutive-rank annotations. *)
Fact no_annot_between : forall l xs m p q r,
  is_nth_annot l xs m p -> is_nth_annot l xs (S m) q ->
  redex_is_l_annotation l (cfg_at xs r) -> p < r -> r < q -> False.
Proof.
  intros l xs m p q r [_ [Hap Hcp]] [_ [_ Hcq]] Har Hpr Hrq.
  assert (HSp : annot_count l xs (S p) = S m)
    by (rewrite (annot_count_annot_S l xs p Hap); rewrite Hcp; reflexivity).
  assert (HSr : annot_count l xs (S r) = S (annot_count l xs r))
    by (apply (annot_count_annot_S l xs r Har)).
  assert (H1 : annot_count l xs (S p) <= annot_count l xs r) by (apply annot_count_mono; lia).
  assert (H2 : annot_count l xs (S r) <= annot_count l xs q) by (apply annot_count_mono; lia).
  rewrite HSp in H1. rewrite HSr in H2. rewrite Hcq in H2. lia.
Qed.

Fact annot_rank_match : forall l gs hs alpha n i j,
  l_aligned_pair l gs hs alpha -> covers_dom gs alpha -> covers_rng hs alpha ->
  is_nth_annot l gs n i -> is_nth_annot l hs n j ->
  alpha i j.
Proof.
  intros l gs hs alpha n i j Hlap Hcov Hcrng Hi Hj.
  assert (Hbound : forall a b, alpha a b -> a < length gs /\ b < length hs)
    by (destruct Hlap as [_ [_ [[Hb _] _]]]; exact Hb).
  assert (Hmono : forall a b c d, alpha a b -> alpha c d -> (a<c -> b<=d) /\ (b<d -> a<=c))
    by (destruct Hlap as [_ [_ [[_ [Hm _]] _]]]; exact Hm).
  assert (Hproper : proper l gs hs alpha) by (destruct Hlap as [_ [_ Hp]]; exact Hp).
  revert i j Hi Hj. induction n as [|m IH]; intros i j Hi Hj.
  - destruct Hi as [Hilt [Hanni Hci]]. destruct Hj as [Hjlt [Hannj Hcj]].
    destruct (Hcov i Hilt) as [b Hib].
    assert (Hannb : redex_is_l_annotation l (cfg_at hs b))
      by (apply (proper_annot_both l gs hs alpha i b Hproper Hib Hanni)).
    destruct (Hbound i b Hib) as [_ Hblt].
    assert (Hcb0 : annot_count l hs b = 0).
    { destruct (Nat.eq_dec (annot_count l hs b) 0) as [H0 | Hne]; [exact H0 | exfalso].
      assert (Hpos : 0 < annot_count l hs b) by lia.
      destruct (annot_count_gives_nth l hs 0 b Hpos) as [j0 [Hj0b Hnth0]].
      assert (Hj0lt : j0 < length hs) by lia.
      destruct (Hcrng j0 Hj0lt) as [a0 Ha0].
      destruct Hnth0 as [_ [Hannj0 _]].
      assert (Hanna0 : redex_is_l_annotation l (cfg_at gs a0))
        by (apply (proper_annot_rev l gs hs alpha a0 j0 Hproper Ha0 Hannj0)).
      assert (Ha0i : a0 <= i) by (apply (proj2 (Hmono a0 j0 i b Ha0 Hib)); lia).
      assert (Ha0eq : a0 = i).
      { destruct (Nat.eq_dec a0 i) as [Heq | Hne2]; [exact Heq | exfalso].
        assert (Ha0lt : a0 < i) by lia.
        assert (Hc : annot_count l gs (S a0) <= annot_count l gs i) by (apply annot_count_mono; lia).
        rewrite (annot_count_annot_S l gs a0 Hanna0) in Hc. rewrite Hci in Hc. lia. }
      subst a0.
      assert (Hj0b' : j0 = b)
        by (apply (annot_img_unique l gs hs alpha i j0 b Hlap Hcrng Ha0 Hib Hanni)).
      lia. }
    assert (Hnthb : is_nth_annot l hs 0 b)
      by (split; [exact Hblt | split; [exact Hannb | exact Hcb0]]).
    assert (Hbj : b = j)
      by (apply (is_nth_annot_unique l hs 0 b j Hnthb);
          split; [exact Hjlt | split; [exact Hannj | exact Hcj]]).
    rewrite <- Hbj. exact Hib.
  - pose proof Hi as Hi0. destruct Hi0 as [Hilt [Hanni Hci]].
    pose proof Hj as Hj0. destruct Hj0 as [Hjlt [Hannj Hcj]].
    assert (Hmlt_i : m < annot_count l gs i) by lia.
    destruct (annot_count_gives_nth l gs m i Hmlt_i) as [i' [Hi'i Hnthi']].
    assert (Hmlt_j : m < annot_count l hs j) by lia.
    destruct (annot_count_gives_nth l hs m j Hmlt_j) as [j' [Hj'j Hnthj']].
    assert (IHres : alpha i' j') by (apply (IH i' j' Hnthi' Hnthj')).
    destruct (Hcov i Hilt) as [b Hib].
    assert (Hannb : redex_is_l_annotation l (cfg_at hs b))
      by (apply (proper_annot_both l gs hs alpha i b Hproper Hib Hanni)).
    assert (Hj'le : j' <= b) by (apply (proj1 (Hmono i' j' i b IHres Hib)); lia).
    assert (Hbj' : j' < b) by
      (destruct (Nat.eq_dec b j') as [Heq | Hne];
       [ subst b;
         assert (Hii' : i = i')
           by (apply (annot_preimg_unique l gs hs alpha i i' j' Hlap Hcov Hib IHres Hannb));
         lia
       | lia ]).
    destruct (Nat.lt_trichotomy b j) as [Hlt | [Heq | Hgt]];
    [ exfalso; apply (no_annot_between l hs m j' j b Hnthj' Hj Hannb Hbj' Hlt)
    | rewrite Heq in Hib; exact Hib
    | destruct (Hcrng j Hjlt) as [a Ha];
      assert (Hanna : redex_is_l_annotation l (cfg_at gs a))
        by (apply (proper_annot_rev l gs hs alpha a j Hproper Ha Hannj));
      assert (Hai : a <= i) by (apply (proj2 (Hmono a j i b Ha Hib)); lia);
      assert (Hi'a : i' <= a) by (apply (proj2 (Hmono i' j' a j IHres Ha)); lia);
      destruct (Nat.eq_dec a i) as [Heqai | Hneai];
      [ subst a; exact Ha
      | destruct (Nat.eq_dec a i') as [Heqai' | Hneai'];
        [ subst a;
          assert (Hanni' : redex_is_l_annotation l (cfg_at gs i'))
            by (destruct Hnthi' as [_ [HH _]]; exact HH);
          assert (Hjj' : j = j')
            by (apply (annot_img_unique l gs hs alpha i' j j' Hlap Hcrng Ha IHres Hanni'));
          lia
        | exfalso; apply (no_annot_between l gs m i' i a Hnthi' Hi Hanna ltac:(lia) ltac:(lia)) ] ] ].
Qed.

(* Rank preservation: an aligned annotation pair has equal annotation rank. *)
Lemma annot_rank_pres : forall l gs hs alpha a b,
  l_aligned_pair l gs hs alpha -> covers_dom gs alpha -> covers_rng hs alpha ->
  alpha a b -> redex_is_l_annotation l (cfg_at gs a) ->
  annot_count l gs a = annot_count l hs b.
Proof.
  intros l gs hs alpha a b Hlap Hcov Hcrng Hab Hanna.
  assert (Hproper : proper l gs hs alpha) by (destruct Hlap as [_ [_ Hp]]; exact Hp).
  assert (Hbound : forall x y, alpha x y -> x < length gs /\ y < length hs)
    by (destruct Hlap as [_ [_ [[Hb _] _]]]; exact Hb).
  assert (Hannb : redex_is_l_annotation l (cfg_at hs b))
    by (apply (proper_annot_both l gs hs alpha a b Hproper Hab Hanna)).
  destruct (Hbound a b Hab) as [Halt Hblt].
  assert (Hntha : is_nth_annot l gs (annot_count l gs a) a)
    by (split; [exact Halt | split; [exact Hanna | reflexivity]]).
  assert (Hnthb : is_nth_annot l hs (annot_count l hs b) b)
    by (split; [exact Hblt | split; [exact Hannb | reflexivity]]).
  destruct (Nat.lt_trichotomy (annot_count l gs a) (annot_count l hs b)) as [Hlt | [Heq | Hgt]];
  [ exfalso;
    destruct (annot_count_gives_nth l hs (annot_count l gs a) b Hlt) as [b' [Hb'b Hnthb']];
    assert (Hab' : alpha a b')
      by (apply (annot_rank_match l gs hs alpha (annot_count l gs a) a b' Hlap Hcov Hcrng Hntha Hnthb'));
    assert (Hbb' : b = b')
      by (apply (annot_img_unique l gs hs alpha a b b' Hlap Hcrng Hab Hab' Hanna));
    lia
  | exact Heq
  | exfalso;
    destruct (annot_count_gives_nth l gs (annot_count l hs b) a Hgt) as [a' [Ha'a Hntha']];
    assert (Ha'b : alpha a' b)
      by (apply (annot_rank_match l gs hs alpha (annot_count l hs b) a' b Hlap Hcov Hcrng Hntha' Hnthb));
    assert (Haa' : a = a')
      by (apply (annot_preimg_unique l gs hs alpha a a' b Hlap Hcov Hab Ha'b Hannb));
    lia ].
Qed.

Fact equal_count : forall l gs hs alpha,
  l_aligned_pair l gs hs alpha -> covers_dom gs alpha -> covers_rng hs alpha ->
  annot_count l gs (length gs) = annot_count l hs (length hs).
Proof.
  intros l gs hs alpha Hlap Hcov Hcrng.
  assert (Hproper : proper l gs hs alpha) by (destruct Hlap as [_ [_ Hp]]; exact Hp).
  assert (Hbound : forall x y, alpha x y -> x < length gs /\ y < length hs)
    by (destruct Hlap as [_ [_ [[Hb _] _]]]; exact Hb).
  assert (Hle1 : annot_count l gs (length gs) <= annot_count l hs (length hs)).
  { destruct (Nat.eq_dec (annot_count l gs (length gs)) 0) as [H0 | Hpos]; [lia |].
    destruct (annot_count_gives_nth l gs (annot_count l gs (length gs) - 1) (length gs))
      as [a [Halt Hntha]]; [lia |].
    destruct Hntha as [Ha_lt [Hanna Hca]].
    destruct (Hcov a Ha_lt) as [b Hab].
    assert (Hannb : redex_is_l_annotation l (cfg_at hs b))
      by (apply (proper_annot_both l gs hs alpha a b Hproper Hab Hanna)).
    destruct (Hbound a b Hab) as [_ Hblt].
    assert (Hpres : annot_count l gs a = annot_count l hs b)
      by (apply (annot_rank_pres l gs hs alpha a b Hlap Hcov Hcrng Hab Hanna)).
    assert (Hbrank : annot_count l hs (S b) <= annot_count l hs (length hs))
      by (apply annot_count_mono; lia).
    rewrite (annot_count_annot_S l hs b Hannb) in Hbrank. lia. }
  assert (Hle2 : annot_count l hs (length hs) <= annot_count l gs (length gs)).
  { destruct (Nat.eq_dec (annot_count l hs (length hs)) 0) as [H0 | Hpos]; [lia |].
    destruct (annot_count_gives_nth l hs (annot_count l hs (length hs) - 1) (length hs))
      as [b [Hblt Hnthb]]; [lia |].
    destruct Hnthb as [Hb_lt [Hannb Hcb]].
    destruct (Hcrng b Hb_lt) as [a Hab].
    assert (Hanna : redex_is_l_annotation l (cfg_at gs a))
      by (apply (proper_annot_rev l gs hs alpha a b Hproper Hab Hannb)).
    destruct (Hbound a b Hab) as [Halt _].
    assert (Hpres : annot_count l gs a = annot_count l hs b)
      by (apply (annot_rank_pres l gs hs alpha a b Hlap Hcov Hcrng Hab Hanna)).
    assert (Harank : annot_count l gs (S a) <= annot_count l gs (length gs))
      by (apply annot_count_mono; lia).
    rewrite (annot_count_annot_S l gs a Hanna) in Harank. lia. }
  lia.
Qed.

(* Forward rank-faithfulness: in an l_aligned_pair whose minor range is
   covered, the alignment's prefix-closed domain (part of [alignment]) already
   forces the n-th l-annotation of the major, when aligned, to land on the n-th
   l-annotation of the minor. (Unlike annot_rank_match this needs only
   covers_rng on the minor; coverage of the major below i comes for free from
   prefix-closed domain.) This is the canonical fact behind the whole
   alignment-canonicity cluster below. *)
Fact annot_align_rank : forall l gs es alpha n i j,
  l_aligned_pair l gs es alpha ->
  covers_rng es alpha ->
  is_nth_annot l gs n i ->
  alpha i j ->
  is_nth_annot l es n j.
Proof.
  intros l gs es alpha n i j Hlap Hcrng.
  destruct Hlap as [Hpregs [Hpres Hproper]]; pose proof Hproper as Hproper2;
    destruct Hproper2 as [Halgn Hcoin]; destruct Halgn as [Hbound [Hmono [Hpcdom Hpcrng]]].
  revert i j; induction n as [|m IH]; intros i j Hnth Halpha.
  - destruct Hnth as [Hilt [Hanni Hci]].
    assert (Hannj : redex_is_l_annotation l (cfg_at es j))
      by (apply (proper_annot_both l gs es alpha i j Hproper Halpha Hanni)).
    destruct (Hbound i j Halpha) as [_ Hjlt].
    split; [exact Hjlt | split; [exact Hannj |]].
    destruct (Nat.eq_dec (annot_count l es j) 0) as [H0 | Hpos]; [exact H0 | exfalso].
    assert (Hp : 0 < annot_count l es j) by lia.
    destruct (annot_count_gives_nth l es 0 j Hp) as [j0 [Hj0j Hnth0]].
    destruct Hnth0 as [_ [Hannj0 _]].
    assert (Hj0lt : j0 < length es) by lia.
    destruct (Hcrng j0 Hj0lt) as [a0 Ha0].
    assert (Hanna0 : redex_is_l_annotation l (cfg_at gs a0))
      by (apply (proper_annot_rev l gs es alpha a0 j0 Hproper Ha0 Hannj0)).
    assert (Ha0i : a0 <= i) by (apply (proj2 (Hmono a0 j0 i j Ha0 Halpha)); lia).
    assert (Ha0eq : a0 = i).
    { destruct (Nat.eq_dec a0 i) as [Heq | Hne]; [exact Heq | exfalso].
      assert (Hc : annot_count l gs (S a0) <= annot_count l gs i) by (apply annot_count_mono; lia).
      rewrite (annot_count_annot_S l gs a0 Hanna0) in Hc. rewrite Hci in Hc. lia. }
    subst a0.
    assert (Hj0eq : j0 = j)
      by (apply (annot_img_unique l gs es alpha i j0 j); try assumption;
          split; [exact Hpregs | split; [exact Hpres | exact Hproper]]).
    lia.
  - destruct Hnth as [Hilt [Hanni Hci]].
    assert (Hannj : redex_is_l_annotation l (cfg_at es j))
      by (apply (proper_annot_both l gs es alpha i j Hproper Halpha Hanni)).
    destruct (Hbound i j Halpha) as [_ Hjlt].
    assert (Hmltci : m < annot_count l gs i) by lia.
    destruct (annot_count_gives_nth l gs m i Hmltci) as [i' [Hi'i Hnthi']].
    assert (Hdomi : align_dom alpha i) by (exists j; exact Halpha).
    destruct (Hpcdom i i' Hdomi Hi'i) as [j' Hj'].
    assert (Hnthesj' : is_nth_annot l es m j') by (apply (IH i' j' Hnthi' Hj')).
    pose proof Hnthesj' as Hnthesj'2. destruct Hnthesj'2 as [Hj'lt [Hannj' Hcj']].
    assert (Hnthi : is_nth_annot l gs (S m) i)
      by (split; [exact Hilt | split; [exact Hanni | exact Hci]]).
    assert (Hj'lej : j' <= j) by (apply (proj1 (Hmono i' j' i j Hj' Halpha)); lia).
    assert (Hj'ltj : j' < j).
    { destruct (Nat.eq_dec j' j) as [Hjeq | Hjne]; [exfalso; subst j' | lia].
      destruct (Nat.eq_dec (S i') i) as [HSi | HnSi].
      - apply (no_adj_annot l gs i' Hpregs);
          [rewrite HSi; exact Hanni | destruct Hnthi' as [_ [Ha _]]; exact Ha].
      - assert (Hki : S i' < i) by lia.
        destruct (Hpcdom i (S i') Hdomi Hki) as [jk Hjk].
        assert (Hjk_ge : j <= jk) by (apply (proj1 (Hmono i' j (S i') jk Hj' Hjk)); lia).
        assert (Hjk_le : jk <= j) by (apply (proj1 (Hmono (S i') jk i j Hjk Halpha)); lia).
        assert (Hjkj : jk = j) by lia. subst jk.
        assert (Hnannk : ~ redex_is_l_annotation l (cfg_at gs (S i')))
          by (intro Hck; apply (no_annot_between l gs m i' i (S i') Hnthi' Hnthi Hck); lia).
        apply Hnannk.
        assert (Hredeq : redex_of (cfg_at gs (S i')) = redex_of (cfg_at es j))
          by (apply (Hcoin (S i') j Hjk); right; exact Hannj).
        unfold redex_is_l_annotation in *. rewrite Hredeq. exact Hannj. }
    split; [exact Hjlt | split; [exact Hannj |]].
    assert (Hnoann : forall t, j' < t -> t < j -> ~ redex_is_l_annotation l (cfg_at es t)).
    { intros t Ht1 Ht2 Hannt. assert (Htlt : t < length es) by lia.
      destruct (Hcrng t Htlt) as [a Ha].
      assert (Hanna : redex_is_l_annotation l (cfg_at gs a))
        by (apply (proper_annot_rev l gs es alpha a t Hproper Ha Hannt)).
      assert (Hi'a : i' <= a) by (apply (proj2 (Hmono i' j' a t Hj' Ha)); lia).
      assert (Hai : a <= i) by (apply (proj2 (Hmono a t i j Ha Halpha)); lia).
      destruct (Nat.eq_dec a i') as [Eq1|Ne1];
        [subst a;
         assert (Htj' : t = j')
           by (apply (annot_img_unique l gs es alpha i' t j' (conj Hpregs (conj Hpres Hproper)) Hcrng Ha Hj' Hanna));
         lia | ].
      destruct (Nat.eq_dec a i) as [Eq2|Ne2];
        [subst a;
         assert (Htj : t = j)
           by (apply (annot_img_unique l gs es alpha i t j (conj Hpregs (conj Hpres Hproper)) Hcrng Ha Halpha Hanni));
         lia
        | apply (no_annot_between l gs m i' i a Hnthi' Hnthi Hanna); lia]. }
    assert (HcSj' : annot_count l es (S j') = S m)
      by (rewrite (annot_count_annot_S l es j' Hannj'); rewrite Hcj'; reflexivity).
    assert (Hgen : forall k, S j' <= k -> k <= j -> annot_count l es k = S m).
    { intro k; induction k as [|k IHk]; intros Hlo Hhi; [lia | ].
      destruct (Nat.eq_dec (S j') (S k)) as [He|Hne];
        [injection He as He2; subst k; exact HcSj' | ].
      assert (Hnk : ~ redex_is_l_annotation l (cfg_at es k)) by (apply Hnoann; lia).
      rewrite (annot_count_nonannot_S l es k Hnk). apply IHk; lia. }
    apply (Hgen j); lia.
Qed.

(* The config at index m of the canonical forward run does not depend on the step
   budget, as long as the budget exceeds m: shorter runs are firstn-prefixes. *)
Lemma frun_snd_nth_agree : forall g rem a b m d,
  m < a -> m < b ->
  nth m (map snd (frun g rem a)) d = nth m (map snd (frun g rem b)) d.
Proof.
  intros g rem a b m d Ha Hb.
  destruct (Nat.le_ge_cases a b) as [Hab | Hab].
  - rewrite <- (frun_firstn b a g rem Hab), ga_firstn_map.
    apply ga_nth_firstn. exact Ha.
  - rewrite <- (frun_firstn a b g rem Hab), ga_firstn_map.
    symmetry. apply ga_nth_firstn. exact Hb.
Qed.

(* Canonical-execution determinism: any pre-run whose trace inputs are a prefix
   of [ins] coincides, config-by-config AND event-by-event, with the canonical
   forward run [frun (Receptive initState) ins ...]. Proof: induction on the
   admits_trace derivation; the appended step is matched to the next frun step.
   frun reaches the new length (else frun_inputs_exact says it consumed all of
   ins, contradicting that one more input is still available), and the new step's
   event equals the trace's: for an active config by astep determinism, for a
   receptive config because both are inputs and both input-extensions are
   equal-length prefixes of ins (list_prefix_snoc_det). The target then agrees by
   step_determ_cfg. *)
Lemma prerun_is_frun : forall g th ins,
  admits_trace g th -> Forall is_input ins -> list_prefix (inputs th) ins ->
  length (frun (Receptive initState) ins (length g - 1)) = length g - 1
  /\ g = Receptive initState :: map snd (frun (Receptive initState) ins (length g - 1))
  /\ th = map fst (frun (Receptive initState) ins (length g - 1)).
Proof.
  intros g th ins Hat. induction Hat as [| gs evs ev g' Hatpre IH Hstep];
    intros Hforall Hpref.
  - (* AT_init *)
    simpl. split; [reflexivity | split; reflexivity].
  - (* AT_step *)
    assert (Hpref_evs : list_prefix (inputs evs) ins).
    { rewrite inputs_app in Hpref. apply (list_prefix_app_weaken _ _ _ _ Hpref). }
    destruct (IH Hforall Hpref_evs) as [IHlen [IHg IHth]].
    pose proof (admits_trace_length gs evs Hatpre) as Hgslen.
    replace (length (gs ++ [g']) - 1) with (S (length gs - 1))
      by (rewrite length_app; simpl; lia).
    set (N := length gs - 1) in *.
    assert (Hfrcfg : frcfg (Receptive initState) ins N = last_cfg gs).
    { unfold frcfg. rewrite <- IHg. reflexivity. }
    (* STEP 1: the forward run reaches the new length S N. *)
    assert (Hfull : length (frun (Receptive initState) ins (S N)) = S N).
    { assert (Hbound : length (frun (Receptive initState) ins (S N)) = S N
                    \/ length (frun (Receptive initState) ins (S N)) = N).
      { pose proof (frun_length (S N) (Receptive initState) ins) as Hub.
        pose proof (frun_firstn (S N) N (Receptive initState) ins ltac:(lia)) as Hfn.
        apply (f_equal (@length (event * config))) in Hfn.
        rewrite length_firstn, IHlen in Hfn.
        pose proof (Nat.le_min_r N (length (frun (Receptive initState) ins (S N)))) as Hmr.
        rewrite Hfn in Hmr. lia. }
      destruct Hbound as [Hf | Hh]; [exact Hf | exfalso].
      assert (Hlt : length (frun (Receptive initState) ins (S N)) < S N) by lia.
      assert (Heq : frun (Receptive initState) ins (S N) = frun (Receptive initState) ins N).
      { rewrite <- (frun_firstn (S N) N (Receptive initState) ins ltac:(lia)).
        symmetry. apply firstn_all2. lia. }
      pose proof (frun_halt_receptive (S N) (Receptive initState) ins Hforall Hlt) as Hrecv.
      assert (HfrcfgS : frcfg (Receptive initState) ins (S N) = last_cfg gs).
      { unfold frcfg. rewrite Heq, <- IHg. reflexivity. }
      rewrite HfrcfgS in Hrecv. destruct Hrecv as [s Hs].
      rewrite Hs in Hstep. pose proof (step_receptive_input s ev g' Hstep) as Hevin.
      assert (Hiev : inputs [ev] = [ev]) by (rewrite (inputs_cons_input ev [] Hevin); reflexivity).
      pose proof (frun_inputs_exact (S N) (Receptive initState) ins Hforall Hlt) as Hinx.
      rewrite Heq, <- IHth in Hinx.
      rewrite inputs_app, Hiev, Hinx in Hpref.
      apply list_prefix_length in Hpref. rewrite length_app in Hpref. simpl in Hpref. lia. }
    (* STEP 2: match the new step to the trace's last step. *)
    destruct (frun_snoc N (Receptive initState) ins Hfull) as [ef [gf [Hsnoc Hstepf]]].
    rewrite Hfrcfg in Hstepf.
    assert (Hef : ef = ev /\ gf = g').
    { remember (last_cfg gs) as lc eqn:Hlc.
      destruct lc as [s | c s].
      - pose proof (step_receptive_input s ef gf Hstepf) as Hefin.
        pose proof (step_receptive_input s ev g' Hstep) as Hevin.
        assert (Hi_ef : inputs [ef] = [ef]) by (rewrite (inputs_cons_input ef [] Hefin); reflexivity).
        assert (Hi_ev : inputs [ev] = [ev]) by (rewrite (inputs_cons_input ev [] Hevin); reflexivity).
        assert (Hmf : map fst (frun (Receptive initState) ins (S N)) = evs ++ [ef])
          by (rewrite Hsnoc, map_app, <- IHth; reflexivity).
        pose proof (frun_inputs_prefix (S N) (Receptive initState) ins) as Hpf.
        rewrite Hmf, inputs_app, Hi_ef in Hpf.
        rewrite inputs_app, Hi_ev in Hpref.
        assert (Hee : ef = ev) by (apply (list_prefix_snoc_det _ (inputs evs) ins ef ev Hpf Hpref)).
        split; [exact Hee | subst ef; apply (step_determ_cfg (Receptive s) ev gf g' Hstepf Hstep)].
      - pose proof (astep_determ c s ef gf Hstepf) as Haf.
        pose proof (astep_determ c s ev g' Hstep) as Hag.
        rewrite Haf in Hag. injection Hag as Hee Hgg. split; [exact Hee | exact Hgg]. }
    destruct Hef as [Hefev Hgfg']. subst ef gf.
    split; [exact Hfull | split].
    + rewrite Hsnoc, map_app. cbn [map]. rewrite app_comm_cons, <- IHg. reflexivity.
    + rewrite Hsnoc, map_app. cbn [map]. rewrite <- IHth. reflexivity.
Qed.

(* Canonical-run determinism: pre-runs whose inputs are prefixes of a common ins
   agree config-by-config at every common index (both are prefixes of the unique
   execution of ins). *)
Lemma prerun_index_det : forall ins g1 g2 ih1 ih2 m,
  Forall is_input ins ->
  pr_inputs g1 ih1 -> list_prefix ih1 ins ->
  pr_inputs g2 ih2 -> list_prefix ih2 ins ->
  m < length g1 -> m < length g2 ->
  cfg_at g1 m = cfg_at g2 m.
Proof.
  intros ins g1 g2 ih1 ih2 m Hforall [th1 [Hat1 Hih1]] Hpf1 [th2 [Hat2 Hih2]] Hpf2 Hm1 Hm2.
  assert (Hp1 : list_prefix (inputs th1) ins) by (rewrite Hih1; exact Hpf1).
  assert (Hp2 : list_prefix (inputs th2) ins) by (rewrite Hih2; exact Hpf2).
  destruct (prerun_is_frun g1 th1 ins Hat1 Hforall Hp1) as [_ [Hg1 _]].
  destruct (prerun_is_frun g2 th2 ins Hat2 Hforall Hp2) as [_ [Hg2 _]].
  unfold cfg_at. rewrite Hg1, Hg2.
  destruct m as [|m'].
  - reflexivity.
  - cbn [nth]. apply frun_snd_nth_agree; lia.
Qed.

(* Maximality of an inputs-exhausted, receptive-ended pre-run: if hb has consumed
   ALL of ins and its last config is receptive (so it cannot advance without more
   input, of which none remain), then any pre-run es whose inputs are a prefix of
   ins is no longer than hb. (A longer es would extend hb by a step out of its
   receptive last config, which consumes an input beyond ins -- impossible since
   es's inputs are a prefix of ins.) *)
Lemma prerun_exhausted_maximal : forall ins hb ihb es ihe,
  Forall is_input ins ->
  pr_inputs hb ihb -> ihb = ins -> is_receptive (last_cfg hb) ->
  pr_inputs es ihe -> list_prefix ihe ins ->
  length es <= length hb.
Proof.
  intros ins hb ihb es ihe Hins Hprhb Hihb Hrecv Hpres Hpfe.
  destruct Hprhb as [thb [Hathb Hihb_eq]]. destruct Hpres as [the [Hate Hihe_eq]].
  subst ihe ihb.
  assert (Hpfhb' : list_prefix (inputs thb) ins) by (rewrite Hihb; apply list_prefix_refl).
  destruct (prerun_is_frun hb thb ins Hathb Hins Hpfhb') as [HlenHb [HgHb HthHb]].
  destruct (prerun_is_frun es the ins Hate Hins Hpfe) as [HlenEs [HgEs HthEs]].
  assert (Hhbpos : 1 <= length hb) by (rewrite HgHb; simpl; lia).
  set (N := length hb - 1) in *.
  destruct (Nat.le_gt_cases (length es) (length hb)) as [Hle|Hgt]; [exact Hle | exfalso].
  assert (HNle : S N <= length es - 1) by lia.
  assert (HRfirst : frun (Receptive initState) ins (S N) = firstn (S N) (frun (Receptive initState) ins (length es - 1)))
    by (symmetry; apply frun_firstn; lia).
  assert (HlenRSN : length (frun (Receptive initState) ins (S N)) = S N)
    by (rewrite HRfirst, length_firstn, HlenEs; apply Nat.min_l; lia).
  destruct (frun_snoc N (Receptive initState) ins HlenRSN) as [ef [gf [Hsnoc Hstepf]]].
  assert (Hrecv2 : is_receptive (frcfg (Receptive initState) ins N))
    by (unfold frcfg; rewrite <- HgHb; exact Hrecv).
  destruct Hrecv2 as [s Hs]. rewrite Hs in Hstepf.
  pose proof (step_receptive_input s ef gf Hstepf) as Hefin.
  assert (Hmf : map fst (frun (Receptive initState) ins (S N)) = map fst (frun (Receptive initState) ins N) ++ [ef])
    by (rewrite Hsnoc, map_app; reflexivity).
  assert (HinN : inputs (map fst (frun (Receptive initState) ins N)) = ins)
    by (rewrite <- HthHb; exact Hihb).
  assert (HinSN : inputs (map fst (frun (Receptive initState) ins (S N))) = ins ++ [ef])
    by (rewrite Hmf, inputs_app, HinN; f_equal; rewrite (inputs_cons_input ef [] Hefin); reflexivity).
  pose proof (frun_inputs_prefix (S N) (Receptive initState) ins) as Hpref.
  rewrite HinSN in Hpref. apply list_prefix_length in Hpref.
  rewrite length_app in Hpref. simpl in Hpref. lia.
Qed.

(* -------------------------------------------------------------------------- *) 
(* A theorem that is interesting but not used in the rest of the development. *)
(* -------------------------------------------------------------------------- *) 

(* The paper's lem:traceFromInput. For any list ins of input events, there is a 
   unique  pre-run gs such that (a) the inputs of the unique trace admitted by gs 
   are a prefix of ins, (b) last(gs) is receptive, and (c) if those inputs are not
   all of ins then there is an infinite chain G, of type nat -> list config, such
   that for all i the following hold.  The length of G_i is i+1, G_i is a prefix 
   of G_(i+1), gs++G_i is a pre-run, and the inputs of gs++G_i are a proper prefix      
   of ins.
*)

(* ---- Helper lemmas ---- *)

(* Number of inputs consumed by the canonical N-step run of ins. *)
Definition tfi_f (ins : list event) (N : nat) : nat :=
  length (inputs (map fst (frun (Receptive initState) ins N))).

Lemma tfi_f0 : forall ins, tfi_f ins 0 = 0.
Proof. intros ins. reflexivity. Qed.

Lemma tfi_f_mono : forall ins a b, a <= b -> tfi_f ins a <= tfi_f ins b.
Proof.
  intros ins a b Hab. unfold tfi_f.
  apply list_prefix_length. apply frun_inputs_mono. exact Hab.
Qed.

Lemma tfi_f_bound : forall ins N, tfi_f ins N <= length ins.
Proof.
  intros ins N. unfold tfi_f. apply list_prefix_length. apply frun_inputs_prefix.
Qed.

Lemma tfi_f_inc : forall ins n, tfi_f ins (S n) <= tfi_f ins n + 1.
Proof.
  intros ins n. unfold tfi_f.
  assert (Hf : frun (Receptive initState) ins n
             = firstn n (frun (Receptive initState) ins (S n))).
  { symmetry. apply frun_firstn. lia. }
  assert (Hsplit : map fst (frun (Receptive initState) ins (S n))
                 = map fst (frun (Receptive initState) ins n)
                   ++ map fst (skipn n (frun (Receptive initState) ins (S n)))).
  { rewrite Hf. rewrite <- map_app. rewrite firstn_skipn. reflexivity. }
  rewrite Hsplit. unfold inputs. rewrite filter_app, length_app.
  assert (Hle : length (filter is_input_b
                  (map fst (skipn n (frun (Receptive initState) ins (S n))))) <= 1).
  { pose proof (filter_length_le is_input_b
                  (map fst (skipn n (frun (Receptive initState) ins (S n))))) as Hf2.
    rewrite length_map in Hf2.
    rewrite length_skipn in Hf2.
    pose proof (frun_length (S n) (Receptive initState) ins) as Hl. lia. }
  lia.
Qed.

(* One-step change in consumed inputs: it grows by 1 iff the emitted event is an
   input; the appended step is taken from the config after p steps. *)
Lemma tfi_snoc_event : forall ins p,
  length (frun (Receptive initState) ins (S p)) = S p ->
  exists ev g',
    step (frcfg (Receptive initState) ins p) ev g' /\
    tfi_f ins (S p) = tfi_f ins p + (if is_input_b ev then 1 else 0).
Proof.
  intros ins p Hlen.
  destruct (frun_snoc p (Receptive initState) ins Hlen) as [ev [g' [Heq Hstep]]].
  exists ev, g'. split; [exact Hstep |].
  unfold tfi_f. rewrite Heq, map_app, inputs_app, length_app. f_equal.
  cbn. destruct (is_input_b ev); reflexivity.
Qed.

(* In the divergent (never-halting) case, a step that does not grow the consumed
   inputs leaves from an active config. *)
Lemma tfi_bridge_act : forall ins,
  (forall N, length (frun (Receptive initState) ins N) = N) ->
  forall p, tfi_f ins (S p) = tfi_f ins p ->
  is_active (frcfg (Receptive initState) ins p).
Proof.
  intros ins HB p Heq.
  destruct (tfi_snoc_event ins p (HB (S p))) as [ev [g' [Hstep Hcount]]].
  assert (Hni : is_input_b ev = false).
  { destruct (is_input_b ev) eqn:E.
    - simpl in Hcount. exfalso. lia.
    - reflexivity. }
  destruct (frcfg (Receptive initState) ins p) as [s | c s] eqn:Ecfg.
  - exfalso. pose proof (step_receptive_input s ev g' Hstep) as Hin.
    rewrite Hin in Hni. discriminate.
  - exists c, s. reflexivity.
Qed.

(* ... and a step that grows the consumed inputs leaves from a receptive config. *)
Lemma tfi_bridge_recv : forall ins,
  (forall N, length (frun (Receptive initState) ins N) = N) ->
  forall d, tfi_f ins (S d) = tfi_f ins d + 1 ->
  is_receptive (frcfg (Receptive initState) ins d).
Proof.
  intros ins HB d Hgrow.
  destruct (tfi_snoc_event ins d (HB (S d))) as [ev [g' [Hstep Hcount]]].
  assert (Hin : is_input_b ev = true).
  { destruct (is_input_b ev) eqn:E.
    - reflexivity.
    - simpl in Hcount. exfalso. lia. }
  destruct (frcfg (Receptive initState) ins d) as [s | c s] eqn:Ecfg.
  - exists s. reflexivity.
  - exfalso. apply astep_determ in Hstep.
    pose proof (astep_event_not_input c s) as Hni.
    rewrite Hstep in Hni. simpl in Hni. rewrite Hin in Hni. discriminate.
Qed.

Lemma tfi_f1 : forall ins,
  (forall N, length (frun (Receptive initState) ins N) = N) ->
  tfi_f ins 1 = 1.
Proof.
  intros ins HB.
  destruct (tfi_snoc_event ins 0 (HB 1)) as [ev [g' [Hstep Hcount]]].
  assert (Hcfg : frcfg (Receptive initState) ins 0 = Receptive initState) by reflexivity.
  rewrite Hcfg in Hstep.
  pose proof (step_receptive_input initState ev g' Hstep) as Hin.
  rewrite Hin in Hcount.
  change (if true then 1 else 0) with 1 in Hcount.
  pose proof (tfi_f0 ins) as H0. lia.
Qed.

(* The following omits uniqueness (bis). *)

Theorem traceFromInput_nonunique :
  forall ins : list event,
    Forall is_input ins ->
    exists gs : list config,
      pre_run gs /\
      is_receptive (last_cfg gs) /\
      (exists evs,
         admits_trace gs evs /\
         list_prefix (inputs evs) ins /\
         (inputs evs <> ins ->
          exists G : nat -> list config,
            (forall i,
               length(G i) = i+1 /\
               Forall is_active (G i) /\
               pre_run (gs ++ G i) /\
               (exists evs', admits_trace (gs ++ G i) evs' /\ list_prefix (inputs evs') ins) /\
               list_strict_prefix (G i) (G (i+1))))).
Proof.
  intros ins Hins.
  destruct (classic (exists N, length (frun (Receptive initState) ins N) < N))
    as [HA | HB].
  - (* Case A: the canonical run halts, consuming all of ins at a receptive
       config.  We choose that halted pre-run and make the divergence branch
       vacuous. *)
    destruct HA as [N Hlt].
    assert (Hconsumed :
      inputs (map fst (frun (last_cfg [Receptive initState]) ins N)) = ins).
    { apply frun_inputs_exact; [exact Hins | exact Hlt]. }
    exists ([Receptive initState]
              ++ map snd (frun (last_cfg [Receptive initState]) ins N)).
    split; [| split].
    + apply frun_pre_run. apply pre_run_singleton_init.
    + rewrite frcfg_last. apply frun_halt_receptive; [exact Hins | exact Hlt].
    + exists (map fst (frun (last_cfg [Receptive initState]) ins N)).
      split; [| split].
      * pose proof (frun_admits N [Receptive initState] [] ins AT_init) as Hat.
        rewrite app_nil_l in Hat. exact Hat.
      * rewrite Hconsumed. apply list_prefix_refl.
      * intros Hne. exfalso. apply Hne. exact Hconsumed.
  - (* Case B: the canonical run never halts (diverges).  It consumes only
       finitely many inputs, so it settles into an infinite purely-active tail
       after the last receptive config; that gives the required chain G. *)
    assert (HBlen : forall N, length (frun (Receptive initState) ins N) = N).
    { intros N. pose proof (frun_length N (Receptive initState) ins) as Hle.
      destruct (Nat.lt_ge_cases (length (frun (Receptive initState) ins N)) N)
        as [Hl | Hg].
      - exfalso. apply HB. exists N. exact Hl.
      - lia. }
    destruct (nat_bounded_fun_has_max (tfi_f ins) (length ins) (tfi_f_bound ins))
      as [Mmax Hmax].
    destruct (decidable_least_witness (fun n => tfi_f ins n = tfi_f ins Mmax)
                (fun n => Nat.eq_dec (tfi_f ins n) (tfi_f ins Mmax))
                (ex_intro _ Mmax eq_refl)) as [Mst [HMst Hleast]].
    assert (HMst1 : 1 <= Mst).
    { destruct Mst as [| m]; [| lia]. exfalso.
      rewrite tfi_f0 in HMst.
      pose proof (Hmax 1) as Hm1.
      pose proof (tfi_f1 ins HBlen) as Hf1. lia. }
    set (d := Mst - 1).
    assert (Hd_eq : d = Mst - 1) by reflexivity.
    assert (HSd : S d = Mst) by (rewrite Hd_eq; lia).
    assert (Hstable : forall p, Mst <= p -> tfi_f ins p = tfi_f ins Mmax).
    { intros p Hp.
      assert (H1 : tfi_f ins Mst <= tfi_f ins p) by (apply tfi_f_mono; exact Hp).
      assert (H2 : tfi_f ins p <= tfi_f ins Mmax) by apply Hmax.
      rewrite HMst in H1. lia. }
    assert (Hrecv : is_receptive (frcfg (Receptive initState) ins d)).
    { apply (tfi_bridge_recv ins HBlen d).
      assert (HdJ : tfi_f ins d < tfi_f ins Mmax).
      { destruct (Nat.lt_ge_cases (tfi_f ins d) (tfi_f ins Mmax))
          as [Hl | Hg]; [exact Hl |].
        exfalso.
        assert (Hle2 : tfi_f ins d <= tfi_f ins Mmax) by apply Hmax.
        assert (Heqd : tfi_f ins d = tfi_f ins Mmax) by lia.
        apply (Hleast d); [rewrite Hd_eq; lia | exact Heqd]. }
      assert (Hinc : tfi_f ins (S d) <= tfi_f ins d + 1) by apply tfi_f_inc.
      rewrite HSd, HMst in Hinc. rewrite HSd, HMst. lia. }
    assert (Hact : forall q, S d <= q -> is_active (frcfg (Receptive initState) ins q)).
    { intros q Hq. apply (tfi_bridge_act ins HBlen q).
      assert (Hq1 : tfi_f ins (S q) = tfi_f ins Mmax)
        by (apply Hstable; rewrite HSd in Hq; lia).
      assert (Hq2 : tfi_f ins q = tfi_f ins Mmax)
        by (apply Hstable; rewrite HSd in Hq; lia).
      lia. }
    exists ([Receptive initState]
              ++ map snd (frun (last_cfg [Receptive initState]) ins d)).
    split; [| split].
    + apply frun_pre_run. apply pre_run_singleton_init.
    + rewrite frcfg_last. exact Hrecv.
    + exists (map fst (frun (last_cfg [Receptive initState]) ins d)).
      split; [| split].
      * pose proof (frun_admits d [Receptive initState] [] ins AT_init) as Hat.
        rewrite app_nil_l in Hat. exact Hat.
      * apply frun_inputs_prefix.
      * intros _.
        exists (fun i => map snd (skipn d (frun (Receptive initState) ins (S (d + i))))).
        intros i. cbv beta.
        remember (S (d + i)) as ni eqn:Hni_eq.
        assert (Hlenni : length (frun (Receptive initState) ins ni) = ni)
          by apply HBlen.
        assert (Hdle : d <= ni) by (rewrite Hni_eq; lia).
        assert (Hcat :
          ([Receptive initState]
             ++ map snd (frun (last_cfg [Receptive initState]) ins d))
            ++ map snd (skipn d (frun (Receptive initState) ins ni))
          = [Receptive initState] ++ map snd (frun (Receptive initState) ins ni)).
        { change (last_cfg [Receptive initState]) with (Receptive initState).
          rewrite <- app_assoc. f_equal. rewrite <- map_app.
          rewrite <- (frun_firstn ni d (Receptive initState) ins Hdle).
          rewrite firstn_skipn. reflexivity. }
        split; [| split; [| split; [| split]]].
        -- rewrite length_map, length_skipn, Hlenni, Hni_eq. lia.
        -- apply Forall_forall. intros x Hx.
           apply (In_nth _ _ (Receptive initState)) in Hx.
           destruct Hx as [k [Hk Hxk]].
           rewrite length_map, length_skipn, Hlenni in Hk.
           rewrite <- Hxk, <- skipn_map, nth_skipn.
           rewrite frun_nth_snd.
           ++ apply Hact. lia.
           ++ rewrite Hlenni, Hni_eq. lia.
        -- rewrite Hcat. apply frun_pre_run. apply pre_run_singleton_init.
        -- exists (map fst (frun (Receptive initState) ins ni)).
           split.
           ++ rewrite Hcat.
              pose proof (frun_admits ni [Receptive initState] [] ins AT_init) as Hat.
              rewrite app_nil_l in Hat.
              change (last_cfg [Receptive initState]) with (Receptive initState) in Hat.
              exact Hat.
           ++ apply frun_inputs_prefix.
        -- assert (HSni : S (d + (i + 1)) = S ni) by (rewrite Hni_eq; lia).
           destruct (frun_snoc ni (Receptive initState) ins (HBlen (S ni)))
             as [ev [g' [Hsnoc _]]].
           split.
           ++ exists [g'].
              rewrite HSni, Hsnoc, skipn_app, Hlenni.
              replace (d - ni) with 0 by lia.
              change (skipn 0 [(ev, g')]) with [(ev, g')].
              rewrite map_app. reflexivity.
           ++ intro Hcontra.
              apply (f_equal (@length config)) in Hcontra.
              rewrite !length_map, !length_skipn in Hcontra.
              rewrite Hlenni, (HBlen (S (d + (i + 1)))) in Hcontra.
              rewrite Hni_eq in Hcontra. lia.
Qed.

(* -------------------------------------------------------------------------- *)
(* The same statement with UNIQUENESS (exists!).  The predicate below is
   exactly the body of traceFromInput_nonunique; naming it lets the uniqueness
   argument refer to it.                                                       *)
(* -------------------------------------------------------------------------- *)

Definition tfi_spec (ins : list event) (gs : list config) : Prop :=
  pre_run gs /\
  is_receptive (last_cfg gs) /\
  (exists evs,
     admits_trace gs evs /\
     list_prefix (inputs evs) ins /\
     (inputs evs <> ins ->
      exists G : nat -> list config,
        (forall i,
           length(G i) = i+1 /\
           Forall is_active (G i) /\
           pre_run (gs ++ G i) /\
           (exists evs', admits_trace (gs ++ G i) evs' /\ list_prefix (inputs evs') ins) /\
           list_strict_prefix (G i) (G (i+1))))).

(* A solution is exactly the canonical run of ins truncated to its length
   (prerun_is_frun), so a solution is determined by its length.  No solution is
   strictly shorter than another: a strictly shorter one either (a) already
   consumed all of ins at a receptive config -- then prerun_exhausted_maximal
   bounds the longer one's length, contradiction; or (b) consumed a proper
   prefix -- then its divergence chain, appended, reconstructs the longer
   solution, forcing that solution's last (receptive) config to be active. *)
Lemma tfi_no_shorter : forall ins, Forall is_input ins ->
  forall g1 g2, tfi_spec ins g1 -> tfi_spec ins g2 ->
  length g1 < length g2 -> False.
Proof.
  intros ins Hins g1 g2 Hs1 Hs2 Hlt.
  unfold tfi_spec in Hs1, Hs2.
  destruct Hs1 as [Hpre1 [Hrecv1 [evs1 [Hat1 [Hpf1 Himpl1]]]]].
  destruct Hs2 as [Hpre2 [Hrecv2 [evs2 [Hat2 [Hpf2 Himpl2]]]]].
  destruct (classic (inputs evs1 = ins)) as [Heqins | Hneins].
  - (* g1 consumed all of ins and ends receptive: it is maximal. *)
    assert (Hle : length g2 <= length g1).
    { apply (prerun_exhausted_maximal ins g1 (inputs evs1) g2 (inputs evs2)).
      - exact Hins.
      - exists evs1. split; [exact Hat1 | reflexivity].
      - exact Heqins.
      - exact Hrecv1.
      - exists evs2. split; [exact Hat2 | reflexivity].
      - exact Hpf2. }
    lia.
  - (* g1's inputs are a proper prefix: use its divergence chain. *)
    destruct (Himpl1 Hneins) as [G HG].
    set (i0 := length g2 - length g1 - 1).
    assert (Hi0 : i0 = length g2 - length g1 - 1) by reflexivity.
    destruct (HG i0) as [Hlen_Gi0 [Hact_Gi0 [Hpre_Gi0 [Hex_Gi0 _]]]].
    destruct Hex_Gi0 as [evs' [Hat' Hpf']].
    destruct (prerun_is_frun (g1 ++ G i0) evs' ins Hat' Hins Hpf')
      as [_ [Hcatfrun _]].
    destruct (prerun_is_frun g2 evs2 ins Hat2 Hins Hpf2) as [_ [Hg2eq _]].
    assert (Hlen_eq : length (g1 ++ G i0) = length g2).
    { rewrite length_app, Hlen_Gi0. lia. }
    assert (Hcat_eq : g1 ++ G i0 = g2).
    { rewrite Hg2eq. rewrite <- Hlen_eq. exact Hcatfrun. }
    assert (HGne : G i0 <> []).
    { intro Hc. rewrite Hc in Hlen_Gi0. simpl in Hlen_Gi0. lia. }
    assert (Hlast_active : is_active (last_cfg (G i0))).
    { rewrite Forall_forall in Hact_Gi0. apply Hact_Gi0.
      unfold last_cfg. rewrite last_nth_def. apply nth_In.
      rewrite Hlen_Gi0. lia. }
    apply (not_active_receptive (last_cfg g2)).
    + rewrite <- Hcat_eq. unfold last_cfg.
      rewrite last_app_nonempty by exact HGne. exact Hlast_active.
    + exact Hrecv2.
Qed.

Lemma tfi_spec_unique : forall ins, Forall is_input ins ->
  forall g1 g2, tfi_spec ins g1 -> tfi_spec ins g2 -> g1 = g2.
Proof.
  intros ins Hins g1 g2 Hs1 Hs2.
  assert (Hlen : length g1 = length g2).
  { destruct (Nat.lt_trichotomy (length g1) (length g2)) as [Hlt | [Heq | Hgt]].
    - exfalso. apply (tfi_no_shorter ins Hins g1 g2 Hs1 Hs2 Hlt).
    - exact Heq.
    - exfalso. apply (tfi_no_shorter ins Hins g2 g1 Hs2 Hs1 Hgt). }
  unfold tfi_spec in Hs1, Hs2.
  destruct Hs1 as [_ [_ [evs1 [Hat1 [Hpf1 _]]]]].
  destruct Hs2 as [_ [_ [evs2 [Hat2 [Hpf2 _]]]]].
  destruct (prerun_is_frun g1 evs1 ins Hat1 Hins Hpf1) as [_ [Hg1eq _]].
  destruct (prerun_is_frun g2 evs2 ins Hat2 Hins Hpf2) as [_ [Hg2eq _]].
  assert (Hidx : length g1 - 1 = length g2 - 1) by (rewrite Hlen; reflexivity).
  rewrite Hg1eq, Hg2eq, Hidx. reflexivity.
Qed.

(* lem:traceFromInput, now WITH the uniqueness that the comment promised. *)
Theorem traceFromInput_unique :
  forall ins : list event,
    Forall is_input ins ->
    exists! gs : list config,
      pre_run gs /\
      is_receptive (last_cfg gs) /\
      (exists evs,
         admits_trace gs evs /\
         list_prefix (inputs evs) ins /\
         (inputs evs <> ins ->
          exists G : nat -> list config,
            (forall i,
               length(G i) = i+1 /\
               Forall is_active (G i) /\
               pre_run (gs ++ G i) /\
               (exists evs', admits_trace (gs ++ G i) evs' /\ list_prefix (inputs evs') ins) /\
               list_strict_prefix (G i) (G (i+1))))).
Proof.
  intros ins Hins.
  destruct (traceFromInput_nonunique ins Hins) as [gs Hgs].
  exists gs. split.
  - exact Hgs.
  - intros gs' Hgs'. apply (tfi_spec_unique ins Hins gs gs').
    + exact Hgs.
    + exact Hgs'.
Qed.




(* TODO check whether following comments are up to date. *)
(* ====================================================================== *)
(* DETERMINACY LEMMAS for the exclusivity results                         *)
(*                                                                        *)
(* Six facts, used to prove the benign-vs-failure contradictions. They    *)
(* split into two kinds of determinism, both expressing that the          *)
(* canonical execution of an input list is unique:                        *)
(*                                                                        *)
(*  * RUN determinism:                                                    *)
(*      prerun_index_det  -- pre-runs with inputs <= ins agree config-by- *)
(*                           config at each index (defined below, near the *)
(*                           divergence reach lemmas).                     *)
(*                                                                        *)
(*  * ALIGNMENT canonicity (a proper covering alignment matches the k-th  *)
(*    l-annotation of gs with the k-th l-annotation of the canonical run, *)
(*    so the major<->minor annotation-index correspondence is canonical): *)
(*      minor_annot_cfg_det     -- domain side (same major annotation =>  *)
(*                                  same aligned minor config)             *)
(*      major_annot_cfg_det     -- range side (same minor annotation  =>  *)
(*                                  same aligned major config; below)      *)
(*      alignF_offense_cfg_det  -- the alignment-failure offense config is *)
(*                                  that canonical minor config            *)
(*      conf_meets_aligned_annot / conf_meets_alignF_offense              *)
(*                              -- coverage + the cfg-determinacy above    *)
(*                                 (a conformance reaches every annotation *)
(*                                  a failure reaches, with config agreement)*)
(*                                                                        *)
(* NOTE: these are NOT mutually derivable from prerun_index_det alone --  *)
(* alignment canonicity is a separate fact (annotations matched rank-by-  *)
(* rank). A single "annotation-matching canonicity" lemma would subsume   *)
(* all of them (kept as separate axioms pending the alignment-failure /   *)
(* divergence design settling; see chat 2026-06-16).                      *)
(* ====================================================================== *)

(* Two minor pre-runs with inputs <= a common ins reach their n-th l-annotation
   at the same index: both are config-prefixes of the canonical run of ins
   (prerun_index_det), so their annotation structure coincides on the common
   range. *)
Lemma nth_annot_det : forall l ins es1 es2 ih1 ih2 n j1 j2,
  Forall is_input ins ->
  pr_inputs es1 ih1 -> list_prefix ih1 ins ->
  pr_inputs es2 ih2 -> list_prefix ih2 ins ->
  is_nth_annot l es1 n j1 -> is_nth_annot l es2 n j2 ->
  j1 = j2.
Proof.
  intros l ins es1 es2 ih1 ih2 n j1 j2 Hins Hpr1 Hpf1 Hpr2 Hpf2 Hn1 Hn2.
  assert (Hkey : forall (a b:list config) iha ihb pa pb,
            pr_inputs a iha -> list_prefix iha ins -> pr_inputs b ihb -> list_prefix ihb ins ->
            is_nth_annot l a n pa -> is_nth_annot l b n pb -> pa < pb -> False).
  { intros a b iha ihb pa pb Hpra Hpfa Hprb Hpfb Hpaa Hpbb Hlt.
    destruct Hpaa as [Hpalt [Hannpa Hcpa]]. pose proof Hpbb as Hpbb2.
    destruct Hpbb2 as [Hpblt [Hannpb Hcpb]].
    assert (Hagree : forall k, k <= pa -> cfg_at a k = cfg_at b k)
      by (intros k Hk; apply (prerun_index_det ins a b iha ihb k Hins Hpra Hpfa Hprb Hpfb); lia).
    assert (Hannpa_b : redex_is_l_annotation l (cfg_at b pa))
      by (rewrite <- (Hagree pa (Nat.le_refl pa)); exact Hannpa).
    assert (Hcnt : annot_count l b pa = annot_count l a pa)
      by (apply annot_count_ext; intros mm Hm; symmetry; apply Hagree; lia).
    assert (Hnthb_pa : is_nth_annot l b n pa)
      by (split; [lia | split; [exact Hannpa_b | rewrite Hcnt, Hcpa; reflexivity]]).
    assert (Hpaeq : pa = pb) by (apply (is_nth_annot_unique l b n pa pb Hnthb_pa Hpbb)). lia. }
  destruct (Nat.lt_trichotomy j1 j2) as [Hlt|[Heq|Hgt]];
    [ exfalso; apply (Hkey es1 es2 ih1 ih2 j1 j2 Hpr1 Hpf1 Hpr2 Hpf2 Hn1 Hn2 Hlt)
    | exact Heq
    | exfalso; apply (Hkey es2 es1 ih2 ih1 j2 j1 Hpr2 Hpf2 Hpr1 Hpf1 Hn2 Hn1 Hgt) ].
Qed.

(* MINOR-RUN DETERMINACY (proved via prerun_index_det / frun canonicity).
   For a fixed major run gs and input list ins, the minor configuration
   aligned to an l-annotation major index i is the same across any two
   minor scenarios (both proper alignments to gs, both minors executing a
   prefix of ins). Justification: each minor is a prefix of the unique
   canonical execution of ins (determinism), and a proper alignment matches
   the k-th l-annotation of gs with the k-th l-annotation of the minor, so
   the annotation major i is aligned to the same minor configuration in
   both scenarios.
   The major lists ds1, ds2 may be (prefix-)truncations of the common gs (the
   conformance_below of an alignment failure aligns to a truncated major); the
   "cfg_at ds1 i = cfg_at ds2 i" hypothesis says both name the same major
   annotation. *)
Lemma minor_annot_cfg_det :
  forall l ins ds1 ds2 es1 es2 alpha1 alpha2 i j1 j2,
    l_aligned_pair l ds1 es1 alpha1 ->
    l_aligned_pair l ds2 es2 alpha2 ->
    covers_rng es1 alpha1 ->
    covers_rng es2 alpha2 ->
    (exists ih, pr_inputs es1 ih /\ list_prefix ih ins) ->
    (exists ih, pr_inputs es2 ih /\ list_prefix ih ins) ->
    Forall is_input ins ->
    cfg_at ds1 i = cfg_at ds2 i ->
    annot_count l ds1 i = annot_count l ds2 i ->
    redex_is_l_annotation l (cfg_at ds1 i) ->
    alpha1 i j1 -> alpha2 i j2 ->
    cfg_at es1 j1 = cfg_at es2 j2.
Proof.
  intros l ins ds1 ds2 es1 es2 alpha1 alpha2 i j1 j2 Hlap1 Hlap2 Hcrng1 Hcrng2 Hih1 Hih2 Hins Hcfg Hrank Hann1 Ha1 Ha2.
  assert (Hi1 : i < length ds1) by (destruct Hlap1 as [_ [_ [[Hb _] _]]]; apply (Hb i j1 Ha1)).
  assert (Hi2 : i < length ds2) by (destruct Hlap2 as [_ [_ [[Hb _] _]]]; apply (Hb i j2 Ha2)).
  assert (Hann2 : redex_is_l_annotation l (cfg_at ds2 i)) by (rewrite <- Hcfg; exact Hann1).
  assert (Hnth1 : is_nth_annot l ds1 (annot_count l ds1 i) i)
    by (split; [exact Hi1 | split; [exact Hann1 | reflexivity]]).
  assert (Hnth2 : is_nth_annot l ds2 (annot_count l ds1 i) i)
    by (split; [exact Hi2 | split; [exact Hann2 | symmetry; exact Hrank]]).
  assert (Hes1 : is_nth_annot l es1 (annot_count l ds1 i) j1)
    by (apply (annot_align_rank l ds1 es1 alpha1 (annot_count l ds1 i) i j1 Hlap1 Hcrng1 Hnth1 Ha1)).
  assert (Hes2 : is_nth_annot l es2 (annot_count l ds1 i) j2)
    by (apply (annot_align_rank l ds2 es2 alpha2 (annot_count l ds1 i) i j2 Hlap2 Hcrng2 Hnth2 Ha2)).
  destruct Hih1 as [ih1 [Hpr1 Hpf1]]. destruct Hih2 as [ih2 [Hpr2 Hpf2]].
  assert (Hjeq : j1 = j2)
    by (apply (nth_annot_det l ins es1 es2 ih1 ih2 (annot_count l ds1 i) j1 j2 Hins Hpr1 Hpf1 Hpr2 Hpf2 Hes1 Hes2)).
  subst j2. destruct Hes1 as [Hj1lt1 _]. destruct Hes2 as [Hj1lt2 _].
  apply (prerun_index_det ins es1 es2 ih1 ih2 j1 Hins Hpr1 Hpf1 Hpr2 Hpf2 Hj1lt1 Hj1lt2).
Qed.

Lemma conf_covers_annot : forall l ins gs hb ab i hf ihf jf,
  conformance l ins gs hb ab ->
  Forall is_input ins ->
  i < length gs ->
  redex_is_l_annotation l (cfg_at gs i) ->
  pr_inputs hf ihf -> list_prefix ihf ins ->
  is_nth_annot l hf (annot_count l gs i) jf ->
  exists jb, ab i jb.
Proof.
  intros l ins gs hb ab i hf ihf jf Hconf Hins Hilt Hann Hprhf Hpfhf Hnthhf.
  set (n := annot_count l gs i) in *.
  destruct Hconf as [Hlapb [Hihb_disj [Hcrngb [Hmodb Hinpb]]]].
  assert (Hnth_gs : is_nth_annot l gs n i) by (split; [exact Hilt | split; [exact Hann | reflexivity]]).
  destruct Hihb_disj as [ihb [Hprhb [Hpfhb Hdisj]]].
  destruct Hdisj as [Hcovdom | [Hihbins Hreceptive]].
  - destruct (Hcovdom i Hilt) as [jb Hjb]. exists jb. exact Hjb.
  - assert (Hlen : length hf <= length hb)
      by (apply (prerun_exhausted_maximal ins hb ihb hf ihf Hins Hprhb Hihbins Hreceptive Hprhf Hpfhf)).
    destruct Hnthhf as [Hjflt [Hannhf Hcnthf]].
    assert (Hjflb : jf < length hb) by lia.
    destruct (Hcrngb jf Hjflb) as [ib Hib].
    assert (Hcfeq : cfg_at hf jf = cfg_at hb jf)
      by (apply (prerun_index_det ins hf hb ihf ihb jf Hins Hprhf Hpfhf Hprhb Hpfhb Hjflt Hjflb)).
    assert (Hannhb : redex_is_l_annotation l (cfg_at hb jf)) by (rewrite <- Hcfeq; exact Hannhf).
    assert (Hcnthb : annot_count l hb jf = n)
      by (rewrite <- Hcnthf; apply annot_count_ext; intros mm Hm; symmetry;
          apply (prerun_index_det ins hf hb ihf ihb mm Hins Hprhf Hpfhf Hprhb Hpfhb); lia).
    assert (Hnthb : is_nth_annot l hb n jf) by (split; [exact Hjflb | split; [exact Hannhb | exact Hcnthb]]).
    assert (Hannib : redex_is_l_annotation l (cfg_at gs ib))
      by (destruct Hlapb as [_ [_ Hpr]]; apply (proper_annot_rev l gs hb ab ib jf Hpr Hib Hannhb)).
    assert (Hiblt : ib < length gs) by (destruct Hlapb as [_ [_ [[Hbb _] _]]]; apply (proj1 (Hbb ib jf Hib))).
    assert (Hnthgsib : is_nth_annot l gs (annot_count l gs ib) ib)
      by (split; [exact Hiblt | split; [exact Hannib | reflexivity]]).
    assert (Hnthhbib : is_nth_annot l hb (annot_count l gs ib) jf)
      by (apply (annot_align_rank l gs hb ab (annot_count l gs ib) ib jf Hlapb Hcrngb Hnthgsib Hib)).
    assert (Hcib : annot_count l gs ib = n) by (destruct Hnthhbib as [_ [_ Hc]]; rewrite <- Hc; exact Hcnthb).
    assert (Hieqib : i = ib)
      by (apply (is_nth_annot_unique l gs n i ib Hnth_gs);
          split; [exact Hiblt | split; [exact Hannib | exact Hcib]]).
    exists jf. rewrite Hieqib. exact Hib.
Qed.

(* Determinacy + coverage for a CONFORMANCE benign class: a conformance over gs
   reaches (aligns) every l-annotation major index i that any scenario reaches,
   to the SAME minor configuration. (Strengthens minor_annot_cfg_det by also
   supplying coverage of i -- needed because a conformance in "inputs exhausted"
   mode need not cover gs structurally, yet by run determinism its minor still
   passes through the i-th annotation.) *)
Lemma conf_meets_aligned_annot : forall l ins gs hb ab hf af i j,
  conformance l ins gs hb ab ->
  l_aligned_pair l gs hf af ->
  covers_rng hf af ->
  (exists ih, pr_inputs hf ih /\ list_prefix ih ins) ->
  Forall is_input ins ->
  i < length gs ->
  redex_is_l_annotation l (cfg_at gs i) ->
  af i j ->
  exists jb, ab i jb /\ cfg_at hb jb = cfg_at hf j.
Proof.
  intros l ins gs hb ab hf af i j Hconf Hlapf Hcrnghf Hihf Hins Hilt Hann Haf.
  set (n := annot_count l gs i) in *.
  assert (Hnth_gs : is_nth_annot l gs n i) by (split; [exact Hilt | split; [exact Hann | reflexivity]]).
  assert (Hnthhf : is_nth_annot l hf n j)
    by (apply (annot_align_rank l gs hf af n i j Hlapf Hcrnghf Hnth_gs Haf)).
  destruct Hihf as [ihf [Hprhf Hpfhf]].
  destruct (conf_covers_annot l ins gs hb ab i hf ihf j Hconf Hins Hilt Hann Hprhf Hpfhf Hnthhf) as [jb Habijb].
  pose proof Hconf as Hconf2. destruct Hconf2 as [Hlapb [Hihb [Hcrngb [Hmodb Hinpb]]]].
  assert (Hnthhb : is_nth_annot l hb n jb)
    by (apply (annot_align_rank l gs hb ab n i jb Hlapb Hcrngb Hnth_gs Habijb)).
  destruct Hihb as [ihb [Hprhb [Hpfhb _]]].
  assert (Hjbeq : jb = j)
    by (apply (nth_annot_det l ins hb hf ihb ihf n jb j Hins Hprhb Hpfhb Hprhf Hpfhf Hnthhb Hnthhf)).
  exists jb. split; [exact Habijb |].
  destruct Hnthhb as [Hjblthb _]. destruct Hnthhf as [Hjlthf _].
  rewrite Hjbeq.
  apply (prerun_index_det ins hb hf ihb ihf j Hins Hprhb Hpfhb Hprhf Hpfhf); lia.
Qed.

(* Offense-position determinacy for an ALIGNMENT FAILURE: the minor configuration
   that any scenario aligns to the i-th major annotation equals the failure's
   offense config hf_{|hf|-1} (the unmatchable annotation at the minor's end).
   alpha need not align i on the failure side (it is precisely the mismatch);
   this fact says every OTHER scenario's i-aligned config is that same canonical
   config. Rests on prerun determinacy (traceDetEv). *)
Lemma alignF_offense_cfg_det : forall l ins gs hf af i ds es a j,
  alignment_failure_at i l ins gs hf af ->
  l_aligned_pair l ds es a ->
  covers_rng es a ->
  (exists ih, pr_inputs es ih /\ list_prefix ih ins) ->
  Forall is_input ins ->
  cfg_at ds i = cfg_at gs i ->
  annot_count l ds i = annot_count l gs i ->
  redex_is_l_annotation l (cfg_at ds i) ->
  a i j ->
  cfg_at es j = cfg_at hf (length hf - 1).
Proof.
  intros l ins gs hf af i ds es a j Halign Hlap Hcrng_es Hih_es Hins Hcfg Hrank Hann_ds Ha.
  destruct Halign as [HihHf [Hbody _]].
  destruct Hbody as [jc [HiLt [Hjceq [HannGi [HannHfjc [Hmis Hbelow]]]]]].
  destruct Hbelow as [HconfBelow HcovDomBelow].
  assert (Hjclt : jc < length hf) by (apply (annot_index_lt_length l hf jc HannHfjc)).
  destruct HconfBelow as [HlapBel [HihBel [HcrngBel [HmodBel HinpBel]]]].
  assert (Hlen1 : length (firstn i gs) = i) by (apply firstn_length_le; lia).
  assert (Hlen2 : length (firstn jc hf) = jc) by (apply firstn_length_le; lia).
  pose proof (equal_count l (firstn i gs) (firstn jc hf) (alignment_below af i jc) HlapBel HcovDomBelow HcrngBel) as Hec.
  rewrite Hlen1, Hlen2 in Hec.
  rewrite (annot_count_firstn l gs i i (Nat.le_refl i)) in Hec.
  rewrite (annot_count_firstn l hf jc jc (Nat.le_refl jc)) in Hec.
  assert (Hnthhf : is_nth_annot l hf (annot_count l gs i) jc)
    by (split; [exact Hjclt | split; [exact HannHfjc | symmetry; exact Hec]]).
  assert (Hids : i < length ds) by (destruct Hlap as [_ [_ [[Hb _] _]]]; apply (proj1 (Hb i j Ha))).
  assert (Hnthds : is_nth_annot l ds (annot_count l ds i) i)
    by (split; [exact Hids | split; [exact Hann_ds | reflexivity]]).
  assert (Hnthes : is_nth_annot l es (annot_count l ds i) j)
    by (apply (annot_align_rank l ds es a (annot_count l ds i) i j Hlap Hcrng_es Hnthds Ha)).
  rewrite Hrank in Hnthes.
  destruct Hih_es as [ihes [Hpres Hpfes]]. destruct HihHf as [ihhf [Hprhf Hpfhf]].
  assert (Hjjc : j = jc)
    by (apply (nth_annot_det l ins es hf ihes ihhf (annot_count l gs i) j jc Hins Hpres Hpfes Hprhf Hpfhf Hnthes Hnthhf)).
  pose proof Hnthes as Hnthes2. destruct Hnthes2 as [Hjlt _]. subst j.
  rewrite <- Hjceq.
  apply (prerun_index_det ins es hf ihes ihhf jc Hins Hpres Hpfes Hprhf Hpfhf Hjlt Hjclt).
Qed.

(* Coverage of an alignment-failure's index by a CONFORMANCE benign class: the
   conformance aligns the (unmatched) annotation index i to some jb whose minor
   config is the failure's offense. (Combines conf coverage with offense
   determinacy.) Rests on prerun determinacy (traceDetEv). *)
Lemma conf_meets_alignF_offense : forall l ins gs hb ab hf af i,
  conformance l ins gs hb ab ->
  alignment_failure_at i l ins gs hf af ->
  Forall is_input ins ->
  exists jb, ab i jb /\ cfg_at hb jb = cfg_at hf (length hf - 1).
Proof.
  intros l ins gs hb ab hf af i Hconf Halign Hins.
  pose proof Halign as Halign0.
  destruct Halign as [HihHf [Hbody _]].
  destruct Hbody as [jc [HiLt [Hjceq [HannGi [HannHfjc [Hmis Hbelow]]]]]].
  destruct Hbelow as [HconfBelow HcovDomBelow].
  set (n := annot_count l gs i) in *.
  assert (Hjclt : jc < length hf) by (apply (annot_index_lt_length l hf jc HannHfjc)).
  destruct HconfBelow as [HlapBel [HihBel [HcrngBel [HmodBel HinpBel]]]].
  assert (Hlen1 : length (firstn i gs) = i) by (apply firstn_length_le; lia).
  assert (Hlen2 : length (firstn jc hf) = jc) by (apply firstn_length_le; lia).
  pose proof (equal_count l (firstn i gs) (firstn jc hf) (alignment_below af i jc) HlapBel HcovDomBelow HcrngBel) as Hec.
  rewrite Hlen1, Hlen2 in Hec.
  rewrite (annot_count_firstn l gs i i (Nat.le_refl i)) in Hec.
  rewrite (annot_count_firstn l hf jc jc (Nat.le_refl jc)) in Hec.
  assert (Hnthhf : is_nth_annot l hf n jc)
    by (split; [exact Hjclt | split; [exact HannHfjc | symmetry; exact Hec]]).
  destruct HihHf as [ihf [Hprhf Hpfhf]].
  destruct (conf_covers_annot l ins gs hb ab i hf ihf jc Hconf Hins HiLt HannGi Hprhf Hpfhf Hnthhf) as [jb Habijb].
  pose proof Hconf as Hconf2. destruct Hconf2 as [Hlapb [Hihb [Hcrngb [Hmodb Hinpb]]]].
  destruct Hihb as [ihb [Hprhb [Hpfhb _]]].
  exists jb. split; [exact Habijb |].
  apply (alignF_offense_cfg_det l ins gs hf af i gs hb ab jb Halign0 Hlapb Hcrngb
           (ex_intro _ ihb (conj Hprhb Hpfhb)) Hins eq_refl eq_refl HannGi Habijb).
Qed.

(* A conformance of a prefix (firstn K gs) that COVERS it forces the models
   verdict at any covered annotation index k < K: there is an aligned minor m
   with the models judgment holding over the (k+1, m+1) prefixes of the full
   runs. Packages the firstn/firstn-min bookkeeping used by the six facts. *)
Lemma below_models : forall l ins gs hsB abB K J k l' tk Phi,
  conformance l ins (firstn K gs) (firstn J hsB) (alignment_below abB K J) ->
  covers_dom (firstn K gs) (alignment_below abB K J) ->
  K <= length gs -> J <= length hsB ->
  k < K ->
  (redex_of (cfg_at gs k) = Some (Cassume l' tk Phi) \/
   redex_of (cfg_at gs k) = Some (Cassert l' tk Phi)) ->
  lleq l' l ->
  exists m, abB k m /\ m < J /\ m < length hsB /\
            models (cfg_state (cfg_at gs k)) (cfg_state (cfg_at hsB m)) Phi.
Proof.
  intros l ins gs hsB abB K J k l' tk Phi Hconf Hcov HK HJ Hk Hred Hle.
  assert (HKlen : length (firstn K gs) = K) by (apply firstn_length_le; exact HK).
  destruct (Hcov k ltac:(rewrite HKlen; exact Hk)) as [m Hbeta].
  destruct Hbeta as [HabB [HkK HmJ]].
  destruct Hconf as [_ [_ [_ [Hmod _]]]].
  assert (Hredk : redex_of (cfg_at (firstn K gs) k) = redex_of (cfg_at gs k)).
  { apply (f_equal redex_of). apply cfg_at_firstn. exact Hk. }
  assert (Hmodel : models (cfg_state (cfg_at (firstn K gs) k))
                          (cfg_state (cfg_at (firstn J hsB) m)) Phi).
  { apply (Hmod k m l' tk Phi).
    - split; [exact HabB | split; [exact HkK | exact HmJ]].
    - rewrite Hredk. exact Hred.
    - exact Hle. }
  exists m. split; [exact HabB | split; [exact HmJ | split; [lia |]]].
  rewrite (cfg_at_firstn K gs k Hk) in Hmodel.
  rewrite (cfg_at_firstn J hsB m HmJ) in Hmodel.
  exact Hmodel.
Qed.


(* ----------------------------------------------------------------------- *)
(* exclusivity of different classes of aligned pairs *)
(* ----------------------------------------------------------------------- *)

(* Conformance excludes assertion failure at the same point *) 
Lemma conf_excl_assertF : forall l ins gs hb ab hf af,
  conformance l ins gs hb ab -> assertion_failure l ins gs hf af -> False.
Proof.
  intros l ins gs hb ab hf af Hconf [i Hassert].
  destruct Hassert as [HlapF [HihF [HcrngF [HexF HinpF]]]].
  destruct HexF as [j [l' [tk [Phi [HiLt [Hjeq [HafIj [Hred [Hle [Hnmod Hbelow]]]]]]]]]].
  assert (Hann : redex_is_l_annotation l (cfg_at gs i)).
  { unfold redex_is_l_annotation, is_l_annotation. rewrite Hred. right. exact Hle. }
  assert (HhfLen : 0 < length hf) by
    (destruct hf; [exfalso; destruct HlapF as [_ [Hp _]]; apply (pre_run_nonempty _ Hp); reflexivity | simpl; lia]).
  assert (HjLt : j < length hf) by lia.
  destruct (conf_meets_aligned_annot l ins gs hb ab hf af i j
              Hconf HlapF HcrngF HihF HinpF HiLt Hann HafIj) as [jb [HabIjb Hcfeq]].
  destruct Hconf as [Hlapc [Hihc [Hcrngc [Hmodc Hinpc]]]].
  assert (Hjblt : jb < length hb).
  { destruct Hlapc as [_ [_ [[Hb _] _]]]. apply (Hb i jb HabIjb). }
  assert (Hmodel : models (cfg_state (cfg_at gs i)) (cfg_state (cfg_at hb jb)) Phi).
  { apply (Hmodc i jb l' tk Phi HabIjb); [right; exact Hred | exact Hle]. }
  apply Hnmod. rewrite Hcfeq in Hmodel. exact Hmodel.
Qed.

(* Conformance excludes alignment failure *)
Lemma conf_excl_alignF : forall l ins gs hb ab hf af,
  conformance l ins gs hb ab -> alignment_failure l ins gs hf af -> False.
Proof.
  intros l ins gs hb ab hf af Hconf [i Halign].
  pose proof Hconf as Hconf0.
  destruct Hconf0 as [Hlapc [Hihc [Hcrngc [Hmodc Hinpc]]]].
  destruct Hlapc as [HpreG [HpreH [Halgn Hcoin]]].
  pose proof Halign as Halign0.
  destruct Halign0 as [HihF [Hmism HinpF]].
  destruct Hmism as [jc [HiLt [Hjceq [HannGi [HannHfjc [Hmis Hbelow]]]]]].
  destruct (conf_meets_alignF_offense l ins gs hb ab hf af i Hconf Halign Hinpc)
    as [jb [HabIjb Hcfeq]].
  assert (Hredeq : redex_of (cfg_at gs i) = redex_of (cfg_at hb jb))
    by (apply (Hcoin i jb HabIjb); left; exact HannGi).
  apply Hmis.
  rewrite Hjceq, <- Hcfeq, <- Hredeq. reflexivity.
Qed.

(* Conformance excludes assertion failure at that point *) 
Lemma assumF_excl_assertF : forall l ins gs hb ab hf af,
  assumption_fiat l ins gs hb ab -> assertion_failure l ins gs hf af -> False.
Proof.
  intros l ins gs hb ab hf af [ia Hassum] [ic Hassert].
  destruct Hassum as [HlapB [HihB [HcrngB [HexB HinpB]]]].
  destruct HexB as [ja [la [tka [Phia [HiaLt [Hjaeq [HabIaJa [HredA [HleA [HnmodA HbelowA]]]]]]]]]].
  destruct Hassert as [HlapF [HihF [HcrngF [HexF HinpF]]]].
  destruct HexF as [jc [lc [tkc [Phic [HicLt [Hjceq [HafIcJc [HredC [HleC [HnmodC HbelowC]]]]]]]]]].
  destruct HbelowA as [HcbA HcovA].
  destruct HbelowC as [HcbC HcovC].
  assert (HhbLen : 0 < length hb) by
    (destruct hb; [exfalso; destruct HlapB as [_ [Hp _]]; apply (pre_run_nonempty _ Hp); reflexivity | simpl; lia]).
  assert (HhfLen : 0 < length hf) by
    (destruct hf; [exfalso; destruct HlapF as [_ [Hp _]]; apply (pre_run_nonempty _ Hp); reflexivity | simpl; lia]).
  assert (HjaLt : ja < length hb) by lia.
  assert (HjcLt : jc < length hf) by lia.
  assert (HannA : redex_is_l_annotation l (cfg_at gs ia)).
  { unfold redex_is_l_annotation, is_l_annotation. rewrite HredA. left. exact HleA. }
  assert (HannC : redex_is_l_annotation l (cfg_at gs ic)).
  { unfold redex_is_l_annotation, is_l_annotation. rewrite HredC. right. exact HleC. }
  destruct (Nat.lt_trichotomy ia ic) as [Hlt | [Heq | Hgt]].
  - (* ia < ic : cover the assume ia inside the assert's below-conformance *)
    destruct (below_models l ins gs hf af ic jc ia la tka Phia HcbC HcovC
                ltac:(lia) ltac:(lia) Hlt (or_introl HredA) HleA)
      as [m [HafIaM [_ [HmLt Hmodel]]]].
    assert (Hcfeq : cfg_at hf m = cfg_at hb ja).
    { apply (minor_annot_cfg_det l ins gs gs hf hb af ab ia m ja
               HlapF HlapB HcrngF HcrngB HihF HihB HinpF eq_refl eq_refl HannA HafIaM HabIaJa). }
    apply HnmodA. rewrite Hcfeq in Hmodel. exact Hmodel.
  - (* ia = ic : gs_ia is simultaneously an assume and an assert *)
    subst ic. rewrite HredA in HredC. discriminate.
  - (* ic < ia : cover the assert ic inside the assume's below-conformance *)
    destruct (below_models l ins gs hb ab ia ja ic lc tkc Phic HcbA HcovA
                ltac:(lia) ltac:(lia) Hgt (or_intror HredC) HleC)
      as [m [HabIcM [_ [HmLt Hmodel]]]].
    assert (Hcfeq : cfg_at hb m = cfg_at hf jc).
    { apply (minor_annot_cfg_det l ins gs gs hb hf ab af ic m jc
               HlapB HlapF HcrngB HcrngF HihB HihF HinpB eq_refl eq_refl HannC HabIcM HafIcJc). }
    apply HnmodC. rewrite Hcfeq in Hmodel. exact Hmodel.
Qed.

(* assumption fiat excludes alignment failure at that point *) 
Lemma assumF_excl_alignF : forall l ins gs hb ab hf af,
  assumption_fiat l ins gs hb ab -> alignment_failure l ins gs hf af -> False.
Proof.
  intros l ins gs hb ab hf af [ia Hassum] [ic Halign].
  pose proof Halign as Halign0.
  destruct Halign0 as [HihFa [Hmism HinpF]].
  destruct Hmism as [jc [HicLt [Hjceq [HannGic [HannHfjc [Hmis HbelowC]]]]]].
  destruct HbelowC as [HcbC HcovC].
  destruct Hassum as [HlapB [HihB [HcrngB [HexB HinpB]]]].
  destruct HexB as [ja [la [tka [Phia [HiaLt [Hjaeq [HabIaJa [HredA [HleA [HnmodA HbelowA]]]]]]]]]].
  destruct HbelowA as [HcbA HcovA].
  assert (HhbLen : 0 < length hb) by
    (destruct hb; [exfalso; destruct HlapB as [_ [Hp _]]; apply (pre_run_nonempty _ Hp); reflexivity | simpl; lia]).
  assert (HjaLt : ja < length hb) by lia.
  assert (HannA : redex_is_l_annotation l (cfg_at gs ia)).
  { unfold redex_is_l_annotation, is_l_annotation. rewrite HredA. left. exact HleA. }
  destruct (Nat.lt_trichotomy ia ic) as [Hlt | [Heq | Hgt]].
  - (* ia < ic : the assume ia is covered by the alignment-failure's below run *)
    pose proof HcbC as HcbC0.
    destruct HcbC0 as [HlapBelowC [HihBelowC0 [HcrngBelowC [HmodBelowC HinpBelowC]]]].
    destruct (below_models l ins gs hf af ic jc ia la tka Phia HcbC HcovC
                ltac:(lia) ltac:(lia) Hlt (or_introl HredA) HleA)
      as [m [HafIaM [HmJ [HmLt Hmodel]]]].
    assert (HihBelowC : exists ih, pr_inputs (firstn jc hf) ih /\ list_prefix ih ins).
    { destruct HihBelowC0 as [ihx [Hprx [Hpfx _]]]. exists ihx; split; assumption. }
    assert (Hmajeq : cfg_at (firstn ic gs) ia = cfg_at gs ia) by (apply cfg_at_firstn; exact Hlt).
    assert (HannBelow : redex_is_l_annotation l (cfg_at (firstn ic gs) ia))
      by (rewrite Hmajeq; exact HannA).
    assert (Hcfeq0 : cfg_at (firstn jc hf) m = cfg_at hb ja).
    { apply (minor_annot_cfg_det l ins (firstn ic gs) gs (firstn jc hf) hb (alignment_below af ic jc) ab ia m ja
               HlapBelowC HlapB HcrngBelowC HcrngB HihBelowC HihB HinpB Hmajeq
               (annot_count_firstn l gs ic ia ltac:(lia)) HannBelow
               (conj HafIaM (conj Hlt HmJ)) HabIaJa). }
    assert (Hcfeq : cfg_at hf m = cfg_at hb ja).
    { rewrite <- Hcfeq0. symmetry. apply cfg_at_firstn. exact HmJ. }
    apply HnmodA. rewrite Hcfeq in Hmodel. exact Hmodel.
  - (* ia = ic : the assume gs_ia is itself the alignment-failure mismatch annotation *)
    subst ic.
    assert (Hoff : cfg_at hb ja = cfg_at hf (length hf - 1)).
    { apply (alignF_offense_cfg_det l ins gs hf af ia gs hb ab ja
               Halign HlapB HcrngB HihB HinpF eq_refl eq_refl HannGic HabIaJa). }
    destruct HlapB as [HpreG [HpreH [Halgn Hcoin]]].
    assert (Hredeq : redex_of (cfg_at gs ia) = redex_of (cfg_at hb ja))
      by (apply (Hcoin ia ja HabIaJa); left; exact HannA).
    apply Hmis.
    rewrite Hjceq, <- Hoff, <- Hredeq. reflexivity.
  - (* ic < ia : the mismatch index ic is covered by the assume's below run *)
    pose proof HcbA as HcbA0.
    destruct HcbA0 as [HlapBelowA [HihBelowA0 [HcrngBelowA [HmodBelowA HinpBelowA]]]].
    assert (HfgaLen : length (firstn ia gs) = ia) by (apply firstn_length_le; lia).
    destruct (HcovA ic ltac:(rewrite HfgaLen; exact Hgt)) as [m [HabIcM [HicIa HmJa]]].
    assert (HihBelowA : exists ih, pr_inputs (firstn ja hb) ih /\ list_prefix ih ins).
    { destruct HihBelowA0 as [ihx [Hprx [Hpfx _]]]. exists ihx; split; assumption. }
    assert (Hmajeq : cfg_at (firstn ia gs) ic = cfg_at gs ic) by (apply cfg_at_firstn; exact Hgt).
    assert (HannBelow : redex_is_l_annotation l (cfg_at (firstn ia gs) ic))
      by (rewrite Hmajeq; exact HannGic).
    assert (Hoff : cfg_at (firstn ja hb) m = cfg_at hf (length hf - 1)).
    { apply (alignF_offense_cfg_det l ins gs hf af ic (firstn ia gs) (firstn ja hb) (alignment_below ab ia ja) m
               Halign HlapBelowA HcrngBelowA HihBelowA HinpF Hmajeq
               (annot_count_firstn l gs ia ic ltac:(lia)) HannBelow
               (conj HabIcM (conj HicIa HmJa))). }
    destruct HlapBelowA as [HpreGa [HpreHa [HalgnA HcoinA]]].
    assert (Hredeq : redex_of (cfg_at (firstn ia gs) ic) = redex_of (cfg_at (firstn ja hb) m))
      by (apply (HcoinA ic m (conj HabIcM (conj HicIa HmJa))); left; exact HannBelow).
    apply Hmis.
    rewrite Hjceq, <- Hoff, <- Hredeq, Hmajeq. reflexivity.
Qed.

(* ----------------------------------------------------------------------- *)
(* extensive technical results for main theorem *)
(* ----------------------------------------------------------------------- *)

(* Range determinacy (dual of minor_annot_cfg_det): if the same minor config --
   an l-annotation -- is aligned to majors i1, i2 by two proper minor scenarios
   over gs (inputs prefixes of ins), the two major configs coincide. *)
Lemma major_annot_cfg_det : forall l ins gs es1 es2 a1 a2 i1 i2 n,
  l_aligned_pair l gs es1 a1 -> l_aligned_pair l gs es2 a2 ->
  covers_rng es1 a1 -> covers_rng es2 a2 ->
  (exists ih, pr_inputs es1 ih /\ list_prefix ih ins) ->
  (exists ih, pr_inputs es2 ih /\ list_prefix ih ins) ->
  Forall is_input ins ->
  cfg_at es1 n = cfg_at es2 n ->
  redex_is_l_annotation l (cfg_at es1 n) ->
  a1 i1 n -> a2 i2 n ->
  cfg_at gs i1 = cfg_at gs i2.
Proof.
  intros l ins gs es1 es2 a1 a2 i1 i2 n Hlap1 Hlap2 Hcrng1 Hcrng2 Hih1 Hih2 Hins Hcfgn Hannn Ha1 Ha2.
  assert (Hi1lt : i1 < length gs) by (destruct Hlap1 as [_ [_ [[Hb _] _]]]; apply (proj1 (Hb i1 n Ha1))).
  assert (Hi2lt : i2 < length gs) by (destruct Hlap2 as [_ [_ [[Hb _] _]]]; apply (proj1 (Hb i2 n Ha2))).
  assert (Hanni1 : redex_is_l_annotation l (cfg_at gs i1))
    by (destruct Hlap1 as [_ [_ Hp1]]; apply (proper_annot_rev l gs es1 a1 i1 n Hp1 Ha1 Hannn)).
  assert (Hannn2 : redex_is_l_annotation l (cfg_at es2 n)) by (rewrite <- Hcfgn; exact Hannn).
  assert (Hanni2 : redex_is_l_annotation l (cfg_at gs i2))
    by (destruct Hlap2 as [_ [_ Hp2]]; apply (proper_annot_rev l gs es2 a2 i2 n Hp2 Ha2 Hannn2)).
  assert (Hnthi1 : is_nth_annot l gs (annot_count l gs i1) i1)
    by (split; [exact Hi1lt | split; [exact Hanni1 | reflexivity]]).
  assert (Hnthi2 : is_nth_annot l gs (annot_count l gs i2) i2)
    by (split; [exact Hi2lt | split; [exact Hanni2 | reflexivity]]).
  assert (Hnf1 : is_nth_annot l es1 (annot_count l gs i1) n)
    by (apply (annot_align_rank l gs es1 a1 (annot_count l gs i1) i1 n Hlap1 Hcrng1 Hnthi1 Ha1)).
  assert (Hnf2 : is_nth_annot l es2 (annot_count l gs i2) n)
    by (apply (annot_align_rank l gs es2 a2 (annot_count l gs i2) i2 n Hlap2 Hcrng2 Hnthi2 Ha2)).
  assert (Hr1 : annot_count l es1 n = annot_count l gs i1) by (destruct Hnf1 as [_ [_ Hc]]; exact Hc).
  assert (Hr2 : annot_count l es2 n = annot_count l gs i2) by (destruct Hnf2 as [_ [_ Hc]]; exact Hc).
  destruct Hih1 as [ih1 [Hpr1 Hpf1]]. destruct Hih2 as [ih2 [Hpr2 Hpf2]].
  assert (Hn1 : n < length es1) by (destruct Hlap1 as [_ [_ [[Hb _] _]]]; apply (proj2 (Hb i1 n Ha1))).
  assert (Hn2 : n < length es2) by (destruct Hlap2 as [_ [_ [[Hb _] _]]]; apply (proj2 (Hb i2 n Ha2))).
  assert (Hcnt : annot_count l es1 n = annot_count l es2 n)
    by (apply annot_count_ext; intros mm Hm;
        apply (prerun_index_det ins es1 es2 ih1 ih2 mm Hins Hpr1 Hpf1 Hpr2 Hpf2); lia).
  assert (Hri : annot_count l gs i1 = annot_count l gs i2) by (rewrite <- Hr1, <- Hr2; exact Hcnt).
  assert (Hi12 : i1 = i2)
    by (apply (is_nth_annot_unique l gs (annot_count l gs i1) i1 i2 Hnthi1);
        split; [exact Hi2lt | split; [exact Hanni2 | symmetry; exact Hri]]).
  rewrite Hi12. reflexivity.
Qed.

(* ---- Divergence-vs-failure reach lemmas ----
   For ia >= k, a divergent minor cannot coexist with a failure that reaches an
   l-annotation at major index ia. Split on |hf| vs |hd|: if |hf| > |hd|, the
   divergent family supplies an annotation-FREE pre-run of length |hf| equal (by
   prerun_index_det) to hf, whose last config is an annotation -- contradiction.
   If |hf| <= |hd|, hf's last config = hd's at that index (prerun_index_det),
   aligned by ad to some i0 <= i; major_annot_cfg_det gives gs_ia = gs_i0, and the
   divergence's embedded conformance forces the assert to hold at i0 while the
   failure says it fails at ia -- contradiction (this branch needs the failure's
   ~models hypothesis, hence it appears in the statement). *)
Lemma divF_assertF_reach : forall i k l ins gs hd ad hf af ia jf l' tk Phi,
  divergence_fiat_at i k l ins gs hd ad ->
  l_aligned_pair l gs hf af ->
  covers_rng hf af ->
  (exists ih, pr_inputs hf ih /\ list_prefix ih ins) ->
  k <= ia -> ia < length gs ->
  jf = length hf - 1 -> af ia jf ->
  redex_of (cfg_at gs ia) = Some (Cassert l' tk Phi) -> lleq l' l ->
  ~ models (cfg_state (cfg_at gs ia)) (cfg_state (cfg_at hf jf)) Phi ->
  False.
Proof.
  intros i k l ins gs hd ad hf af ia jf l' tk Phi Hdiv HlapF HcrngFa HihF Hgek HiaLt Hjfeq HafIaJf Hred Hle Hnmod.
  destruct HihF as [ihf [Hprhf Hpfhf]].
  destruct Hdiv as [Hinp [Hik [Hklt [Hlapd [Hannk Hexj]]]]].
  destruct Hexj as [j [Hjeq [Haij [Hicase [Hnogrow [Hconfd Hfamouter]]]]]].
  destruct Hfamouter as [ihd [Hprhd [Hpfhd [Hfam0 Hfam]]]].
  assert (HhfNE : 0 < length hf) by
    (destruct hf; [exfalso; destruct HlapF as [_ [Hp _]]; apply (pre_run_nonempty _ Hp); reflexivity | simpl; lia]).
  assert (HjfLt : jf < length hf) by lia.
  assert (HannGia : redex_is_l_annotation l (cfg_at gs ia))
    by (unfold redex_is_l_annotation, is_l_annotation; rewrite Hred; right; exact Hle).
  assert (HannHf : redex_is_l_annotation l (cfg_at hf jf))
    by (destruct HlapF as [_ [_ Hproper]];
        apply (proper_annot_both l gs hf af ia jf Hproper HafIaJf HannGia)).
  destruct (Nat.le_gt_cases (length hf) (length hd)) as [Hlehd | Hgthd].
  - (* |hf| <= |hd| : the assert lands in the divergence's conformant minor *)
    assert (HjfLtHd : jf < length hd) by lia.
    assert (Hidx : cfg_at hf jf = cfg_at hd jf).
    { apply (prerun_index_det ins hf hd ihf ihd jf Hinp Hprhf Hpfhf Hprhd Hpfhd HjfLt HjfLtHd). }
    assert (Hcrngd : covers_rng hd ad) by (destruct Hconfd as [_ [_ [Hc _]]]; exact Hc).
    destruct (Hcrngd jf HjfLtHd) as [i0 HadI0Jf].
    assert (Hi0le : i0 <= i).
    { destruct Hconfd as [[_ [_ [[Hb _] _]]] _].
      destruct (Hb i0 jf HadI0Jf) as [Hb1 _].
      rewrite firstn_length_le in Hb1 by lia. lia. }
    assert (Hmajeq : cfg_at gs ia = cfg_at gs i0).
    { apply (major_annot_cfg_det l ins gs hf hd af ad ia i0 jf
               HlapF Hlapd HcrngFa Hcrngd (ex_intro _ ihf (conj Hprhf Hpfhf)) (ex_intro _ ihd (conj Hprhd Hpfhd))
               Hinp Hidx HannHf HafIaJf HadI0Jf). }
    destruct Hconfd as [HlapConf [HihConf [HcrngConf [HmodConf HinpConf]]]].
    assert (Hredi0 : redex_of (cfg_at (firstn (i + 1) gs) i0) = Some (Cassert l' tk Phi)).
    { rewrite cfg_at_firstn by lia. rewrite <- Hmajeq. exact Hred. }
    assert (Hmodel : models (cfg_state (cfg_at (firstn (i + 1) gs) i0)) (cfg_state (cfg_at hd jf)) Phi).
    { apply (HmodConf i0 jf l' tk Phi HadI0Jf); [right; exact Hredi0 | exact Hle]. }
    rewrite (cfg_at_firstn (i + 1) gs i0 ltac:(lia)) in Hmodel.
    apply Hnmod. rewrite Hmajeq, Hidx. exact Hmodel.
  - (* |hf| > |hd| : the divergent family supplies an annotation-free run = hf *)
    set (n := length hf - length hd).
    destruct (Hfam n) as [HlenHn [HnoannHn [ih' [Hpr' Hpf']]]].
    assert (HlenHdHn : length (hd ++ Hfam0 n) = length hf).
    { rewrite length_app, HlenHn. unfold n. lia. }
    assert (HjfLtHdHn : jf < length (hd ++ Hfam0 n)) by (rewrite HlenHdHn; lia).
    assert (Hidx : cfg_at hf jf = cfg_at (hd ++ Hfam0 n) jf).
    { apply (prerun_index_det ins hf (hd ++ Hfam0 n) ihf ih' jf Hinp Hprhf Hpfhf Hpr' Hpf' HjfLt HjfLtHdHn). }
    assert (HjfGeHd : length hd <= jf) by (unfold n in *; lia).
    assert (Happ : cfg_at (hd ++ Hfam0 n) jf = cfg_at (Hfam0 n) (jf - length hd)).
    { unfold cfg_at. rewrite app_nth2 by lia. reflexivity. }
    assert (HjfHdLt : jf - length hd < n) by (unfold n; lia).
    apply (proj1 (HnoannHn (jf - length hd) HjfHdLt)).
    rewrite <- Happ, <- Hidx. exact HannHf.
Qed.

Lemma divF_alignF_reach : forall i k l ins gs hd ad hf af ia,
  divergence_fiat_at i k l ins gs hd ad ->
  alignment_failure_at ia l ins gs hf af ->
  k <= ia ->
  False.
Proof.
  intros i k l ins gs hd ad hf af ia Hdiv Halign Hkia.
  destruct (divergence_fiat_at_cover i k l ins gs hd ad Hdiv) as [Hcovdom Hcrngd].
  pose proof Hdiv as Hdiv0.
  destruct Hdiv0 as [Hinp [Hik [Hklt [Hlapd [Hannk Hexj]]]]].
  destruct Hexj as [j [Hjeq [Haij [_ [_ [Hconfd Hfamouter]]]]]].
  destruct Hfamouter as [ihd [Hprhd [Hpfhd [Hfam0 Hfam]]]].
  assert (Hproperd : proper l (firstn (i + 1) gs) hd ad)
    by (destruct Hconfd as [[_ [_ Hp]] _]; exact Hp).
  destruct Halign as [HihF [Hmism HinpF]].
  destruct Hmism as [jc [HiaLt [Hjceq [HannGia [HannHfjc [Hmis Hbelow]]]]]].
  destruct Hbelow as [HcbC HcovC].
  assert (HproperC : proper l (firstn ia gs) (firstn jc hf) (alignment_below af ia jc))
    by (destruct HcbC as [[_ [_ Hp]] _]; exact Hp).
  assert (HcrngC : covers_rng (firstn jc hf) (alignment_below af ia jc))
    by (destruct HcbC as [_ [_ [Hc _]]]; exact Hc).
  destruct HihF as [ihf [Hprhf Hpfhf]].
  assert (HhfNE : 0 < length hf).
  { destruct Hprhf as [th [Hat _]]. apply admits_trace_nonempty in Hat.
    destruct hf; [contradiction | simpl; lia]. }
  assert (HjcLt : jc < length hf) by lia.
  assert (Hiai : i < ia) by lia.
  assert (Hlen_fia : length (firstn ia gs) = ia) by (apply firstn_length_le; lia).
  assert (Hlen_fjc : length (firstn jc hf) = jc) by (apply firstn_length_le; lia).
  assert (HlapC : l_aligned_pair l (firstn ia gs) (firstn jc hf) (alignment_below af ia jc))
    by (destruct HcbC as [Hl _]; exact Hl).
  pose proof (equal_count l (firstn ia gs) (firstn jc hf) (alignment_below af ia jc) HlapC HcovC HcrngC) as Heqc_f.
  rewrite Hlen_fia, Hlen_fjc in Heqc_f.
  rewrite (annot_count_firstn l gs ia ia ltac:(lia)) in Heqc_f.
  rewrite (annot_count_firstn l hf jc jc ltac:(lia)) in Heqc_f.
  destruct (Nat.le_gt_cases (length hf) (length hd)) as [Hle | Hgt].
  - (* Case A: |hf| <= |hd| *)
    assert (HjcLtHd : jc < length hd) by lia.
    assert (Hidx : cfg_at hf jc = cfg_at hd jc).
    { apply (prerun_index_det ins hf hd ihf ihd jc Hinp Hprhf Hpfhf Hprhd Hpfhd HjcLt HjcLtHd). }
    assert (HannHdjc : redex_is_l_annotation l (cfg_at hd jc)) by (rewrite <- Hidx; exact HannHfjc).
    assert (Hcfeq : annot_count l hf jc = annot_count l hd jc).
    { apply annot_count_ext. intros m Hm.
      apply (prerun_index_det ins hf hd ihf ihd m Hinp Hprhf Hpfhf Hprhd Hpfhd); lia. }
    assert (HnthIa : is_nth_annot l gs (annot_count l hd jc) ia).
    { split; [exact HiaLt | split; [exact HannGia |]]. rewrite Heqc_f. exact Hcfeq. }
    assert (Hlen_fi1 : length (firstn (i + 1) gs) = i + 1) by (apply firstn_length_le; lia).
    assert (Hlapd_e : l_aligned_pair l (firstn (i + 1) gs) hd ad)
      by (destruct Hconfd as [Hl _]; exact Hl).
    pose proof (equal_count l (firstn (i + 1) gs) hd ad Hlapd_e Hcovdom Hcrngd) as Heqc_d.
    rewrite Hlen_fi1 in Heqc_d.
    assert (HhdGe : annot_count l (firstn (i + 1) gs) (i + 1) > annot_count l hd jc).
    { rewrite Heqc_d.
      assert (Hm : annot_count l hd (S jc) <= annot_count l hd (length hd)) by (apply annot_count_mono; lia).
      rewrite (annot_count_annot_S l hd jc HannHdjc) in Hm. lia. }
    destruct (annot_count_gives_nth l (firstn (i + 1) gs) (annot_count l hd jc) (i + 1) HhdGe)
      as [ic [Hic_lt Hic_nth]].
    assert (HnthIc : is_nth_annot l gs (annot_count l hd jc) ic)
      by (apply (is_nth_annot_firstn l gs (i + 1) (annot_count l hd jc) ic Hic_lt Hic_nth)).
    assert (Heq : ic = ia) by (apply (is_nth_annot_unique l gs (annot_count l hd jc) ic ia HnthIc HnthIa)).
    lia.
  - (* Case B: |hf| > |hd| *)
    set (n := length hf - length hd).
    destruct (Hfam n) as [HlenHn [HnoannHn [ih' [Hpr' Hpf']]]].
    assert (Hlen_ext : length (hd ++ Hfam0 n) = length hf).
    { rewrite length_app, HlenHn. unfold n. lia. }
    assert (HjcLtExt : jc < length (hd ++ Hfam0 n)) by (rewrite Hlen_ext; lia).
    assert (Hidx : cfg_at hf jc = cfg_at (hd ++ Hfam0 n) jc).
    { apply (prerun_index_det ins hf (hd ++ Hfam0 n) ihf ih' jc Hinp Hprhf Hpfhf Hpr' Hpf' HjcLt HjcLtExt). }
    assert (HjcGe : length hd <= jc) by (unfold n in *; lia).
    assert (Happ : cfg_at (hd ++ Hfam0 n) jc = cfg_at (Hfam0 n) (jc - length hd)).
    { unfold cfg_at. rewrite app_nth2 by lia. reflexivity. }
    assert (HjcHdLt : jc - length hd < n) by (unfold n; lia).
    apply (proj1 (HnoannHn (jc - length hd) HjcHdLt)).
    rewrite <- Happ, <- Hidx. exact HannHfjc.
Qed.

(* divergence fiat excludes assertion failure *) 
Lemma divF_excl_assertF : forall l ins gs hb ab hf af,
  divergence_fiat l ins gs hb ab -> assertion_failure l ins gs hf af -> False.
Proof.
  intros l ins gs hb ab hf af [i [k Hdiv]] [ia Hassert].
  destruct (divergence_fiat_at_cover i k l ins gs hb ab Hdiv) as [Hcovdom _].
  pose proof Hdiv as Hdiv0.
  destruct Hdiv0 as [Hinp [Hik [Hklt [Hlapd [Hannk Hexj]]]]].
  destruct Hexj as [j [Hjeq [Haij [Hicase [Hnogrow [Hconfd Hexfam]]]]]].
  destruct Hassert as [HlapF [HihF [HcrngF [HexF HinpF]]]].
  destruct HexF as [jf [l' [tk [Phi [HiaLt [Hjfeq [HafIaJf [Hred [Hle [Hnmod Hbelow]]]]]]]]]].
  assert (HannIa : redex_is_l_annotation l (cfg_at gs ia)).
  { unfold redex_is_l_annotation, is_l_annotation. rewrite Hred. right. exact Hle. }
  assert (HhfLen : 0 < length hf) by
    (destruct hf; [exfalso; destruct HlapF as [_ [Hp _]]; apply (pre_run_nonempty _ Hp); reflexivity | simpl; lia]).
  assert (HjfLt : jf < length hf) by lia.
  destruct (Nat.lt_ge_cases ia k) as [Hltk | Hgek].
  - destruct (Nat.le_gt_cases ia i) as [Hlei | Hgti].
    + (* ia <= i : conformant region firstn (i+1) gs *)
      assert (HiaInLen : ia < length (firstn (i + 1) gs)) by (rewrite firstn_length_le; lia).
      destruct (Hcovdom ia HiaInLen) as [j0 HabIaJ0].
      destruct Hconfd as [HlapConf [HihConf [HcrngConf [HmodConf HinpConf]]]].
      assert (Hredfn : redex_of (cfg_at (firstn (i + 1) gs) ia) = Some (Cassert l' tk Phi)).
      { rewrite cfg_at_firstn by lia. exact Hred. }
      assert (Hj0lt : j0 < length hb).
      { destruct HlapConf as [_ [_ [[Hb _] _]]]. apply (Hb ia j0 HabIaJ0). }
      assert (Hmodel : models (cfg_state (cfg_at (firstn (i + 1) gs) ia)) (cfg_state (cfg_at hb j0)) Phi).
      { apply (HmodConf ia j0 l' tk Phi HabIaJ0); [right; exact Hredfn | exact Hle]. }
      rewrite (cfg_at_firstn (i + 1) gs ia ltac:(lia)) in Hmodel.
      assert (HihHb : exists ih, pr_inputs hb ih /\ list_prefix ih ins).
      { destruct HihConf as [ihx [Hprx [Hpfx _]]]. exists ihx; split; assumption. }
      assert (Hannfn : redex_is_l_annotation l (cfg_at (firstn (i + 1) gs) ia))
        by (rewrite cfg_at_firstn by lia; exact HannIa).
      assert (Hmajeq : cfg_at (firstn (i + 1) gs) ia = cfg_at gs ia) by (apply cfg_at_firstn; lia).
      assert (Hcfeq : cfg_at hb j0 = cfg_at hf jf).
      { apply (minor_annot_cfg_det l ins (firstn (i + 1) gs) gs hb hf ab af ia j0 jf
                 HlapConf HlapF HcrngConf HcrngF HihHb HihF HinpF Hmajeq
                 (annot_count_firstn l gs (i+1) ia ltac:(lia)) Hannfn HabIaJ0 HafIaJf). }
      apply Hnmod. rewrite Hcfeq in Hmodel. exact Hmodel.
    + (* i < ia < k : in the annotation-free gap, but the assert is an annotation *)
      exfalso. apply (Hnogrow ia Hgti Hltk). exact HannIa.
  - (* k <= ia : divergence determinacy *)
    exact (divF_assertF_reach i k l ins gs hb ab hf af ia jf l' tk Phi
             Hdiv HlapF HcrngF HihF Hgek HiaLt Hjfeq HafIaJf Hred Hle Hnmod).
Qed.

(* divergence fiat excludes alignment failure *) 
Lemma divF_excl_alignF : forall l ins gs hb ab hf af,
  divergence_fiat l ins gs hb ab -> alignment_failure l ins gs hf af -> False.
Proof.
  intros l ins gs hb ab hf af [i [k Hdiv]] [ia Halign].
  destruct (divergence_fiat_at_cover i k l ins gs hb ab Hdiv) as [Hcovdom _].
  pose proof Hdiv as Hdiv0.
  destruct Hdiv0 as [Hinp [Hik [Hklt [Hlapd [Hannk Hexj]]]]].
  destruct Hexj as [j [Hjeq [Haij [Hicase [Hnogrow [Hconfd Hexfam]]]]]].
  pose proof Halign as Halign0.
  destruct Halign0 as [HihFa [Hmism HinpF]].
  destruct Hmism as [jc [HiaLt [Hjceq [HannGia [HannHfjc [Hmis Hbelow]]]]]].
  destruct (Nat.lt_ge_cases ia k) as [Hltk | Hgek].
  - destruct (Nat.le_gt_cases ia i) as [Hlei | Hgti].
    + (* ia <= i : conformant region; divergence aligns ia, offense determinacy *)
      assert (HiaInLen : ia < length (firstn (i + 1) gs)) by (rewrite firstn_length_le; lia).
      destruct (Hcovdom ia HiaInLen) as [j0 HabIaJ0].
      pose proof Hlapd as Hlapd0.
      destruct Hlapd0 as [_ [_ [_ Hcoind]]].
      assert (Hredeq : redex_of (cfg_at gs ia) = redex_of (cfg_at hb j0))
        by (apply (Hcoind ia j0 HabIaJ0); left; exact HannGia).
      assert (HihHb : exists ih, pr_inputs hb ih /\ list_prefix ih ins).
      { destruct Hconfd as [_ [[ihx [Hprx [Hpfx _]]] _]]. exists ihx; split; assumption. }
      assert (HcrngHb : covers_rng hb ab) by (destruct Hconfd as [_ [_ [Hc _]]]; exact Hc).
      assert (Hoff : cfg_at hb j0 = cfg_at hf (length hf - 1)).
      { apply (alignF_offense_cfg_det l ins gs hf af ia gs hb ab j0
                 Halign Hlapd HcrngHb HihHb HinpF eq_refl eq_refl HannGia HabIaJ0). }
      apply Hmis.
      rewrite Hjceq, <- Hoff, <- Hredeq. reflexivity.
    + (* i < ia < k : annotation-free gap, but gs_ia is an annotation *)
      exfalso. apply (Hnogrow ia Hgti Hltk). exact HannGia.
  - (* k <= ia : divergence determinacy *)
    exact (divF_alignF_reach i k l ins gs hb ab hf af ia Hdiv Halign Hgek).
Qed.

(* Dropping the last config of a nonempty pre-run leaves a pre-run. *)
Lemma pre_run_snoc_inv : forall xs c,
  pre_run (xs ++ [c]) -> xs <> [] -> pre_run xs.
Proof.
  intros xs c [evs Hat] Hne.
  inversion Hat as [Heq Hev | gs0 evs0 ev g Hat0 Hstep Hgseq Heveq]; subst.
  - exfalso. apply (f_equal (@length config)) in Heq. rewrite length_app in Heq.
    simpl in Heq. apply Hne. destruct xs; [reflexivity | simpl in Heq; lia].
  - apply app_inj_tail in Hgseq. destruct Hgseq as [Hgs Hg]. subst gs0.
    exists evs0. exact Hat0.
Qed.

(* A step that emits a visible output Eout l' n is taken from an Active config
   whose redex is the output command Cout l' e, with n the value of e. *)
Lemma step_emits_output : forall c0 ev g,
  step c0 ev g -> forall l' n, ev = Eout l' n ->
  exists cc s e, c0 = Active cc s /\ redex_cmd cc = Cout l' e /\ n = eval_expr s e.
Proof.
  intros c0 ev g Hstep. induction Hstep; intros lo no Heq; try discriminate.
  - injection Heq as Hl Hn. exists (Cout l e), s, e.
    split; [reflexivity | split; [rewrite Hl; reflexivity | symmetry; exact Hn]].
  - destruct (IHHstep lo no Heq) as [cc [s0 [e [Hac [Hred Hn]]]]].
    injection Hac as Hcc Hs0. subst cc s0. exists (Cseq c d), s, e.
    split; [reflexivity | split; [simpl; exact Hred | exact Hn]].
Qed.

(* Runtime well-specification invariant on the active command: either it is still
   outputs_asserted, or it is in the two transient forms produced once a paired
   assert has fired -- [Cseq Cskip (Cout l e)] (assert done, skip pending) and
   [Cout l e] (about to output) -- closed under a left Cseq with outputs_asserted
   continuation (so the output region may sit arbitrarily deep). This is preserved
   by stepping even though outputs_asserted itself is not (the assert step exits
   it), and it pins that a Cout redex was reached from its matching assert. *)
Inductive oa_active : cmd -> Prop :=
| OAA_oa : forall c, outputs_asserted c -> oa_active c
| OAA_postassert : forall l e, oa_active (Cseq Cskip (Cout l e))
| OAA_atoutput : forall l e, oa_active (Cout l e)
| OAA_ctx : forall c d, oa_active c -> outputs_asserted d -> oa_active (Cseq c d).

Definition oa_config (g : config) : Prop :=
  match g with Active c _ => oa_active c | Receptive _ => True end.

(* Stepping an outputs_asserted active command stays in the invariant. *)
Lemma oa_step_oa : forall c s ev c' s',
  outputs_asserted c -> step (Active c s) ev (Active c' s') -> oa_active c'.
Proof.
  intros c s ev c' s' Hoa. revert s ev c' s'. induction Hoa; intros s0 ev c' s' Hstep.
  - inversion Hstep.
  - inversion Hstep; subst; apply OAA_oa; constructor.
  - inversion Hstep; subst; apply OAA_oa; assumption.
  - inversion Hstep; subst;
      [apply OAA_oa; apply OP_seq_other; [exact Hoa | apply OP_while; exact Hoa]
      | apply OAA_oa; constructor].
  - inversion Hstep; subst; apply OAA_oa; constructor.
  - inversion Hstep; subst; apply OAA_oa; constructor.
  - inversion Hstep; subst;
      match goal with H : step (Active (Cassert _ _ _) _) _ _ |- _ => inversion H; subst end;
      apply OAA_postassert.
  - inversion Hstep; subst;
      [apply OAA_oa; exact Hoa2
      | apply OAA_ctx; [eapply IHHoa1; eassumption | exact Hoa2]].
Qed.

(* The invariant is preserved by any step between active configs. *)
Lemma oa_active_step : forall c s ev c' s',
  oa_active c -> step (Active c s) ev (Active c' s') -> oa_active c'.
Proof.
  intros c s ev c' s' Hoa. revert s ev c' s'. induction Hoa; intros s0 ev c' s' Hstep.
  - apply (oa_step_oa c s0 ev c' s' H Hstep).
  - inversion Hstep; subst;
      [apply OAA_atoutput | match goal with H : step (Active Cskip _) _ _ |- _ => inversion H end].
  - inversion Hstep; subst; apply OAA_oa; constructor.
  - inversion Hstep; subst;
      [apply OAA_oa; exact H | apply OAA_ctx; [eapply IHHoa; eassumption | exact H]].
Qed.

(* The invariant holds at the last config of every pre-run (initial input lands
   in a handler body, which is outputs_asserted by well-specification, and each
   step preserves the invariant). *)
Lemma prerun_oa_last : forall gs, pre_run gs -> oa_config (last_cfg gs).
Proof.
  intros gs [evs Hat]. induction Hat as [| gs evs ev g Hat IH Hstep].
  - simpl. exact I.
  - assert (Hlg : last_cfg (gs ++ [g]) = g) by (unfold last_cfg; apply last_last). rewrite Hlg.
    destruct (last_cfg gs) as [sr | cc sr] eqn:Hlc.
    + inversion Hstep; subst; destruct (prog_well_specified l) as [wtag [d [Hbody Hd]]];
        cbn [oa_config]; rewrite Hbody; apply OAA_oa; apply OP_seq_other; [apply OP_assume | exact Hd].
    + destruct g as [s'|c' s'];
        [exact I | cbn [oa_config] in IH |- *; apply (oa_active_step cc sr ev c' s' IH Hstep)].
Qed.

(* ... hence at every config of a pre-run. *)
Lemma prerun_oa_at : forall gs p, pre_run gs -> p < length gs -> oa_config (cfg_at gs p).
Proof.
  intros gs p Hpre Hp.
  assert (Hpre' : pre_run (firstn (p+1) gs)) by (apply (pre_run_firstn gs (p+1) Hpre); lia).
  pose proof (prerun_oa_last _ Hpre') as Hoa.
  assert (Hlen : length (firstn (p+1) gs) = p+1) by (apply firstn_length_le; lia).
  assert (Hne : firstn (p+1) gs <> []) by (apply pre_run_nonempty; exact Hpre').
  rewrite <- (last_eq_cfg_at (firstn (p+1) gs) Hne), Hlen in Hoa.
  replace (p + 1 - 1) with p in Hoa by lia.
  rewrite (cfg_at_firstn (p+1) gs p ltac:(lia)) in Hoa. exact Hoa.
Qed.

(* ---- (a) assert-extraction: at an output-redex config of a pre-run, the
   matching [Cassert l0 (Ragr e)] occurred earlier with the same state ----    *)

(* at_out c l0 e : the redex of c is the output command Cout l0 e. *)
Inductive at_out : cmd -> Lev -> expr -> Prop :=
| AO_here : forall l0 e, at_out (Cout l0 e) l0 e
| AO_ctx  : forall c d l0 e, at_out c l0 e -> at_out (Cseq c d) l0 e.

(* post_assert c l0 e : c is the transient form [..Cseq Cskip (Cout l0 e)..]
   reached right after the paired assert has fired (skip;output still pending),
   possibly under a left Cseq context. *)
Inductive post_assert : cmd -> Lev -> expr -> Prop :=
| PA_here : forall l0 e, post_assert (Cseq Cskip (Cout l0 e)) l0 e
| PA_ctx  : forall c d l0 e, post_assert c l0 e -> post_assert (Cseq c d) l0 e.

Lemma at_out_redex : forall c l0 e, at_out c l0 e -> redex_cmd c = Cout l0 e.
Proof. intros c l0 e H. induction H; simpl; [reflexivity | exact IHat_out]. Qed.

Lemma redex_at_out : forall c lo eo, redex_cmd c = Cout lo eo -> at_out c lo eo.
Proof.
  induction c; simpl; intros lo eo H; try discriminate.
  - injection H as H1 H2; subst; apply AO_here.
  - apply AO_ctx; apply IHc1; exact H.
Qed.

Lemma at_out_not_oa : forall c l0 e, at_out c l0 e -> ~ outputs_asserted c.
Proof.
  intros c l0 e H. induction H; intros Hoa.
  - inversion Hoa.
  - inversion Hoa; subst; [ inversion H | apply IHat_out; assumption ].
Qed.

Lemma post_assert_not_oa : forall c l0 e, post_assert c l0 e -> ~ outputs_asserted c.
Proof.
  intros c l0 e H. induction H; intros Hoa.
  - inversion Hoa; subst.
    match goal with H : outputs_asserted (Cout _ _) |- _ => inversion H end.
  - inversion Hoa; subst; [ inversion H | apply IHpost_assert; assumption ].
Qed.

(* An at_out config is reached only from its post_assert predecessor (skip;seq),
   with an Etick step and unchanged state. *)
Lemma step_to_atout : forall cp sp ev cc s,
  oa_active cp -> step (Active cp sp) ev (Active cc s) ->
  forall lo eo, at_out cc lo eo -> post_assert cp lo eo /\ ev = Etick /\ s = sp.
Proof.
  intros cp. induction cp; intros sp ev cc s Hoa Hstep lo eo Hat.
  - inversion Hstep.
  - inversion Hstep; subst; inversion Hat.
  - inversion Hstep; subst; inversion Hat.
  - (* Cif *) inversion Hstep; subst;
      (inversion Hoa as [cz Hoac | | |]; subst;
       inversion Hoac; subst;
       match goal with
       | Hb : outputs_asserted ?b, Ha : at_out ?b _ _ |- _ =>
           exfalso; apply (at_out_not_oa b lo eo Ha Hb)
       end).
  - (* Cwhile *) inversion Hstep; subst.
    + (* true: cc = Cseq c (Cwhile e c), at_out -> at_out c, but c outputs_asserted *)
      inversion Hat; subst.
      inversion Hoa as [cz Hoac | | |]; subst. inversion Hoac; subst.
      exfalso. eapply at_out_not_oa; eassumption.
    + (* false: cc = Cskip *) inversion Hat.
  - (* Cseq cp1 cp2 *) inversion Hstep; subst.
    + (* Step_skip_seq: cp1 = Cskip, cc = cp2 *)
      inversion Hoa as [cz Hoac | l1 e1 Heq | | c0 d0 Hoac0 Hoad0 Heq]; subst.
      * (* OAA_oa: only OP_seq_other survives (first child Cskip) *)
        inversion Hoac; subst. exfalso. eapply at_out_not_oa; eassumption.
      * (* OAA_postassert: cp2 = Cout l1 e1 *)
        inversion Hat; subst. split; [apply PA_here | split; reflexivity].
      * (* OAA_ctx *) exfalso. eapply at_out_not_oa; eassumption.
    + (* Step_seq: inner cp1 -> c', cc = Cseq c' cp2 *)
      inversion Hat; subst.
      inversion Hoa as [cz Hoac | | | c0 d0 Hoac0 Hoad0 Heq]; subst.
      * (* OAA_oa: outputs_asserted (Cseq cp1 cp2) *)
        inversion Hoac; subst.
        -- (* paired terminal: cp1 = Cassert, inner step -> Cskip, at_out Cskip false *)
           match goal with H : step (Active (Cassert _ _ _) _) _ _ |- _ => inversion H; subst end.
           match goal with H : at_out Cskip _ _ |- _ => inversion H end.
        -- (* OP_seq_other *)
           destruct (IHcp1 sp ev _ s (OAA_oa cp1 ltac:(assumption))
                       ltac:(eassumption) lo eo ltac:(assumption)) as [Hpa [Hev Hst]].
           split; [apply PA_ctx; exact Hpa | split; assumption].
      * (* OAA_postassert: cp1 = Cskip, inner step impossible *)
        match goal with H : step (Active Cskip _) _ _ |- _ => inversion H end.
      * (* OAA_ctx *)
        destruct (IHcp1 sp ev _ s Hoac0 ltac:(eassumption) lo eo ltac:(assumption))
          as [Hpa [Hev Hst]].
        split; [apply PA_ctx; exact Hpa | split; assumption].
  - inversion Hstep; subst; inversion Hat.
  - inversion Hstep; subst; inversion Hat.
Qed.

(* A post_assert config is reached only from its assert config (redex Cassert
   l0 (Ragr e)), with an Etick step and unchanged state. *)
Lemma step_to_postassert : forall cp sp ev cc s,
  oa_active cp -> step (Active cp sp) ev (Active cc s) ->
  forall lo eo, post_assert cc lo eo ->
  exists tk, redex_cmd cp = Cassert lo tk (Ragr eo) /\ ev = Etick /\ s = sp.
Proof.
  intros cp. induction cp; intros sp ev cc s Hoa Hstep lo eo Hpa.
  - inversion Hstep.
  - inversion Hstep; subst; inversion Hpa.
  - inversion Hstep; subst; inversion Hpa.
  - (* Cif *) inversion Hstep; subst;
      (inversion Hoa as [cz Hoac | | |]; subst; inversion Hoac; subst;
       match goal with
       | Hb : outputs_asserted ?b, Hp : post_assert ?b _ _ |- _ =>
           exfalso; apply (post_assert_not_oa b lo eo Hp Hb)
       end).
  - (* Cwhile *) inversion Hstep; subst.
    + (* true: cc = Cseq c (Cwhile e c); only PA_ctx survives (2nd child Cwhile) *)
      inversion Hpa; subst.
      inversion Hoa as [cz Hoac | | |]; subst. inversion Hoac; subst.
      exfalso. eapply post_assert_not_oa; eassumption.
    + inversion Hpa.
  - (* Cseq cp1 cp2 *) inversion Hstep; subst.
    + (* Step_skip_seq: cp1 = Cskip, cc = cp2, post_assert cp2 *)
      inversion Hoa as [cz Hoac | l1 e1 Heq | | c0 d0 Hoac0 Hoad0 Heq]; subst.
      * (* OAA_oa: only OP_seq_other survives (first child Cskip) *)
        inversion Hoac; subst. exfalso. eapply post_assert_not_oa; eassumption.
      * (* OAA_postassert: cp2 = Cout l1 e1, post_assert (Cout ..) false *)
        inversion Hpa.
      * exfalso. eapply post_assert_not_oa; eassumption.
    + (* Step_seq: inner cp1 -> c', cc = Cseq c' cp2, post_assert (Cseq c' cp2) *)
      inversion Hpa as [la ea Heqa | c1 d1 la ea Hpac Heqb]; subst.
      * (* PA_here: c' = Cskip, cp2 = Cout lo eo *)
        inversion Hoa as [cz Hoac | | | c0 d0 Hoac0 Hoad0 Heq]; subst.
        -- (* OAA_oa: outputs_asserted (Cseq cp1 (Cout lo eo)) *)
           inversion Hoac; subst.
           ++ (* paired terminal: cp1 = Cassert lo (Ragr eo) *)
              eexists. simpl. split;
                [ reflexivity
                | match goal with H : step (Active (Cassert _ _ _) _) _ _ |- _ =>
                    inversion H; subst end; split; reflexivity ].
           ++ (* OP_seq_other: outputs_asserted (Cout lo eo) impossible *)
              match goal with H : outputs_asserted (Cout _ _) |- _ => inversion H end.
        -- (* OAA_postassert: cp1 = Cskip, inner step impossible *)
           match goal with H : step (Active Cskip _) _ _ |- _ => inversion H end.
        -- (* OAA_ctx: outputs_asserted (Cout lo eo) impossible *)
           match goal with H : outputs_asserted (Cout _ _) |- _ => inversion H end.
      * (* PA_ctx: post_assert c' *)
        inversion Hoa as [cz Hoac | | | c0 d0 Hoac0 Hoad0 Heq]; subst.
        -- inversion Hoac; subst.
           ++ (* paired terminal: cp1 = Cassert, inner -> Cskip, post_assert Cskip false *)
              match goal with H : step (Active (Cassert _ _ _) _) _ _ |- _ => inversion H; subst end.
              inversion Hpac.
           ++ destruct (IHcp1 sp ev _ s (OAA_oa cp1 ltac:(assumption))
                         ltac:(eassumption) lo eo ltac:(assumption)) as [tk1 [Hred [Hev Hst]]].
              exists tk1. simpl. split; [exact Hred | split; assumption].
        -- (* OAA_postassert: cp1 = Cskip, inner step impossible *)
           match goal with H : step (Active Cskip _) _ _ |- _ => inversion H end.
        -- destruct (IHcp1 sp ev _ s Hoac0 ltac:(eassumption) lo eo ltac:(assumption))
             as [tk1 [Hred [Hev Hst]]].
           exists tk1. simpl. split; [exact Hred | split; assumption].
  - inversion Hstep; subst; inversion Hpa.
  - inversion Hstep; subst; inversion Hpa.
Qed.

(* The run invariant: at every Active config, an output redex (resp. a transient
   post-assert form) has its matching assert at an earlier index with equal state. *)
Definition out_assert_inv (gs : list config) : Prop :=
  forall p cc s, p < length gs -> cfg_at gs p = Active cc s ->
    (forall l0 e, at_out cc l0 e ->
       exists ia tk, ia < p /\ redex_of (cfg_at gs ia) = Some (Cassert l0 tk (Ragr e)) /\
                  cfg_state (cfg_at gs ia) = s) /\
    (forall l0 e, post_assert cc l0 e ->
       exists ia tk, ia < p /\ redex_of (cfg_at gs ia) = Some (Cassert l0 tk (Ragr e)) /\
                  cfg_state (cfg_at gs ia) = s).

Lemma prerun_out_assert_inv : forall gs, pre_run gs -> out_assert_inv gs.
Proof.
  intros gs [evs Hat]. induction Hat as [| gs evs ev g Hat IH Hstep].
  - unfold out_assert_inv. intros p cc s Hp Hcfg. simpl in Hp.
    assert (p = 0) by lia. subst p. unfold cfg_at in Hcfg. simpl in Hcfg. discriminate.
  - unfold out_assert_inv in *. intros p cc s Hp Hcfg.
    rewrite length_app in Hp. simpl in Hp.
    destruct (Nat.lt_ge_cases p (length gs)) as [Hlt | Hge].
    + rewrite (cfg_at_app1 gs g p Hlt) in Hcfg.
      destruct (IH p cc s Hlt Hcfg) as [Hao Hpa]. split.
      * intros l0 e Hat0. destruct (Hao l0 e Hat0) as [ia [tk1 [Hia [Hred Hst]]]].
        exists ia, tk1. rewrite (cfg_at_app1 gs g ia ltac:(lia)).
        split; [lia | split; [exact Hred | exact Hst]].
      * intros l0 e Hpa0. destruct (Hpa l0 e Hpa0) as [ia [tk1 [Hia [Hred Hst]]]].
        exists ia, tk1. rewrite (cfg_at_app1 gs g ia ltac:(lia)).
        split; [lia | split; [exact Hred | exact Hst]].
    + assert (Hpeq : p = length gs) by lia. subst p.
      rewrite (cfg_at_app2 gs g) in Hcfg. subst g.
      assert (Hpre_gs : pre_run gs) by (exists evs; exact Hat).
      pose proof (prerun_oa_last gs Hpre_gs) as Hoalast.
      assert (Hgsne : gs <> []) by (apply pre_run_nonempty; exact Hpre_gs).
      assert (Hgspos : 1 <= length gs)
        by (destruct gs; [contradiction Hgsne; reflexivity | simpl; lia]).
      set (pp := length gs - 1).
      assert (Hpplt : pp < length gs) by (unfold pp; lia).
      assert (Hppcfg : cfg_at gs pp = last_cfg gs) by (apply last_eq_cfg_at; exact Hgsne).
      destruct (last_cfg gs) as [sr | cp sp] eqn:Hlc.
      * (* Receptive predecessor: g redex is the assume boilerplate *)
        inversion Hstep; subst.
        destruct (prog_well_specified l) as [wtag [d [Hbody Hd]]].
        rewrite Hbody. split; intros l0 e0 Hx; inversion Hx; subst;
          match goal with H : _ (Cassume _ _ _) _ _ |- _ => inversion H end.
      * (* Active predecessor cp sp, oa_active cp *)
        cbn [oa_config] in Hoalast.
        split.
        -- intros l0 e Hat0.
           destruct (step_to_atout cp sp ev cc s Hoalast Hstep l0 e Hat0) as [Hpacp [Hev Hseq]].
           destruct (IH pp cp sp Hpplt Hppcfg) as [_ Hpa].
           destruct (Hpa l0 e Hpacp) as [ia [tk1 [Hia [Hred Hst]]]].
           exists ia, tk1. rewrite (cfg_at_app1 gs (Active cc s) ia ltac:(lia)).
           split; [lia | split; [exact Hred | rewrite Hst; exact (eq_sym Hseq)]].
        -- intros l0 e Hpa0.
           destruct (step_to_postassert cp sp ev cc s Hoalast Hstep l0 e Hpa0)
             as [tkp [Hredcp [Hev Hseq]]].
           exists pp, tkp. rewrite (cfg_at_app1 gs (Active cc s) pp Hpplt).
           rewrite Hppcfg. simpl. rewrite Hredcp.
           split; [lia | split; [reflexivity | exact (eq_sym Hseq)]].
Qed.

(* (a) The output-extraction lemma consumed by the conformance case. *)
Lemma prerun_output_assert : forall gs p cc s l0 e,
  pre_run gs -> p < length gs -> cfg_at gs p = Active cc s -> redex_cmd cc = Cout l0 e ->
  exists ia tk, ia < p /\ redex_of (cfg_at gs ia) = Some (Cassert l0 tk (Ragr e)) /\
             cfg_state (cfg_at gs ia) = s.
Proof.
  intros gs p cc s l0 e Hpre Hp Hcfg Hred.
  destruct (prerun_out_assert_inv gs Hpre p cc s Hp Hcfg) as [Hao _].
  apply Hao. apply redex_at_out. exact Hred.
Qed.

(* ---- Single-run event<->config correspondence (toward the conformance =>
   visible-trace bridge). The m-th event of a trace is emitted by the step from
   config m to config (S m); from that step we read off the producing config:
   an output event exposes its Cout redex (hence, via prerun_output_assert, its
   matching assert), an input event exposes the receptive config it consumes and
   the handler config it lands in (whose redex is the entry l-assume). ---- *)

(* The m-th trace event is the label of the step config_m -> config_{S m}. *)
Lemma admits_trace_step_at : forall gs ts m d,
  admits_trace gs ts -> m < length ts ->
  step (cfg_at gs m) (nth m ts d) (cfg_at gs (S m)).
Proof.
  intros gs ts m d Hat. revert m. induction Hat as [| gs evs ev g Hat IH Hstep]; intros m Hm.
  - simpl in Hm. lia.
  - pose proof (admits_trace_length gs evs Hat) as Hlen.
    rewrite length_app in Hm. simpl in Hm.
    destruct (Nat.lt_ge_cases m (length evs)) as [Hlt | Hge].
    + rewrite (cfg_at_app1 gs g m ltac:(lia)).
      rewrite (cfg_at_app1 gs g (S m) ltac:(lia)).
      rewrite (app_nth1 evs [ev] d Hlt).
      apply (IH m Hlt).
    + assert (Hmeq : m = length evs) by lia. subst m.
      assert (Hne : gs <> []) by (apply (admits_trace_nonempty gs evs Hat)).
      assert (Hnth : nth (length evs) (evs ++ [ev]) d = ev).
      { rewrite app_nth2 by lia. rewrite Nat.sub_diag. reflexivity. }
      rewrite Hnth.
      assert (Hc1 : cfg_at (gs ++ [g]) (length evs) = last_cfg gs).
      { rewrite (cfg_at_app1 gs g (length evs) ltac:(lia)).
        replace (length evs) with (length gs - 1) by lia.
        apply (last_eq_cfg_at gs Hne). }
      assert (Hc2 : cfg_at (gs ++ [g]) (S (length evs)) = g).
      { replace (S (length evs)) with (length gs) by lia. apply (cfg_at_app2 gs g). }
      rewrite Hc1, Hc2. exact Hstep.
Qed.

(* An input-labelled step departs from a receptive config. *)
Lemma step_input_receptive : forall c0 ev g,
  step c0 ev g -> forall l n, ev = Ein l n -> exists s, c0 = Receptive s.
Proof.
  intros c0 ev g H. induction H; intros lo no Heq; try discriminate.
  - exists s. reflexivity.
  - destruct (IHstep lo no Heq) as [s0 Hs0]. discriminate Hs0.
Qed.

(* An l-visible output event at trace position m exposes its Cout redex (with the
   emitted value the value of the output expression) at config m. *)
Lemma trace_output_cfg : forall gs ts m l' n,
  admits_trace gs ts -> m < length ts -> nth m ts Etick = Eout l' n ->
  exists cc s e, cfg_at gs m = Active cc s /\ redex_cmd cc = Cout l' e /\ n = eval_expr s e.
Proof.
  intros gs ts m l' n Hat Hm Hev.
  pose proof (admits_trace_step_at gs ts m Etick Hat Hm) as Hstep.
  rewrite Hev in Hstep.
  apply (step_emits_output (cfg_at gs m) (Eout l' n) (cfg_at gs (S m)) Hstep l' n eq_refl).
Qed.

(* An input event at trace position m consumes the receptive config m and lands
   in the handler body at config (S m); by well-specification that config's redex
   is the entry assume Cassume l' (Ragr (EVar (h_var (prog l')))), and the input
   value n is the value of h_var there. *)
Lemma trace_input_cfg : forall gs ts m l' n,
  admits_trace gs ts -> m < length ts -> nth m ts Etick = Ein l' n ->
  exists s, cfg_at gs m = Receptive s /\
            cfg_at gs (S m) = Active (h_body (prog l')) (update s (h_var (prog l')) n).
Proof.
  intros gs ts m l' n Hat Hm Hev.
  pose proof (admits_trace_step_at gs ts m Etick Hat Hm) as Hstep.
  rewrite Hev in Hstep.
  destruct (cfg_at gs m) as [s | cc s] eqn:Hcm.
  - apply step_receptive_inv in Hstep.
    destruct Hstep as [l0 [n0 [Hev0 Hg0]]].
    injection Hev0 as Hl0 Hn0. subst l0 n0.
    exists s. split; [reflexivity | exact Hg0].
  - destruct (step_input_receptive (Active cc s) (Ein l' n) (cfg_at gs (S m)) Hstep l' n eq_refl)
      as [s0 Hs0]. discriminate Hs0.
Qed.


(* -------------------------------------------------------- *)
(* The run invariant: the active command of a reachable config
   is a residual of the body of the handler that is running   *)
(* -------------------------------------------------------- *)

(* A handler body's first step consumes its entry assume; there is no other
   step it can take. *)
Lemma step_seq_assume : forall l tk Phi d s ev g,
  step (Active (Cseq (Cassume l tk Phi) d) s) ev g -> g = Active (Cseq Cskip d) s.
Proof.
  intros l tk Phi d s ev g H. inversion H; subst.
  match goal with
  | Hs : step (Active (Cassume _ _ _) _) _ _ |- _ =>
      inversion Hs; subst; reflexivity
  end.
Qed.

(* THE RUN INVARIANT.  An active config of a pre-run is in exactly one of two
   situations.  Either it was just entered -- its command is a whole handler
   body and the preceding trace event is the input that dispatched it -- or the
   handler's entry assume has already been consumed, and the command is a
   residual of what the body left after that first step.  The second disjunct
   is what makes the first one informative: a residual past the entry assume
   can no longer contain the entry assume's tag (see below), so the two cases
   are mutually exclusive, which is exactly what handler_entry_dispatched says.

   Induction is on the trace, and the only real work is the hand-off between
   the disjuncts: the step out of a freshly entered body is forced to be the
   entry-assume step (step_seq_assume), which lands in the second disjunct,
   where residual-hood is preserved by every subsequent step. *)
Lemma run_cmd_inv : forall gs ts q c s,
  admits_trace gs ts -> q < length gs -> cfg_at gs q = Active c s ->
  (exists l, 0 < q
             /\ nth (q - 1) ts Etick = Ein l (eval_expr s (EVar (h_var (prog l))))
             /\ c = h_body (prog l))
  \/ (exists l tk Phi d,
        h_body (prog l) = Cseq (Cassume l tk Phi) d /\ residual (Cseq Cskip d) c).
Proof.
  intros gs ts q c s Hat. revert q c s.
  induction Hat as [| gs evs ev g Hat IH Hstep]; intros q c s Hq Hcfg.
  - (* the initial pre-run holds only the receptive config *)
    simpl in Hq. assert (Hq0 : q = 0) by lia. subst q.
    unfold cfg_at in Hcfg. simpl in Hcfg. discriminate.
  - pose proof (admits_trace_length gs evs Hat) as Hlen.
    assert (Hne : gs <> []) by (apply (admits_trace_nonempty gs evs Hat)).
    rewrite length_app in Hq. simpl in Hq.
    destruct (Nat.lt_ge_cases q (length gs)) as [Hlt | Hge].
    + (* q is in the prefix: the invariant is inherited *)
      rewrite (cfg_at_app1 gs g q Hlt) in Hcfg.
      destruct (IH q c s Hlt Hcfg) as [[l [Hpos [Hev' Hc]]] | Hright].
      * left. exists l. split; [exact Hpos |]. split; [| exact Hc].
        rewrite app_nth1 by lia. exact Hev'.
      * right. exact Hright.
    + (* q is the newly appended config, reached by the last step *)
      assert (Hqeq : q = length gs) by lia. subst q.
      rewrite (cfg_at_app2 gs g) in Hcfg. subst g.
      rewrite <- (last_eq_cfg_at gs Hne) in Hstep.
      assert (Hnthlast : nth (length gs - 1) (evs ++ [ev]) Etick = ev).
      { rewrite app_nth2 by lia.
        replace (length gs - 1 - length evs) with 0 by lia. reflexivity. }
      assert (Hprevlt : length gs - 1 < length gs) by lia.
      remember (cfg_at gs (length gs - 1)) as gprev eqn:Hprev.
      symmetry in Hprev.
      destruct gprev as [s0 | c0 s0].
      * (* the previous config is receptive: this step is the dispatching input *)
        apply step_receptive_inv in Hstep.
        destruct Hstep as [lo [no [Hev0 Hg0]]].
        injection Hg0 as Hc0 Hs0. subst c s.
        left. exists lo. split; [lia |]. split; [| reflexivity].
        rewrite Hnthlast, Hev0. simpl. rewrite update_eq. reflexivity.
      * (* the previous config is active: use the invariant there *)
        destruct (IH (length gs - 1) c0 s0 Hprevlt Hprev) as [[l [_ [_ Hc0]]] | Hright].
        -- (* it was a freshly entered body: this step consumes the entry assume *)
           subst c0.
           destruct (prog_well_specified l) as [tk [d [Hbody _]]].
           rewrite Hbody in Hstep.
           pose proof (step_seq_assume l tk (Ragr (EVar (h_var (prog l)))) d s0 ev
                                       (Active c s) Hstep) as Heq.
           injection Heq as Hceq Hseq. subst c.
           right. exists l, tk, (Ragr (EVar (h_var (prog l)))), d.
           split; [exact Hbody | apply Resid_refl].
        -- (* already past the entry assume: residual-hood is step-closed *)
           destruct Hright as [l [tk [Phi [d [Hbody Hres]]]]].
           right. exists l, tk, Phi, d. split; [exact Hbody |].
           exact (Resid_step (Cseq Cskip d) c0 c s0 s ev Hres Hstep).
Qed.

(* Two corollaries of the invariant, in the two forms the sequel needs. *)

(* (1) Every reachable active command is a residual of a handler body. *)
Lemma reach_residual : forall gs ts q c s,
  admits_trace gs ts -> q < length gs -> cfg_at gs q = Active c s ->
  exists l, residual (h_body (prog l)) c.
Proof.
  intros gs ts q c s Hat Hq Hcfg.
  destruct (run_cmd_inv gs ts q c s Hat Hq Hcfg) as [[l [_ [_ Hc]]] | Hright].
  - exists l. subst c. apply Resid_refl.
  - destruct Hright as [l [tk [Phi [d [Hbody Hres]]]]].
    exists l. rewrite Hbody.
    apply (residual_trans _ (Cseq Cskip d) _); [| exact Hres].
    apply (residual_one _ _ s s Etick).
    apply Step_seq. apply Step_assume.
Qed.

(* (2) Past the entry assume, the entry tag is gone.  Together with the
   invariant this makes "the command is a whole handler body" equivalent to
   "the previous step was the dispatching input". *)
Lemma reach_body_entered : forall gs ts q c s l',
  admits_trace gs ts -> q < length gs -> cfg_at gs q = Active c s ->
  c = h_body (prog l') ->
  0 < q /\ nth (q - 1) ts Etick = Ein l' (eval_expr s (EVar (h_var (prog l')))).
Proof.
  intros gs ts q c s l' Hat Hq Hcfg Hc.
  destruct (prog_tags_unique) as [Hnodup Hcross].
  destruct (prog_well_specified l') as [tk' [d' [Hbody' _]]].
  destruct (run_cmd_inv gs ts q c s Hat Hq Hcfg) as [[l [Hpos [Hev Hcl]]] | Hright].
  - (* the two levels agree, because they share the entry tag *)
    assert (Hll : l = l').
    { destruct (prog_well_specified l) as [tk [d [Hbody _]]].
      assert (Hb : h_body (prog l') = h_body (prog l)) by congruence.
      apply (Hcross l l' tk).
      - rewrite Hbody. simpl. left. reflexivity.
      - rewrite Hb, Hbody. simpl. left. reflexivity. }
    subst l. split; [exact Hpos | exact Hev].
  - (* impossible: a residual past the entry assume has lost the entry tag *)
    exfalso.
    destruct Hright as [l [tk [Phi [d [Hbody Hres]]]]].
    (* the entry tag of l' occurs in c, hence in d, hence in l's body *)
    assert (Hin_c : In tk' (annot_tags c)).
    { rewrite Hc, Hbody'. simpl. left. reflexivity. }
    assert (Hin_d : In tk' (annot_tags d)).
    { pose proof (residual_annot_tags (Cseq Cskip d) c Hres tk' Hin_c) as Hin.
      simpl in Hin. exact Hin. }
    assert (Hin_body : In tk' (annot_tags (h_body (prog l)))).
    { rewrite Hbody. simpl. right. exact Hin_d. }
    assert (Hin_body' : In tk' (annot_tags (h_body (prog l')))).
    { rewrite Hbody'. simpl. left. reflexivity. }
    assert (Hll : l = l') by (apply (Hcross l l' tk'); assumption).
    subst l.
    (* the two descriptions of l's body agree on the entry tag, so tk = tk' ... *)
    assert (Htags : annot_tags (Cseq (Cassume l' tk Phi) d)
                  = annot_tags (Cseq (Cassume l' tk' (Ragr (EVar (h_var (prog l'))))) d'))
      by (f_equal; congruence).
    simpl in Htags. injection Htags as Htk _. subst tk'.
    (* ... and then tk occurs both at the entry and inside d, contradicting NoDup *)
    pose proof (Hnodup l') as Hnd. rewrite Hbody in Hnd. simpl in Hnd.
    rewrite NoDup_cons_iff in Hnd. destruct Hnd as [Hnotin _].
    exact (Hnotin Hin_d).
Qed.

(* First of the two facts formerly posited as KludgeHyp: a config whose command
   is a whole handler body was produced by the input step that dispatched that
   handler. *)
Lemma handler_entry_dispatched_lem : handler_entry_dispatched.
Proof.
  unfold handler_entry_dispatched.
  intros gs ts q l' s Hat Hq Hcfg.
  exact (reach_body_entered gs ts q (h_body (prog l')) s l' Hat Hq Hcfg eq_refl).
Qed.

(* RIGIDITY.  Two reachable configs stopped at the same annotation occurrence
   are at the same control point -- not merely the same redex, but the same
   whole command, continuation included.  The tag identifies the handler
   (tags_unique, cross-handler clause), the run invariant makes both commands
   residuals of that one body, and within that body the tag identifies the
   residual (resid_struct_redex_det, using the body's NoDup). *)
Lemma reach_annot_redex_det : forall gs ts q c s hs us q' c' s' t,
  admits_trace gs ts -> q < length gs -> cfg_at gs q = Active c s ->
  admits_trace hs us -> q' < length hs -> cfg_at hs q' = Active c' s' ->
  annot_tag_of (redex_cmd c) = Some t ->
  annot_tag_of (redex_cmd c') = Some t ->
  c = c'.
Proof.
  intros gs ts q c s hs us q' c' s' t Hat Hq Hcfg Hat' Hq' Hcfg' Ht Ht'.
  destruct (reach_residual gs ts q c s Hat Hq Hcfg) as [l Hres].
  destruct (reach_residual hs us q' c' s' Hat' Hq' Hcfg') as [l' Hres'].
  destruct prog_tags_unique as [Hnodup Hcross].
  assert (Hll : l = l').
  { apply (Hcross l l' t).
    - apply (residual_annot_tags _ _ Hres). apply redex_annot_tag_in. exact Ht.
    - apply (residual_annot_tags _ _ Hres'). apply redex_annot_tag_in. exact Ht'. }
  subst l'.
  exact (resid_struct_redex_det (h_body (prog l)) c c' t (Hnodup l)
           (residual_resid_struct _ _ Hres) (residual_resid_struct _ _ Hres') Ht Ht').
Qed.

(* Second of the two facts formerly posited as KludgeHyp.  With this, KludgeHyp
   is gone: both are now lemmas, and tags_unique is what pays for them. *)
Lemma aligned_annot_same_cmd : aligned_annot_same_cmd_hyp.
Proof.
  unfold aligned_annot_same_cmd_hyp.
  intros l gs hs alpha i j Hlap Haij Hann.
  destruct Hlap as [[tsg Hatg] [[tsh Hath] [Halign Hcoin]]].
  pose proof (Hcoin i j Haij (or_introl Hann)) as Hred.
  destruct Halign as [Hbound _].
  destruct (Hbound i j Haij) as [Hilt Hjlt].
  unfold redex_is_l_annotation in Hann.
  destruct (cfg_at gs i) as [sg | cg sg] eqn:Hgi.
  { simpl in Hann. contradiction. }
  simpl in Hann, Hred.
  destruct (cfg_at hs j) as [sh | ch sh] eqn:Hhj.
  { simpl in Hred. discriminate. }
  simpl in Hred. injection Hred as Hred.
  destruct (is_l_annotation_tag l (redex_cmd cg) Hann) as [t Ht].
  simpl. f_equal.
  apply (reach_annot_redex_det gs tsg i cg sg hs tsh j ch sh t
           Hatg Hilt Hgi Hath Hjlt Hhj Ht).
  rewrite <- Hred. exact Ht.
Qed.

(* Converse-ish to step_emits_output: a config whose redex is an output command
   can only take the matching output step. *)
Lemma step_out_event : forall c s ev g l' e,
  redex_cmd c = Cout l' e -> step (Active c s) ev g -> ev = Eout l' (eval_expr s e).
Proof.
  intros c s ev g l' e Hred Hstep.
  remember (Active c s) as c0 eqn:Hc0. revert c s Hc0 Hred.
  induction Hstep; intros cc ss Hc0 Hred; try discriminate Hc0;
    injection Hc0 as Hcc Hss; subst cc ss; try discriminate Hred.
  - injection Hred as Hl He; subst; reflexivity.
  - simpl in Hred. apply (IHHstep c s eq_refl Hred).
Qed.

(* Stepping an assert-redex config emits a tick and preserves the state. *)
Lemma step_assert_event : forall c s ev g l' tk Phi,
  redex_cmd c = Cassert l' tk Phi -> step (Active c s) ev g ->
  ev = Etick /\ exists c', g = Active c' s.
Proof.
  intros c s ev g l' tk Phi Hred Hstep.
  remember (Active c s) as c0 eqn:Hc0. revert c s Hc0 Hred.
  induction Hstep; intros cc ss Hc0 Hred; try discriminate Hc0;
    injection Hc0 as Hcc Hss; subst cc ss; try discriminate Hred.
  - split; [reflexivity | exists Cskip; reflexivity].
  - simpl in Hred. destruct (IHHstep c s eq_refl Hred) as [Hev [c1 Hg]].
    injection Hg as Hc1 Hss'. subst c'. subst s'.
    split; [exact Hev | exists (Cseq c1 d); reflexivity].
Qed.

(* The command resulting from stepping an assert-redex config is determined by
   the command alone -- independent of the state. *)
Lemma step_assert_cmd_det : forall c s1 s2 ev1 ev2 c1 t1 c2 t2 l' tk Phi,
  redex_cmd c = Cassert l' tk Phi ->
  step (Active c s1) ev1 (Active c1 t1) ->
  step (Active c s2) ev2 (Active c2 t2) ->
  c1 = c2.
Proof.
  induction c; intros s1 s2 ev1 ev2 cc1 t1 cc2 t2 l' tk Phi Hred Hs1 Hs2;
    simpl in Hred; try discriminate.
  - inversion Hs1; subst; [simpl in Hred; discriminate |].
    inversion Hs2; subst; [simpl in Hred; discriminate |].
    f_equal. eapply IHc1; [exact Hred | eassumption | eassumption].
  - inversion Hs1; subst. inversion Hs2; subst. reflexivity.
Qed.

(* Strengthening of step_skip_cmd_det: from a skip-redex config that steps to an
   Active config, ANY other step (regardless of state) also lands in an Active
   config carrying the SAME command. (A skip-redex config reaches Receptive only
   when it is the bare [Cskip], which cannot also step to Active.) *)
Lemma step_skip_cmd_det : forall c s1 s2 ev1 ev2 c1 t1 g2,
  redex_cmd c = Cskip ->
  step (Active c s1) ev1 (Active c1 t1) ->
  step (Active c s2) ev2 g2 ->
  exists c2 t2, g2 = Active c2 t2 /\ c1 = c2.
Proof.
  induction c; intros s1 s2 ev1 ev2 cc1 t1 g2 Hred Hs1 Hs2;
    simpl in Hred; try discriminate.
  - inversion Hs1.
  - inversion Hs1; subst.
    + inversion Hs2; subst.
      * do 2 eexists; split; reflexivity.
      * match goal with H : step (Active Cskip _) _ _ |- _ => inversion H end.
    + inversion Hs2; subst.
      * match goal with H : step (Active Cskip _) _ _ |- _ => inversion H end.
      * match goal with
        | HA : step (Active c1 ?sa) ?e1 (Active ?ca ?ta),
          HB : step (Active c1 ?sb) ?e2 (Active ?cb ?tb) |- _ =>
            destruct (IHc1 sa sb e1 e2 ca ta (Active cb tb) Hred HA HB)
              as [c2x [t2x [Hg Hc]]];
            injection Hg as Hc2 Ht2; subst c2x t2x;
            exists (Cseq cb c2), tb; split; [reflexivity | f_equal; exact Hc]
        end.
Qed.

(* Two-step forward transfer of commands. Two runs whose configs at a, b carry the
   SAME command c (a paired-assert form: redex Cassert), and where the first run's
   successor is the post-assert (redex Cskip), reach the SAME command two steps on
   -- because an assert-step's result command is state-independent (step_assert_
   cmd_det) and then the skip-step's is too (step_skip_cmd_det). Lets the major M
   follow the minor fs's assert->skip->Cout evolution from the shared command. *)
Lemma cmd_two_step_transfer : forall gs hs a b c sa sb c1 t1 l' tk Phi,
  pre_run gs -> pre_run hs ->
  cfg_at gs a = Active c sa ->
  cfg_at hs b = Active c sb ->
  redex_cmd c = Cassert l' tk Phi ->
  cfg_at gs (S a) = Active c1 t1 ->
  redex_cmd c1 = Cskip ->
  S (S a) < length gs ->
  S (S b) < length hs ->
  cfg_cmd (cfg_at gs (S (S a))) = cfg_cmd (cfg_at hs (S (S b))).
Proof.
  intros gs hs a b c sa sb c1 t1 l' tk Phi Hpg Hph Hgsa Hhsb Hredc Hgsa1 Hredc1 HSSa HSSb.
  assert (HSa_lt : S a < length gs) by lia.
  destruct (pre_run_step_adj gs a Hpg HSa_lt) as [ev1 Hstep1].
  rewrite Hgsa, Hgsa1 in Hstep1.
  assert (HSb_lt : S b < length hs) by lia.
  destruct (pre_run_step_adj hs b Hph HSb_lt) as [evb Hstepb].
  rewrite Hhsb in Hstepb.
  destruct (step_assert_event c sb evb (cfg_at hs (S b)) l' tk Phi Hredc Hstepb)
    as [Hevb [c1' Hhsb1]].
  rewrite Hhsb1 in Hstepb.
  assert (Hc1eq : c1 = c1')
    by (apply (step_assert_cmd_det c sa sb ev1 evb c1 t1 c1' sb l' tk Phi Hredc Hstep1 Hstepb)).
  subst c1'.
  destruct (pre_run_step_adj gs (S a) Hpg HSSa) as [ev2 Hstep2].
  rewrite Hgsa1 in Hstep2.
  destruct (pre_run_step_adj hs (S b) Hph HSSb) as [evb2 Hstepb2].
  rewrite Hhsb1 in Hstepb2.
  destruct (cfg_at gs (S (S a))) as [sr2 | c2 t2] eqn:Hgsa2.
  - (* gs reaches Receptive: forces c1 = bare Cskip, so hs also reaches Receptive *)
    destruct c1 as [ | xa ea | la ea | ea ca cb | ea ca | ca cb | la ta Pa | la ta Pa ];
      simpl in Hredc1; try discriminate.
    + assert (Hn : cfg_cmd (cfg_at hs (S (S b))) = None)
        by (inversion Hstepb2; reflexivity).
      rewrite Hn. reflexivity.
    + inversion Hstep2.
  - (* gs reaches Active: transfer the command to hs's successor *)
    destruct (step_skip_cmd_det c1 t1 sb ev2 evb2 c2 t2 (cfg_at hs (S (S b)))
                Hredc1 Hstep2 Hstepb2) as [c2' [t2' [Hhsa2 Hc2]]].
    rewrite Hhsa2. simpl. f_equal. exact Hc2.
Qed.

(* The head config of any pre-run is the initial receptive config. *)
Lemma prerun_head : forall gs, pre_run gs -> cfg_at gs 0 = Receptive initState.
Proof.
  intros gs [evs Hat]. induction Hat as [| gs0 evs0 ev g Hat IH Hstep].
  - reflexivity.
  - unfold cfg_at in *.
    rewrite app_nth1 by (apply admits_trace_nonempty in Hat;
                         destruct gs0; [contradiction | simpl; lia]).
    exact IH.
Qed.

(* A post_assert command's redex is [Cskip]. *)
Lemma post_assert_redex_skip : forall c l0 e, post_assert c l0 e -> redex_cmd c = Cskip.
Proof. intros c l0 e H. induction H; simpl; [reflexivity | exact IHpost_assert]. Qed.

(* Backward paired-structure extraction: an output-redex config at p exposes its
   paired assert TWO configs back (at p-2, redex Cassert l' (Ragr e)) with the
   post-assert (redex Cskip) at p-1 -- all sharing the output's state. (Sharpens
   prerun_output_assert, which only locates the assert at some ia<p; here the
   offset is exactly +2 and the post-assert is pinned, so cmd_two_step_transfer
   can drive the major run from the shared assert command to its own output.) *)
Lemma prerun_output_pair_struct : forall gs p cc s l' e,
  pre_run gs -> p < length gs ->
  cfg_at gs p = Active cc s -> redex_cmd cc = Cout l' e ->
  exists cq cp tk, 2 <= p /\
    cfg_at gs (p - 2) = Active cq s /\ redex_cmd cq = Cassert l' tk (Ragr e) /\
    cfg_at gs (p - 1) = Active cp s /\ redex_cmd cp = Cskip.
Proof.
  intros gs p cc s l' e Hpre Hp Hcp Hred.
  (* p >= 1 *)
  assert (Hp1 : 1 <= p).
  { destruct p as [|p']; [| lia]. rewrite (prerun_head gs Hpre) in Hcp. discriminate. }
  (* predecessor step p-1 -> p *)
  assert (HSp : S (p - 1) = p) by lia.
  assert (HSp_lt : S (p - 1) < length gs) by lia.
  destruct (pre_run_step_adj gs (p - 1) Hpre HSp_lt) as [ev Hstep].
  rewrite HSp, Hcp in Hstep.
  assert (Hp1lt : p - 1 < length gs) by lia.
  pose proof (prerun_oa_at gs (p - 1) Hpre Hp1lt) as Hoa1.
  destruct (cfg_at gs (p - 1)) as [sr1 | cp sp] eqn:Hcfgp1.
  - (* Receptive predecessor: input lands in handler body, redex Cassume <> Cout *)
    exfalso. apply step_receptive_inv in Hstep.
    destruct Hstep as [li [ni [_ Hgi]]]. injection Hgi as Hbody _. subst cc.
    destruct (prog_well_specified li) as [wtag [d [Hwb _]]].
    rewrite Hwb in Hred. simpl in Hred. discriminate.
  - (* Active predecessor: it is the post-assert, redex Cskip, state s *)
    cbn [oa_config] in Hoa1.
    destruct (step_to_atout cp sp ev cc s Hoa1 Hstep l' e (redex_at_out cc l' e Hred))
      as [Hpa1 [_ Hsp]]. subst sp.
    assert (Hredcp : redex_cmd cp = Cskip) by (apply (post_assert_redex_skip cp l' e Hpa1)).
    (* p >= 2 *)
    assert (Hp2 : 2 <= p).
    { destruct (Nat.le_gt_cases 2 p) as [|Hlt]; [assumption | exfalso].
      assert (Hpe : p = 1) by lia. rewrite Hpe in Hcfgp1. simpl in Hcfgp1.
      rewrite (prerun_head gs Hpre) in Hcfgp1. discriminate. }
    (* predecessor step p-2 -> p-1 *)
    assert (HSp2 : S (p - 2) = p - 1) by lia.
    assert (HSp2_lt : S (p - 2) < length gs) by lia.
    destruct (pre_run_step_adj gs (p - 2) Hpre HSp2_lt) as [ev2 Hstep2].
    rewrite HSp2, Hcfgp1 in Hstep2.
    assert (Hp2lt : p - 2 < length gs) by lia.
    pose proof (prerun_oa_at gs (p - 2) Hpre Hp2lt) as Hoa2.
    destruct (cfg_at gs (p - 2)) as [sr2 | cq sq] eqn:Hcfgp2.
    + exfalso. apply step_receptive_inv in Hstep2.
      destruct Hstep2 as [lj [nj [_ Hgj]]]. injection Hgj as Hbody _. subst cp.
      destruct (prog_well_specified lj) as [wtag [d [Hwb _]]].
      rewrite Hwb in Hredcp. simpl in Hredcp. discriminate.
    + cbn [oa_config] in Hoa2.
      destruct (step_to_postassert cq sq ev2 cp s Hoa2 Hstep2 l' e Hpa1)
        as [tkq [Hredcq [_ Hsq]]]. subst sq.
      exists cq, cp, tkq. split; [exact Hp2 | split; [reflexivity | split; [exact Hredcq | split; [reflexivity | exact Hredcp]]]].
Qed.

(* One-step forward transfer of the successor command: two runs whose configs at
   a, b share the command c (redex Cassert) reach the SAME command at a+1, b+1
   (the assert-step result is state-independent). *)
Lemma assert_succ_cmd : forall gs hs a b c sa sb c1 t1 l' tk Phi,
  pre_run gs -> pre_run hs ->
  cfg_at gs a = Active c sa -> cfg_at hs b = Active c sb ->
  redex_cmd c = Cassert l' tk Phi ->
  cfg_at gs (S a) = Active c1 t1 ->
  S a < length gs -> S b < length hs ->
  exists s1, cfg_at hs (S b) = Active c1 s1.
Proof.
  intros gs hs a b c sa sb c1 t1 l' tk Phi Hpg Hph Hgsa Hhsb Hredc Hgsa1 HSa HSb.
  destruct (pre_run_step_adj gs a Hpg HSa) as [ev1 Hs1]. rewrite Hgsa, Hgsa1 in Hs1.
  destruct (pre_run_step_adj hs b Hph HSb) as [evb Hsb]. rewrite Hhsb in Hsb.
  destruct (step_assert_event c sb evb (cfg_at hs (S b)) l' tk Phi Hredc Hsb) as [_ [c1' HhsSb]].
  rewrite HhsSb in Hsb.
  assert (Hc1 : c1 = c1')
    by (apply (step_assert_cmd_det c sa sb ev1 evb c1 t1 c1' sb l' tk Phi Hredc Hs1 Hsb)).
  subst c1'. exists sb. exact HhsSb.
Qed.

(* Cross-run OUTPUT realization: if the minor es has an output-redex config at p
   (a realized visible output) and the major ds carries the SAME command at the
   matched index i (its paired-assert, two configs before the output), then ds
   reaches the post-assert (redex Cskip) at i+1 and the SAME output command at
   i+2 -- provided ds is long enough. The minor's assert->skip->Cout evolution
   transfers to the major by cmd_two_step_transfer / assert_succ_cmd; the shared
   command is supplied by the rank match (cfg_cmd equality from
   aligned_annot_same_cmd_hyp / minor_major_rank). *)
Lemma output_realize_cross : forall ds es i p cc s l' e,
  pre_run ds -> pre_run es ->
  cfg_at es p = Active cc s -> redex_cmd cc = Cout l' e ->
  p < length es ->
  cfg_cmd (cfg_at ds i) = cfg_cmd (cfg_at es (p - 2)) ->
  S (S i) < length ds ->
  redex_of (cfg_at ds (S i)) = Some Cskip /\
  redex_of (cfg_at ds (S (S i))) = Some (Cout l' e).
Proof.
  intros ds es i p cc s l' e Hpd Hpe Hesp Hred Hplt Hcmdeq HSSi.
  destruct (prerun_output_pair_struct es p cc s l' e Hpe Hplt Hesp Hred)
    as [cq [cp [tq1 [Hp2 [Hesq [Hredq [Hesp1 Hredp]]]]]]].
  rewrite Hesq in Hcmdeq. simpl in Hcmdeq.
  destruct (cfg_at ds i) as [sr | dci dsi] eqn:Hdci; [discriminate Hcmdeq |].
  simpl in Hcmdeq. injection Hcmdeq as Hdcicq. subst dci.
  assert (Hes_p1 : cfg_at es (S (p - 2)) = Active cp s)
    by (replace (S (p - 2)) with (p - 1) by lia; exact Hesp1).
  assert (Hlen_es : S (S (p - 2)) < length es) by lia.
  split.
  - destruct (assert_succ_cmd es ds (p - 2) i cq s dsi cp s l' tq1 (Ragr e)
                Hpe Hpd Hesq Hdci Hredq Hes_p1 ltac:(lia) ltac:(lia)) as [s1 HdsSi].
    rewrite HdsSi. simpl. rewrite Hredp. reflexivity.
  - pose proof (cmd_two_step_transfer es ds (p - 2) i cq s dsi cp s l' tq1 (Ragr e)
                  Hpe Hpd Hesq Hdci Hredq Hes_p1 Hredp Hlen_es HSSi) as Htr.
    replace (S (S (p - 2))) with p in Htr by lia.
    rewrite Hesp in Htr. simpl in Htr.
    destruct (cfg_at ds (S (S i))) as [sr2 | dc2 ds2] eqn:Hds2;
      [simpl in Htr; discriminate Htr |].
    simpl in Htr. injection Htr as Hdc2. subst dc2.
    simpl. rewrite Hred. reflexivity.
Qed.

(* The l-visible event emitted at trace position p, read off the configs: an
   output is exposed at its own Cout config; an input is exposed at the receptive
   config it departs, reading level and value from the handler config it lands
   in. Anchored at the emitting position (no offset), so reading configs in order
   recovers the visible trace (vis_at_sound/vis_at_complete below). *)
Definition vis_at (l : Lev) (gs : list config) (p : nat) : option event :=
  match cfg_at gs p with
  | Active c s =>
      match redex_cmd c with
      | Cout l' e => if lleq_dec l' l then Some (Eout l' (eval_expr s e)) else None
      | _ => None
      end
  | Receptive _ =>
      match cfg_at gs (S p) with
      | Active c' s' =>
          match redex_cmd c' with
          | Cassume l' _ (Ragr (EVar x)) =>
              if lleq_dec l' l then Some (Ein l' (eval_expr s' (EVar x))) else None
          | _ => None
          end
      | Receptive _ => None
      end
  end.

(* vis_at reports only genuine l-visible events of the trace ... *)
Lemma vis_at_sound : forall l gs ts p ev,
  admits_trace gs ts -> p < length ts -> vis_at l gs p = Some ev ->
  nth p ts Etick = ev /\ Vev l ev.
Proof.
  intros l gs ts p ev Hat Hp Hv.
  pose proof (admits_trace_step_at gs ts p Etick Hat Hp) as Hstep.
  unfold vis_at in Hv.
  destruct (cfg_at gs p) as [sr | c s] eqn:Hcp.
  - (* receptive: input *)
    destruct (cfg_at gs (S p)) as [sr' | c' s'] eqn:HcSp; [discriminate |].
    destruct (redex_cmd c') as [ | xa ea | la ea | ea ca cb | ea ca | ca cb | la ta Pa | l0 t0 r ] eqn:Hrc';
      try discriminate.
    destruct r as [ e0 | Pb | Pb e0 | Pa Pb ]; try discriminate.
    destruct e0 as [ za | x | bb a1 a2 | a1 ]; try discriminate.
    destruct (lleq_dec l0 l) as [Hle | Hnle]; [| discriminate].
    injection Hv as Hev. subst ev.
    apply step_receptive_inv in Hstep.
    destruct Hstep as [li [ni [Hevi Hgi]]].
    injection Hgi as Hbody Hstate.
    rewrite Hbody in Hrc'.
    destruct (prog_well_specified li) as [wtag [d [Hwb _]]].
    rewrite Hwb in Hrc'. simpl in Hrc'. injection Hrc' as Hl0 Hx. subst l0 x.
    rewrite Hstate. simpl. rewrite update_eq.
    rewrite Hevi. split; [reflexivity | left; exists li, ni; split; [reflexivity | exact Hle]].
  - (* active: output *)
    destruct (redex_cmd c) as [ | xa ea | l0 e0 | ea ca cb | ea ca | ca cb | la ta Pa | la ta Pa ] eqn:Hrc;
      try discriminate.
    destruct (lleq_dec l0 l) as [Hle | Hnle]; [| discriminate].
    injection Hv as Hev. subst ev.
    pose proof (step_out_event c s (nth p ts Etick) (cfg_at gs (S p)) l0 e0 Hrc Hstep) as Hev.
    rewrite Hev. split; [reflexivity | right; exists l0, (eval_expr s e0); split; [reflexivity | exact Hle]].
Qed.

(* ... and reports every l-visible event of the trace. *)
Lemma vis_at_complete : forall l gs ts p,
  admits_trace gs ts -> p < length ts -> Vev l (nth p ts Etick) ->
  vis_at l gs p = Some (nth p ts Etick).
Proof.
  intros l gs ts p Hat Hp Hvev.
  unfold vis_at. destruct Hvev as [Hin | Hout].
  - (* visible input *)
    destruct Hin as [l' [n [Hev Hle]]].
    destruct (trace_input_cfg gs ts p l' n Hat Hp Hev) as [s [Hcp HcSp]].
    rewrite Hcp, HcSp.
    destruct (prog_well_specified l') as [wtag [d [Hwb _]]].
    rewrite Hwb. simpl.
    destruct (lleq_dec l' l) as [Hle' | Hnle]; [| contradiction].
    rewrite update_eq, Hev. reflexivity.
  - (* visible output *)
    destruct Hout as [l' [n [Hev Hle]]].
    destruct (trace_output_cfg gs ts p l' n Hat Hp Hev) as [cc [s [e [Hcp [Hrc Hn]]]]].
    rewrite Hcp, Hrc.
    destruct (lleq_dec l' l) as [Hle' | Hnle]; [| contradiction].
    rewrite Hev, Hn. reflexivity.
Qed.

(* l-silence connector: a position whose own config is not an l-output and whose
   successor is not an l-annotation emits no l-visible event. (An output needs a
   Cout config; an input needs to land in an entry assume, which is an
   l-annotation.) *)
Lemma vis_at_silent : forall l gs p,
  ~ redex_is_l_output l (cfg_at gs p) ->
  ~ redex_is_l_annotation l (cfg_at gs (S p)) ->
  vis_at l gs p = None.
Proof.
  intros l gs p Hout Hann. unfold vis_at.
  destruct (cfg_at gs p) as [sr | c s] eqn:Hcp.
  - destruct (cfg_at gs (S p)) as [sr' | c' s'] eqn:HcSp; [reflexivity |].
    destruct (redex_cmd c') as [ | xa ea | la ea | ea ca cb | ea ca | ca cb | la ta Pa | l0 t0 r ] eqn:Hrc';
      try reflexivity.
    destruct r as [ e1 | Pb | Pb e1 | P1 P2 ]; try reflexivity.
    destruct e1 as [ za | x | bb a1 a2 | a1 ]; try reflexivity.
    destruct (lleq_dec l0 l) as [Hle | Hnle]; [| reflexivity].
    exfalso. apply Hann. unfold redex_is_l_annotation. simpl. rewrite Hrc'. left. exact Hle.
  - destruct (redex_cmd c) as [ | xa ea | l0 e0 | ea ca cb | ea ca | ca cb | la ta Pa | la ta Pa ] eqn:Hrc;
      try reflexivity.
    destruct (lleq_dec l0 l) as [Hle | Hnle]; [| reflexivity].
    exfalso. apply Hout. unfold redex_is_l_output. simpl. rewrite Hrc. exact Hle.
Qed.

(* Collapse a list of optional events to the events present. *)
Fixpoint collect_opt {A : Type} (os : list (option A)) : list A :=
  match os with
  | [] => []
  | Some a :: r => a :: collect_opt r
  | None :: r => collect_opt r
  end.

(* A filter is the option-collection of its per-index test. *)
Lemma filter_eq_collect : forall {A : Type} (p : A -> bool) (xs : list A) (d : A),
  filter p xs =
  collect_opt (map (fun i => if p (nth i xs d) then Some (nth i xs d) else None)
                   (seq 0 (length xs))).
Proof.
  intros A p xs d. induction xs as [| x xs' IH]; [reflexivity |].
  cbn [length seq map filter].
  replace (nth 0 (x :: xs') d) with x by reflexivity.
  replace (map (fun i => if p (nth i (x :: xs') d) then Some (nth i (x :: xs') d) else None)
               (seq 1 (length xs')))
     with (map (fun i => if p (nth i xs' d) then Some (nth i xs' d) else None)
               (seq 0 (length xs'))).
  2:{ rewrite <- seq_shift, map_map. apply map_ext. intros a. cbn [nth]. reflexivity. }
  destruct (p x); cbn [collect_opt]; rewrite <- ? IH; reflexivity.
Qed.

(* Combined characterization: at an in-range position, vis_at is exactly the
   per-position visibility test of the trace event. *)
Lemma vis_at_char : forall l gs ts p,
  admits_trace gs ts -> p < length ts ->
  vis_at l gs p = (if visible_atb l (nth p ts Etick) then Some (nth p ts Etick) else None).
Proof.
  intros l gs ts p Hat Hp.
  destruct (visible_atb l (nth p ts Etick)) eqn:Hb.
  - apply vis_at_complete; [exact Hat | exact Hp |].
    apply (visible_atb_spec l (nth p ts Etick)); exact Hb.
  - destruct (vis_at l gs p) as [ev |] eqn:Hva; [| reflexivity].
    exfalso. destruct (vis_at_sound l gs ts p ev Hat Hp Hva) as [Hnth Hvev].
    assert (Hbt : visible_atb l (nth p ts Etick) = true)
      by (rewrite Hnth; apply (visible_atb_spec l ev); exact Hvev).
    rewrite Hbt in Hb; discriminate.
Qed.

(* Single-run list form: the visible trace is read off the configs by vis_at. *)
Lemma vis_eq_collect : forall l gs ts,
  admits_trace gs ts -> vis l ts = collect_opt (map (vis_at l gs) (seq 0 (length ts))).
Proof.
  intros l gs ts Hat. unfold vis.
  rewrite (filter_eq_collect (visible_atb l) ts Etick).
  f_equal. apply map_ext_in. intros p Hpin. apply in_seq in Hpin.
  symmetry. apply vis_at_char; [exact Hat | lia].
Qed.

(* The visible projection of a trace prefix is no longer than that of the trace. *)
Lemma vis_firstn_le : forall l n ts, length (vis l (firstn n ts)) <= length (vis l ts).
Proof.
  intros l n ts. rewrite <- (firstn_skipn n ts) at 2.
  rewrite vis_app, length_app. lia.
Qed.

(* ---- counting primitives for the conformance length bound ---- *)

(* The length of a collected option-list is the number of Some entries. *)
Lemma collect_opt_length : forall (A : Type) (os : list (option A)),
  length (collect_opt os) =
  length (filter (fun o => match o with Some _ => true | None => false end) os).
Proof.
  induction os as [|o os' IH]; [reflexivity |].
  destruct o; simpl; rewrite IH; reflexivity.
Qed.

Lemma filter_map_length : forall (A B : Type) (p : B -> bool) (f : A -> B) (xs : list A),
  length (filter p (map f xs)) = length (filter (fun x => p (f x)) xs).
Proof.
  induction xs as [|x xs' IH]; simpl; [reflexivity |].
  destruct (p (f x)); simpl; rewrite IH; reflexivity.
Qed.

(* The number of l-visible trace events equals the number of trace positions at
   which vis_at fires. *)
Lemma vis_length_positions : forall l gs ts,
  admits_trace gs ts ->
  length (vis l ts) =
  length (filter (fun p => match vis_at l gs p with Some _ => true | None => false end)
                 (seq 0 (length ts))).
Proof.
  intros l gs ts Hat.
  rewrite (vis_eq_collect l gs ts Hat), collect_opt_length, filter_map_length.
  reflexivity.
Qed.

(* A list-counting bound via an injective map: if [f] sends every element of a
   duplicate-free [l] into [l'] and is injective on [l], then [l] is no longer
   than [l']. *)
Lemma NoDup_map_inj : forall (f : nat -> nat) (l : list nat),
  NoDup l ->
  (forall x y, In x l -> In y l -> f x = f y -> x = y) ->
  NoDup (map f l).
Proof.
  induction l as [|a l' IH]; intros Hnd Hinj; simpl; [constructor |].
  inversion Hnd as [| z zs Hnin Hnd' Heq]; subst.
  constructor.
  - intros Hin. apply in_map_iff in Hin. destruct Hin as [x [Hfx Hxin]].
    assert (a = x) by (apply Hinj; [left; reflexivity | right; exact Hxin | symmetry; exact Hfx]).
    subst x. contradiction.
  - apply IH; [exact Hnd' | intros x y Hx Hy Hf; apply Hinj; [right; exact Hx | right; exact Hy | exact Hf]].
Qed.

Lemma length_le_via_inj : forall (f : nat -> nat) (l l' : list nat),
  NoDup l ->
  (forall x, In x l -> In (f x) l') ->
  (forall x y, In x l -> In y l -> f x = f y -> x = y) ->
  length l <= length l'.
Proof.
  intros f l l' Hnd Hmaps Hinj.
  rewrite <- (length_map f l).
  apply NoDup_incl_length.
  - apply NoDup_map_inj; assumption.
  - intros y Hy. apply in_map_iff in Hy. destruct Hy as [x [Hfx Hxin]].
    subst y. apply Hmaps; exact Hxin.
Qed.

(* annot_count, as a count of annotation indices below k. *)
Lemma annot_count_filter : forall l gs k,
  annot_count l gs k =
  length (filter (fun i => if redex_is_l_annotation_dec l (cfg_at gs i) then true else false)
                 (seq 0 k)).
Proof.
  induction k as [|k' IH]; [reflexivity |].
  simpl annot_count. rewrite IH, seq_S, filter_app, length_app. simpl.
  destruct (redex_is_l_annotation_dec l (cfg_at gs k')); simpl; lia.
Qed.

(* The r-th element of [filter p (seq 0 N)] is an index below N that passes p and
   has exactly r earlier passing indices. *)
Lemma filter_seq_nth_count : forall (p : nat -> bool) N r,
  r < length (filter p (seq 0 N)) ->
  nth r (filter p (seq 0 N)) N < N /\
  p (nth r (filter p (seq 0 N)) N) = true /\
  length (filter p (seq 0 (nth r (filter p (seq 0 N)) N))) = r.
Proof.
  induction N as [|N' IH]; intros r Hr.
  - simpl in Hr. lia.
  - rewrite seq_S in Hr |- *. replace (0 + N') with N' in * by lia.
    rewrite filter_app in Hr |- *. rewrite length_app in Hr.
    remember (filter p (seq 0 N')) as L eqn:HL.
    destruct (Nat.lt_ge_cases r (length L)) as [Hlt | Hge].
    + rewrite app_nth1 by exact Hlt.
      assert (Hind : nth r L (S N') = nth r L N') by (apply nth_indep; exact Hlt).
      rewrite Hind. destruct (IH r Hlt) as [Hi [Hpi Hcnt]].
      split; [lia | split; [exact Hpi | exact Hcnt]].
    + assert (HpN : p N' = true).
      { destruct (p N') eqn:Hp; [reflexivity | exfalso].
        simpl in Hr. rewrite Hp in Hr. simpl in Hr. lia. }
      simpl in Hr. rewrite HpN in Hr. simpl in Hr.
      assert (Hre : r = length L) by lia.
      assert (Hi : nth r (L ++ filter p [N']) (S N') = N').
      { rewrite app_nth2 by lia. rewrite Hre, Nat.sub_diag. simpl. rewrite HpN. reflexivity. }
      rewrite Hi.
      split; [lia | split; [exact HpN | rewrite HL in Hre; lia]].
Qed.

(* A function selecting the index of the r-th l-annotation of gs. *)
Definition annot_idx (l : Lev) (gs : list config) (r : nat) : nat :=
  nth r (filter (fun i => if redex_is_l_annotation_dec l (cfg_at gs i) then true else false)
                (seq 0 (length gs))) (length gs).

Lemma annot_idx_is_nth : forall l gs r,
  r < annot_count l gs (length gs) -> is_nth_annot l gs r (annot_idx l gs r).
Proof.
  intros l gs r Hr.
  rewrite (annot_count_filter l gs (length gs)) in Hr.
  destruct (filter_seq_nth_count
              (fun i => if redex_is_l_annotation_dec l (cfg_at gs i) then true else false)
              (length gs) r Hr) as [Hlt [Hpt Hcnt]].
  unfold annot_idx, is_nth_annot.
  split; [exact Hlt | split].
  - destruct (redex_is_l_annotation_dec l
                (cfg_at gs (nth r (filter _ (seq 0 (length gs))) (length gs))));
      [assumption | discriminate Hpt].
  - rewrite (annot_count_filter l gs
              (nth r (filter _ (seq 0 (length gs))) (length gs))).
    exact Hcnt.
Qed.

(* Cross-run rank correspondence: when both runs are covered, the n-th
   l-annotation of the major is aligned to the n-th l-annotation of the minor,
   and (by rigidity) they carry the same command. *)
Lemma major_minor_rank : forall l gs hs alpha n i,
  l_aligned_pair l gs hs alpha -> covers_dom gs alpha -> covers_rng hs alpha ->
  is_nth_annot l gs n i ->
  exists j, alpha i j /\ is_nth_annot l hs n j /\
            cfg_cmd (cfg_at gs i) = cfg_cmd (cfg_at hs j).
Proof.
  intros l gs hs alpha n i Hlap Hcd Hcr Hnth.
  pose proof Hnth as [Hilt [Hann Hcnt]].
  destruct (Hcd i Hilt) as [j Haij].
  assert (Hnthj : is_nth_annot l hs n j)
    by (apply (annot_align_rank l gs hs alpha n i j Hlap Hcr Hnth Haij)).
  exists j. split; [exact Haij | split; [exact Hnthj |]].
(*  apply (aligned_annot_same_cmd_hyp l gs hs alpha i j); *)
    apply (aligned_annot_same_cmd l gs hs alpha i j); 
    [exact Hlap | exact Haij | exact Hann].
Qed.

(* An Active config sits inside the run. *)
Lemma cfg_at_active_lt : forall gs p c s, cfg_at gs p = Active c s -> p < length gs.
Proof.
  intros gs p c s H. destruct (Nat.lt_ge_cases p (length gs)) as [Hlt | Hge]; [exact Hlt |].
  unfold cfg_at in H. rewrite nth_overflow in H by exact Hge. discriminate.
Qed.

(* An output visible at p is backed by its paired assert annotation, which holds
   the same value. *)
Lemma vis_at_out_assert : forall l gs p l' n,
  pre_run gs -> vis_at l gs p = Some (Eout l' n) ->
  exists ia e tk, ia < p /\ redex_of (cfg_at gs ia) = Some (Cassert l' tk (Ragr e)) /\
               n = eval_expr (cfg_state (cfg_at gs ia)) e /\ lleq l' l.
Proof.
  intros l gs p l' n Hpre Hv. unfold vis_at in Hv.
  destruct (cfg_at gs p) as [sr | c s] eqn:Hcp.
  - destruct (cfg_at gs (S p)) as [sr' | c' s'] eqn:HcSp; [discriminate |].
    destruct (redex_cmd c') as [ | xa ea | la ea | ea ca cb | ea ca | ca cb | la ta Pa | l0 t0 r ] eqn:Hrc';
      try discriminate.
    destruct r as [ e1 | Pb | Pb e1 | P1 P2 ]; try discriminate.
    destruct e1 as [ za | x | bb a1 a2 | a1 ]; try discriminate.
    destruct (lleq_dec l0 l); discriminate.
  - destruct (redex_cmd c) as [ | xa ea | l0 e0 | ea ca cb | ea ca | ca cb | la ta Pa | la ta Pa ] eqn:Hrc;
      try discriminate.
    destruct (lleq_dec l0 l) as [Hle | Hnle]; [| discriminate].
    injection Hv as Hl0 Hn. subst l0.
    assert (Hplt : p < length gs) by (apply (cfg_at_active_lt gs p c s Hcp)).
    destruct (prerun_output_assert gs p c s l' e0 Hpre Hplt Hcp Hrc) as [ia [tka [Hialt [Hredia Hstia]]]].
    exists ia, e0, tka. split; [exact Hialt | split; [exact Hredia | split; [| exact Hle]]].
    rewrite Hstia. symmetry. exact Hn.
Qed.

(* An input visible at p lands in its handler-entry assume annotation (at S p),
   which holds the same value. *)
Lemma vis_at_in_entry : forall l gs p l' n,
  vis_at l gs p = Some (Ein l' n) ->
  exists x tk, redex_of (cfg_at gs (S p)) = Some (Cassume l' tk (Ragr (EVar x))) /\
            n = eval_expr (cfg_state (cfg_at gs (S p))) (EVar x) /\ lleq l' l.
Proof.
  intros l gs p l' n Hv. unfold vis_at in Hv.
  destruct (cfg_at gs p) as [sr | c s] eqn:Hcp.
  - destruct (cfg_at gs (S p)) as [sr' | c' s'] eqn:HcSp; [discriminate |].
    destruct (redex_cmd c') as [ | xa ea | la ea | ea ca cb | ea ca | ca cb | la ta Pa | l0 t0 r ] eqn:Hrc';
      try discriminate.
    destruct r as [ e1 | Pb | Pb e1 | P1 P2 ]; try discriminate.
    destruct e1 as [ za | x | bb a1 a2 | a1 ]; try discriminate.
    destruct (lleq_dec l0 l) as [Hle | Hnle]; [| discriminate].
    injection Hv as Hl0 Hn. subst l0.
    exists x, t0. split; [| split; [| exact Hle]].
    + simpl. rewrite Hrc'. reflexivity.
    + simpl. symmetry. exact Hn.
  - destruct (redex_cmd c) as [ | xa ea | l0 e0 | ea ca cb | ea ca | ca cb | la ta Pa | la ta Pa ] eqn:Hrc;
      try discriminate.
    destruct (lleq_dec l0 l); discriminate.
Qed.

(* Unified connector: every visible event at p is denoted by a value-bearing
   [Ragr e] l-annotation -- an assert for an output, an assume for an input --
   whose value at that config is the event's value. *)
Lemma vis_at_annot : forall l gs p ev,
  pre_run gs -> vis_at l gs p = Some ev ->
  exists ai l' e tk, lleq l' l /\
    ((redex_of (cfg_at gs ai) = Some (Cassert l' tk (Ragr e)) /\
      ev = Eout l' (eval_expr (cfg_state (cfg_at gs ai)) e)) \/
     (redex_of (cfg_at gs ai) = Some (Cassume l' tk (Ragr e)) /\
      ev = Ein l' (eval_expr (cfg_state (cfg_at gs ai)) e))).
Proof.
  intros l gs p ev Hpre Hv.
  destruct ev as [l' n | l' n | ].
  - destruct (vis_at_in_entry l gs p l' n Hv) as [x [tka [Hred [Hval Hle]]]].
    exists (S p), l', (EVar x), tka. split; [exact Hle | right; split; [exact Hred | rewrite Hval; reflexivity]].
  - destruct (vis_at_out_assert l gs p l' n Hpre Hv) as [ia [e [tka [Hlt [Hred [Hval Hle]]]]]].
    exists ia, l', e, tka. split; [exact Hle | left; split; [exact Hred | rewrite Hval; reflexivity]].
  - exfalso. unfold vis_at in Hv.
    destruct (cfg_at gs p) as [sr | c s] eqn:Hcp.
    + destruct (cfg_at gs (S p)) as [sr' | c' s'] eqn:HcSp; [discriminate |].
      destruct (redex_cmd c') as [ | xa ea | la ea | ea ca cb | ea ca | ca cb | la ta Pa | l0 t0 r ] eqn:Hrc';
        try discriminate.
      destruct r as [ e1 | Pb | Pb e1 | P1 P2 ]; try discriminate.
      destruct e1 as [ za | x | bb a1 a2 | a1 ]; try discriminate.
      destruct (lleq_dec l0 l); discriminate.
    + destruct (redex_cmd c) as [ | xa ea | l0 e0 | ea ca cb | ea ca | ca cb | la ta Pa | la ta Pa ] eqn:Hrc;
        try discriminate.
      destruct (lleq_dec l0 l); discriminate.
Qed.

(* Value agreement: at an aligned annotation carrying an agreement formula
   [Ragr e], the conformance models clause forces the two runs to agree on e. *)
Lemma conf_annot_value : forall l ins gs hs alpha i j l' tk e,
  conformance l ins gs hs alpha -> alpha i j ->
  (redex_of (cfg_at gs i) = Some (Cassume l' tk (Ragr e)) \/
   redex_of (cfg_at gs i) = Some (Cassert l' tk (Ragr e))) ->
  lleq l' l ->
  eval_expr (cfg_state (cfg_at gs i)) e = eval_expr (cfg_state (cfg_at hs j)) e.
Proof.
  intros l ins gs hs alpha i j l' tk e Hconf Haij Hred Hle.
  destruct Hconf as [_ [_ [_ [Hmod _]]]].
  pose proof (Hmod i j l' tk (Ragr e) Haij Hred Hle) as Hm.
  simpl in Hm. exact Hm.
Qed.

(* Reverse rank correspondence: when both runs are covered they have equally many
   l-annotations (equal_count), so the n-th minor annotation is matched by an
   n-th major annotation, aligned and with the same command. *)
Lemma minor_major_rank : forall l gs hs alpha n j,
  l_aligned_pair l gs hs alpha -> covers_dom gs alpha -> covers_rng hs alpha ->
  is_nth_annot l hs n j ->
  exists i, alpha i j /\ is_nth_annot l gs n i /\
            cfg_cmd (cfg_at gs i) = cfg_cmd (cfg_at hs j).
Proof.
  intros l gs hs alpha n j Hlap Hcd Hcr Hnthj.
  pose proof (equal_count l gs hs alpha Hlap Hcd Hcr) as Heq.
  pose proof Hnthj as [Hjlt [Hannj Hcntj]].
  assert (Hnlt : n < annot_count l gs (length gs)).
  { rewrite Heq. rewrite <- Hcntj.
    assert (HS : annot_count l hs (S j) = S (annot_count l hs j))
      by (apply annot_count_annot_S; exact Hannj).
    assert (Hmono : annot_count l hs (S j) <= annot_count l hs (length hs))
      by (apply annot_count_mono; lia).
    lia. }
  destruct (annot_count_gives_nth l gs n (length gs) Hnlt) as [i [Hilt Hnthi]].
  destruct (major_minor_rank l gs hs alpha n i Hlap Hcd Hcr Hnthi) as [j' [Haij' [Hnthj' Hcmd]]].
  assert (Hjj : j' = j) by (apply (is_nth_annot_unique l hs n j' j Hnthj' Hnthj)).
  subst j'. exists i. split; [exact Haij' | split; [exact Hnthi | exact Hcmd]].
Qed.

(* covers_rng-ONLY analogue of minor_major_rank: a minor (es) annotation of rank
   [r] is matched by a major (ds) annotation of the SAME rank [r], aligned and
   with the same command -- WITHOUT covers_dom ds.  The injectivity/rank-fidelity
   that covers_dom bought (via equal_count) comes here from annot_align_rank,
   which needs only covers_rng.  Used in the receptive branch of the conformance
   case, where covers_dom of the major fails. *)
Lemma minor_major_rank_rng : forall l ds es alpha r j,
  l_aligned_pair l ds es alpha -> covers_rng es alpha ->
  is_nth_annot l es r j ->
  exists i, alpha i j /\ is_nth_annot l ds r i /\
            cfg_cmd (cfg_at ds i) = cfg_cmd (cfg_at es j).
Proof.
  intros l ds es alpha r j Hlap Hcr Hnthj.
  pose proof Hlap as [Hpd [Hpe Hproper]].
  pose proof Hnthj as [Hjlt [Hannj Hcntj]].
  destruct (Hcr j Hjlt) as [i Haij].
  pose proof (proper_annot_rev l ds es alpha i j Hproper Haij Hannj) as Hanni.
(*  pose proof (aligned_annot_same_cmd_hyp l ds es alpha i j Hproper Haij Hanni) as Hcmd. *)
  pose proof (aligned_annot_same_cmd l ds es alpha i j Hlap Haij Hanni) as Hcmd. 
  assert (Hilt : i < length ds)
    by (destruct Hproper as [[Hbound _] _]; exact (proj1 (Hbound i j Haij))).
  set (n := annot_count l ds i) in *.
  assert (Hnthi : is_nth_annot l ds n i)
    by (unfold is_nth_annot, n; split; [exact Hilt | split; [exact Hanni | reflexivity]]).
  pose proof (annot_align_rank l ds es alpha n i j Hlap Hcr Hnthi Haij) as [_ [_ Hcntj']].
  assert (Hnr : n = r)
    by (transitivity (annot_count l es j); [symmetry; exact Hcntj' | exact Hcntj]).
  rewrite Hnr in Hnthi.
  exists i. split; [exact Haij | split; [exact Hnthi | exact Hcmd]].
Qed.

(* From covers_rng alone, the major has at least as many l-annotations as the
   minor (each minor annotation is matched, rank-preserving, by minor_major_rank_rng). *)
Lemma annot_count_le_rng : forall l ds es alpha,
  l_aligned_pair l ds es alpha -> covers_rng es alpha ->
  annot_count l es (length es) <= annot_count l ds (length ds).
Proof.
  intros l ds es alpha Hlap Hcr.
  destruct (Nat.eq_dec (annot_count l es (length es)) 0) as [H0 | Hpos].
  - rewrite H0. lia.
  - set (Ce := annot_count l es (length es)) in *.
    assert (Hlt : Ce - 1 < Ce) by lia.
    destruct (annot_count_gives_nth l es (Ce - 1) (length es) Hlt) as [j [_ Hnthj]].
    destruct (minor_major_rank_rng l ds es alpha (Ce - 1) j Hlap Hcr Hnthj)
      as [i [_ [[Hilt [Hanni Hcnti]] _]]].
    pose proof (annot_count_annot_S l ds i Hanni) as HS.
    pose proof (annot_count_mono l ds (S i) (length ds) ltac:(lia)) as Hm.
    lia.
Qed.

(* Cross-run INPUT realization: a config whose command is a full handler body
   [h_body (prog l')] was reached by consuming the corresponding l'-input
   (handler_entry_dispatched), so when l' is l-visible the run exposes that input
   at the receptive position i-1. Used on the major ds at a rank-matched
   entry-assume (its command is h_body by aligned_annot_same_cmd_hyp). *)
Lemma input_realize_ds : forall l ds tds i l' sb,
  admits_trace ds tds ->
  cfg_at ds i = Active (h_body (prog l')) sb ->
  i < length ds -> lleq l' l ->
  vis_at l ds (i - 1) = Some (Ein l' (eval_expr sb (EVar (h_var (prog l'))))).
Proof.
  intros l ds tds i l' sb Hat Hcfg Hilt Hle.
  destruct (handler_entry_dispatched_lem ds tds i l' sb Hat Hilt Hcfg) as [Hipos Hnth].
  pose proof (admits_trace_length ds tds Hat) as Hlen.
  assert (Hi1 : i - 1 < length tds) by lia.
  pose proof (vis_at_complete l ds tds (i - 1) Hat Hi1) as Hcomp.
  rewrite Hnth in Hcomp.
  assert (Hvev : Vev l (Ein l' (eval_expr sb (EVar (h_var (prog l')))))).
  { left. exists l', (eval_expr sb (EVar (h_var (prog l')))).
    split; [reflexivity | exact Hle]. }
  exact (Hcomp Hvev).
Qed.

(* An output-redex config of ds at a visible level fires vis_at there. *)
Lemma vis_at_out_some : forall l gs q l' e,
  redex_of (cfg_at gs q) = Some (Cout l' e) -> lleq l' l ->
  vis_at l gs q = Some (Eout l' (eval_expr (cfg_state (cfg_at gs q)) e)).
Proof.
  intros l gs q l' e Hred Hle.
  destruct (cfg_at gs q) as [sr | c s] eqn:Hc; simpl in Hred; [discriminate |].
  injection Hred as Hrc. unfold vis_at. rewrite Hc, Hrc. simpl.
  destruct (lleq_dec l' l) as [|Hn]; [reflexivity | contradiction].
Qed.

(* A config whose redex is a low output is l-visible (vis_at fires). *)
Lemma l_output_vis_at_some : forall l gs q,
  redex_is_l_output l (cfg_at gs q) -> vis_at l gs q <> None.
Proof.
  intros l gs q H. unfold redex_is_l_output in H.
  destruct (redex_of (cfg_at gs q)) as [c | ] eqn:Hred; [| contradiction].
  destruct c as [ | xa ea | l' e | ea ca cb | ea ca | ca cb | la ta Pa | la ta Pa ]; try contradiction.
  rewrite (vis_at_out_some l gs q l' e Hred H). discriminate.
Qed.

(* Membership in the list of vis_at-firing trace positions. *)
Lemma in_filter_seq_isSome : forall (A : Type) (h : nat -> option A) N q,
  In q (filter (fun p => match h p with Some _ => true | None => false end) (seq 0 N)) <->
  (q < N /\ exists a, h q = Some a).
Proof.
  intros A h N q. rewrite filter_In, in_seq. split.
  - intros [[_ Hlt] Hb]. split; [lia | destruct (h q); [eexists; reflexivity | discriminate]].
  - intros [Hlt [a Ha]]. split; [split; [lia | exact Hlt] | rewrite Ha; reflexivity].
Qed.

(* An l-visible OUTPUT of the minor es at position p is realized by the major ds:
   its rank-r paired assert matches (same command) ds's rank-r annotation at
   i := annot_idx ds r, and ds reaches the SAME output at i+2, which is a genuine
   trace position of ds (i+2 < length tM). The trace-position bound is the crux:
   r is not the top rank (es's last config is an annotation, so the assert at p-2
   has rank below it), hence ds has a rank-(r+1) annotation strictly after the
   output configs i+1 (Cskip) and i+2 (Cout) -- neither an annotation -- so
   i+2 < that annotation index < length ds. *)
Lemma out_maps_into : forall l ds es alpha tM tf p l' n,
  l_aligned_pair l ds es alpha -> covers_dom ds alpha -> covers_rng es alpha ->
  admits_trace ds tM -> admits_trace es tf ->
  redex_is_l_annotation l (cfg_at es (length es - 1)) ->
  p < length tf -> vis_at l es p = Some (Eout l' n) ->
  S (S (annot_idx l ds (annot_count l es (p - 2)))) < length tM /\
  (exists m, vis_at l ds (S (S (annot_idx l ds (annot_count l es (p - 2))))) = Some (Eout l' m)).
Proof.
  intros l ds es alpha tM tf p l' n Hlap Hcd Hcr HatM Hatf Heslast Hp Hvis.
  assert (Hpd : pre_run ds) by (destruct Hlap as [H _]; exact H).
  assert (Hpe : pre_run es) by (destruct Hlap as [_ [H _]]; exact H).
  pose proof (admits_trace_length ds tM HatM) as HdM.
  pose proof (admits_trace_length es tf Hatf) as HeM.
  destruct (vis_at_sound l es tf p (Eout l' n) Hatf Hp Hvis) as [Hnthp Hvev].
  assert (Hle : lleq l' l).
  { destruct Hvev as [Hin | Hout].
    - destruct Hin as [l0 [n0 [Heq _]]]; discriminate Heq.
    - destruct Hout as [l2 [n2 [Heq Hl2]]]; injection Heq as Hl Hnn; subst l2; exact Hl2. }
  destruct (trace_output_cfg es tf p l' n Hatf Hp Hnthp) as [cc [s [e [Hcfgp [Hredcc Hn]]]]].
  assert (Hples : p < length es) by lia.
  destruct (prerun_output_pair_struct es p cc s l' e Hpe Hples Hcfgp Hredcc)
    as [cq [cp [tq2 [Hp2 [Hesq [Hredq [Hesp1 Hredp]]]]]]].
  assert (Hannp2 : redex_is_l_annotation l (cfg_at es (p - 2))).
  { unfold redex_is_l_annotation. rewrite Hesq. simpl. rewrite Hredq.
    unfold is_l_annotation. right. simpl. exact Hle. }
  set (r := annot_count l es (p - 2)) in *.
  assert (Hp2lt : p - 2 < length es) by lia.
  assert (Hnth_es : is_nth_annot l es r (p - 2))
    by (unfold is_nth_annot, r; split; [exact Hp2lt | split; [exact Hannp2 | reflexivity]]).
  destruct (minor_major_rank l ds es alpha r (p - 2) Hlap Hcd Hcr Hnth_es)
    as [i [Haip [Hnth_ds Hcmdeq]]].
  assert (HrC : r < annot_count l ds (length ds)).
  { destruct Hnth_ds as [Hilt [Hannds Hcnt]].
    pose proof (annot_count_annot_S l ds i Hannds) as HS.
    pose proof (annot_count_mono l ds (S i) (length ds) ltac:(lia)) as Hm. lia. }
  assert (Hidx : i = annot_idx l ds r)
    by (apply (is_nth_annot_unique l ds r i (annot_idx l ds r) Hnth_ds (annot_idx_is_nth l ds r HrC))).
  rewrite <- Hidx.
  destruct Hnth_ds as [Hilt [Hannds Hcnt]].
  (* next rank exists: r is not the top rank because es's last config is annot *)
  assert (Heq_count : annot_count l ds (length ds) = annot_count l es (length es))
    by (apply (equal_count l ds es alpha Hlap Hcd Hcr)).
  assert (HesC : annot_count l es (length es) = S (annot_count l es (length es - 1))).
  { replace (length es) with (S (length es - 1)) at 1 by lia.
    apply (annot_count_annot_S l es (length es - 1) Heslast). }
  assert (Hmono : S r <= annot_count l es (length es - 1)).
  { unfold r. rewrite <- (annot_count_annot_S l es (p - 2) Hannp2).
    apply (annot_count_mono l es (S (p - 2)) (length es - 1)); lia. }
  assert (Hr1C : S r < annot_count l ds (length ds)) by lia.
  destruct (annot_idx_is_nth l ds (S r) Hr1C) as [Hi'lt [Hanni' Hcnti']].
  set (i' := annot_idx l ds (S r)) in *.
  assert (Hi'gt : i < i').
  { destruct (Nat.le_gt_cases i' i) as [Hle' | Hgt]; [| exact Hgt].
    pose proof (annot_count_mono l ds i' i Hle') as Hm.
    rewrite Hcnti', Hcnt in Hm. lia. }
  assert (HnSi : ~ redex_is_l_annotation l (cfg_at ds (S i)))
    by (intro H; exact (no_adj_annot l ds i Hpd H Hannds)).
  assert (Hi'neSi : i' <> S i) by (intro He; rewrite He in Hanni'; contradiction).
  assert (HSSi_ds : S (S i) < length ds) by lia.
  destruct (output_realize_cross ds es i p cc s l' e Hpd Hpe Hcfgp Hredcc Hples Hcmdeq HSSi_ds)
    as [Hpost Hout].
  assert (HnSSi : ~ redex_is_l_annotation l (cfg_at ds (S (S i)))).
  { unfold redex_is_l_annotation. rewrite Hout. simpl. unfold is_l_annotation. tauto. }
  assert (Hi'neSSi : i' <> S (S i)) by (intro He; rewrite He in Hanni'; contradiction).
  split.
  - lia.
  - exists (eval_expr (cfg_state (cfg_at ds (S (S i)))) e).
    apply (vis_at_out_some l ds (S (S i)) l' e Hout Hle).
Qed.

(* An l-visible INPUT of the minor es at position p is realized by the major ds:
   its entry-assume (at S p, command h_body l') matches ds's rank-r annotation at
   i := annot_idx ds r, whose command is therefore that handler body, reached by
   dispatching the l'-input -- so ds exposes the input at i-1 (a genuine trace
   position, since 0 < i < length ds). No truncation subtlety (inputs are
   realized at the dispatch step, always within the run). *)
Lemma in_maps_into : forall l ds es alpha tM tf p l' n,
  l_aligned_pair l ds es alpha -> covers_dom ds alpha -> covers_rng es alpha ->
  admits_trace ds tM -> admits_trace es tf ->
  p < length tf -> vis_at l es p = Some (Ein l' n) ->
  annot_idx l ds (annot_count l es (S p)) - 1 < length tM /\
  (exists m, vis_at l ds (annot_idx l ds (annot_count l es (S p)) - 1) = Some (Ein l' m)).
Proof.
  intros l ds es alpha tM tf p l' n Hlap Hcd Hcr HatM Hatf Hp Hvis.
  assert (Hpd : pre_run ds) by (destruct Hlap as [H _]; exact H).
  assert (Hpe : pre_run es) by (destruct Hlap as [_ [H _]]; exact H).
  pose proof (admits_trace_length ds tM HatM) as HdM.
  destruct (vis_at_sound l es tf p (Ein l' n) Hatf Hp Hvis) as [Hnthp Hvev].
  assert (Hle : lleq l' l).
  { destruct Hvev as [Hin | Hout].
    - destruct Hin as [l2 [n2 [Heq Hl2]]]; injection Heq as Hl Hnn; subst l2; exact Hl2.
    - destruct Hout as [l0 [n0 [Heq _]]]; discriminate Heq. }
  destruct (trace_input_cfg es tf p l' n Hatf Hp Hnthp) as [s [Hcfgp HcfgSp]].
  destruct (prog_well_specified l') as [wtag [d [Hwb Hd]]].
  assert (HannSp : redex_is_l_annotation l (cfg_at es (S p))).
  { unfold redex_is_l_annotation. rewrite HcfgSp. simpl. rewrite Hwb. simpl.
    unfold is_l_annotation. left. simpl. exact Hle. }
  assert (HSplt : S p < length es)
    by (apply (cfg_at_active_lt es (S p) (h_body (prog l')) _ HcfgSp)).
  set (r := annot_count l es (S p)) in *.
  assert (Hnth_es : is_nth_annot l es r (S p))
    by (unfold is_nth_annot, r; split; [exact HSplt | split; [exact HannSp | reflexivity]]).
  destruct (minor_major_rank l ds es alpha r (S p) Hlap Hcd Hcr Hnth_es)
    as [i [Haip [Hnth_ds Hcmdeq]]].
  assert (HrC : r < annot_count l ds (length ds)).
  { destruct Hnth_ds as [Hilt [Hannds Hcnt]].
    pose proof (annot_count_annot_S l ds i Hannds) as HS.
    pose proof (annot_count_mono l ds (S i) (length ds) ltac:(lia)) as Hm. lia. }
  assert (Hidx : i = annot_idx l ds r)
    by (apply (is_nth_annot_unique l ds r i (annot_idx l ds r) Hnth_ds (annot_idx_is_nth l ds r HrC))).
  rewrite <- Hidx.
  destruct Hnth_ds as [Hilt [Hannds Hcnt]].
  rewrite HcfgSp in Hcmdeq. simpl in Hcmdeq.
  destruct (cfg_at ds i) as [sr | dci dsi] eqn:Hdci; [discriminate Hcmdeq |].
  simpl in Hcmdeq. injection Hcmdeq as Hdcicq. subst dci.
  pose proof (input_realize_ds l ds tM i l' dsi HatM Hdci Hilt Hle) as Hvisi.
  destruct (handler_entry_dispatched_lem ds tM i l' dsi HatM Hilt Hdci) as [Hipos _].
  split.
  - lia.
  - exists (eval_expr dsi (EVar (h_var (prog l')))). exact Hvisi.
Qed.

(* covers_rng-ONLY versions of out_maps_into / in_maps_into: the minor's visible
   event maps to a genuine major visible position, using minor_major_rank_rng
   (no covers_dom) and annot_count_le_rng for the "next rank exists" bound. *)
Lemma out_maps_into_rng : forall l ds es alpha tM tf p l' n,
  l_aligned_pair l ds es alpha -> covers_rng es alpha ->
  admits_trace ds tM -> admits_trace es tf ->
  redex_is_l_annotation l (cfg_at es (length es - 1)) ->
  p < length tf -> vis_at l es p = Some (Eout l' n) ->
  S (S (annot_idx l ds (annot_count l es (p - 2)))) < length tM /\
  (exists m, vis_at l ds (S (S (annot_idx l ds (annot_count l es (p - 2))))) = Some (Eout l' m)).
Proof.
  intros l ds es alpha tM tf p l' n Hlap Hcr HatM Hatf Heslast Hp Hvis.
  assert (Hpd : pre_run ds) by (destruct Hlap as [H _]; exact H).
  assert (Hpe : pre_run es) by (destruct Hlap as [_ [H _]]; exact H).
  pose proof (admits_trace_length ds tM HatM) as HdM.
  pose proof (admits_trace_length es tf Hatf) as HeM.
  destruct (vis_at_sound l es tf p (Eout l' n) Hatf Hp Hvis) as [Hnthp Hvev].
  assert (Hle : lleq l' l).
  { destruct Hvev as [Hin | Hout].
    - destruct Hin as [l0 [n0 [Heq _]]]; discriminate Heq.
    - destruct Hout as [l2 [n2 [Heq Hl2]]]; injection Heq as Hl Hnn; subst l2; exact Hl2. }
  destruct (trace_output_cfg es tf p l' n Hatf Hp Hnthp) as [cc [s [e [Hcfgp [Hredcc Hn]]]]].
  assert (Hples : p < length es) by lia.
  destruct (prerun_output_pair_struct es p cc s l' e Hpe Hples Hcfgp Hredcc)
    as [cq [cp [tq3 [Hp2 [Hesq [Hredq [Hesp1 Hredp]]]]]]].
  assert (Hannp2 : redex_is_l_annotation l (cfg_at es (p - 2))).
  { unfold redex_is_l_annotation. rewrite Hesq. simpl. rewrite Hredq.
    unfold is_l_annotation. right. simpl. exact Hle. }
  set (r := annot_count l es (p - 2)) in *.
  assert (Hp2lt : p - 2 < length es) by lia.
  assert (Hnth_es : is_nth_annot l es r (p - 2))
    by (unfold is_nth_annot, r; split; [exact Hp2lt | split; [exact Hannp2 | reflexivity]]).
  destruct (minor_major_rank_rng l ds es alpha r (p - 2) Hlap Hcr Hnth_es)
    as [i [Haip [Hnth_ds Hcmdeq]]].
  assert (HrC : r < annot_count l ds (length ds)).
  { destruct Hnth_ds as [Hilt [Hannds Hcnt]].
    pose proof (annot_count_annot_S l ds i Hannds) as HS.
    pose proof (annot_count_mono l ds (S i) (length ds) ltac:(lia)) as Hm. lia. }
  assert (Hidx : i = annot_idx l ds r)
    by (apply (is_nth_annot_unique l ds r i (annot_idx l ds r) Hnth_ds (annot_idx_is_nth l ds r HrC))).
  rewrite <- Hidx.
  destruct Hnth_ds as [Hilt [Hannds Hcnt]].
  assert (Hle_count : annot_count l es (length es) <= annot_count l ds (length ds))
    by (apply (annot_count_le_rng l ds es alpha Hlap Hcr)).
  assert (HesC : annot_count l es (length es) = S (annot_count l es (length es - 1))).
  { replace (length es) with (S (length es - 1)) at 1 by lia.
    apply (annot_count_annot_S l es (length es - 1) Heslast). }
  assert (Hmono : S r <= annot_count l es (length es - 1)).
  { unfold r. rewrite <- (annot_count_annot_S l es (p - 2) Hannp2).
    apply (annot_count_mono l es (S (p - 2)) (length es - 1)); lia. }
  assert (Hr1C : S r < annot_count l ds (length ds)) by lia.
  destruct (annot_idx_is_nth l ds (S r) Hr1C) as [Hi'lt [Hanni' Hcnti']].
  set (i' := annot_idx l ds (S r)) in *.
  assert (Hi'gt : i < i').
  { destruct (Nat.le_gt_cases i' i) as [Hle' | Hgt]; [| exact Hgt].
    pose proof (annot_count_mono l ds i' i Hle') as Hm.
    rewrite Hcnti', Hcnt in Hm. lia. }
  assert (HnSi : ~ redex_is_l_annotation l (cfg_at ds (S i)))
    by (intro H; exact (no_adj_annot l ds i Hpd H Hannds)).
  assert (Hi'neSi : i' <> S i) by (intro He; rewrite He in Hanni'; contradiction).
  assert (HSSi_ds : S (S i) < length ds) by lia.
  destruct (output_realize_cross ds es i p cc s l' e Hpd Hpe Hcfgp Hredcc Hples Hcmdeq HSSi_ds)
    as [Hpost Hout].
  assert (HnSSi : ~ redex_is_l_annotation l (cfg_at ds (S (S i)))).
  { unfold redex_is_l_annotation. rewrite Hout. simpl. unfold is_l_annotation. tauto. }
  assert (Hi'neSSi : i' <> S (S i)) by (intro He; rewrite He in Hanni'; contradiction).
  split.
  - lia.
  - exists (eval_expr (cfg_state (cfg_at ds (S (S i)))) e).
    apply (vis_at_out_some l ds (S (S i)) l' e Hout Hle).
Qed.

(* Variant of out_maps_into_rng whose realization comes from a LOCAL "next rank
   exists" bound [S r < count_ds] instead of either es-ends-in-annotation or a
   global strict count.  Used in the no-gap argument, where an es output of rank
   r is realized in ds because ds has an annotation of some rank > r. *)
Lemma out_maps_into_local : forall l ds es alpha tM tf p l' n,
  l_aligned_pair l ds es alpha -> covers_rng es alpha ->
  admits_trace ds tM -> admits_trace es tf ->
  S (annot_count l es (p - 2)) < annot_count l ds (length ds) ->
  p < length tf -> vis_at l es p = Some (Eout l' n) ->
  S (S (annot_idx l ds (annot_count l es (p - 2)))) < length tM /\
  (exists m, vis_at l ds (S (S (annot_idx l ds (annot_count l es (p - 2))))) = Some (Eout l' m)).
Proof.
  intros l ds es alpha tM tf p l' n Hlap Hcr HatM Hatf Hr1Cin Hp Hvis.
  assert (Hpd : pre_run ds) by (destruct Hlap as [H _]; exact H).
  assert (Hpe : pre_run es) by (destruct Hlap as [_ [H _]]; exact H).
  pose proof (admits_trace_length ds tM HatM) as HdM.
  pose proof (admits_trace_length es tf Hatf) as HeM.
  destruct (vis_at_sound l es tf p (Eout l' n) Hatf Hp Hvis) as [Hnthp Hvev].
  assert (Hle : lleq l' l).
  { destruct Hvev as [Hin | Hout].
    - destruct Hin as [l0 [n0 [Heq _]]]; discriminate Heq.
    - destruct Hout as [l2 [n2 [Heq Hl2]]]; injection Heq as Hl Hnn; subst l2; exact Hl2. }
  destruct (trace_output_cfg es tf p l' n Hatf Hp Hnthp) as [cc [s [e [Hcfgp [Hredcc Hn]]]]].
  assert (Hples : p < length es) by lia.
  destruct (prerun_output_pair_struct es p cc s l' e Hpe Hples Hcfgp Hredcc)
    as [cq [cp [tq4 [Hp2 [Hesq [Hredq [Hesp1 Hredp]]]]]]].
  assert (Hannp2 : redex_is_l_annotation l (cfg_at es (p - 2))).
  { unfold redex_is_l_annotation. rewrite Hesq. simpl. rewrite Hredq.
    unfold is_l_annotation. right. simpl. exact Hle. }
  set (r := annot_count l es (p - 2)) in *.
  assert (Hp2lt : p - 2 < length es) by lia.
  assert (Hnth_es : is_nth_annot l es r (p - 2))
    by (unfold is_nth_annot, r; split; [exact Hp2lt | split; [exact Hannp2 | reflexivity]]).
  destruct (minor_major_rank_rng l ds es alpha r (p - 2) Hlap Hcr Hnth_es)
    as [i [Haip [Hnth_ds Hcmdeq]]].
  assert (HrC : r < annot_count l ds (length ds)).
  { destruct Hnth_ds as [Hilt [Hannds Hcnt]].
    pose proof (annot_count_annot_S l ds i Hannds) as HS.
    pose proof (annot_count_mono l ds (S i) (length ds) ltac:(lia)) as Hm. lia. }
  assert (Hidx : i = annot_idx l ds r)
    by (apply (is_nth_annot_unique l ds r i (annot_idx l ds r) Hnth_ds (annot_idx_is_nth l ds r HrC))).
  rewrite <- Hidx.
  destruct Hnth_ds as [Hilt [Hannds Hcnt]].
  assert (Hr1C : S r < annot_count l ds (length ds)) by (unfold r in *; exact Hr1Cin).
  destruct (annot_idx_is_nth l ds (S r) Hr1C) as [Hi'lt [Hanni' Hcnti']].
  set (i' := annot_idx l ds (S r)) in *.
  assert (Hi'gt : i < i').
  { destruct (Nat.le_gt_cases i' i) as [Hle' | Hgt]; [| exact Hgt].
    pose proof (annot_count_mono l ds i' i Hle') as Hm.
    rewrite Hcnti', Hcnt in Hm. lia. }
  assert (HnSi : ~ redex_is_l_annotation l (cfg_at ds (S i)))
    by (intro H; exact (no_adj_annot l ds i Hpd H Hannds)).
  assert (Hi'neSi : i' <> S i) by (intro He; rewrite He in Hanni'; contradiction).
  assert (HSSi_ds : S (S i) < length ds) by lia.
  destruct (output_realize_cross ds es i p cc s l' e Hpd Hpe Hcfgp Hredcc Hples Hcmdeq HSSi_ds)
    as [Hpost Hout].
  assert (HnSSi : ~ redex_is_l_annotation l (cfg_at ds (S (S i)))).
  { unfold redex_is_l_annotation. rewrite Hout. simpl. unfold is_l_annotation. tauto. }
  assert (Hi'neSSi : i' <> S (S i)) by (intro He; rewrite He in Hanni'; contradiction).
  split.
  - lia.
  - exists (eval_expr (cfg_state (cfg_at ds (S (S i)))) e).
    apply (vis_at_out_some l ds (S (S i)) l' e Hout Hle).
Qed.

(* Variant of out_maps_into_rng with the es-ends-in-annotation hypothesis
   replaced by a STRICT annotation-count inequality.  This drops the requirement
   that es end at an annotation (so it applies when es ends receptive), at the
   cost of knowing the major has strictly more annotations -- exactly the
   situation in the receptive branch when t's assert is uncovered. *)
Lemma out_maps_into_strict : forall l ds es alpha tM tf p l' n,
  l_aligned_pair l ds es alpha -> covers_rng es alpha ->
  admits_trace ds tM -> admits_trace es tf ->
  annot_count l es (length es) < annot_count l ds (length ds) ->
  p < length tf -> vis_at l es p = Some (Eout l' n) ->
  S (S (annot_idx l ds (annot_count l es (p - 2)))) < length tM /\
  (exists m, vis_at l ds (S (S (annot_idx l ds (annot_count l es (p - 2))))) = Some (Eout l' m)).
Proof.
  intros l ds es alpha tM tf p l' n Hlap Hcr HatM Hatf Hstrict Hp Hvis.
  assert (Hpd : pre_run ds) by (destruct Hlap as [H _]; exact H).
  assert (Hpe : pre_run es) by (destruct Hlap as [_ [H _]]; exact H).
  pose proof (admits_trace_length ds tM HatM) as HdM.
  pose proof (admits_trace_length es tf Hatf) as HeM.
  destruct (vis_at_sound l es tf p (Eout l' n) Hatf Hp Hvis) as [Hnthp Hvev].
  assert (Hle : lleq l' l).
  { destruct Hvev as [Hin | Hout].
    - destruct Hin as [l0 [n0 [Heq _]]]; discriminate Heq.
    - destruct Hout as [l2 [n2 [Heq Hl2]]]; injection Heq as Hl Hnn; subst l2; exact Hl2. }
  destruct (trace_output_cfg es tf p l' n Hatf Hp Hnthp) as [cc [s [e [Hcfgp [Hredcc Hn]]]]].
  assert (Hples : p < length es) by lia.
  destruct (prerun_output_pair_struct es p cc s l' e Hpe Hples Hcfgp Hredcc)
    as [cq [cp [tq5 [Hp2 [Hesq [Hredq [Hesp1 Hredp]]]]]]].
  assert (Hannp2 : redex_is_l_annotation l (cfg_at es (p - 2))).
  { unfold redex_is_l_annotation. rewrite Hesq. simpl. rewrite Hredq.
    unfold is_l_annotation. right. simpl. exact Hle. }
  set (r := annot_count l es (p - 2)) in *.
  assert (Hp2lt : p - 2 < length es) by lia.
  assert (Hnth_es : is_nth_annot l es r (p - 2))
    by (unfold is_nth_annot, r; split; [exact Hp2lt | split; [exact Hannp2 | reflexivity]]).
  destruct (minor_major_rank_rng l ds es alpha r (p - 2) Hlap Hcr Hnth_es)
    as [i [Haip [Hnth_ds Hcmdeq]]].
  assert (HrC : r < annot_count l ds (length ds)).
  { destruct Hnth_ds as [Hilt [Hannds Hcnt]].
    pose proof (annot_count_annot_S l ds i Hannds) as HS.
    pose proof (annot_count_mono l ds (S i) (length ds) ltac:(lia)) as Hm. lia. }
  assert (Hidx : i = annot_idx l ds r)
    by (apply (is_nth_annot_unique l ds r i (annot_idx l ds r) Hnth_ds (annot_idx_is_nth l ds r HrC))).
  rewrite <- Hidx.
  destruct Hnth_ds as [Hilt [Hannds Hcnt]].
  assert (Hrlt : r < annot_count l es (length es)).
  { unfold r. pose proof (annot_count_annot_S l es (p - 2) Hannp2) as HSr.
    pose proof (annot_count_mono l es (S (p - 2)) (length es) ltac:(lia)) as Hmr. lia. }
  assert (Hr1C : S r < annot_count l ds (length ds)) by lia.
  destruct (annot_idx_is_nth l ds (S r) Hr1C) as [Hi'lt [Hanni' Hcnti']].
  set (i' := annot_idx l ds (S r)) in *.
  assert (Hi'gt : i < i').
  { destruct (Nat.le_gt_cases i' i) as [Hle' | Hgt]; [| exact Hgt].
    pose proof (annot_count_mono l ds i' i Hle') as Hm.
    rewrite Hcnti', Hcnt in Hm. lia. }
  assert (HnSi : ~ redex_is_l_annotation l (cfg_at ds (S i)))
    by (intro H; exact (no_adj_annot l ds i Hpd H Hannds)).
  assert (Hi'neSi : i' <> S i) by (intro He; rewrite He in Hanni'; contradiction).
  assert (HSSi_ds : S (S i) < length ds) by lia.
  destruct (output_realize_cross ds es i p cc s l' e Hpd Hpe Hcfgp Hredcc Hples Hcmdeq HSSi_ds)
    as [Hpost Hout].
  assert (HnSSi : ~ redex_is_l_annotation l (cfg_at ds (S (S i)))).
  { unfold redex_is_l_annotation. rewrite Hout. simpl. unfold is_l_annotation. tauto. }
  assert (Hi'neSSi : i' <> S (S i)) by (intro He; rewrite He in Hanni'; contradiction).
  split.
  - lia.
  - exists (eval_expr (cfg_state (cfg_at ds (S (S i)))) e).
    apply (vis_at_out_some l ds (S (S i)) l' e Hout Hle).
Qed.

Lemma in_maps_into_rng : forall l ds es alpha tM tf p l' n,
  l_aligned_pair l ds es alpha -> covers_rng es alpha ->
  admits_trace ds tM -> admits_trace es tf ->
  p < length tf -> vis_at l es p = Some (Ein l' n) ->
  annot_idx l ds (annot_count l es (S p)) - 1 < length tM /\
  (exists m, vis_at l ds (annot_idx l ds (annot_count l es (S p)) - 1) = Some (Ein l' m)).
Proof.
  intros l ds es alpha tM tf p l' n Hlap Hcr HatM Hatf Hp Hvis.
  assert (Hpd : pre_run ds) by (destruct Hlap as [H _]; exact H).
  assert (Hpe : pre_run es) by (destruct Hlap as [_ [H _]]; exact H).
  pose proof (admits_trace_length ds tM HatM) as HdM.
  destruct (vis_at_sound l es tf p (Ein l' n) Hatf Hp Hvis) as [Hnthp Hvev].
  assert (Hle : lleq l' l).
  { destruct Hvev as [Hin | Hout].
    - destruct Hin as [l2 [n2 [Heq Hl2]]]; injection Heq as Hl Hnn; subst l2; exact Hl2.
    - destruct Hout as [l0 [n0 [Heq _]]]; discriminate Heq. }
  destruct (trace_input_cfg es tf p l' n Hatf Hp Hnthp) as [s [Hcfgp HcfgSp]].
  destruct (prog_well_specified l') as [wtag [d [Hwb Hd]]].
  assert (HannSp : redex_is_l_annotation l (cfg_at es (S p))).
  { unfold redex_is_l_annotation. rewrite HcfgSp. simpl. rewrite Hwb. simpl.
    unfold is_l_annotation. left. simpl. exact Hle. }
  assert (HSplt : S p < length es)
    by (apply (cfg_at_active_lt es (S p) (h_body (prog l')) _ HcfgSp)).
  set (r := annot_count l es (S p)) in *.
  assert (Hnth_es : is_nth_annot l es r (S p))
    by (unfold is_nth_annot, r; split; [exact HSplt | split; [exact HannSp | reflexivity]]).
  destruct (minor_major_rank_rng l ds es alpha r (S p) Hlap Hcr Hnth_es)
    as [i [Haip [Hnth_ds Hcmdeq]]].
  assert (HrC : r < annot_count l ds (length ds)).
  { destruct Hnth_ds as [Hilt [Hannds Hcnt]].
    pose proof (annot_count_annot_S l ds i Hannds) as HS.
    pose proof (annot_count_mono l ds (S i) (length ds) ltac:(lia)) as Hm. lia. }
  assert (Hidx : i = annot_idx l ds r)
    by (apply (is_nth_annot_unique l ds r i (annot_idx l ds r) Hnth_ds (annot_idx_is_nth l ds r HrC))).
  rewrite <- Hidx.
  destruct Hnth_ds as [Hilt [Hannds Hcnt]].
  rewrite HcfgSp in Hcmdeq. simpl in Hcmdeq.
  destruct (cfg_at ds i) as [sr | dci dsi] eqn:Hdci; [discriminate Hcmdeq |].
  simpl in Hcmdeq. injection Hcmdeq as Hdcicq. subst dci.
  pose proof (input_realize_ds l ds tM i l' dsi HatM Hdci Hilt Hle) as Hvisi.
  destruct (handler_entry_dispatched_lem ds tM i l' dsi HatM Hilt Hdci) as [Hipos _].
  split.
  - lia.
  - exists (eval_expr dsi (EVar (h_var (prog l')))). exact Hvisi.
Qed.

(* annot_idx is injective on valid ranks. *)
Lemma annot_idx_inj : forall l gs r1 r2,
  r1 < annot_count l gs (length gs) -> r2 < annot_count l gs (length gs) ->
  annot_idx l gs r1 = annot_idx l gs r2 -> r1 = r2.
Proof.
  intros l gs r1 r2 H1 H2 Heq.
  destruct (annot_idx_is_nth l gs r1 H1) as [_ [_ Hc1]].
  destruct (annot_idx_is_nth l gs r2 H2) as [_ [_ Hc2]].
  congruence.
Qed.

(* An annotation index is positive (config 0 is the initial receptive config). *)
Lemma annot_idx_pos : forall l gs r,
  pre_run gs -> r < annot_count l gs (length gs) -> 1 <= annot_idx l gs r.
Proof.
  intros l gs r Hpre Hr. destruct (annot_idx_is_nth l gs r Hr) as [_ [Hann _]].
  destruct (Nat.eq_dec (annot_idx l gs r) 0) as [He | Hne]; [| lia].
  exfalso. rewrite He, (prerun_head gs Hpre) in Hann.
  unfold redex_is_l_annotation in Hann. simpl in Hann. exact Hann.
Qed.

(* An annotation's rank is below the total count. *)
Lemma rank_lt_total : forall l gs i,
  i < length gs -> redex_is_l_annotation l (cfg_at gs i) ->
  annot_count l gs i < annot_count l gs (length gs).
Proof.
  intros l gs i Hilt Hann.
  pose proof (annot_count_annot_S l gs i Hann) as HS.
  pose proof (annot_count_mono l gs (S i) (length gs) ltac:(lia)) as Hm. lia.
Qed.

(* A visible OUTPUT position p exposes its paired assert as the rank-r annotation
   at p-2 (r = annot_count es (p-2)). *)
Lemma out_rank : forall l es tf p l' n,
  pre_run es -> admits_trace es tf -> p < length tf -> vis_at l es p = Some (Eout l' n) ->
  2 <= p /\ is_nth_annot l es (annot_count l es (p - 2)) (p - 2).
Proof.
  intros l es tf p l' n Hpe Hatf Hp Hvis.
  destruct (vis_at_sound l es tf p (Eout l' n) Hatf Hp Hvis) as [Hnthp Hvev].
  assert (Hle : lleq l' l).
  { destruct Hvev as [Hin | Hout].
    - destruct Hin as [l0 [n0 [Heq _]]]; discriminate Heq.
    - destruct Hout as [l2 [n2 [Heq Hl2]]]; injection Heq as Hl Hnn; subst l2; exact Hl2. }
  destruct (trace_output_cfg es tf p l' n Hatf Hp Hnthp) as [cc [s [e [Hcfgp [Hredcc Hn]]]]].
  assert (Hples : p < length es) by (apply admits_trace_length in Hatf; lia).
  destruct (prerun_output_pair_struct es p cc s l' e Hpe Hples Hcfgp Hredcc)
    as [cq [cp [tq6 [Hp2 [Hesq [Hredq [Hesp1 Hredp]]]]]]].
  assert (Hannp2 : redex_is_l_annotation l (cfg_at es (p - 2))).
  { unfold redex_is_l_annotation. rewrite Hesq. simpl. rewrite Hredq.
    unfold is_l_annotation. right. simpl. exact Hle. }
  split; [exact Hp2 |].
  unfold is_nth_annot. split; [lia | split; [exact Hannp2 | reflexivity]].
Qed.

(* A visible INPUT position p exposes its entry assume as the rank-r annotation
   at S p (r = annot_count es (S p)). *)
Lemma in_rank : forall l es tf p l' n,
  pre_run es -> admits_trace es tf -> p < length tf -> vis_at l es p = Some (Ein l' n) ->
  is_nth_annot l es (annot_count l es (S p)) (S p).
Proof.
  intros l es tf p l' n Hpe Hatf Hp Hvis.
  destruct (vis_at_sound l es tf p (Ein l' n) Hatf Hp Hvis) as [Hnthp Hvev].
  assert (Hle : lleq l' l).
  { destruct Hvev as [Hin | Hout].
    - destruct Hin as [l2 [n2 [Heq Hl2]]]; injection Heq as Hl Hnn; subst l2; exact Hl2.
    - destruct Hout as [l0 [n0 [Heq _]]]; discriminate Heq. }
  destruct (trace_input_cfg es tf p l' n Hatf Hp Hnthp) as [s [Hcfgp HcfgSp]].
  destruct (prog_well_specified l') as [wtag [d [Hwb Hd]]].
  assert (HannSp : redex_is_l_annotation l (cfg_at es (S p))).
  { unfold redex_is_l_annotation. rewrite HcfgSp. simpl. rewrite Hwb. simpl.
    unfold is_l_annotation. left. simpl. exact Hle. }
  assert (HSplt : S p < length es)
    by (apply (cfg_at_active_lt es (S p) (h_body (prog l')) _ HcfgSp)).
  unfold is_nth_annot. split; [exact HSplt | split; [exact HannSp | reflexivity]].
Qed.

(* The realization map from minor visible positions to major visible positions. *)
Definition vmap (l : Lev) (ds es : list config) (p : nat) : nat :=
  match vis_at l es p with
  | Some (Eout _ _) => S (S (annot_idx l ds (annot_count l es (p - 2))))
  | Some (Ein _ _)  => annot_idx l ds (annot_count l es (S p)) - 1
  | _ => 0
  end.

(* The CONFORMANCE LENGTH BOUND: when ds (major, covers_dom) and es (minor,
   covers_rng) are an aligned pair and es's last config is an annotation, the
   minor's l-visible trace is no longer than the major's. vmap injects the
   minor's visible positions into the major's: outputs via out_maps_into, inputs
   via in_maps_into; injectivity from annot_idx_inj + is_nth_annot uniqueness
   (same kind) and the major's event kind at the image (cross kind). *)
Lemma conf_vis_le : forall l ds es alpha tM tf,
  l_aligned_pair l ds es alpha -> covers_dom ds alpha -> covers_rng es alpha ->
  admits_trace ds tM -> admits_trace es tf ->
  redex_is_l_annotation l (cfg_at es (length es - 1)) ->
  length (vis l tf) <= length (vis l tM).
Proof.
  intros l ds es alpha tM tf Hlap Hcd Hcr HatM Hatf Heslast.
  assert (Hpd : pre_run ds) by (destruct Hlap as [H _]; exact H).
  assert (Hpe : pre_run es) by (destruct Hlap as [_ [H _]]; exact H).
  assert (Heqcount : annot_count l es (length es) = annot_count l ds (length ds))
    by (symmetry; apply (equal_count l ds es alpha Hlap Hcd Hcr)).
  rewrite (vis_length_positions l ds tM HatM), (vis_length_positions l es tf Hatf).
  apply (length_le_via_inj (vmap l ds es)).
  - apply NoDup_filter, seq_NoDup.
  - (* maps into *)
    intros p Hpin.
    apply (in_filter_seq_isSome _ (vis_at l es) (length tf) p) in Hpin.
    destruct Hpin as [Hp [ev Hev]].
    apply (in_filter_seq_isSome _ (vis_at l ds) (length tM) (vmap l ds es p)).
    destruct ev as [l' n | l' n | ].
    + (* Ein *) unfold vmap; rewrite Hev.
      destruct (in_maps_into l ds es alpha tM tf p l' n Hlap Hcd Hcr HatM Hatf Hp Hev)
        as [Hlt [m Hsome]].
      split; [exact Hlt | exists (Ein l' m); exact Hsome].
    + (* Eout *) unfold vmap; rewrite Hev.
      destruct (out_maps_into l ds es alpha tM tf p l' n Hlap Hcd Hcr HatM Hatf Heslast Hp Hev)
        as [Hlt [m Hsome]].
      split; [exact Hlt | exists (Eout l' m); exact Hsome].
    + exfalso. destruct (vis_at_sound l es tf p Etick Hatf Hp Hev) as [_ Hvev].
      destruct Hvev as [[? [? [Hc _]]] | [? [? [Hc _]]]]; discriminate Hc.
  - (* injectivity *)
    intros p1 p2 Hp1in Hp2in Hfeq.
    apply (in_filter_seq_isSome _ (vis_at l es) (length tf) p1) in Hp1in.
    apply (in_filter_seq_isSome _ (vis_at l es) (length tf) p2) in Hp2in.
    destruct Hp1in as [Hp1 [ev1 Hev1]]. destruct Hp2in as [Hp2 [ev2 Hev2]].
    destruct ev1 as [l1 n1 | l1 n1 | ]; destruct ev2 as [l2 n2 | l2 n2 | ];
      try (exfalso;
           match goal with
           | H : vis_at l es ?p = Some Etick |- _ =>
               destruct (vis_at_sound l es tf p Etick Hatf ltac:(assumption) H) as [_ Hvev];
               destruct Hvev as [[? [? [Hc _]]] | [? [? [Hc _]]]]; discriminate Hc
           end).
    + (* Ein, Ein *)
      pose proof (in_rank l es tf p1 l1 n1 Hpe Hatf Hp1 Hev1) as Hr1.
      pose proof (in_rank l es tf p2 l2 n2 Hpe Hatf Hp2 Hev2) as Hr2.
      unfold vmap in Hfeq; rewrite Hev1, Hev2 in Hfeq.
      set (R1 := annot_count l es (S p1)) in *.
      set (R2 := annot_count l es (S p2)) in *.
      assert (HR1 : R1 < annot_count l ds (length ds))
        by (rewrite <- Heqcount; destruct Hr1 as [HSp [Hann _]]; apply (rank_lt_total l es (S p1) HSp Hann)).
      assert (HR2 : R2 < annot_count l ds (length ds))
        by (rewrite <- Heqcount; destruct Hr2 as [HSp [Hann _]]; apply (rank_lt_total l es (S p2) HSp Hann)).
      pose proof (annot_idx_pos l ds R1 Hpd HR1) as Hpos1.
      pose proof (annot_idx_pos l ds R2 Hpd HR2) as Hpos2.
      assert (Hidxeq : annot_idx l ds R1 = annot_idx l ds R2) by lia.
      pose proof (annot_idx_inj l ds R1 R2 HR1 HR2 Hidxeq) as HReq.
      assert (HSeq : S p1 = S p2)
        by (apply (is_nth_annot_unique l es R1 (S p1) (S p2) Hr1);
            rewrite HReq; exact Hr2).
      lia.
    + (* Ein, Eout: major event kinds differ *)
      exfalso.
      destruct (in_maps_into l ds es alpha tM tf p1 l1 n1 Hlap Hcd Hcr HatM Hatf Hp1 Hev1)
        as [_ [m1 Hi1]].
      destruct (out_maps_into l ds es alpha tM tf p2 l2 n2 Hlap Hcd Hcr HatM Hatf Heslast Hp2 Hev2)
        as [_ [m2 Ho2]].
      unfold vmap in Hfeq; rewrite Hev1, Hev2 in Hfeq.
      rewrite Hfeq, Ho2 in Hi1. discriminate Hi1.
    + (* Eout, Ein: symmetric *)
      exfalso.
      destruct (out_maps_into l ds es alpha tM tf p1 l1 n1 Hlap Hcd Hcr HatM Hatf Heslast Hp1 Hev1)
        as [_ [m1 Ho1]].
      destruct (in_maps_into l ds es alpha tM tf p2 l2 n2 Hlap Hcd Hcr HatM Hatf Hp2 Hev2)
        as [_ [m2 Hi2]].
      unfold vmap in Hfeq; rewrite Hev1, Hev2 in Hfeq.
      rewrite Hfeq, Hi2 in Ho1. discriminate Ho1.
    + (* Eout, Eout *)
      pose proof (out_rank l es tf p1 l1 n1 Hpe Hatf Hp1 Hev1) as [Hp1ge Hr1].
      pose proof (out_rank l es tf p2 l2 n2 Hpe Hatf Hp2 Hev2) as [Hp2ge Hr2].
      unfold vmap in Hfeq; rewrite Hev1, Hev2 in Hfeq.
      set (R1 := annot_count l es (p1 - 2)) in *.
      set (R2 := annot_count l es (p2 - 2)) in *.
      assert (HR1 : R1 < annot_count l ds (length ds))
        by (rewrite <- Heqcount; destruct Hr1 as [Hlt [Hann _]]; apply (rank_lt_total l es (p1 - 2) Hlt Hann)).
      assert (HR2 : R2 < annot_count l ds (length ds))
        by (rewrite <- Heqcount; destruct Hr2 as [Hlt [Hann _]]; apply (rank_lt_total l es (p2 - 2) Hlt Hann)).
      assert (Hidxeq : annot_idx l ds R1 = annot_idx l ds R2) by lia.
      pose proof (annot_idx_inj l ds R1 R2 HR1 HR2 Hidxeq) as HReq.
      assert (Hp2eq : p1 - 2 = p2 - 2)
        by (apply (is_nth_annot_unique l es R1 (p1 - 2) (p2 - 2) Hr1);
            rewrite HReq; exact Hr2).
      lia.
Qed.

(* When the minor [es] ENDS at a low output (its last config), every l-visible
   output COUNTED in the trace [tf] (position p < length tf, i.e. p <= length es-2)
   has its guarding assert STRICTLY below the top annotation -- because the top
   annotation (the assert at length es-3) guards only the boundary output at
   length es-1, which is not a trace position.  Hence the LOCAL rank bound that
   out_maps_into_local needs holds, WITHOUT an annotation-last hypothesis. *)
Lemma out_endpoint_local_bound : forall l ds es alpha tM tf p l' n,
  l_aligned_pair l ds es alpha -> covers_dom ds alpha -> covers_rng es alpha ->
  admits_trace ds tM -> admits_trace es tf ->
  redex_is_l_output l (cfg_at es (length es - 1)) ->
  p < length tf -> vis_at l es p = Some (Eout l' n) ->
  S (annot_count l es (p - 2)) < annot_count l ds (length ds).
Proof.
  intros l ds es alpha tM tf p l' n Hlap Hcd Hcr HatM Hatf Hlastout Hp Hvis.
  assert (Hpe : pre_run es) by (destruct Hlap as [_ [H _]]; exact H).
  pose proof (admits_trace_length es tf Hatf) as HeM.
  assert (Heqcount : annot_count l ds (length ds) = annot_count l es (length es))
    by (apply (equal_count l ds es alpha Hlap Hcd Hcr)).
  destruct (cfg_at es (length es - 1)) as [sr | ccL sL] eqn:HcfgL.
  { unfold redex_is_l_output in Hlastout. simpl in Hlastout. contradiction. }
  unfold redex_is_l_output in Hlastout. simpl in Hlastout.
  destruct (redex_cmd ccL) as [ | xa ea | loL eoL | ea ca cb | ea ca | ca cb | la ta Pa | la ta Pa ] eqn:HredL;
    try contradiction.
  assert (HLlt : length es - 1 < length es) by lia.
  destruct (prerun_output_pair_struct es (length es - 1) ccL sL loL eoL Hpe HLlt HcfgL HredL)
    as [cqL [cpL [tq7 [HLge2 [HesqL [HredqL [HespL HredpL]]]]]]].
  assert (Hann_es3 : redex_is_l_annotation l (cfg_at es (length es - 3))).
  { replace (length es - 3) with (length es - 1 - 2) by lia.
    unfold redex_is_l_annotation. rewrite HesqL. simpl. rewrite HredqL.
    unfold is_l_annotation. right. simpl. exact Hlastout. }
  assert (Hnoann_es2 : ~ redex_is_l_annotation l (cfg_at es (length es - 2))).
  { replace (length es - 2) with (length es - 1 - 1) by lia.
    intro H. unfold redex_is_l_annotation in H. rewrite HespL in H. simpl in H.
    rewrite HredpL in H. destruct H as [H | H]; exact H. }
  assert (Hnoann_es1 : ~ redex_is_l_annotation l (cfg_at es (length es - 1))).
  { intro H. unfold redex_is_l_annotation in H. rewrite HcfgL in H. simpl in H.
    rewrite HredL in H. destruct H as [H | H]; exact H. }
  assert (Hcnt_es : annot_count l es (length es) = S (annot_count l es (length es - 3))).
  { replace (length es) with (S (length es - 1)) at 1 by lia.
    rewrite (annot_count_nonannot_S l es (length es - 1) Hnoann_es1).
    replace (length es - 1) with (S (length es - 2)) by lia.
    rewrite (annot_count_nonannot_S l es (length es - 2) Hnoann_es2).
    replace (length es - 2) with (S (length es - 3)) by lia.
    rewrite (annot_count_annot_S l es (length es - 3) Hann_es3). reflexivity. }
  destruct (vis_at_sound l es tf p (Eout l' n) Hatf Hp Hvis) as [Hnthp Hvev].
  assert (Hle' : lleq l' l).
  { destruct Hvev as [Hin | Hout].
    - destruct Hin as [? [? [Heq _]]]; discriminate Heq.
    - destruct Hout as [? [? [Heq Hl2]]]; injection Heq as Hl _; subst; exact Hl2. }
  destruct (trace_output_cfg es tf p l' n Hatf Hp Hnthp) as [cc [s [e [Hcfgp [Hredcc Hn]]]]].
  assert (Hples : p < length es) by lia.
  destruct (prerun_output_pair_struct es p cc s l' e Hpe Hples Hcfgp Hredcc)
    as [cqp [cpp [tq8 [Hp2 [Hesqp [Hredqp [Hespp Hredpp]]]]]]].
  assert (Hannp2 : redex_is_l_annotation l (cfg_at es (p - 2))).
  { unfold redex_is_l_annotation. rewrite Hesqp. simpl. rewrite Hredqp.
    unfold is_l_annotation. right. simpl. exact Hle'. }
  assert (Hstep_count : annot_count l es (S (p - 2)) = S (annot_count l es (p - 2)))
    by (apply (annot_count_annot_S l es (p - 2) Hannp2)).
  assert (Hmono : annot_count l es (S (p - 2)) <= annot_count l es (length es - 3))
    by (apply annot_count_mono; lia).
  lia.
Qed.

(* Output-endpoint variant of conf_vis_le: the minor [es] need not end at an
   annotation -- it may end at a low OUTPUT.  Counted outputs are realized via
   out_maps_into_local (the local rank bound supplied by out_endpoint_local_bound)
   instead of out_maps_into (which needs an annotation-last). *)
Lemma conf_vis_le_out : forall l ds es alpha tM tf,
  l_aligned_pair l ds es alpha -> covers_dom ds alpha -> covers_rng es alpha ->
  admits_trace ds tM -> admits_trace es tf ->
  redex_is_l_output l (cfg_at es (length es - 1)) ->
  length (vis l tf) <= length (vis l tM).
Proof.
  intros l ds es alpha tM tf Hlap Hcd Hcr HatM Hatf Hlastout.
  assert (Hpd : pre_run ds) by (destruct Hlap as [H _]; exact H).
  assert (Hpe : pre_run es) by (destruct Hlap as [_ [H _]]; exact H).
  assert (Heqcount : annot_count l es (length es) = annot_count l ds (length ds))
    by (symmetry; apply (equal_count l ds es alpha Hlap Hcd Hcr)).
  rewrite (vis_length_positions l ds tM HatM), (vis_length_positions l es tf Hatf).
  apply (length_le_via_inj (vmap l ds es)).
  - apply NoDup_filter, seq_NoDup.
  - (* maps into *)
    intros p Hpin.
    apply (in_filter_seq_isSome _ (vis_at l es) (length tf) p) in Hpin.
    destruct Hpin as [Hp [ev Hev]].
    apply (in_filter_seq_isSome _ (vis_at l ds) (length tM) (vmap l ds es p)).
    destruct ev as [l' n | l' n | ].
    + (* Ein *) unfold vmap; rewrite Hev.
      destruct (in_maps_into l ds es alpha tM tf p l' n Hlap Hcd Hcr HatM Hatf Hp Hev)
        as [Hlt [m Hsome]].
      split; [exact Hlt | exists (Ein l' m); exact Hsome].
    + (* Eout *) unfold vmap; rewrite Hev.
      destruct (out_maps_into_local l ds es alpha tM tf p l' n Hlap Hcr HatM Hatf
                  (out_endpoint_local_bound l ds es alpha tM tf p l' n Hlap Hcd Hcr HatM Hatf Hlastout Hp Hev)
                  Hp Hev)
        as [Hlt [m Hsome]].
      split; [exact Hlt | exists (Eout l' m); exact Hsome].
    + exfalso. destruct (vis_at_sound l es tf p Etick Hatf Hp Hev) as [_ Hvev].
      destruct Hvev as [[? [? [Hc _]]] | [? [? [Hc _]]]]; discriminate Hc.
  - (* injectivity *)
    intros p1 p2 Hp1in Hp2in Hfeq.
    apply (in_filter_seq_isSome _ (vis_at l es) (length tf) p1) in Hp1in.
    apply (in_filter_seq_isSome _ (vis_at l es) (length tf) p2) in Hp2in.
    destruct Hp1in as [Hp1 [ev1 Hev1]]. destruct Hp2in as [Hp2 [ev2 Hev2]].
    destruct ev1 as [l1 n1 | l1 n1 | ]; destruct ev2 as [l2 n2 | l2 n2 | ];
      try (exfalso;
           match goal with
           | H : vis_at l es ?p = Some Etick |- _ =>
               destruct (vis_at_sound l es tf p Etick Hatf ltac:(assumption) H) as [_ Hvev];
               destruct Hvev as [[? [? [Hc _]]] | [? [? [Hc _]]]]; discriminate Hc
           end).
    + (* Ein, Ein *)
      pose proof (in_rank l es tf p1 l1 n1 Hpe Hatf Hp1 Hev1) as Hr1.
      pose proof (in_rank l es tf p2 l2 n2 Hpe Hatf Hp2 Hev2) as Hr2.
      unfold vmap in Hfeq; rewrite Hev1, Hev2 in Hfeq.
      set (R1 := annot_count l es (S p1)) in *.
      set (R2 := annot_count l es (S p2)) in *.
      assert (HR1 : R1 < annot_count l ds (length ds))
        by (rewrite <- Heqcount; destruct Hr1 as [HSp [Hann _]]; apply (rank_lt_total l es (S p1) HSp Hann)).
      assert (HR2 : R2 < annot_count l ds (length ds))
        by (rewrite <- Heqcount; destruct Hr2 as [HSp [Hann _]]; apply (rank_lt_total l es (S p2) HSp Hann)).
      pose proof (annot_idx_pos l ds R1 Hpd HR1) as Hpos1.
      pose proof (annot_idx_pos l ds R2 Hpd HR2) as Hpos2.
      assert (Hidxeq : annot_idx l ds R1 = annot_idx l ds R2) by lia.
      pose proof (annot_idx_inj l ds R1 R2 HR1 HR2 Hidxeq) as HReq.
      assert (HSeq : S p1 = S p2)
        by (apply (is_nth_annot_unique l es R1 (S p1) (S p2) Hr1);
            rewrite HReq; exact Hr2).
      lia.
    + (* Ein, Eout: major event kinds differ *)
      exfalso.
      destruct (in_maps_into l ds es alpha tM tf p1 l1 n1 Hlap Hcd Hcr HatM Hatf Hp1 Hev1)
        as [_ [m1 Hi1]].
      destruct (out_maps_into_local l ds es alpha tM tf p2 l2 n2 Hlap Hcr HatM Hatf
                  (out_endpoint_local_bound l ds es alpha tM tf p2 l2 n2 Hlap Hcd Hcr HatM Hatf Hlastout Hp2 Hev2)
                  Hp2 Hev2)
        as [_ [m2 Ho2]].
      unfold vmap in Hfeq; rewrite Hev1, Hev2 in Hfeq.
      rewrite Hfeq, Ho2 in Hi1. discriminate Hi1.
    + (* Eout, Ein: symmetric *)
      exfalso.
      destruct (out_maps_into_local l ds es alpha tM tf p1 l1 n1 Hlap Hcr HatM Hatf
                  (out_endpoint_local_bound l ds es alpha tM tf p1 l1 n1 Hlap Hcd Hcr HatM Hatf Hlastout Hp1 Hev1)
                  Hp1 Hev1)
        as [_ [m1 Ho1]].
      destruct (in_maps_into l ds es alpha tM tf p2 l2 n2 Hlap Hcd Hcr HatM Hatf Hp2 Hev2)
        as [_ [m2 Hi2]].
      unfold vmap in Hfeq; rewrite Hev1, Hev2 in Hfeq.
      rewrite Hfeq, Hi2 in Ho1. discriminate Ho1.
    + (* Eout, Eout *)
      pose proof (out_rank l es tf p1 l1 n1 Hpe Hatf Hp1 Hev1) as [Hp1ge Hr1].
      pose proof (out_rank l es tf p2 l2 n2 Hpe Hatf Hp2 Hev2) as [Hp2ge Hr2].
      unfold vmap in Hfeq; rewrite Hev1, Hev2 in Hfeq.
      set (R1 := annot_count l es (p1 - 2)) in *.
      set (R2 := annot_count l es (p2 - 2)) in *.
      assert (HR1 : R1 < annot_count l ds (length ds))
        by (rewrite <- Heqcount; destruct Hr1 as [Hlt [Hann _]]; apply (rank_lt_total l es (p1 - 2) Hlt Hann)).
      assert (HR2 : R2 < annot_count l ds (length ds))
        by (rewrite <- Heqcount; destruct Hr2 as [Hlt [Hann _]]; apply (rank_lt_total l es (p2 - 2) Hlt Hann)).
      assert (Hidxeq : annot_idx l ds R1 = annot_idx l ds R2) by lia.
      pose proof (annot_idx_inj l ds R1 R2 HR1 HR2 Hidxeq) as HReq.
      assert (Hp2eq : p1 - 2 = p2 - 2)
        by (apply (is_nth_annot_unique l es R1 (p1 - 2) (p2 - 2) Hr1);
            rewrite HReq; exact Hr2).
      lia.
Qed.

(* [proper] is symmetric under swapping the two runs and inverting the alignment. *)
Lemma proper_swap : forall l gs hs alpha,
  proper l gs hs alpha -> proper l hs gs (fun a b => alpha b a).
Proof.
  intros l gs hs alpha [[Hbound [Hmono [Hpcd Hpcr]]] Hcoin].
  split.
  - split; [| split; [| split]].
    + intros a b Hab. destruct (Hbound b a Hab) as [Hb Ha]. split; [exact Ha | exact Hb].
    + intros a b c d Hab Hcd. destruct (Hmono b a d c Hab Hcd) as [H1 H2]. split; [exact H2 | exact H1].
    + intros a c Hda Hca. apply (Hpcr a c Hda Hca).
    + intros a c Hra Hca. apply (Hpcd a c Hra Hca).
  - intros a b Hab Hannot. symmetry. apply (Hcoin b a Hab). tauto.
Qed.

(* Reverse-direction output-endpoint bound: when the MAJOR [ds] ends at a low output
   and the alignment is bijective (covers both sides), the major's l-visible count is
   bounded by the minor's -- obtained from conf_vis_le_out on the swapped pair. *)
Lemma conf_vis_ge_out : forall l ds es alpha tM tf,
  l_aligned_pair l ds es alpha -> covers_dom ds alpha -> covers_rng es alpha ->
  admits_trace ds tM -> admits_trace es tf ->
  redex_is_l_output l (cfg_at ds (length ds - 1)) ->
  length (vis l tM) <= length (vis l tf).
Proof.
  intros l ds es alpha tM tf Hlap Hcd Hcr HatM Hatf Hlastout.
  set (alpha' := fun a b => alpha b a).
  assert (Hlap' : l_aligned_pair l es ds alpha').
  { destruct Hlap as [Hpd [Hpe Hprop]]. split; [exact Hpe | split; [exact Hpd |]].
    apply proper_swap; exact Hprop. }
  assert (Hcd' : covers_dom es alpha')
    by (intros j Hj; destruct (Hcr j Hj) as [a Ha]; exists a; exact Ha).
  assert (Hcr' : covers_rng ds alpha')
    by (intros a Ha; destruct (Hcd a Ha) as [j Hj]; exists j; exact Hj).
  apply (conf_vis_le_out l es ds alpha' tf tM Hlap' Hcd' Hcr' Hatf HatM Hlastout).
Qed.

(* If a run's last three configs are [annotation; non-annotation; non-annotation]
   (the paired assert, post-assert, and output), the run's total annotation count is
   one more than the rank of that final assert. *)
Lemma annot_count_output_top : forall l gs b,
  redex_is_l_annotation l (cfg_at gs b) ->
  ~ redex_is_l_annotation l (cfg_at gs (S b)) ->
  ~ redex_is_l_annotation l (cfg_at gs (S (S b))) ->
  S (S (S b)) = length gs ->
  annot_count l gs (length gs) = S (annot_count l gs b).
Proof.
  intros l gs b Hann Hnp Hno Hlen.
  rewrite <- Hlen.
  rewrite (annot_count_nonannot_S l gs (S (S b)) Hno).
  rewrite (annot_count_nonannot_S l gs (S b) Hnp).
  rewrite (annot_count_annot_S l gs b Hann).
  reflexivity.
Qed.

(* When both runs end at aligned low outputs (the LAST config of each), their final
   output events coincide: the guarding asserts (two back) are the TOP annotation of
   each, hence aligned (minor_major_rank + rank uniqueness), so they share the redex
   (coincidence) and the agreed expression evaluates equally (conf_annot_value); the
   output state equals the assert state (prerun_output_pair_struct). *)
Lemma aligned_last_output_event : forall l ins ds es alpha,
  conformance l ins ds es alpha -> covers_dom ds alpha -> covers_rng es alpha ->
  redex_is_l_output l (cfg_at ds (length ds - 1)) ->
  redex_is_l_output l (cfg_at es (length es - 1)) ->
  alpha (length ds - 1) (length es - 1) ->
  vis_at l ds (length ds - 1) = vis_at l es (length es - 1).
Proof.
  intros l ins ds es alpha Hconf Hcd Hcr Houtd Houte Halast.
  assert (Hlap : l_aligned_pair l ds es alpha) by (destruct Hconf as [H _]; exact H).
  assert (Hpd : pre_run ds) by (destruct Hlap as [H _]; exact H).
  assert (Hpe : pre_run es) by (destruct Hlap as [_ [H _]]; exact H).
  (* major output config and its paired assert *)
  destruct (cfg_at ds (length ds - 1)) as [srd | ccd scd] eqn:Hcfgd.
  { unfold redex_is_l_output in Houtd. simpl in Houtd. contradiction. }
  unfold redex_is_l_output in Houtd. simpl in Houtd.
  destruct (redex_cmd ccd) as [ | xa ea | lod eod | ea ca cb | ea ca | ca cb | la ta Pa | la ta Pa ] eqn:Hredd;
    try contradiction.
  assert (Hdlt : length ds - 1 < length ds)
    by (destruct ds; [discriminate Hcfgd | simpl; lia]).
  destruct (prerun_output_pair_struct ds (length ds - 1) ccd scd lod eod Hpd Hdlt Hcfgd Hredd)
    as [cqd [cpd [tq9 [Hd2 [Hesqd [Hredqd [Hespd Hredpd]]]]]]].
  (* minor output config and its paired assert *)
  destruct (cfg_at es (length es - 1)) as [sre | cce sce] eqn:Hcfge.
  { unfold redex_is_l_output in Houte. simpl in Houte. contradiction. }
  unfold redex_is_l_output in Houte. simpl in Houte.
  destruct (redex_cmd cce) as [ | xb eb | loe eoe | eb cba cbb | eb cba | cba cbb | lb tb Pb | lb tb Pb ] eqn:Hrede;
    try contradiction.
  assert (Helt : length es - 1 < length es)
    by (destruct es; [discriminate Hcfge | simpl; lia]).
  destruct (prerun_output_pair_struct es (length es - 1) cce sce loe eoe Hpe Helt Hcfge Hrede)
    as [cqe [cpe [tq10 [He2 [Hesqe [Hredqe [Hespe Hredpe]]]]]]].
  (* the asserts are the TOP annotation of each run *)
  assert (Hannd : redex_is_l_annotation l (cfg_at ds (length ds - 1 - 2))).
  { unfold redex_is_l_annotation. rewrite Hesqd. simpl. rewrite Hredqd.
    unfold is_l_annotation. right. simpl. exact Houtd. }
  assert (Hanne : redex_is_l_annotation l (cfg_at es (length es - 1 - 2))).
  { unfold redex_is_l_annotation. rewrite Hesqe. simpl. rewrite Hredqe.
    unfold is_l_annotation. right. simpl. exact Houte. }
  assert (Hnnd_o : ~ redex_is_l_annotation l (cfg_at ds (length ds - 1)))
    by (rewrite Hcfgd; intro H; unfold redex_is_l_annotation in H; simpl in H;
        rewrite Hredd in H; destruct H as [H | H]; exact H).
  assert (Hnnd_p : ~ redex_is_l_annotation l (cfg_at ds (length ds - 1 - 1)))
    by (rewrite Hespd; intro H; unfold redex_is_l_annotation in H; simpl in H;
        rewrite Hredpd in H; destruct H as [H | H]; exact H).
  assert (Hnne_o : ~ redex_is_l_annotation l (cfg_at es (length es - 1)))
    by (rewrite Hcfge; intro H; unfold redex_is_l_annotation in H; simpl in H;
        rewrite Hrede in H; destruct H as [H | H]; exact H).
  assert (Hnne_p : ~ redex_is_l_annotation l (cfg_at es (length es - 1 - 1)))
    by (rewrite Hespe; intro H; unfold redex_is_l_annotation in H; simpl in H;
        rewrite Hredpe in H; destruct H as [H | H]; exact H).
  assert (Hcntd : annot_count l ds (length ds) = S (annot_count l ds (length ds - 1 - 2)))
    by (apply (annot_count_output_top l ds (length ds - 1 - 2) Hannd
                 ltac:(replace (S (length ds - 1 - 2)) with (length ds - 1 - 1) by lia; exact Hnnd_p)
                 ltac:(replace (S (S (length ds - 1 - 2))) with (length ds - 1) by lia; exact Hnnd_o)
                 ltac:(lia))).
  assert (Hcnte : annot_count l es (length es) = S (annot_count l es (length es - 1 - 2)))
    by (apply (annot_count_output_top l es (length es - 1 - 2) Hanne
                 ltac:(replace (S (length es - 1 - 2)) with (length es - 1 - 1) by lia; exact Hnne_p)
                 ltac:(replace (S (S (length es - 1 - 2))) with (length es - 1) by lia; exact Hnne_o)
                 ltac:(lia))).
  pose proof (equal_count l ds es alpha Hlap Hcd Hcr) as Heqc.
  set (r := annot_count l es (length es - 1 - 2)) in *.
  assert (Hrd : annot_count l ds (length ds - 1 - 2) = r) by (unfold r; lia).
  assert (Hnthe : is_nth_annot l es r (length es - 1 - 2))
    by (unfold is_nth_annot; split; [lia | split; [exact Hanne | reflexivity]]).
  destruct (minor_major_rank l ds es alpha r (length es - 1 - 2) Hlap Hcd Hcr Hnthe)
    as [a [Haa [Hntha _]]].
  assert (Hnthd : is_nth_annot l ds r (length ds - 1 - 2))
    by (unfold is_nth_annot; split; [lia | split; [exact Hannd | exact Hrd]]).
  assert (Haeq : a = length ds - 1 - 2) by (apply (is_nth_annot_unique l ds r a _ Hntha Hnthd)).
  subst a.
  (* coincidence at the aligned asserts: same redex *)
  assert (Hproper : proper l ds es alpha) by (destruct Hlap as [_ [_ H]]; exact H).
  destruct Hproper as [_ Hcoin].
  assert (Hredeq : redex_of (cfg_at ds (length ds - 1 - 2)) = redex_of (cfg_at es (length es - 1 - 2)))
    by (apply (Hcoin (length ds - 1 - 2) (length es - 1 - 2) Haa); left; exact Hannd).
  rewrite Hesqd, Hesqe in Hredeq. simpl in Hredeq. rewrite Hredqd, Hredqe in Hredeq.
  injection Hredeq as Hlo Htq Heo. subst loe eoe tq10.
  (* value agreement at the asserts, transported to the output states *)
  assert (HredM : redex_of (cfg_at ds (length ds - 1 - 2)) = Some (Cassert lod tq9 (Ragr eod)))
    by (rewrite Hesqd; simpl; rewrite Hredqd; reflexivity).
  pose proof (conf_annot_value l ins ds es alpha (length ds - 1 - 2) (length es - 1 - 2) lod tq9 eod
                Hconf Haa (or_intror HredM) Houtd) as Hval.
  rewrite Hesqd, Hesqe in Hval. simpl in Hval.
  (* assemble the two output events *)
  rewrite (vis_at_out_some l ds (length ds - 1) lod eod
             ltac:(rewrite Hcfgd; simpl; rewrite Hredd; reflexivity) Houtd).
  rewrite (vis_at_out_some l es (length es - 1) lod eod
             ltac:(rewrite Hcfge; simpl; rewrite Hrede; reflexivity) Houtd).
  rewrite Hcfgd, Hcfge. simpl. rewrite Hval. reflexivity.
Qed.

(* covers_rng-ONLY version of conf_vis_le: the minor's l-visible count is bounded
   by the major's, WITHOUT covers_dom of the major.  Same injection [vmap], but
   maps-into via out_maps_into_rng / in_maps_into_rng and the rank bound via
   annot_count_le_rng instead of equal_count.  This is what the receptive branch
   of the conformance case needs, since there covers_dom of the major fails. *)
Lemma minor_vis_le_rng : forall l ds es alpha tM tf,
  l_aligned_pair l ds es alpha -> covers_rng es alpha ->
  admits_trace ds tM -> admits_trace es tf ->
  redex_is_l_annotation l (cfg_at es (length es - 1)) ->
  length (vis l tf) <= length (vis l tM).
Proof.
  intros l ds es alpha tM tf Hlap Hcr HatM Hatf Heslast.
  assert (Hpd : pre_run ds) by (destruct Hlap as [H _]; exact H).
  assert (Hpe : pre_run es) by (destruct Hlap as [_ [H _]]; exact H).
  assert (Hle_count : annot_count l es (length es) <= annot_count l ds (length ds))
    by (apply (annot_count_le_rng l ds es alpha Hlap Hcr)).
  rewrite (vis_length_positions l ds tM HatM), (vis_length_positions l es tf Hatf).
  apply (length_le_via_inj (vmap l ds es)).
  - apply NoDup_filter, seq_NoDup.
  - (* maps into *)
    intros p Hpin.
    apply (in_filter_seq_isSome _ (vis_at l es) (length tf) p) in Hpin.
    destruct Hpin as [Hp [ev Hev]].
    apply (in_filter_seq_isSome _ (vis_at l ds) (length tM) (vmap l ds es p)).
    destruct ev as [l' n | l' n | ].
    + (* Ein *) unfold vmap; rewrite Hev.
      destruct (in_maps_into_rng l ds es alpha tM tf p l' n Hlap Hcr HatM Hatf Hp Hev)
        as [Hlt [m Hsome]].
      split; [exact Hlt | exists (Ein l' m); exact Hsome].
    + (* Eout *) unfold vmap; rewrite Hev.
      destruct (out_maps_into_rng l ds es alpha tM tf p l' n Hlap Hcr HatM Hatf Heslast Hp Hev)
        as [Hlt [m Hsome]].
      split; [exact Hlt | exists (Eout l' m); exact Hsome].
    + exfalso. destruct (vis_at_sound l es tf p Etick Hatf Hp Hev) as [_ Hvev].
      destruct Hvev as [[? [? [Hc _]]] | [? [? [Hc _]]]]; discriminate Hc.
  - (* injectivity *)
    intros p1 p2 Hp1in Hp2in Hfeq.
    apply (in_filter_seq_isSome _ (vis_at l es) (length tf) p1) in Hp1in.
    apply (in_filter_seq_isSome _ (vis_at l es) (length tf) p2) in Hp2in.
    destruct Hp1in as [Hp1 [ev1 Hev1]]. destruct Hp2in as [Hp2 [ev2 Hev2]].
    destruct ev1 as [l1 n1 | l1 n1 | ]; destruct ev2 as [l2 n2 | l2 n2 | ];
      try (exfalso;
           match goal with
           | H : vis_at l es ?p = Some Etick |- _ =>
               destruct (vis_at_sound l es tf p Etick Hatf ltac:(assumption) H) as [_ Hvev];
               destruct Hvev as [[? [? [Hc _]]] | [? [? [Hc _]]]]; discriminate Hc
           end).
    + (* Ein, Ein *)
      pose proof (in_rank l es tf p1 l1 n1 Hpe Hatf Hp1 Hev1) as Hr1.
      pose proof (in_rank l es tf p2 l2 n2 Hpe Hatf Hp2 Hev2) as Hr2.
      unfold vmap in Hfeq; rewrite Hev1, Hev2 in Hfeq.
      set (R1 := annot_count l es (S p1)) in *.
      set (R2 := annot_count l es (S p2)) in *.
      assert (HR1 : R1 < annot_count l ds (length ds)).
      { apply (Nat.lt_le_trans _ (annot_count l es (length es)) _);
          [ destruct Hr1 as [HSp [Hann _]]; apply (rank_lt_total l es (S p1) HSp Hann)
          | exact Hle_count ]. }
      assert (HR2 : R2 < annot_count l ds (length ds)).
      { apply (Nat.lt_le_trans _ (annot_count l es (length es)) _);
          [ destruct Hr2 as [HSp [Hann _]]; apply (rank_lt_total l es (S p2) HSp Hann)
          | exact Hle_count ]. }
      pose proof (annot_idx_pos l ds R1 Hpd HR1) as Hpos1.
      pose proof (annot_idx_pos l ds R2 Hpd HR2) as Hpos2.
      assert (Hidxeq : annot_idx l ds R1 = annot_idx l ds R2) by lia.
      pose proof (annot_idx_inj l ds R1 R2 HR1 HR2 Hidxeq) as HReq.
      assert (HSeq : S p1 = S p2)
        by (apply (is_nth_annot_unique l es R1 (S p1) (S p2) Hr1);
            rewrite HReq; exact Hr2).
      lia.
    + (* Ein, Eout: major event kinds differ *)
      exfalso.
      destruct (in_maps_into_rng l ds es alpha tM tf p1 l1 n1 Hlap Hcr HatM Hatf Hp1 Hev1)
        as [_ [m1 Hi1]].
      destruct (out_maps_into_rng l ds es alpha tM tf p2 l2 n2 Hlap Hcr HatM Hatf Heslast Hp2 Hev2)
        as [_ [m2 Ho2]].
      unfold vmap in Hfeq; rewrite Hev1, Hev2 in Hfeq.
      rewrite Hfeq, Ho2 in Hi1. discriminate Hi1.
    + (* Eout, Ein: symmetric *)
      exfalso.
      destruct (out_maps_into_rng l ds es alpha tM tf p1 l1 n1 Hlap Hcr HatM Hatf Heslast Hp1 Hev1)
        as [_ [m1 Ho1]].
      destruct (in_maps_into_rng l ds es alpha tM tf p2 l2 n2 Hlap Hcr HatM Hatf Hp2 Hev2)
        as [_ [m2 Hi2]].
      unfold vmap in Hfeq; rewrite Hev1, Hev2 in Hfeq.
      rewrite Hfeq, Hi2 in Ho1. discriminate Ho1.
    + (* Eout, Eout *)
      pose proof (out_rank l es tf p1 l1 n1 Hpe Hatf Hp1 Hev1) as [Hp1ge Hr1].
      pose proof (out_rank l es tf p2 l2 n2 Hpe Hatf Hp2 Hev2) as [Hp2ge Hr2].
      unfold vmap in Hfeq; rewrite Hev1, Hev2 in Hfeq.
      set (R1 := annot_count l es (p1 - 2)) in *.
      set (R2 := annot_count l es (p2 - 2)) in *.
      assert (HR1 : R1 < annot_count l ds (length ds)).
      { apply (Nat.lt_le_trans _ (annot_count l es (length es)) _);
          [ destruct Hr1 as [Hlt [Hann _]]; apply (rank_lt_total l es (p1 - 2) Hlt Hann)
          | exact Hle_count ]. }
      assert (HR2 : R2 < annot_count l ds (length ds)).
      { apply (Nat.lt_le_trans _ (annot_count l es (length es)) _);
          [ destruct Hr2 as [Hlt [Hann _]]; apply (rank_lt_total l es (p2 - 2) Hlt Hann)
          | exact Hle_count ]. }
      assert (Hidxeq : annot_idx l ds R1 = annot_idx l ds R2) by lia.
      pose proof (annot_idx_inj l ds R1 R2 HR1 HR2 Hidxeq) as HReq.
      assert (Hp2eq : p1 - 2 = p2 - 2)
        by (apply (is_nth_annot_unique l es R1 (p1 - 2) (p2 - 2) Hr1);
            rewrite HReq; exact Hr2).
      lia.
Qed.

(* Strict-count variant of minor_vis_le_rng: drops the es-ends-in-annotation
   hypothesis in favour of a strict annotation-count inequality (so it applies
   when es ends receptive).  Uses out_maps_into_strict for outputs. *)
Lemma minor_vis_le_strict : forall l ds es alpha tM tf,
  l_aligned_pair l ds es alpha -> covers_rng es alpha ->
  admits_trace ds tM -> admits_trace es tf ->
  annot_count l es (length es) < annot_count l ds (length ds) ->
  length (vis l tf) <= length (vis l tM).
Proof.
  intros l ds es alpha tM tf Hlap Hcr HatM Hatf Hstrict.
  assert (Hpd : pre_run ds) by (destruct Hlap as [H _]; exact H).
  assert (Hpe : pre_run es) by (destruct Hlap as [_ [H _]]; exact H).
  assert (Hle_count : annot_count l es (length es) <= annot_count l ds (length ds))
    by lia.
  rewrite (vis_length_positions l ds tM HatM), (vis_length_positions l es tf Hatf).
  apply (length_le_via_inj (vmap l ds es)).
  - apply NoDup_filter, seq_NoDup.
  - (* maps into *)
    intros p Hpin.
    apply (in_filter_seq_isSome _ (vis_at l es) (length tf) p) in Hpin.
    destruct Hpin as [Hp [ev Hev]].
    apply (in_filter_seq_isSome _ (vis_at l ds) (length tM) (vmap l ds es p)).
    destruct ev as [l' n | l' n | ].
    + (* Ein *) unfold vmap; rewrite Hev.
      destruct (in_maps_into_rng l ds es alpha tM tf p l' n Hlap Hcr HatM Hatf Hp Hev)
        as [Hlt [m Hsome]].
      split; [exact Hlt | exists (Ein l' m); exact Hsome].
    + (* Eout *) unfold vmap; rewrite Hev.
      destruct (out_maps_into_strict l ds es alpha tM tf p l' n Hlap Hcr HatM Hatf Hstrict Hp Hev)
        as [Hlt [m Hsome]].
      split; [exact Hlt | exists (Eout l' m); exact Hsome].
    + exfalso. destruct (vis_at_sound l es tf p Etick Hatf Hp Hev) as [_ Hvev].
      destruct Hvev as [[? [? [Hc _]]] | [? [? [Hc _]]]]; discriminate Hc.
  - (* injectivity *)
    intros p1 p2 Hp1in Hp2in Hfeq.
    apply (in_filter_seq_isSome _ (vis_at l es) (length tf) p1) in Hp1in.
    apply (in_filter_seq_isSome _ (vis_at l es) (length tf) p2) in Hp2in.
    destruct Hp1in as [Hp1 [ev1 Hev1]]. destruct Hp2in as [Hp2 [ev2 Hev2]].
    destruct ev1 as [l1 n1 | l1 n1 | ]; destruct ev2 as [l2 n2 | l2 n2 | ];
      try (exfalso;
           match goal with
           | H : vis_at l es ?p = Some Etick |- _ =>
               destruct (vis_at_sound l es tf p Etick Hatf ltac:(assumption) H) as [_ Hvev];
               destruct Hvev as [[? [? [Hc _]]] | [? [? [Hc _]]]]; discriminate Hc
           end).
    + (* Ein, Ein *)
      pose proof (in_rank l es tf p1 l1 n1 Hpe Hatf Hp1 Hev1) as Hr1.
      pose proof (in_rank l es tf p2 l2 n2 Hpe Hatf Hp2 Hev2) as Hr2.
      unfold vmap in Hfeq; rewrite Hev1, Hev2 in Hfeq.
      set (R1 := annot_count l es (S p1)) in *.
      set (R2 := annot_count l es (S p2)) in *.
      assert (HR1 : R1 < annot_count l ds (length ds)).
      { apply (Nat.lt_le_trans _ (annot_count l es (length es)) _);
          [ destruct Hr1 as [HSp [Hann _]]; apply (rank_lt_total l es (S p1) HSp Hann)
          | exact Hle_count ]. }
      assert (HR2 : R2 < annot_count l ds (length ds)).
      { apply (Nat.lt_le_trans _ (annot_count l es (length es)) _);
          [ destruct Hr2 as [HSp [Hann _]]; apply (rank_lt_total l es (S p2) HSp Hann)
          | exact Hle_count ]. }
      pose proof (annot_idx_pos l ds R1 Hpd HR1) as Hpos1.
      pose proof (annot_idx_pos l ds R2 Hpd HR2) as Hpos2.
      assert (Hidxeq : annot_idx l ds R1 = annot_idx l ds R2) by lia.
      pose proof (annot_idx_inj l ds R1 R2 HR1 HR2 Hidxeq) as HReq.
      assert (HSeq : S p1 = S p2)
        by (apply (is_nth_annot_unique l es R1 (S p1) (S p2) Hr1);
            rewrite HReq; exact Hr2).
      lia.
    + (* Ein, Eout *)
      exfalso.
      destruct (in_maps_into_rng l ds es alpha tM tf p1 l1 n1 Hlap Hcr HatM Hatf Hp1 Hev1)
        as [_ [m1 Hi1]].
      destruct (out_maps_into_strict l ds es alpha tM tf p2 l2 n2 Hlap Hcr HatM Hatf Hstrict Hp2 Hev2)
        as [_ [m2 Ho2]].
      unfold vmap in Hfeq; rewrite Hev1, Hev2 in Hfeq.
      rewrite Hfeq, Ho2 in Hi1. discriminate Hi1.
    + (* Eout, Ein *)
      exfalso.
      destruct (out_maps_into_strict l ds es alpha tM tf p1 l1 n1 Hlap Hcr HatM Hatf Hstrict Hp1 Hev1)
        as [_ [m1 Ho1]].
      destruct (in_maps_into_rng l ds es alpha tM tf p2 l2 n2 Hlap Hcr HatM Hatf Hp2 Hev2)
        as [_ [m2 Hi2]].
      unfold vmap in Hfeq; rewrite Hev1, Hev2 in Hfeq.
      rewrite Hfeq, Hi2 in Ho1. discriminate Ho1.
    + (* Eout, Eout *)
      pose proof (out_rank l es tf p1 l1 n1 Hpe Hatf Hp1 Hev1) as [Hp1ge Hr1].
      pose proof (out_rank l es tf p2 l2 n2 Hpe Hatf Hp2 Hev2) as [Hp2ge Hr2].
      unfold vmap in Hfeq; rewrite Hev1, Hev2 in Hfeq.
      set (R1 := annot_count l es (p1 - 2)) in *.
      set (R2 := annot_count l es (p2 - 2)) in *.
      assert (HR1 : R1 < annot_count l ds (length ds)).
      { apply (Nat.lt_le_trans _ (annot_count l es (length es)) _);
          [ destruct Hr1 as [Hlt [Hann _]]; apply (rank_lt_total l es (p1 - 2) Hlt Hann)
          | exact Hle_count ]. }
      assert (HR2 : R2 < annot_count l ds (length ds)).
      { apply (Nat.lt_le_trans _ (annot_count l es (length es)) _);
          [ destruct Hr2 as [Hlt [Hann _]]; apply (rank_lt_total l es (p2 - 2) Hlt Hann)
          | exact Hle_count ]. }
      assert (Hidxeq : annot_idx l ds R1 = annot_idx l ds R2) by lia.
      pose proof (annot_idx_inj l ds R1 R2 HR1 HR2 Hidxeq) as HReq.
      assert (Hp2eq : p1 - 2 = p2 - 2)
        by (apply (is_nth_annot_unique l es R1 (p1 - 2) (p2 - 2) Hr1);
            rewrite HReq; exact Hr2).
      lia.
Qed.

(* Structure at a visible OUTPUT position: the emitting Cout config at p and the
   paired assert (an l-annotation) at p-2. *)
Lemma vis_out_struct : forall l gs tg p l' n,
  pre_run gs -> admits_trace gs tg -> p < length tg -> vis_at l gs p = Some (Eout l' n) ->
  2 <= p /\ lleq l' l /\
  (exists cq sq e0 tk, cfg_at gs (p - 2) = Active cq sq /\ redex_cmd cq = Cassert l' tk (Ragr e0)) /\
  (exists cc sc e0, cfg_at gs p = Active cc sc /\ redex_cmd cc = Cout l' e0).
Proof.
  intros l gs tg p l' n Hpe Hat Hp Hvis.
  destruct (vis_at_sound l gs tg p (Eout l' n) Hat Hp Hvis) as [Hnthp Hvev].
  assert (Hle : lleq l' l).
  { destruct Hvev as [Hin | Hout].
    - destruct Hin as [l0 [n0 [Heq _]]]; discriminate Heq.
    - destruct Hout as [l2 [n2 [Heq Hl2]]]; injection Heq as Hl Hnn; subst l2; exact Hl2. }
  destruct (trace_output_cfg gs tg p l' n Hat Hp Hnthp) as [cc [s [e [Hcfgp [Hredcc Hn]]]]].
  assert (Hples : p < length gs)
    by (pose proof (admits_trace_length gs tg Hat) as Hlen; lia).
  destruct (prerun_output_pair_struct gs p cc s l' e Hpe Hples Hcfgp Hredcc)
    as [cq [cp [tq11 [Hp2 [Hesq [Hredq [Hesp1 Hredp]]]]]]].
  split; [exact Hp2 | split; [exact Hle | split]].
  - exists cq, s, e, tq11. split; [exact Hesq | exact Hredq].
  - exists cc, s, e. split; [exact Hcfgp | exact Hredcc].
Qed.

(* Structure at a visible INPUT position: the receptive config at p and the
   handler-entry assume (an l-annotation) at S p. *)
Lemma vis_in_struct : forall l gs tg p l' n,
  admits_trace gs tg -> p < length tg -> vis_at l gs p = Some (Ein l' n) ->
  lleq l' l /\
  (exists sr, cfg_at gs p = Receptive sr) /\
  (exists sb, cfg_at gs (S p) = Active (h_body (prog l')) sb) /\
  (exists tk, redex_cmd (h_body (prog l')) = Cassume l' tk (Ragr (EVar (h_var (prog l'))))).
Proof.
  intros l gs tg p l' n Hat Hp Hvis.
  destruct (vis_at_sound l gs tg p (Ein l' n) Hat Hp Hvis) as [Hnthp Hvev].
  assert (Hle : lleq l' l).
  { destruct Hvev as [Hin | Hout].
    - destruct Hin as [l2 [n2 [Heq Hl2]]]; injection Heq as Hl Hnn; subst l2; exact Hl2.
    - destruct Hout as [l0 [n0 [Heq _]]]; discriminate Heq. }
  destruct (trace_input_cfg gs tg p l' n Hat Hp Hnthp) as [s [Hcfgp HcfgSp]].
  destruct (prog_well_specified l') as [wtag [d [Hwb _]]].
  split; [exact Hle | split; [exists s; exact Hcfgp | split]].
  - exists (update s (h_var (prog l')) n). exact HcfgSp.
  - exists wtag. rewrite Hwb. reflexivity.
Qed.

(* An annotation's count strictly increases past it. *)
Lemma annot_count_realizer_lt : forall l gs r1 r2,
  redex_is_l_annotation l (cfg_at gs r1) -> r1 < r2 ->
  annot_count l gs r1 < annot_count l gs r2.
Proof.
  intros l gs r1 r2 Hann Hlt.
  pose proof (annot_count_annot_S l gs r1 Hann) as HS.
  pose proof (annot_count_mono l gs (S r1) r2 ltac:(lia)) as Hm. lia.
Qed.

(* MONOTONICITY of the realizer rank: for visible positions p1 < p2, the
   annotation rank of p1's realizer is strictly below that of p2's.  The only
   delicate case (input p1, output p2) uses that an output's assert config is an
   Active Cassert -- neither the receptive input-dispatch config nor the
   handler-entry assume -- so the output sits >= 3 positions after the input and
   realizer order follows event order.  The rank expressions match [vmap]'s. *)
Lemma vis_rrank_mono : forall l gs tg p1 p2 e1 e2,
  pre_run gs -> admits_trace gs tg ->
  p1 < length tg -> p2 < length tg ->
  vis_at l gs p1 = Some e1 -> vis_at l gs p2 = Some e2 -> p1 < p2 ->
  (match e1 with Eout _ _ => annot_count l gs (p1 - 2) | Ein _ _ => annot_count l gs (S p1) | Etick => 0 end)
  < (match e2 with Eout _ _ => annot_count l gs (p2 - 2) | Ein _ _ => annot_count l gs (S p2) | Etick => 0 end).
Proof.
  intros l gs tg p1 p2 e1 e2 Hpe Hat Hp1 Hp2 Hv1 Hv2 Hlt.
  destruct e1 as [l1 n1 | l1 n1 | ]; destruct e2 as [l2 n2 | l2 n2 | ];
    try (exfalso;
      match goal with
      | Hv : vis_at l gs ?p = Some Etick |- _ =>
        destruct (vis_at_sound l gs tg p Etick Hat ltac:(assumption) Hv) as [_ Hvev];
        destruct Hvev as [[? [? [Hc _]]] | [? [? [Hc _]]]]; discriminate Hc
      end).
  - (* Ein p1, Ein p2 *)
    destruct (vis_in_struct l gs tg p1 l1 n1 Hat Hp1 Hv1)
      as [Hle1 [[sr1 Hrec1] [[sb1 Hbody1] [tkh1 Hredh1]]]].
    assert (Hann1 : redex_is_l_annotation l (cfg_at gs (S p1))).
    { unfold redex_is_l_annotation. rewrite Hbody1. simpl. rewrite Hredh1.
      unfold is_l_annotation. left. simpl. exact Hle1. }
    apply (annot_count_realizer_lt l gs (S p1) (S p2) Hann1 ltac:(lia)).
  - (* Ein p1, Eout p2 -- the delicate case *)
    destruct (vis_in_struct l gs tg p1 l1 n1 Hat Hp1 Hv1)
      as [Hle1 [[sr1 Hrec1] [[sb1 Hbody1] [tkh1 Hredh1]]]].
    destruct (vis_out_struct l gs tg p2 l2 n2 Hpe Hat Hp2 Hv2)
      as [Hp2ge [Hle2 [[cq2 [sq2 [e02 [tq2 [Hcfgq2 Hredq2]]]]] [cc2 [sc2 [e02' [Hcfgp2 Hredc2]]]]]]].
    assert (Hann1 : redex_is_l_annotation l (cfg_at gs (S p1))).
    { unfold redex_is_l_annotation. rewrite Hbody1. simpl. rewrite Hredh1.
      unfold is_l_annotation. left. simpl. exact Hle1. }
    assert (Hord : S p1 < p2 - 2).
    { destruct (Nat.le_gt_cases (p2 - 2) (S p1)) as [Hle' | Hgt]; [| exact Hgt].
      exfalso.
      assert (Hcases : p2 = S p1 \/ p2 = S (S p1) \/ p2 = S (S (S p1))) by lia.
      destruct Hcases as [He | [He | He]].
      - rewrite He in Hcfgp2. rewrite Hbody1 in Hcfgp2.
        injection Hcfgp2 as Hcc Hss. subst cc2. rewrite Hredh1 in Hredc2. discriminate Hredc2.
      - assert (Hp22 : p2 - 2 = p1) by lia. rewrite Hp22 in Hcfgq2.
        rewrite Hrec1 in Hcfgq2. discriminate Hcfgq2.
      - assert (Hp22 : p2 - 2 = S p1) by lia. rewrite Hp22 in Hcfgq2.
        rewrite Hbody1 in Hcfgq2. injection Hcfgq2 as Hcc Hss. subst cq2.
        rewrite Hredh1 in Hredq2. discriminate Hredq2. }
    apply (annot_count_realizer_lt l gs (S p1) (p2 - 2) Hann1 Hord).
  - (* Eout p1, Ein p2 *)
    destruct (vis_out_struct l gs tg p1 l1 n1 Hpe Hat Hp1 Hv1)
      as [Hp1ge [Hle1 [[cq1 [sq1 [e01 [tq1a [Hcfgq1 Hredq1]]]]] _]]].
    assert (Hann1 : redex_is_l_annotation l (cfg_at gs (p1 - 2))).
    { unfold redex_is_l_annotation. rewrite Hcfgq1. simpl. rewrite Hredq1.
      unfold is_l_annotation. right. simpl. exact Hle1. }
    apply (annot_count_realizer_lt l gs (p1 - 2) (S p2) Hann1 ltac:(lia)).
  - (* Eout p1, Eout p2 *)
    destruct (vis_out_struct l gs tg p1 l1 n1 Hpe Hat Hp1 Hv1)
      as [Hp1ge [Hle1 [[cq1 [sq1 [e01 [tq1a [Hcfgq1 Hredq1]]]]] _]]].
    destruct (vis_out_struct l gs tg p2 l2 n2 Hpe Hat Hp2 Hv2) as [Hp2ge _].
    assert (Hann1 : redex_is_l_annotation l (cfg_at gs (p1 - 2))).
    { unfold redex_is_l_annotation. rewrite Hcfgq1. simpl. rewrite Hredq1.
      unfold is_l_annotation. right. simpl. exact Hle1. }
    apply (annot_count_realizer_lt l gs (p1 - 2) (p2 - 2) Hann1 ltac:(lia)).
Qed.

(* The image vmap p is a visible position of ds whose OWN realizer rank equals
   es's realizer rank at p.  (Outputs land at annot_idx+2, inputs at annot_idx-1;
   either way the rank reads back as the matched annotation rank.) *)
Lemma vmap_rrank_strict : forall l ds es alpha tM tf p e,
  l_aligned_pair l ds es alpha -> covers_rng es alpha ->
  admits_trace ds tM -> admits_trace es tf ->
  annot_count l es (length es) < annot_count l ds (length ds) ->
  p < length tf -> vis_at l es p = Some e ->
  vmap l ds es p < length tM /\
  exists e', vis_at l ds (vmap l ds es p) = Some e' /\
    (match e' with Eout _ _ => annot_count l ds (vmap l ds es p - 2)
                | Ein _ _ => annot_count l ds (S (vmap l ds es p))
                | Etick => 0 end)
    = (match e with Eout _ _ => annot_count l es (p - 2)
                | Ein _ _ => annot_count l es (S p)
                | Etick => 0 end).
Proof.
  intros l ds es alpha tM tf p e Hlap Hcr HatM Hatf Hstrict Hp Hvis.
  assert (Hpd : pre_run ds) by (destruct Hlap as [H _]; exact H).
  assert (Hpe : pre_run es) by (destruct Hlap as [_ [H _]]; exact H).
  destruct e as [l' n | l' n | ].
  - (* Ein *)
    destruct (vis_in_struct l es tf p l' n Hatf Hp Hvis) as [Hle [_ [[sb HcfgSp] [tkh Hredh]]]].
    assert (HannSp : redex_is_l_annotation l (cfg_at es (S p))).
    { unfold redex_is_l_annotation. rewrite HcfgSp. simpl. rewrite Hredh.
      unfold is_l_annotation. left. simpl. exact Hle. }
    assert (HSplt : S p < length es)
      by (apply (cfg_at_active_lt es (S p) (h_body (prog l')) sb HcfgSp)).
    assert (Hr_ds : annot_count l es (S p) < annot_count l ds (length ds))
      by (pose proof (rank_lt_total l es (S p) HSplt HannSp) as Hh; lia).
    destruct (in_maps_into_rng l ds es alpha tM tf p l' n Hlap Hcr HatM Hatf Hp Hvis)
      as [Hlt [m Hsome]].
    assert (Hvmap : vmap l ds es p = annot_idx l ds (annot_count l es (S p)) - 1)
      by (unfold vmap; rewrite Hvis; reflexivity).
    pose proof (annot_idx_is_nth l ds (annot_count l es (S p)) Hr_ds) as [_ [_ Hcnti]].
    pose proof (annot_idx_pos l ds (annot_count l es (S p)) Hpd Hr_ds) as Hipos.
    set (i := annot_idx l ds (annot_count l es (S p))) in *.
    rewrite Hvmap. split; [exact Hlt |].
    exists (Ein l' m). split; [exact Hsome |].
    replace (S (i - 1)) with i by lia. exact Hcnti.
  - (* Eout *)
    destruct (vis_out_struct l es tf p l' n Hpe Hatf Hp Hvis)
      as [Hp2 [Hle [[cq [sq [e0 [tq0 [Hcfgq Hredq]]]]] _]]].
    assert (Hannp2 : redex_is_l_annotation l (cfg_at es (p - 2))).
    { unfold redex_is_l_annotation. rewrite Hcfgq. simpl. rewrite Hredq.
      unfold is_l_annotation. right. simpl. exact Hle. }
    assert (Hp2lt : p - 2 < length es)
      by (pose proof (admits_trace_length es tf Hatf) as HeM; lia).
    assert (Hr_ds : annot_count l es (p - 2) < annot_count l ds (length ds))
      by (pose proof (rank_lt_total l es (p - 2) Hp2lt Hannp2) as Hh; lia).
    destruct (out_maps_into_strict l ds es alpha tM tf p l' n Hlap Hcr HatM Hatf Hstrict Hp Hvis)
      as [Hlt [m Hsome]].
    assert (Hvmap : vmap l ds es p = S (S (annot_idx l ds (annot_count l es (p - 2)))))
      by (unfold vmap; rewrite Hvis; reflexivity).
    pose proof (annot_idx_is_nth l ds (annot_count l es (p - 2)) Hr_ds) as [_ [_ Hcnti]].
    set (i := annot_idx l ds (annot_count l es (p - 2))) in *.
    rewrite Hvmap. split; [exact Hlt |].
    exists (Eout l' m). split; [exact Hsome |].
    replace (S (S i) - 2) with i by lia. exact Hcnti.
  - (* Etick: impossible *)
    exfalso. destruct (vis_at_sound l es tf p Etick Hatf Hp Hvis) as [_ Hvev].
    destruct Hvev as [[? [? [Hc _]]] | [? [? [Hc _]]]]; discriminate Hc.
Qed.

(* Local-bound version of vmap_rrank_strict: realizes an es visible position in
   ds from a LOCAL "next rank exists" bound on outputs (inputs are always
   realized), rather than a global strict count.  Used in the no-gap argument. *)
Lemma vmap_rrank_local : forall l ds es alpha tM tf p e,
  l_aligned_pair l ds es alpha -> covers_rng es alpha ->
  admits_trace ds tM -> admits_trace es tf ->
  p < length tf -> vis_at l es p = Some e ->
  (forall lo no, e = Eout lo no -> S (annot_count l es (p - 2)) < annot_count l ds (length ds)) ->
  vmap l ds es p < length tM /\
  exists e', vis_at l ds (vmap l ds es p) = Some e' /\
    (match e' with Eout _ _ => annot_count l ds (vmap l ds es p - 2)
                | Ein _ _ => annot_count l ds (S (vmap l ds es p))
                | Etick => 0 end)
    = (match e with Eout _ _ => annot_count l es (p - 2)
                | Ein _ _ => annot_count l es (S p)
                | Etick => 0 end).
Proof.
  intros l ds es alpha tM tf p e Hlap Hcr HatM Hatf Hp Hvis Hbound.
  assert (Hpd : pre_run ds) by (destruct Hlap as [H _]; exact H).
  assert (Hpe : pre_run es) by (destruct Hlap as [_ [H _]]; exact H).
  destruct e as [l' n | l' n | ].
  - (* Ein *)
    destruct (vis_in_struct l es tf p l' n Hatf Hp Hvis) as [Hle [_ [[sb HcfgSp] [tkh Hredh]]]].
    assert (HannSp : redex_is_l_annotation l (cfg_at es (S p))).
    { unfold redex_is_l_annotation. rewrite HcfgSp. simpl. rewrite Hredh.
      unfold is_l_annotation. left. simpl. exact Hle. }
    assert (HSplt : S p < length es)
      by (apply (cfg_at_active_lt es (S p) (h_body (prog l')) sb HcfgSp)).
    assert (Hnth_es : is_nth_annot l es (annot_count l es (S p)) (S p))
      by (unfold is_nth_annot; split; [exact HSplt | split; [exact HannSp | reflexivity]]).
    destruct (minor_major_rank_rng l ds es alpha (annot_count l es (S p)) (S p) Hlap Hcr Hnth_es)
      as [i0 [_ [Hnthds0 _]]].
    assert (Hr_ds : annot_count l es (S p) < annot_count l ds (length ds)).
    { destruct Hnthds0 as [Hi0lt [Hann0 Hcnt0]].
      pose proof (annot_count_annot_S l ds i0 Hann0) as HS.
      pose proof (annot_count_mono l ds (S i0) (length ds) ltac:(lia)) as Hm. lia. }
    destruct (in_maps_into_rng l ds es alpha tM tf p l' n Hlap Hcr HatM Hatf Hp Hvis)
      as [Hlt [m Hsome]].
    assert (Hvmap : vmap l ds es p = annot_idx l ds (annot_count l es (S p)) - 1)
      by (unfold vmap; rewrite Hvis; reflexivity).
    pose proof (annot_idx_is_nth l ds (annot_count l es (S p)) Hr_ds) as [_ [_ Hcnti]].
    pose proof (annot_idx_pos l ds (annot_count l es (S p)) Hpd Hr_ds) as Hipos.
    set (i := annot_idx l ds (annot_count l es (S p))) in *.
    rewrite Hvmap. split; [exact Hlt |].
    exists (Ein l' m). split; [exact Hsome |].
    replace (S (i - 1)) with i by lia. exact Hcnti.
  - (* Eout *)
    destruct (vis_out_struct l es tf p l' n Hpe Hatf Hp Hvis)
      as [Hp2 [Hle [[cq [sq [e0 [tq0 [Hcfgq Hredq]]]]] _]]].
    assert (Hannp2 : redex_is_l_annotation l (cfg_at es (p - 2))).
    { unfold redex_is_l_annotation. rewrite Hcfgq. simpl. rewrite Hredq.
      unfold is_l_annotation. right. simpl. exact Hle. }
    assert (Hp2lt : p - 2 < length es)
      by (pose proof (admits_trace_length es tf Hatf) as HeM; lia).
    assert (Hbnd : S (annot_count l es (p - 2)) < annot_count l ds (length ds))
      by (apply (Hbound l' n); reflexivity).
    assert (Hr_ds : annot_count l es (p - 2) < annot_count l ds (length ds)) by lia.
    destruct (out_maps_into_local l ds es alpha tM tf p l' n Hlap Hcr HatM Hatf Hbnd Hp Hvis)
      as [Hlt [m Hsome]].
    assert (Hvmap : vmap l ds es p = S (S (annot_idx l ds (annot_count l es (p - 2)))))
      by (unfold vmap; rewrite Hvis; reflexivity).
    pose proof (annot_idx_is_nth l ds (annot_count l es (p - 2)) Hr_ds) as [_ [_ Hcnti]].
    set (i := annot_idx l ds (annot_count l es (p - 2))) in *.
    rewrite Hvmap. split; [exact Hlt |].
    exists (Eout l' m). split; [exact Hsome |].
    replace (S (S i) - 2) with i by lia. exact Hcnti.
  - (* Etick *)
    exfalso. destruct (vis_at_sound l es tf p Etick Hatf Hp Hvis) as [_ Hvev].
    destruct Hvev as [[? [? [Hc _]]] | [? [? [Hc _]]]]; discriminate Hc.
Qed.

(* vmap is MONOTONE on es's visible positions: order-preserving into ds's visible
   positions.  Proof: rrank_ds(vmap p) = rrank_es(p) (vmap_rrank_strict), which is
   strictly increasing in p (vis_rrank_mono on es), and rrank is order-reflecting
   on ds (vis_rrank_mono on ds), so the images keep the order. *)
Lemma vmap_mono_strict : forall l ds es alpha tM tf p1 p2 e1 e2,
  l_aligned_pair l ds es alpha -> covers_rng es alpha ->
  admits_trace ds tM -> admits_trace es tf ->
  annot_count l es (length es) < annot_count l ds (length ds) ->
  p1 < length tf -> p2 < length tf ->
  vis_at l es p1 = Some e1 -> vis_at l es p2 = Some e2 -> p1 < p2 ->
  vmap l ds es p1 < vmap l ds es p2.
Proof.
  intros l ds es alpha tM tf p1 p2 e1 e2 Hlap Hcr HatM Hatf Hstrict Hp1 Hp2 Hv1 Hv2 Hlt.
  assert (Hpe : pre_run es) by (destruct Hlap as [_ [H _]]; exact H).
  assert (Hpd : pre_run ds) by (destruct Hlap as [H _]; exact H).
  destruct (vmap_rrank_strict l ds es alpha tM tf p1 e1 Hlap Hcr HatM Hatf Hstrict Hp1 Hv1)
    as [Hq1lt [e1' [Hq1vis Hrr1]]].
  destruct (vmap_rrank_strict l ds es alpha tM tf p2 e2 Hlap Hcr HatM Hatf Hstrict Hp2 Hv2)
    as [Hq2lt [e2' [Hq2vis Hrr2]]].
  pose proof (vis_rrank_mono l es tf p1 p2 e1 e2 Hpe Hatf Hp1 Hp2 Hv1 Hv2 Hlt) as Hrrmono.
  set (q1 := vmap l ds es p1) in *. set (q2 := vmap l ds es p2) in *.
  destruct (Nat.lt_trichotomy q1 q2) as [Hlt' | [Heq | Hgt']].
  - exact Hlt'.
  - exfalso.
    rewrite Heq in Hq1vis, Hrr1.
    rewrite Hq1vis in Hq2vis. injection Hq2vis as He. subst e1'.
    rewrite Hrr2 in Hrr1. lia.
  - exfalso.
    pose proof (vis_rrank_mono l ds tM q2 q1 e2' e1' Hpd HatM Hq2lt Hq1lt Hq2vis Hq1vis Hgt')
      as Hcontra.
    lia.
Qed.

(* vmap is EVENT-preserving: the ds-event at vmap p equals the es-event at p.
   Levels match by construction (out/in_maps); values by conf_annot_value at the
   matched assert/entry-assume (states shared with the realized output/input). *)
Lemma vmap_event_eq : forall l ins ds es alpha tM tf p e,
  conformance l ins ds es alpha ->
  admits_trace ds tM -> admits_trace es tf ->
  annot_count l es (length es) < annot_count l ds (length ds) ->
  p < length tf -> vis_at l es p = Some e ->
  vis_at l ds (vmap l ds es p) = Some e.
Proof.
  intros l ins ds es alpha tM tf p e Hconf HatM Hatf Hstrict Hp Hvis.
  assert (Hlap : l_aligned_pair l ds es alpha) by (destruct Hconf as [H _]; exact H).
  assert (Hcr : covers_rng es alpha) by (destruct Hconf as [_ [_ [H _]]]; exact H).
  assert (Hpd : pre_run ds) by (destruct Hlap as [H _]; exact H).
  assert (Hpe : pre_run es) by (destruct Hlap as [_ [H _]]; exact H).
  destruct e as [l' n | l' n | ].
  - (* Ein l' n *)
    destruct (vis_at_sound l es tf p (Ein l' n) Hatf Hp Hvis) as [Hnthp Hvev].
    assert (Hle : lleq l' l).
    { destruct Hvev as [Hin | Hout];
        [destruct Hin as [l2 [n2 [Heq Hl2]]]; injection Heq as Hl Hnn; subst l2; exact Hl2
        | destruct Hout as [? [? [Hc _]]]; discriminate Hc]. }
    destruct (trace_input_cfg es tf p l' n Hatf Hp Hnthp) as [s [Hcfgp HcfgSp]].
    destruct (prog_well_specified l') as [wtag [d [Hwb _]]].
    assert (HredhS : redex_cmd (h_body (prog l')) = Cassume l' wtag (Ragr (EVar (h_var (prog l')))))
      by (rewrite Hwb; reflexivity).
    assert (HannSp : redex_is_l_annotation l (cfg_at es (S p)))
      by (unfold redex_is_l_annotation; rewrite HcfgSp; simpl; rewrite HredhS;
          unfold is_l_annotation; left; simpl; exact Hle).
    assert (HSplt : S p < length es)
      by (apply (cfg_at_active_lt es (S p) (h_body (prog l')) _ HcfgSp)).
    assert (Hnth_es : is_nth_annot l es (annot_count l es (S p)) (S p))
      by (unfold is_nth_annot; split; [exact HSplt | split; [exact HannSp | reflexivity]]).
    destruct (minor_major_rank_rng l ds es alpha (annot_count l es (S p)) (S p) Hlap Hcr Hnth_es)
      as [i [Haip [Hnthds Hcmdeq]]].
    pose proof Hnthds as [Hilt [Hannds Hcnt]].
    assert (HrC : annot_count l es (S p) < annot_count l ds (length ds))
      by (pose proof (annot_count_annot_S l ds i Hannds);
          pose proof (annot_count_mono l ds (S i) (length ds) ltac:(lia)); lia).
    assert (Hidx : i = annot_idx l ds (annot_count l es (S p)))
      by (apply (is_nth_annot_unique l ds (annot_count l es (S p)) i _ Hnthds
                   (annot_idx_is_nth l ds _ HrC))).
    assert (Hipos : 1 <= i) by (rewrite Hidx; apply (annot_idx_pos l ds _ Hpd HrC)).
    assert (Hvmap : vmap l ds es p = i - 1) by (unfold vmap; rewrite Hvis, <- Hidx; reflexivity).
    rewrite HcfgSp in Hcmdeq. simpl in Hcmdeq.
    destruct (cfg_at ds i) as [srM | ccM sM] eqn:Hdci; [simpl in Hcmdeq; discriminate Hcmdeq |].
    simpl in Hcmdeq. injection Hcmdeq as Hccm. subst ccM.
    pose proof (input_realize_ds l ds tM i l' sM HatM Hdci Hilt Hle) as Hvisi.
    assert (HredM_i : redex_of (cfg_at ds i) = Some (Cassume l' wtag (Ragr (EVar (h_var (prog l'))))))
      by (rewrite Hdci; unfold redex_of; rewrite HredhS; reflexivity).
    pose proof (conf_annot_value l ins ds es alpha i (S p) l' wtag (EVar (h_var (prog l')))
                  Hconf Haip (or_introl HredM_i) Hle) as Hval.
    rewrite Hvmap, Hvisi. f_equal. f_equal.
    rewrite Hdci, HcfgSp in Hval. simpl in Hval.
    simpl. rewrite Hval. apply update_eq.
  - (* Eout l' n *)
    destruct (vis_at_sound l es tf p (Eout l' n) Hatf Hp Hvis) as [Hnthp Hvev].
    assert (Hle : lleq l' l).
    { destruct Hvev as [Hin | Hout];
        [destruct Hin as [? [? [Hc _]]]; discriminate Hc
        | destruct Hout as [l2 [n2 [Heq Hl2]]]; injection Heq as Hl Hnn; subst l2; exact Hl2]. }
    destruct (trace_output_cfg es tf p l' n Hatf Hp Hnthp) as [cc [s [e [Hcfgp [Hredc Hn]]]]].
    assert (Hples : p < length es) by (pose proof (admits_trace_length es tf Hatf); lia).
    destruct (prerun_output_pair_struct es p cc s l' e Hpe Hples Hcfgp Hredc)
      as [cq [cp [tq12 [Hp2 [Hcfgq [Hredq [_ _]]]]]]].
    assert (Hannp2 : redex_is_l_annotation l (cfg_at es (p - 2)))
      by (unfold redex_is_l_annotation; rewrite Hcfgq; simpl; rewrite Hredq;
          unfold is_l_annotation; right; simpl; exact Hle).
    assert (Hnth_es : is_nth_annot l es (annot_count l es (p - 2)) (p - 2))
      by (unfold is_nth_annot; split; [lia | split; [exact Hannp2 | reflexivity]]).
    destruct (minor_major_rank_rng l ds es alpha (annot_count l es (p - 2)) (p - 2) Hlap Hcr Hnth_es)
      as [i [Haip [Hnthds Hcmdeq]]].
    pose proof Hnthds as [Hilt [Hannds Hcnt]].
    assert (HrC : annot_count l es (p - 2) < annot_count l ds (length ds))
      by (pose proof (annot_count_annot_S l ds i Hannds);
          pose proof (annot_count_mono l ds (S i) (length ds) ltac:(lia)); lia).
    assert (Hidx : i = annot_idx l ds (annot_count l es (p - 2)))
      by (apply (is_nth_annot_unique l ds (annot_count l es (p - 2)) i _ Hnthds
                   (annot_idx_is_nth l ds _ HrC))).
    assert (Hvmap : vmap l ds es p = S (S i)) by (unfold vmap; rewrite Hvis, <- Hidx; reflexivity).
    destruct (out_maps_into_strict l ds es alpha tM tf p l' n Hlap Hcr HatM Hatf Hstrict Hp Hvis)
      as [Hvlt _].
    rewrite <- Hidx in Hvlt.
    assert (HSSilt : S (S i) < length ds)
      by (pose proof (admits_trace_length ds tM HatM); lia).
    destruct (output_realize_cross ds es i p cc s l' e Hpd Hpe Hcfgp Hredc Hples Hcmdeq HSSilt)
      as [_ Hout].
    destruct (cfg_at ds (S (S i))) as [srM | ccM sM] eqn:HcfgSSi;
      [simpl in Hout; discriminate Hout |].
    assert (HredcM : redex_cmd ccM = Cout l' e)
      by (simpl in Hout; injection Hout as Hrc; exact Hrc).
    rewrite <- HcfgSSi in Hout.
    destruct (prerun_output_pair_struct ds (S (S i)) ccM sM l' e Hpd HSSilt HcfgSSi HredcM)
      as [cqM [cpM [tq13 [_ [HcfgqM [HredqM [_ _]]]]]]].
    assert (Hi2 : S (S i) - 2 = i) by lia. rewrite Hi2 in HcfgqM.
    assert (HredM_i : redex_of (cfg_at ds i) = Some (Cassert l' tq13 (Ragr e)))
      by (rewrite HcfgqM; unfold redex_of; rewrite HredqM; reflexivity).
    pose proof (conf_annot_value l ins ds es alpha i (p - 2) l' tq13 e
                  Hconf Haip (or_intror HredM_i) Hle) as Hval.
    pose proof (vis_at_out_some l ds (S (S i)) l' e Hout Hle) as Hvisout.
    rewrite Hvmap, Hvisout, HcfgSSi. simpl.
    rewrite HcfgqM, Hcfgq in Hval. simpl in Hval.
    rewrite Hval, <- Hn. reflexivity.
  - (* Etick: impossible *)
    exfalso. destruct (vis_at_sound l es tf p Etick Hatf Hp Hvis) as [_ Hvev].
    destruct Hvev as [[? [? [Hc _]]] | [? [? [Hc _]]]]; discriminate Hc.
Qed.

(* ---- A small strictly-increasing-list toolkit, to turn the monotone bijection
   [vmap] between the two visible-position lists into a list equality. ---- *)
Fixpoint ascending (L : list nat) : Prop :=
  match L with
  | [] => True
  | x :: r => (forall y, In y r -> x < y) /\ ascending r
  end.

Lemma ascending_NoDup : forall L, ascending L -> NoDup L.
Proof.
  induction L as [|x r IH]; intros Hasc; [constructor |].
  destruct Hasc as [Hhd Hr]. constructor.
  - intro Hin. pose proof (Hhd x Hin). lia.
  - apply IH; exact Hr.
Qed.

Lemma ascending_incl_eq : forall L1 L2,
  ascending L1 -> ascending L2 -> incl L1 L2 -> length L1 = length L2 -> L1 = L2.
Proof.
  induction L1 as [|x r1 IH]; intros L2 Hasc1 Hasc2 Hincl Hlen.
  - destruct L2; [reflexivity | simpl in Hlen; discriminate].
  - destruct L2 as [|y r2]; [simpl in Hlen; discriminate |].
    destruct Hasc1 as [Hhd1 Hr1]. destruct Hasc2 as [Hhd2 Hr2].
    assert (HND1 : NoDup (x :: r1)) by (apply ascending_NoDup; split; assumption).
    assert (Hincl2 : incl (y :: r2) (x :: r1))
      by (apply (NoDup_length_incl HND1); [simpl in Hlen |- *; lia | exact Hincl]).
    assert (Hxy : x = y).
    { assert (Hxin : In x (y :: r2)) by (apply Hincl; left; reflexivity).
      assert (Hyin : In y (x :: r1)) by (apply Hincl2; left; reflexivity).
      destruct Hxin as [Hxy | Hxr2]; [symmetry; exact Hxy |].
      destruct Hyin as [Hyx | Hyr1]; [exact Hyx |].
      exfalso. pose proof (Hhd2 x Hxr2). pose proof (Hhd1 y Hyr1). lia. }
    subst y. f_equal.
    assert (Hinclr : incl r1 r2).
    { intros a Hain.
      assert (Hax : a <> x) by (intro Heq; subst a; pose proof (Hhd1 x Hain); lia).
      assert (Hax2 : In a (x :: r2)) by (apply Hincl; right; exact Hain).
      destruct Hax2 as [Hxa | Har2]; [exfalso; apply Hax; symmetry; exact Hxa | exact Har2]. }
    apply IH; [exact Hr1 | exact Hr2 | exact Hinclr | simpl in Hlen; lia].
Qed.

Lemma seq_ascending : forall N a, ascending (seq a N).
Proof.
  induction N as [|N IH]; intros a; [exact I |].
  simpl. split; [intros y Hy; apply in_seq in Hy; lia | apply IH].
Qed.

Lemma ascending_filter : forall (P : nat -> bool) L, ascending L -> ascending (filter P L).
Proof.
  induction L as [|x r IH]; intros Hasc; [exact I |].
  destruct Hasc as [Hhd Hr]. simpl. destruct (P x).
  - simpl. split; [intros y Hy; apply filter_In in Hy; apply Hhd; exact (proj1 Hy) | apply IH; exact Hr].
  - apply IH; exact Hr.
Qed.

Lemma ascending_map_mono : forall (f : nat -> nat) L,
  ascending L ->
  (forall x y, In x L -> In y L -> x < y -> f x < f y) ->
  ascending (map f L).
Proof.
  induction L as [|x r IH]; intros Hasc Hmono; [exact I |].
  destruct Hasc as [Hhd Hr]. simpl. split.
  - intros z Hz. apply in_map_iff in Hz. destruct Hz as [y [Hfy Hyin]].
    subst z. apply Hmono; [left; reflexivity | right; exact Hyin | apply Hhd; exact Hyin].
  - apply IH; [exact Hr | intros a b Ha Hb Hab; apply Hmono; [right; exact Ha | right; exact Hb | exact Hab]].
Qed.

(* collect_opt of a per-index option map equals the value-map over the
   firing-index list. *)
Lemma collect_opt_filter : forall (A : Type) (h : nat -> option A) (d : A) (xs : list nat),
  collect_opt (map h xs) =
  map (fun x => match h x with Some a => a | None => d end)
      (filter (fun x => match h x with Some _ => true | None => false end) xs).
Proof.
  intros A h d xs. induction xs as [|x xs IH]; [reflexivity |].
  simpl. destruct (h x) as [a|] eqn:Hhx; simpl; rewrite ?Hhx, ?IH; reflexivity.
Qed.

(* THE BRIDGE (strict-count form): the minor reproduces the major's whole visible
   trace.  [vmap] is a monotone (vmap_mono_strict), injective, event-preserving
   (vmap_event_eq) bijection between the two visible-position lists (equal length
   from the two count bounds), so the visible traces are equal element-by-element. *)
Lemma vis_bridge_strict : forall l ins ds es alpha tM tf,
  conformance l ins ds es alpha ->
  admits_trace ds tM -> admits_trace es tf ->
  annot_count l es (length es) < annot_count l ds (length ds) ->
  length (vis l tM) <= length (vis l tf) ->
  vis l tf = vis l tM.
Proof.
  intros l ins ds es alpha tM tf Hconf HatM Hatf Hstrict Hge.
  assert (Hlap : l_aligned_pair l ds es alpha) by (destruct Hconf as [H _]; exact H).
  assert (Hcr : covers_rng es alpha) by (destruct Hconf as [_ [_ [H _]]]; exact H).
  pose proof (minor_vis_le_strict l ds es alpha tM tf Hlap Hcr HatM Hatf Hstrict) as Hle.
  assert (Hlen_eq : length (vis l tf) = length (vis l tM)) by lia.
  assert (HmapAB :
    map (vmap l ds es)
        (filter (fun p => match vis_at l es p with Some _ => true | None => false end)
                (seq 0 (length tf)))
    = filter (fun p => match vis_at l ds p with Some _ => true | None => false end)
             (seq 0 (length tM))).
  { apply ascending_incl_eq.
    - apply ascending_map_mono; [apply ascending_filter, seq_ascending |].
      intros x y Hx Hy Hxy.
      apply (in_filter_seq_isSome event (vis_at l es) (length tf) x) in Hx.
      apply (in_filter_seq_isSome event (vis_at l es) (length tf) y) in Hy.
      destruct Hx as [Hxlt [ex Hex]]. destruct Hy as [Hylt [ey Hey]].
      exact (vmap_mono_strict l ds es alpha tM tf x y ex ey
               Hlap Hcr HatM Hatf Hstrict Hxlt Hylt Hex Hey Hxy).
    - apply ascending_filter, seq_ascending.
    - intros z Hz. apply in_map_iff in Hz. destruct Hz as [a [Hva Ha]]. subst z.
      apply (in_filter_seq_isSome event (vis_at l es) (length tf) a) in Ha.
      destruct Ha as [Halt [ea Hea]].
      apply (in_filter_seq_isSome event (vis_at l ds) (length tM) (vmap l ds es a)).
      destruct (vmap_rrank_strict l ds es alpha tM tf a ea
                  Hlap Hcr HatM Hatf Hstrict Halt Hea) as [Hvlt [e' [Hvis' _]]].
      split; [exact Hvlt | exists e'; exact Hvis'].
    - rewrite length_map.
      rewrite <- (vis_length_positions l es tf Hatf), <- (vis_length_positions l ds tM HatM).
      exact Hlen_eq. }
  rewrite (vis_eq_collect l es tf Hatf), (vis_eq_collect l ds tM HatM).
  rewrite (collect_opt_filter event (vis_at l es) Etick (seq 0 (length tf))).
  rewrite (collect_opt_filter event (vis_at l ds) Etick (seq 0 (length tM))).
  rewrite <- HmapAB, map_map.
  apply map_ext_in. intros a Ha.
  apply (in_filter_seq_isSome event (vis_at l es) (length tf) a) in Ha.
  destruct Ha as [Halt [ea Hea]].
  pose proof (vmap_event_eq l ins ds es alpha tM tf a ea Hconf HatM Hatf Hstrict Halt Hea) as Hev.
  rewrite Hea, Hev. reflexivity.
Qed.

(* Two pre-runs whose trace-inputs are prefixes of a common [ins] have
   prefix-comparable traces: the shorter run's trace is a prefix of the longer
   run's (both are prefixes of the unique canonical execution of [ins]). *)
Lemma prerun_trace_prefix : forall ins a tha b thb,
  Forall is_input ins ->
  admits_trace a tha -> list_prefix (inputs tha) ins ->
  admits_trace b thb -> list_prefix (inputs thb) ins ->
  length a <= length b ->
  list_prefix tha thb.
Proof.
  intros ins a tha b thb Hforall Hata Hpa Hatb Hpb Hlen.
  destruct (prerun_is_frun a tha ins Hata Hforall Hpa) as [_ [_ Htha]].
  destruct (prerun_is_frun b thb ins Hatb Hforall Hpb) as [_ [_ Hthb]].
  assert (Htf : tha = firstn (length a - 1) thb).
  { rewrite Htha, Hthb.
    rewrite <- (frun_firstn (length b - 1) (length a - 1) (Receptive initState) ins ltac:(lia)).
    rewrite firstn_map. reflexivity. }
  exists (skipn (length a - 1) thb).
  rewrite Htf. symmetry. apply firstn_skipn.
Qed.

(* Config-list version of prerun_trace_prefix: the shorter run's CONFIG list is a
   prefix of the longer's (both unfold the same canonical [frun]).  Used to make
   the maximal run on [ins] extend the conformance minor config-for-config. *)
Lemma prerun_config_prefix : forall ins a tha b thb,
  Forall is_input ins ->
  admits_trace a tha -> list_prefix (inputs tha) ins ->
  admits_trace b thb -> list_prefix (inputs thb) ins ->
  length a <= length b ->
  exists ex, b = a ++ ex.
Proof.
  intros ins a tha b thb Hforall Hata Hpa Hatb Hpb Hlen.
  destruct (prerun_is_frun a tha ins Hata Hforall Hpa) as [_ [Hga _]].
  destruct (prerun_is_frun b thb ins Hatb Hforall Hpb) as [_ [Hgb _]].
  set (Fb := frun (Receptive initState) ins (length b - 1)) in *.
  assert (HFa : frun (Receptive initState) ins (length a - 1) = firstn (length a - 1) Fb)
    by (symmetry; apply (frun_firstn (length b - 1) (length a - 1) (Receptive initState) ins ltac:(lia))).
  set (k := length a - 1) in *.
  exists (map snd (skipn k Fb)).
  rewrite Hgb, Hga, HFa, <- app_comm_cons. f_equal.
  rewrite <- (firstn_skipn k Fb) at 1. rewrite map_app. reflexivity.
Qed.

Lemma admits_trace_firstn_full : forall gs evs n,
  admits_trace gs evs -> n < length gs -> admits_trace (firstn (S n) gs) (firstn n evs).
Proof.
  intros gs evs n Hat. revert n. induction Hat as [| gs0 evs0 ev g' Hat IH Hstep]; intros n Hn.
  - simpl in Hn. assert (n = 0) by lia. subst n. simpl. apply AT_init.
  - rewrite length_app in Hn. simpl in Hn.
    pose proof (admits_trace_length gs0 evs0 Hat) as Hlen0.
    destruct (Nat.lt_ge_cases n (length gs0)) as [Hlt | Hge].
    + rewrite (firstn_app1 config gs0 g' (S n) ltac:(lia)).
      rewrite (firstn_app1 event evs0 ev n ltac:(lia)).
      apply IH; exact Hlt.
    + assert (Hne : n = length gs0) by lia. subst n.
      replace (S (length gs0)) with (length (gs0 ++ [g']))
        by (rewrite length_app; simpl; lia).
      rewrite firstn_all.
      replace (length gs0) with (length (evs0 ++ [ev]))
        by (rewrite length_app; simpl; lia).
      rewrite firstn_all. apply AT_step; assumption.
Qed.

(* Either a config list has no l-annotation, or it has a greatest l-annotation
   index, above which it is annotation-free. *)
Lemma last_annot_or_none : forall l xs,
  (forall m, m < length xs -> ~ redex_is_l_annotation l (cfg_at xs m)) \/
  (exists a, a < length xs /\ redex_is_l_annotation l (cfg_at xs a) /\
             (forall m, a < m -> m < length xs -> ~ redex_is_l_annotation l (cfg_at xs m))).
Proof.
  intros l xs. induction xs as [| c ys IHys] using rev_ind.
  - left. intros m Hm. simpl in Hm. lia.
  - assert (Hlen : length (ys ++ [c]) = S (length ys)) by (rewrite length_app; simpl; lia).
    assert (Hlast : cfg_at (ys ++ [c]) (length ys) = c) by (apply cfg_at_app2).
    assert (Hread : forall m, m < length ys -> cfg_at (ys ++ [c]) m = cfg_at ys m)
      by (intros m Hm; apply cfg_at_app1; exact Hm).
    destruct (classic (redex_is_l_annotation l c)) as [Hann | Hnann].
    + right. exists (length ys).
      split; [rewrite Hlen; lia |].
      split; [rewrite Hlast; exact Hann |].
      intros m Hgt Hlt. rewrite Hlen in Hlt. lia.
    + destruct IHys as [Hno | [a [Halt [Hannot Hgap]]]].
      * left. intros m Hm. rewrite Hlen in Hm.
        destruct (Nat.eq_dec m (length ys)) as [Heq | Hne].
        -- rewrite Heq, Hlast. exact Hnann.
        -- rewrite Hread by lia. apply Hno. lia.
      * right. exists a.
        split; [rewrite Hlen; lia |].
        split; [rewrite Hread by exact Halt; exact Hannot |].
        intros m Hgt Hlt. rewrite Hlen in Hlt.
        destruct (Nat.eq_dec m (length ys)) as [Heq | Hne].
        -- rewrite Heq, Hlast. exact Hnann.
        -- rewrite Hread by lia. apply Hgap; lia.
Qed.

(* If a pre-run on (a prefix of) ins reaches length K+1, the canonical forward
   run frun on ins reaches length K. *)
Lemma frun_full_of_prerun : forall ins g th K,
  Forall is_input ins -> admits_trace g th -> list_prefix (inputs th) ins ->
  K <= length g - 1 ->
  length (frun (Receptive initState) ins K) = K.
Proof.
  intros ins g th K Hinp Hat Hpref HK.
  destruct (prerun_is_frun g th ins Hat Hinp Hpref) as [Hlen [_ _]].
  rewrite <- (frun_firstn (length g - 1) K (Receptive initState) ins HK).
  rewrite length_firstn, Hlen. lia.
Qed.

(* In a pre-run, an output redex at index q (q>=2) has its matching assert
   exactly two indices back (the silent post-assert skip sits between). *)
Lemma prerun_output_two_back : forall gs q l0 e cc s,
  pre_run gs -> 2 <= q -> q < length gs ->
  cfg_at gs q = Active cc s -> redex_cmd cc = Cout l0 e ->
  exists tk, redex_of (cfg_at gs (q - 2)) = Some (Cassert l0 tk (Ragr e)).
Proof.
  intros gs q l0 e cc s Hpre Hq2 Hqlt Hcfgq Hred.
  destruct Hpre as [evs Hat]. pose proof (admits_trace_length gs evs Hat) as Hleng.
  assert (Hatout : at_out cc l0 e) by (apply redex_at_out; exact Hred).
  assert (Hm1 : q - 1 < length evs) by lia.
  pose proof (admits_trace_step_at gs evs (q-1) Etick Hat Hm1) as Hstep1.
  replace (S (q-1)) with q in Hstep1 by lia.
  rewrite Hcfgq in Hstep1.
  assert (Hoa1 : oa_config (cfg_at gs (q-1)))
    by (apply (prerun_oa_at gs (q-1) (ex_intro _ evs Hat)); lia).
  destruct (cfg_at gs (q-1)) as [sr1 | cp sp] eqn:Hc1.
  - inversion Hstep1; subst.
    destruct (prog_well_specified l) as [wtag [d [Hbody _]]].
    rewrite Hbody in Hatout. inversion Hatout; subst.
    match goal with H : at_out (Cassume _ _ _) _ _ |- _ => inversion H end.
  - simpl in Hoa1.
    destruct (step_to_atout cp sp _ cc s Hoa1 Hstep1 l0 e Hatout) as [Hpa [_ _]].
    assert (Hm2 : q - 2 < length evs) by lia.
    pose proof (admits_trace_step_at gs evs (q-2) Etick Hat Hm2) as Hstep2.
    replace (S (q-2)) with (q-1) in Hstep2 by lia.
    rewrite Hc1 in Hstep2.
    assert (Hoa2 : oa_config (cfg_at gs (q-2)))
      by (apply (prerun_oa_at gs (q-2) (ex_intro _ evs Hat)); lia).
    destruct (cfg_at gs (q-2)) as [sr2 | ca sa] eqn:Hc2.
    + inversion Hstep2; subst.
      destruct (prog_well_specified l) as [wtag [d [Hbody _]]].
      rewrite Hbody in Hpa. inversion Hpa; subst.
      match goal with H : post_assert (Cassume _ _ _) _ _ |- _ => inversion H end.
    + simpl in Hoa2.
      destruct (step_to_postassert ca sa _ cp sp Hoa2 Hstep2 l0 e Hpa) as [tkc [Hredca [_ _]]].
      exists tkc. simpl. rewrite Hredca. reflexivity.
Qed.

Lemma cfg_at_skipn : forall l k m, cfg_at (skipn k l) m = cfg_at l (k + m).
Proof.
  intros l k m. unfold cfg_at. revert l m.
  induction k as [| k IH]; intros l m.
  - reflexivity.
  - destruct l as [| x xs]; simpl; [destruct m; reflexivity | apply IH].
Qed.

(* [c] is an active l-output guard: its redex is a low assert [Cassert lo (Ragr eo)]
   whose two-step continuation reaches the matching output [Cout lo eo].  This is the
   precise shape that produces a boundary l-output two configs later, distinguishing a
   genuine output guard (Cseq (Cassert lo <eo>)(Cout lo eo)) from a standalone low
   assert (which steps to Cskip and never outputs).  A Receptive config is never a
   guard. *)
Definition emits_output_in_two (l : Lev) (c : config) : Prop :=
  exists lo eo cq s cp sp ev1 cc sc ev2 tk,
    c = Active cq s /\ lleq lo l /\
    redex_cmd cq = Cassert lo tk (Ragr eo) /\
    step (Active cq s) ev1 (Active cp sp) /\
    step (Active cp sp) ev2 (Active cc sc) /\
    redex_cmd cc = Cout lo eo.

(* If the config at index [a] of a pre-run is an output guard, its successor [a+1]
   is the post-assert (redex Cskip). *)
Lemma emits_run_post : forall l gs a,
  pre_run gs -> emits_output_in_two l (cfg_at gs a) -> S a < length gs ->
  exists cp sp, cfg_at gs (S a) = Active cp sp /\ redex_cmd cp = Cskip.
Proof.
  intros l gs a Hpre Hem HSa.
  destruct Hem as (lo & eo & cq & s & cp0 & sp0 & ev1 & cc0 & sc0 & ev2 & tko &
                   Hca & Hle & Hredcq & Hstep1 & Hstep2 & Hredcc).
  destruct (step_assert_event cq s ev1 (Active cp0 sp0) lo tko (Ragr eo) Hredcq Hstep1)
    as [_ [c1' Hc1']]. injection Hc1' as _ Hse. subst sp0.
  destruct (pre_run_step_adj gs a Hpre HSa) as [evR Hstepg].
  rewrite Hca in Hstepg.
  destruct (step_assert_event cq s evR (cfg_at gs (S a)) lo tko (Ragr eo) Hredcq Hstepg)
    as [_ [cR HgSa]]. rewrite HgSa in Hstepg.
  assert (HcReq : cR = cp0)
    by (apply (step_assert_cmd_det cq s s evR ev1 cR s cp0 s lo tko (Ragr eo)
                 Hredcq Hstepg Hstep1)).
  subst cR.
  assert (Hoa : oa_config (Active cp0 s))
    by (rewrite <- HgSa; apply (prerun_oa_at gs (S a) Hpre HSa)).
  destruct (step_to_atout cp0 s ev2 cc0 sc0 Hoa Hstep2 lo eo (redex_at_out cc0 lo eo Hredcc))
    as [Hpa [_ _]].
  exists cp0, s. split; [exact HgSa | apply (post_assert_redex_skip cp0 lo eo Hpa)].
Qed.

(* If the config at index [a] of a pre-run is an output guard, its second successor
   [a+2] is the at_out config emitting the matching low output [Cout lo eo]. *)
Lemma emits_run_out : forall l gs a,
  pre_run gs -> emits_output_in_two l (cfg_at gs a) -> S (S a) < length gs ->
  exists lo eo cc tc, lleq lo l /\
    cfg_at gs (S (S a)) = Active cc tc /\ redex_cmd cc = Cout lo eo.
Proof.
  intros l gs a Hpre Hem HSSa.
  assert (HSa : S a < length gs) by lia.
  destruct Hem as (lo & eo & cq & s & cp0 & sp0 & ev1 & cc0 & sc0 & ev2 & tko &
                   Hca & Hle & Hredcq & Hstep1 & Hstep2 & Hredcc).
  destruct (step_assert_event cq s ev1 (Active cp0 sp0) lo tko (Ragr eo) Hredcq Hstep1)
    as [_ [c1' Hc1']]. injection Hc1' as _ Hse. subst sp0.
  destruct (pre_run_step_adj gs a Hpre HSa) as [evR Hstepg].
  rewrite Hca in Hstepg.
  destruct (step_assert_event cq s evR (cfg_at gs (S a)) lo tko (Ragr eo) Hredcq Hstepg)
    as [_ [cR HgSa]]. rewrite HgSa in Hstepg.
  assert (HcReq : cR = cp0)
    by (apply (step_assert_cmd_det cq s s evR ev1 cR s cp0 s lo tko (Ragr eo)
                 Hredcq Hstepg Hstep1)).
  subst cR.
  assert (Hoa : oa_config (Active cp0 s))
    by (rewrite <- HgSa; apply (prerun_oa_at gs (S a) Hpre HSa)).
  destruct (step_to_atout cp0 s ev2 cc0 sc0 Hoa Hstep2 lo eo (redex_at_out cc0 lo eo Hredcc))
    as [Hpa [_ _]].
  assert (Hredcp0 : redex_cmd cp0 = Cskip) by (apply (post_assert_redex_skip cp0 lo eo Hpa)).
  destruct (pre_run_step_adj gs (S a) Hpre HSSa) as [evR2 Hstepg2].
  rewrite HgSa in Hstepg2.
  destruct (step_skip_cmd_det cp0 s s ev2 evR2 cc0 sc0 (cfg_at gs (S (S a)))
              Hredcp0 Hstep2 Hstepg2) as [c2 [t2 [HgSSa Hc2]]].
  subst c2.
  exists lo, eo, cc0, t2. split; [exact Hle | split; [exact HgSSa | exact Hredcc]].
Qed.

(* A Cskip-redex (post-assert) config is never an l-annotation. *)
Lemma redex_skip_not_annot : forall l c s,
  redex_cmd c = Cskip -> ~ redex_is_l_annotation l (Active c s).
Proof.
  intros l c s H Hann. unfold redex_is_l_annotation in Hann. simpl in Hann.
  rewrite H in Hann. destruct Hann as [H1 | H1]; exact H1.
Qed.

(* A Cout-redex (at_out) config is never an l-annotation. *)
Lemma redex_out_not_annot : forall l c s lo eo,
  redex_cmd c = Cout lo eo -> ~ redex_is_l_annotation l (Active c s).
Proof.
  intros l c s lo eo H Hann. unfold redex_is_l_annotation in Hann. simpl in Hann.
  rewrite H in Hann. destruct Hann as [H1 | H1]; exact H1.
Qed.

(* The divergence-family bridge: from a divergence (Hdiv: annotation-free runs of
   every length) plus an annotation-free minor tail above the truncation point,
   build the output-free (above the boundary) family extending the truncated
   minor [hst]. *)
Lemma diverge_family_build : forall l ins hst ihst hs ih,
  Forall is_input ins ->
  pre_run hst -> pr_inputs hst ihst -> list_prefix ihst ins ->
  pre_run hs -> pr_inputs hs ih -> list_prefix ih ins ->
  length hst <= length hs ->
  (forall q, length hst <= q -> q < length hs -> ~ redex_is_l_annotation l (cfg_at hs q)) ->
  (forall n, n >= length hs -> exists hs' ih', length hs' = n /\ pr_inputs hs' ih' /\
       list_prefix ih ih' /\ list_prefix ih' ins /\ ~ redex_is_l_annotation l (last_cfg hs')) ->
  ((length hst = 1) \/ redex_of (cfg_at hs (length hst - 1)) <> Some Cskip) ->
  ~ emits_output_in_two l (cfg_at hs (length hst - 1)) ->
  diverge_family l ins hst ihst.
Proof.
  intros l ins hst ihst hs ih Hinp Hprehst Hprhst Hpfhst Hprehs Hprhs Hpfhs Hlenle Htail Hdiv
         Hlast Hnotguard.
  destruct Hprhst as [thst [Hathst Hihst]].
  destruct Hprhs as [ths [Haths Hihs]].
  assert (Hpf_thst : list_prefix (inputs thst) ins) by (rewrite Hihst; exact Hpfhst).
  assert (Hpf_ths : list_prefix (inputs ths) ins) by (rewrite Hihs; exact Hpfhs).
  assert (Hhstpos : 0 < length hst) by (apply admits_trace_length in Hathst; lia).
  assert (Hfull : forall K, length (frun (Receptive initState) ins K) = K).
  { intro K. destruct (le_lt_dec (S K) (length hs)) as [Hle | Hgt].
    - apply (frun_full_of_prerun ins hs ths K Hinp Haths Hpf_ths); lia.
    - destruct (Hdiv (S K) ltac:(lia)) as [R [ihR [HlenR [HprR [_ [HpfR _]]]]]].
      destruct HprR as [thR [HatR HihR]].
      apply (frun_full_of_prerun ins R thR K Hinp HatR); [rewrite HihR; exact HpfR | lia]. }
  destruct (prerun_is_frun hst thst ins Hathst Hinp Hpf_thst) as [_ [_ Hthst_eq]].
  pose (Cn := fun n => Receptive initState :: map snd (frun (Receptive initState) ins (length hst + n - 1))).
  pose (icn := fun n => inputs (map fst (frun (Receptive initState) ins (length hst + n - 1)))).
  exists (fun n => skipn (length hst) (Cn n)), (fun n => skipn (length ihst) (icn n)).
  intro n.
  assert (HClen : length (Cn n) = length hst + n).
  { unfold Cn. simpl. rewrite length_map, Hfull. lia. }
  assert (HCpre : pre_run (Cn n)).
  { unfold Cn. assert (Hlc : last_cfg [Receptive initState] = Receptive initState) by reflexivity.
    pose proof (frun_pre_run (length hst + n - 1) [Receptive initState] ins (ex_intro _ [] AT_init)) as Hp.
    rewrite Hlc in Hp. exact Hp. }
  assert (HCpr : pr_inputs (Cn n) (icn n)).
  { unfold Cn, icn. assert (Hlc : last_cfg [Receptive initState] = Receptive initState) by reflexivity.
    pose proof (frun_pr_inputs (length hst + n - 1) [Receptive initState] [] ins AT_init) as Hp.
    rewrite Hlc in Hp. simpl in Hp. exact Hp. }
  assert (HCpf : list_prefix (icn n) ins) by (unfold icn; apply frun_inputs_prefix).
  destruct HCpr as [thC [HatC HicC]].
  assert (Hpf_thC : list_prefix (inputs thC) ins) by (rewrite HicC; exact HCpf).
  destruct (prerun_config_prefix ins hst thst (Cn n) thC Hinp Hathst Hpf_thst HatC Hpf_thC
              ltac:(rewrite HClen; lia)) as [ex Hex].
  assert (HEeq : skipn (length hst) (Cn n) = ex)
    by (rewrite Hex; rewrite skipn_app, skipn_all, Nat.sub_diag; reflexivity).
  assert (HhstE : hst ++ skipn (length hst) (Cn n) = Cn n)
    by (rewrite HEeq; symmetry; exact Hex).
  assert (Hexlen : length ex = n)
    by (apply (f_equal (@length config)) in Hex; rewrite length_app in Hex; lia).
  assert (HElen : length (skipn (length hst) (Cn n)) = n) by (rewrite HEeq; exact Hexlen).
  (* annotation-freeness of every family position *)
  assert (Hannfree : forall m, m < n ->
            ~ redex_is_l_annotation l (cfg_at (skipn (length hst) (Cn n)) m)).
  { intros m Hm Hann. rewrite cfg_at_skipn in Hann.
    destruct (le_lt_dec (length hs) (length hst + m)) as [Hqge | Hqlt].
    - destruct (Hdiv (S (length hst + m)) ltac:(lia))
        as [R [ihR [HlenR [HprR [_ [HpfR Hlastann]]]]]].
      destruct HprR as [thR [HatR HihR]].
      assert (Hne : R <> []) by (intro Hc; subst R; simpl in HlenR; lia).
      assert (Hdet : cfg_at (Cn n) (length hst + m) = cfg_at R (length hst + m)).
      { apply (prerun_index_det ins (Cn n) R (icn n) ihR (length hst + m) Hinp
                 (ex_intro _ thC (conj HatC HicC)) HCpf
                 (ex_intro _ thR (conj HatR HihR)) HpfR);
          [rewrite HClen; lia | rewrite HlenR; lia]. }
      rewrite Hdet in Hann.
      assert (Hqeq : length hst + m = length R - 1) by (rewrite HlenR; lia).
      rewrite Hqeq, (last_eq_cfg_at R Hne) in Hann.
      apply Hlastann; exact Hann.
    - assert (Hdet : cfg_at (Cn n) (length hst + m) = cfg_at hs (length hst + m)).
      { apply (prerun_index_det ins (Cn n) hs (icn n) ih (length hst + m) Hinp
                 (ex_intro _ thC (conj HatC HicC)) HCpf
                 (ex_intro _ ths (conj Haths Hihs)) Hpfhs);
          [rewrite HClen; lia | lia]. }
      rewrite Hdet in Hann.
      apply (Htail (length hst + m) ltac:(lia) Hqlt); exact Hann. }
  (* assemble *)
  split; [exact HElen |].
  split; [rewrite HhstE; exact HCpre |].
  assert (Hihst_pref : list_prefix ihst (icn n)).
  { rewrite <- Hihst, Hthst_eq. unfold icn. apply frun_inputs_mono; lia. }
  assert (HihstE : ihst ++ skipn (length ihst) (icn n) = icn n).
  { destruct Hihst_pref as [rest Hrest]. rewrite Hrest.
    rewrite skipn_app, skipn_all, Nat.sub_diag. reflexivity. }
  split; [rewrite HhstE, HihstE; exact (ex_intro _ thC (conj HatC HicC)) |].
  split; [rewrite HihstE; exact HCpf |].
  intros m Hm. split; [apply Hannfree; exact Hm |].
  destruct (le_lt_dec 2 m) as [Hm2 | Hmlt2].
  - (* m >= 2: an output's guarding assert is two steps back, hence at a family
       position (>= length hst), which is annotation-free -- contradiction. *)
    intros Hout. rewrite cfg_at_skipn in Hout.
    destruct (cfg_at (Cn n) (length hst + m)) as [sr | cc s] eqn:Hcfgq.
    + unfold redex_is_l_output in Hout. simpl in Hout. exact Hout.
    + unfold redex_is_l_output in Hout. simpl in Hout.
      destruct (redex_cmd cc) as [ | xa ea | lo eo | ea ca cb | ea ca | ca cb | la ta ra | la ta ra ] eqn:Hredc;
        try contradiction.
      pose proof (prerun_output_two_back (Cn n) (length hst + m) lo eo cc s HCpre
                    ltac:(lia) ltac:(rewrite HClen; lia) Hcfgq Hredc) as [tkb Hback].
      apply (Hannfree (m - 2) ltac:(lia)).
      rewrite cfg_at_skipn.
      replace (length hst + (m - 2)) with (length hst + m - 2) by lia.
      unfold redex_is_l_annotation. rewrite Hback. right. exact Hout.
  - (* m < 2 (family positions 0,1): the only possible boundary l-output is the one
       guarded by the truncation point itself.  At m=1 that guard sits exactly at
       [length hst - 1] and is ruled out by [Hnotguard]; at m=0 the truncation point
       would have to be a post-assert (redex Cskip), contradicting that it is an
       l-annotation (or, in the origin case, that it follows a receptive step). *)
    pose proof (admits_trace_length (Cn n) thC HatC) as HlenC.
    intros Hout. rewrite cfg_at_skipn in Hout.
    destruct (cfg_at (Cn n) (length hst + m)) as [sr | cc s] eqn:Hcfgq.
    { unfold redex_is_l_output in Hout. simpl in Hout. exact Hout. }
    unfold redex_is_l_output in Hout. simpl in Hout.
    destruct (redex_cmd cc) as [ | xa ea | lo eo | ea ca cb | ea ca | ca cb | la ta ra | la ta ra ] eqn:Hredc;
      try contradiction.
    assert (Hbridge : cfg_at (Cn n) (length hst - 1) = cfg_at hs (length hst - 1)).
    { apply (prerun_index_det ins (Cn n) hs (icn n) ih (length hst - 1) Hinp
               (ex_intro _ thC (conj HatC HicC)) HCpf
               (ex_intro _ ths (conj Haths Hihs)) Hpfhs);
        [rewrite HClen; lia | lia]. }
    destruct (Nat.eq_dec m 1) as [Hm1 | Hmn1].
    + (* m = 1: the output at family position 1 is guarded by an output guard sitting
         exactly at the truncation point length hst - 1 -- contradicting Hnotguard's
         [~ emits_output_in_two]. *)
      subst m.
      destruct (prerun_output_pair_struct (Cn n) (length hst + 1) cc s lo eo HCpre
                  ltac:(rewrite HClen; lia) Hcfgq Hredc)
        as [cq [cp [tq20 [_ [Hcq [Hredcq [Hcp Hredcp]]]]]]].
      replace (length hst + 1 - 2) with (length hst - 1) in Hcq by lia.
      replace (length hst + 1 - 1) with (length hst) in Hcp by lia.
      assert (HSa : S (length hst - 1) < length (Cn n)) by (rewrite HClen; lia).
      assert (HSb : S (length hst) < length (Cn n)) by (rewrite HClen; lia).
      destruct (pre_run_step_adj (Cn n) (length hst - 1) HCpre HSa) as [ev1 Hstep1].
      destruct (pre_run_step_adj (Cn n) (length hst) HCpre HSb) as [ev2 Hstep2].
      replace (S (length hst - 1)) with (length hst) in Hstep1 by lia.
      replace (S (length hst)) with (length hst + 1) in Hstep2 by lia.
      rewrite Hcq, Hcp in Hstep1. rewrite Hcp, Hcfgq in Hstep2.
      apply Hnotguard.
      exists lo, eo, cq, s, cp, s, ev1, cc, s, ev2, tq20.
      split; [rewrite <- Hbridge; exact Hcq |].
      split; [exact Hout |].
      split; [exact Hredcq |].
      split; [exact Hstep1 |].
      split; [exact Hstep2 | exact Hredc].
    + (* m = 0: the predecessor of the output config (index length hst - 1) is either
         Receptive (the step into the output config is an input, so its redex is a
         handler-entry Cassume, never Cout) or Active (a post-assert by step_to_atout,
         redex Cskip, contradicting Hlast's [<> Some Cskip]). *)
      assert (Hm0 : m = 0) by lia. subst m. rewrite Nat.add_0_r in Hcfgq.
      assert (Hatout : at_out cc lo eo) by (apply redex_at_out; exact Hredc).
      assert (Hstep1 : step (cfg_at (Cn n) (length hst - 1)) (nth (length hst - 1) thC Etick)
                             (cfg_at (Cn n) (S (length hst - 1)))).
      { apply (admits_trace_step_at (Cn n) thC (length hst - 1) Etick HatC).
        rewrite HClen in HlenC. lia. }
      replace (S (length hst - 1)) with (length hst) in Hstep1 by lia.
      rewrite Hcfgq in Hstep1.
      assert (Hoa1 : oa_config (cfg_at (Cn n) (length hst - 1)))
        by (apply (prerun_oa_at (Cn n) (length hst - 1) HCpre); rewrite HClen; lia).
      destruct (cfg_at (Cn n) (length hst - 1)) as [sr1 | cp sp] eqn:Hc1.
      * (* Receptive predecessor: Step_input gives cc = h_body, redex Cassume <> Cout *)
        inversion Hstep1; subst.
        match goal with
        | H : redex_cmd (h_body (prog ?lv)) = _ |- _ =>
            destruct (prog_well_specified lv) as [wtag [d [Hbody _]]];
            rewrite Hbody in H; simpl in H; discriminate H
        end.
      * (* Active predecessor: post-assert (redex Cskip), contradicting Hlast *)
        simpl in Hoa1.
        assert (Hnotskip : redex_of (cfg_at hs (length hst - 1)) <> Some Cskip).
        { destruct Hlast as [Hl1 | Hns]; [exfalso | exact Hns].
          assert (Hr0 : cfg_at (Cn n) (length hst - 1) = Receptive initState).
          { replace (length hst - 1) with 0 by lia. apply (prerun_head (Cn n) HCpre). }
          rewrite Hr0 in Hc1. discriminate Hc1. }
        destruct (step_to_atout cp sp _ cc s Hoa1 Hstep1 lo eo Hatout) as [Hpa [_ _]].
        assert (Hskip : redex_cmd cp = Cskip) by (apply (post_assert_redex_skip cp lo eo Hpa)).
        apply Hnotskip.
        assert (Hform : cfg_at hs (length hst - 1) = Active cp sp) by congruence.
        rewrite Hform. simpl. rewrite Hskip. reflexivity.
Qed.

(* Constructor for the divergence case: from the truncated minor [hst] ending at
   the annotation aligned to the major's last annotation [i], plus coverage up to
   [i] and the divergent family, build a [divergence_fiat].  This is the alt lemma
   with the conformance/covers_dom hypotheses weakened to the truncated form. *)
Lemma conformance_extend_diverge_trunc : forall l ins fs g hst alpha i ihst,
  Forall is_input ins ->
  i < length fs ->
  pre_run (fs ++ [g]) ->
  pre_run hst ->
  proper l fs hst alpha ->
  covers_rng hst alpha ->
  (forall a b l' tk Phi, alpha a b ->
     (redex_of (cfg_at fs a) = Some (Cassume l' tk Phi) \/
      redex_of (cfg_at fs a) = Some (Cassert l' tk Phi)) ->
     lleq l' l ->
     models (cfg_state (cfg_at fs a)) (cfg_state (cfg_at hst b)) Phi) ->
  redex_is_l_annotation l g ->
  alpha i (length hst - 1) ->
  ((i = 0 /\ length hst = 1) \/ redex_is_l_annotation l (cfg_at fs i)
                             \/ (redex_is_l_output l (cfg_at fs i) /\
                                 redex_is_l_output l (cfg_at hst (length hst - 1)))) ->
  (forall m, i < m -> m < length fs -> ~ redex_is_l_annotation l (cfg_at fs m)) ->
  (forall a, a <= i -> align_dom alpha a) ->
  pr_inputs hst ihst -> list_prefix ihst ins ->
  diverge_family l ins hst ihst ->
  exists alpha', divergence_fiat l ins (fs ++ [g]) hst alpha'.
Proof.
  intros l ins fs g hst alpha i ihst Hinp Hilt Hpre Hprehst Hproper Hcrng Hmod Hann
         Halphai Hcase Hgap Hcovi Hpr Hpfih Hfam.
  assert (Hmono : forall a b c d, alpha a b -> alpha c d ->
                    (a < c -> b <= d) /\ (b < d -> a <= c)).
  { destruct Hproper as [[_ [Hm _]] _]. exact Hm. }
  assert (Hhspos : 0 < length hst) by
    (destruct hst; [exfalso; apply (pre_run_nonempty _ Hprehst); reflexivity | simpl; lia]).
  set (alpha' := fun a b => alpha a b /\ a <= i).
  assert (Hglen : length (fs ++ [g]) = S (length fs)) by (rewrite length_app; simpl; lia).
  assert (Hcrng' : covers_rng hst alpha').
  { intros b Hb. destruct (Nat.eq_dec b (length hst - 1)) as [Heq | Hne].
    - exists i. unfold alpha'. subst b. split; [exact Halphai | lia].
    - destruct (Hcrng b Hb) as [a Haab].
      exists a. unfold alpha'. split; [exact Haab |].
      apply (proj2 (Hmono a b i (length hst - 1) Haab Halphai)). lia. }
  assert (Hcovdom' : covers_dom (firstn (i + 1) (fs ++ [g])) alpha').
  { intros a Ha.
    assert (Halen : length (firstn (i + 1) (fs ++ [g])) = i + 1)
      by (rewrite firstn_length_le; [reflexivity | rewrite Hglen; lia]).
    rewrite Halen in Ha.
    destruct (Hcovi a ltac:(lia)) as [b Hab].
    exists b. unfold alpha'. split; [exact Hab | lia]. }
  assert (Hproper_top : proper l (fs ++ [g]) hst alpha').
  { apply (proper_restrict_le l fs hst alpha i (fs ++ [g]) Hproper Hilt).
    - intros a Hai. rewrite Hglen. lia.
    - intros a Hai. apply cfg_at_app1. lia. }
  assert (Hproper_emb : proper l (firstn (i + 1) (fs ++ [g])) hst alpha').
  { apply (proper_restrict_le l fs hst alpha i (firstn (i + 1) (fs ++ [g])) Hproper Hilt).
    - intros a Hai. rewrite firstn_length_le by (rewrite Hglen; lia). lia.
    - intros a Hai. rewrite cfg_at_firstn by lia. apply cfg_at_app1. lia. }
  assert (Hconf_emb : conformance l ins (firstn (i + 1) (fs ++ [g])) hst alpha').
  { unfold conformance. split; [| split; [| split; [| split]]].
    - split; [| split].
      + apply pre_run_firstn; [exact Hpre | lia | rewrite Hglen; lia].
      + exact Hprehst.
      + exact Hproper_emb.
    - exists ihst. split; [exact Hpr | split; [exact Hpfih | left; exact Hcovdom']].
    - exact Hcrng'.
    - intros a b l' tk Phi Hab Hred Hle.
      destruct Hab as [Haba Hai].
      assert (Hreadfs : cfg_at (firstn (i + 1) (fs ++ [g])) a = cfg_at fs a)
        by (rewrite cfg_at_firstn by lia; apply cfg_at_app1; lia).
      rewrite Hreadfs in Hred. rewrite Hreadfs.
      apply (Hmod a b l' tk Phi Haba Hred Hle).
    - exact Hinp. }
  exists alpha'. exists i, (length fs).
  split; [exact Hinp |].
  split; [exact Hilt |].
  split; [rewrite Hglen; lia |].
  split; [split; [exact Hpre | split; [exact Hprehst | exact Hproper_top]] |].
  split; [rewrite cfg_at_app2; exact Hann |].
  exists (length hst - 1).
  split; [reflexivity |].
  split; [unfold alpha'; split; [exact Halphai | lia] |].
  split.
  { destruct Hcase as [[Hi0 Hhs1] | [Hannfsi | Houtfsi]].
    - left. split; [exact Hi0 | lia].
    - right; left. rewrite (cfg_at_app1 fs g i Hilt). exact Hannfsi.
    - right; right. split;
        [rewrite (cfg_at_app1 fs g i Hilt); exact (proj1 Houtfsi) | exact (proj2 Houtfsi)]. }
  split.
  { intros m Hm1 Hm2. rewrite (cfg_at_app1 fs g m Hm2). apply Hgap; [exact Hm1 | exact Hm2]. }
  split; [exact Hconf_emb |].
  destruct Hfam as [E [ihe HE]].
  exists ihst. split; [exact Hpr | split; [exact Hpfih |]].
  exists E. intro n.
  destruct (HE n) as [HlenE [HpreE [HprE [HpfE HannfreeE]]]].
  split; [exact HlenE | split; [exact HannfreeE |]].
  exists (ihst ++ ihe n). split; [exact HprE | exact HpfE].
Qed.

(* Restricting a proper alignment's range (truncating the minor to firstn M). *)
Lemma proper_restrict_rng : forall l fs hs alpha M,
  proper l fs hs alpha -> M <= length hs ->
  proper l fs (firstn M hs) (fun a b => alpha a b /\ b < M).
Proof.
  intros l fs hs alpha M [Halgn Hcoin] HM.
  destruct Halgn as [Hbound [Hmono [Hpcd Hpcr]]].
  assert (Hlen : length (firstn M hs) = M) by (apply firstn_length_le; exact HM).
  assert (Hread : forall b, b < M -> cfg_at (firstn M hs) b = cfg_at hs b)
    by (intros b Hb; apply cfg_at_firstn; exact Hb).
  split.
  - split; [| split; [| split]].
    + intros a b [Hab Hb]. split; [exact (proj1 (Hbound a b Hab)) | rewrite Hlen; exact Hb].
    + intros a b c d [Hab _] [Hcd _]. apply (Hmono a b c d Hab Hcd).
    + intros a c Hda Hca. destruct Hda as [b [Hab Hb]].
      destruct (Hpcd a c (ex_intro _ b Hab) Hca) as [b' Hcb'].
      exists b'. split; [exact Hcb' |].
      assert (b' <= b) by (apply (proj1 (Hmono c b' a b Hcb' Hab)); exact Hca). lia.
    + intros b d Hrb Hdb. destruct Hrb as [a [Hab Hb]].
      destruct (Hpcr b d (ex_intro _ a Hab) Hdb) as [a' Hda'].
      exists a'. split; [exact Hda' | lia].
  - intros a b [Hab Hb] Hannot.
    rewrite (Hread b Hb) in Hannot. rewrite (Hread b Hb).
    apply (Hcoin a b Hab). exact Hannot.
Qed.

(* Given the major's last annotation [i] (or origin) aligned to minor index [b],
   with annotation-free tails above both, build the divergence_fiat by truncating
   the minor to firstn (b+1) hs and supplying the divergent family. *)
Lemma divergence_from_truncation : forall l ins fs g hs alpha ih i b,
  Forall is_input ins ->
  pre_run (fs ++ [g]) ->
  pre_run fs -> pre_run hs ->
  proper l fs hs alpha -> covers_rng hs alpha ->
  (forall a c l' tk Phi, alpha a c ->
     (redex_of (cfg_at fs a) = Some (Cassume l' tk Phi) \/
      redex_of (cfg_at fs a) = Some (Cassert l' tk Phi)) ->
     lleq l' l -> models (cfg_state (cfg_at fs a)) (cfg_state (cfg_at hs c)) Phi) ->
  covers_dom fs alpha ->
  redex_is_l_annotation l g ->
  pr_inputs hs ih -> list_prefix ih ins ->
  (forall n, n >= length hs -> exists hs' ih', length hs' = n /\ pr_inputs hs' ih' /\
       list_prefix ih ih' /\ list_prefix ih' ins /\ ~ redex_is_l_annotation l (last_cfg hs')) ->
  i < length fs -> b < length hs -> alpha i b ->
  ((i = 0 /\ b = 0) \/ redex_is_l_annotation l (cfg_at fs i)) ->
  (forall m, i < m -> m < length fs -> ~ redex_is_l_annotation l (cfg_at fs m)) ->
  (forall q, b < q -> q < length hs -> ~ redex_is_l_annotation l (cfg_at hs q)) ->
  ((b = 0) \/ redex_is_l_annotation l (cfg_at hs b)) ->
  ~ emits_output_in_two l (cfg_at hs b) ->
  exists hs' alpha', divergence_fiat l ins (fs ++ [g]) hs' alpha'.
Proof.
  intros l ins fs g hs alpha ih i b Hinp Hpreg Hprefs Hprehs Hproper Hcrng Hmod Hcov Hann
         Hprih Hpf Hdiv Hilt Hblt Halphaib Hcase Hgap Htail Hbcase Hbnotguard.
  destruct Hprih as [ths [Haths Hihs]].
  assert (Hmono : forall a c d e, alpha a c -> alpha d e ->
                    (a < d -> c <= e) /\ (c < e -> a <= d))
    by (destruct Hproper as [[_ [Hm _]] _]; exact Hm).
  set (hst := firstn (b + 1) hs).
  assert (Hhstlen : length hst = b + 1) by (unfold hst; apply firstn_length_le; lia).
  assert (Hathst : admits_trace hst (firstn b ths)).
  { unfold hst. replace (b + 1) with (S b) by lia.
    apply admits_trace_firstn_full; [exact Haths | lia]. }
  set (ihst := inputs (firstn b ths)).
  assert (Hprhst : pr_inputs hst ihst)
    by (exists (firstn b ths); split; [exact Hathst | reflexivity]).
  assert (Hprehst : pre_run hst) by (exists (firstn b ths); exact Hathst).
  assert (Hpf_ihst : list_prefix ihst ins).
  { apply (list_prefix_trans _ ihst ih ins); [| exact Hpf].
    unfold ihst. rewrite <- Hihs. unfold inputs.
    exists (filter is_input_b (skipn b ths)).
    rewrite <- filter_app, firstn_skipn. reflexivity. }
  set (alpha_t := fun a c => alpha a c /\ c < b + 1).
  assert (Hproper_t : proper l fs hst alpha_t)
    by (unfold hst, alpha_t; apply proper_restrict_rng; [exact Hproper | lia]).
  assert (Hread : forall c, c < b + 1 -> cfg_at hst c = cfg_at hs c)
    by (intros c Hc; unfold hst; apply cfg_at_firstn; exact Hc).
  assert (Hcrng_t : covers_rng hst alpha_t).
  { intros c Hc. rewrite Hhstlen in Hc. destruct (Hcrng c ltac:(lia)) as [a Hac].
    exists a. unfold alpha_t. split; [exact Hac | exact Hc]. }
  assert (Hmod_t : forall a c l' tk Phi, alpha_t a c ->
     (redex_of (cfg_at fs a) = Some (Cassume l' tk Phi) \/
      redex_of (cfg_at fs a) = Some (Cassert l' tk Phi)) ->
     lleq l' l -> models (cfg_state (cfg_at fs a)) (cfg_state (cfg_at hst c)) Phi).
  { intros a c l' tk Phi [Hac Hc] Hred Hle. rewrite (Hread c Hc).
    apply (Hmod a c l' tk Phi Hac Hred Hle). }
  assert (Halpha_t_ib : alpha_t i (length hst - 1)).
  { unfold alpha_t. rewrite Hhstlen. replace (b + 1 - 1) with b by lia.
    split; [exact Halphaib | lia]. }
  assert (Hcase_t : (i = 0 /\ length hst = 1) \/ redex_is_l_annotation l (cfg_at fs i)
                      \/ (redex_is_l_output l (cfg_at fs i) /\
                          redex_is_l_output l (cfg_at hst (length hst - 1)))).
  { destruct Hcase as [[Hi0 Hb0] | Hannfsi];
      [left; split; [exact Hi0 | rewrite Hhstlen; lia] | right; left; exact Hannfsi]. }
  assert (Hcovi_t : forall a, a <= i -> align_dom alpha_t a).
  { intros a Ha. destruct (Nat.eq_dec a i) as [-> | Hne].
    - exists b. unfold alpha_t. split; [exact Halphaib | lia].
    - destruct (Hcov a ltac:(lia)) as [c Hac].
      exists c. unfold alpha_t. split; [exact Hac |].
      assert (c <= b) by (apply (proj1 (Hmono a c i b Hac Halphaib)); lia). lia. }
  assert (Hfam : diverge_family l ins hst ihst).
  { apply (diverge_family_build l ins hst ihst hs ih Hinp Hprehst Hprhst Hpf_ihst
             Hprehs (ex_intro _ ths (conj Haths Hihs)) Hpf ltac:(lia)).
    - intros q Hq1 Hq2. apply Htail; [rewrite Hhstlen in Hq1; lia | exact Hq2].
    - exact Hdiv.
    - (* Hlast *) rewrite Hhstlen. replace (b + 1 - 1) with b by lia.
      destruct Hbcase as [Hb0 | Hba]; [left; lia | right].
      intro Hsk. unfold redex_is_l_annotation in Hba. rewrite Hsk in Hba.
      simpl in Hba. destruct Hba as [H | H]; exact H.
    - (* Hnotguard *) rewrite Hhstlen. replace (b + 1 - 1) with b by lia. exact Hbnotguard. }
  destruct (conformance_extend_diverge_trunc l ins fs g hst alpha_t i ihst
              Hinp Hilt Hpreg Hprehst Hproper_t Hcrng_t Hmod_t Hann Halpha_t_ib Hcase_t Hgap
              Hcovi_t Hprhst Hpf_ihst Hfam) as [alpha' Hdf].
  exists hst, alpha'. exact Hdf.
Qed.

(* The output-endpoint divergence: the minor's last l-annotation at [bp] is an
   output guard (emits an l-output two configs later).  The major's aligned
   annotation at [ap] carries the SAME command (aligned_annot_same_cmd_hyp), so it emits the
   matching output at [ap+2 < length fs].  Truncate the (extended) minor at the
   output [bp+2], align [ap+2 ~ bp+2], and build the divergence_fiat with an output
   endpoint. *)
Lemma divergence_from_output_guard : forall l ins fs g hs alpha ih ap bp,
  Forall is_input ins ->
  pre_run (fs ++ [g]) ->
  pre_run fs -> pre_run hs ->
  proper l fs hs alpha -> covers_rng hs alpha ->
  (forall a c l' tk Phi, alpha a c ->
     (redex_of (cfg_at fs a) = Some (Cassume l' tk Phi) \/
      redex_of (cfg_at fs a) = Some (Cassert l' tk Phi)) ->
     lleq l' l -> models (cfg_state (cfg_at fs a)) (cfg_state (cfg_at hs c)) Phi) ->
  covers_dom fs alpha ->
  redex_is_l_annotation l g ->
  pr_inputs hs ih -> list_prefix ih ins ->
  (forall n, n >= length hs -> exists hs' ih', length hs' = n /\ pr_inputs hs' ih' /\
       list_prefix ih ih' /\ list_prefix ih' ins /\ ~ redex_is_l_annotation l (last_cfg hs')) ->
  ap < length fs -> bp < length hs -> alpha ap bp ->
  redex_is_l_annotation l (cfg_at fs ap) ->
  (forall m, ap < m -> m < length fs -> ~ redex_is_l_annotation l (cfg_at fs m)) ->
  (forall q, bp < q -> q < length hs -> ~ redex_is_l_annotation l (cfg_at hs q)) ->
  emits_output_in_two l (cfg_at hs bp) ->
  exists hs' alpha', divergence_fiat l ins (fs ++ [g]) hs' alpha'.
Proof.
  intros l ins fs g hs alpha ih ap bp Hinp Hpreg Hprefs Hprehs Hproper Hcrng Hmod Hcov Hann
         Hprih Hpf Hdiv Haplt Hbplt Halpha_apbp Hannfsap Hgapfs Hgaphs Hguard.
  pose proof Hproper as Hproper0.
  destruct Hproper as [[Hbound [Hmono [Hpcd Hpcr]]] Hcoin].
  destruct Hguard as (lo & eo & cq & s & cp0 & sp0 & ev1 & cc0 & sc0 & ev2 & tko &
                      Hca_hs & Hle & Hredcq & Hstep1 & Hstep2 & Hredcc).
  (* extended reference run hsR of length Lr = max (length hs) (bp+3) *)
  set (Lr := Nat.max (length hs) (S (S (S bp)))).
  assert (HLr_hs : length hs <= Lr) by (apply Nat.le_max_l).
  assert (HLr_bp : S (S (S bp)) <= Lr) by (apply Nat.le_max_r).
  destruct (Hdiv Lr HLr_hs) as [hsR [ihR [HhsRlen [HprhsR0 [_ [HpfR _]]]]]].
  destruct HprhsR0 as [thR [HathR HihR]].
  assert (Hprehsr : pre_run hsR) by (exists thR; exact HathR).
  assert (HprhsR : pr_inputs hsR ihR) by (exists thR; split; [exact HathR | exact HihR]).
  assert (HpfthR : list_prefix (inputs thR) ins) by (rewrite HihR; exact HpfR).
  assert (Hdet_R : forall j, j < length hs -> cfg_at hsR j = cfg_at hs j).
  { intros j Hj. apply (prerun_index_det ins hsR hs ihR ih j Hinp HprhsR HpfR Hprih Hpf);
      [rewrite HhsRlen; lia | exact Hj]. }
  assert (Hca_hsR : cfg_at hsR bp = Active cq s)
    by (rewrite Hdet_R; [exact Hca_hs | exact Hbplt]).
  assert (Hguard_R : emits_output_in_two l (cfg_at hsR bp)).
  { rewrite Hca_hsR. exists lo, eo, cq, s, cp0, sp0, ev1, cc0, sc0, ev2, tko.
    split; [reflexivity | split; [exact Hle | split; [exact Hredcq |
    split; [exact Hstep1 | split; [exact Hstep2 | exact Hredcc]]]]]. }
  (* the minor chain in hsR: post at bp+1, output at bp+2 *)
  assert (Hbp1lt : S bp < length hsR) by (rewrite HhsRlen; lia).
  assert (Hbp2lt : S (S bp) < length hsR) by (rewrite HhsRlen; lia).
  destruct (emits_run_post l hsR bp Hprehsr Hguard_R Hbp1lt) as [cpR [spR [HminP1 HredcpR]]].
  destruct (emits_run_out l hsR bp Hprehsr Hguard_R Hbp2lt)
    as [loR [eoR [ccR [tcR [HleR [HminP2 HredccR]]]]]].
  destruct (pre_run_step_adj hsR bp Hprehsr Hbp1lt) as [eA HstepA].
  rewrite Hca_hsR, HminP1 in HstepA.
  destruct (pre_run_step_adj hsR (S bp) Hprehsr Hbp2lt) as [eB HstepB].
  rewrite HminP1, HminP2 in HstepB.
  (* the major's command at ap equals the guard command cq (uses aligned_annot_same_cmd_hyp) *)
  assert (Hredof_fsap : redex_of (cfg_at fs ap) = Some (Cassert lo tko (Ragr eo))).
  { rewrite (Hcoin ap bp Halpha_apbp (or_introl Hannfsap)), Hca_hs. simpl.
    rewrite Hredcq. reflexivity. }
  assert (Hfsap_active : exists cqM sM, cfg_at fs ap = Active cqM sM /\
                                        redex_cmd cqM = Cassert lo tko (Ragr eo)).
  { destruct (cfg_at fs ap) as [srfa | cqM sM] eqn:Hfsap.
    - simpl in Hredof_fsap. discriminate.
    - exists cqM, sM. split; [reflexivity |].
      simpl in Hredof_fsap. injection Hredof_fsap as H. exact H. }
  destruct Hfsap_active as [cqM [sM [Hfsap HredcqM]]].
  assert (HcqMeq : cqM = cq).
  { pose proof (aligned_annot_same_cmd l fs hs alpha ap bp
                 (conj Hprefs (conj Hprehs Hproper0)) Halpha_apbp Hannfsap) as Hcmd.
    rewrite Hfsap, Hca_hs in Hcmd. simpl in Hcmd. injection Hcmd as Hcmd. exact Hcmd. }
  subst cqM.
  assert (HmajA : cfg_at (fs ++ [g]) ap = Active cq sM)
    by (rewrite cfg_at_app1 by exact Haplt; exact Hfsap).
  (* major step ap -> ap+1 = the post-assert (redex Cskip) *)
  assert (HSap_lt : S ap < length (fs ++ [g])) by (rewrite length_app; simpl; lia).
  destruct (pre_run_step_adj (fs ++ [g]) ap Hpreg HSap_lt) as [eA' HstepA'].
  rewrite HmajA in HstepA'.
  destruct (step_assert_event cq sM eA' (cfg_at (fs ++ [g]) (S ap)) lo tko (Ragr eo) Hredcq HstepA')
    as [_ [cAM HmajP1g]].
  rewrite HmajP1g in HstepA'.
  assert (HcAMeq : cAM = cpR)
    by (apply (step_assert_cmd_det cq sM s eA' eA cAM sM cpR spR lo tko (Ragr eo) Hredcq HstepA' HstepA)).
  subst cAM.
  assert (Hap1lt : S ap < length fs).
  { destruct (Nat.eq_dec (S ap) (length fs)) as [Heq | Hne]; [exfalso | lia].
    rewrite Heq, cfg_at_app2 in HmajP1g. rewrite HmajP1g in Hann.
    exact (redex_skip_not_annot l cpR sM HredcpR Hann). }
  (* major step ap+1 -> ap+2 = the output (redex Cout) *)
  assert (HSSap_lt : S (S ap) < length (fs ++ [g])) by (rewrite length_app; simpl; lia).
  destruct (pre_run_step_adj (fs ++ [g]) (S ap) Hpreg HSSap_lt) as [eB' HstepB'].
  rewrite HmajP1g in HstepB'.
  destruct (step_skip_cmd_det cpR spR sM eB eB' ccR tcR (cfg_at (fs ++ [g]) (S (S ap)))
              HredcpR HstepB HstepB') as [cM2 [tM2 [HmajP2g HccM]]].
  subst cM2.
  assert (Hap2lt : S (S ap) < length fs).
  { destruct (Nat.eq_dec (S (S ap)) (length fs)) as [Heq | Hne]; [exfalso | lia].
    rewrite Heq, cfg_at_app2 in HmajP2g. rewrite HmajP2g in Hann.
    exact (redex_out_not_annot l ccR tM2 loR eoR HredccR Hann). }
  assert (HmajP1fs : cfg_at fs (S ap) = Active cpR sM)
    by (rewrite <- (cfg_at_app1 fs g (S ap) Hap1lt); exact HmajP1g).
  assert (HmajP2 : cfg_at fs (S (S ap)) = Active ccR tM2)
    by (rewrite <- (cfg_at_app1 fs g (S (S ap)) Hap2lt); exact HmajP2g).
  assert (Hout_major : redex_is_l_output l (cfg_at fs (S (S ap)))).
  { rewrite HmajP2. unfold redex_is_l_output. simpl. rewrite HredccR. exact HleR. }
  (* truncate the minor to firstn (bp+3) hsR ending at the output bp+2 *)
  set (hst := firstn (S (S (S bp))) hsR).
  assert (Hhstlen : length hst = S (S (S bp)))
    by (unfold hst; apply firstn_length_le; rewrite HhsRlen; lia).
  assert (Hathst : admits_trace hst (firstn (S (S bp)) thR)).
  { unfold hst. apply admits_trace_firstn_full; [exact HathR | rewrite HhsRlen; lia]. }
  set (ihst := inputs (firstn (S (S bp)) thR)).
  assert (Hprhst : pr_inputs hst ihst)
    by (exists (firstn (S (S bp)) thR); split; [exact Hathst | reflexivity]).
  assert (Hprehst : pre_run hst) by (exists (firstn (S (S bp)) thR); exact Hathst).
  assert (Hpf_ihst : list_prefix ihst ins).
  { apply (list_prefix_trans _ ihst ihR ins); [| exact HpfR].
    unfold ihst. rewrite <- HihR. unfold inputs.
    exists (filter is_input_b (skipn (S (S bp)) thR)).
    rewrite <- filter_app, firstn_skipn. reflexivity. }
  assert (Hread : forall c, c < S (S (S bp)) -> cfg_at hst c = cfg_at hsR c)
    by (intros c Hc; unfold hst; apply cfg_at_firstn; exact Hc).
  assert (Hhst_bp1 : cfg_at hst (S bp) = Active cpR spR)
    by (rewrite (Hread (S bp) ltac:(lia)); exact HminP1).
  assert (Hhst_bp2 : cfg_at hst (S (S bp)) = Active ccR tcR)
    by (rewrite (Hread (S (S bp)) ltac:(lia)); exact HminP2).
  (* the aligned relation with two extra rungs ap+1~bp+1, ap+2~bp+2 *)
  set (alpha2 := fun a c =>
       (alpha a c /\ a <= ap /\ c <= bp) \/
       (a = S ap /\ c = S bp) \/
       (a = S (S ap) /\ c = S (S bp))).
  assert (Hcovi2 : forall a, a <= S (S ap) -> align_dom alpha2 a).
  { intros a Ha. unfold alpha2.
    destruct (Nat.eq_dec a (S (S ap))) as [-> | Hn2].
    - exists (S (S bp)). right; right; split; reflexivity.
    - destruct (Nat.eq_dec a (S ap)) as [-> | Hn1].
      + exists (S bp). right; left; split; reflexivity.
      + destruct (Nat.eq_dec a ap) as [-> | Hna].
        * exists bp. left; split; [exact Halpha_apbp | split; lia].
        * destruct (Hcov a ltac:(lia)) as [c Hac].
          exists c. left. split; [exact Hac |].
          split; [lia | apply (proj1 (Hmono a c ap bp Hac Halpha_apbp)); lia]. }
  assert (Hcrng2 : covers_rng hst alpha2).
  { intros c Hc. rewrite Hhstlen in Hc. unfold alpha2.
    destruct (Nat.eq_dec c (S (S bp))) as [-> | Hn2].
    - exists (S (S ap)). right; right; split; reflexivity.
    - destruct (Nat.eq_dec c (S bp)) as [-> | Hn1].
      + exists (S ap). right; left; split; reflexivity.
      + destruct (Nat.eq_dec c bp) as [-> | Hnc].
        * exists ap. left; split; [exact Halpha_apbp | split; lia].
        * destruct (Hcrng c ltac:(lia)) as [a Hac].
          exists a. left. split; [exact Hac |].
          split; [apply (proj2 (Hmono a c ap bp Hac Halpha_apbp)); lia | lia]. }
  assert (Hproper2 : proper l fs hst alpha2).
  { split.
    - split; [| split; [| split]].
      + intros a c Hac2. unfold alpha2 in Hac2.
        destruct Hac2 as [[Hac [Ha Hc]] | [[Ha Hc] | [Ha Hc]]].
        * split; [exact (proj1 (Hbound a c Hac)) | rewrite Hhstlen; lia].
        * subst a c. split; [lia | rewrite Hhstlen; lia].
        * subst a c. split; [exact Hap2lt | rewrite Hhstlen; lia].
      + intros a c d e Hac2 Hde2. unfold alpha2 in Hac2, Hde2.
        destruct Hac2 as [[Hac [Ha Hc]] | [[Ha Hc] | [Ha Hc]]];
          destruct Hde2 as [[Hde [Hd He]] | [[Hd He] | [Hd He]]];
          try (subst; split; intro; lia).
        exact (Hmono a c d e Hac Hde).
      + intros a c Hda Hca. destruct Hda as [c0 Hac0].
        assert (Ha2 : a <= S (S ap))
          by (unfold alpha2 in Hac0; destruct Hac0 as [[_ [H _]] | [[H _] | [H _]]]; lia).
        apply Hcovi2. lia.
      + intros a c Hra Hca. destruct Hra as [a0 Ha0].
        assert (Ha2 : a <= S (S bp))
          by (unfold alpha2 in Ha0; destruct Ha0 as [[_ [_ H]] | [[_ H] | [_ H]]]; lia).
        apply (Hcrng2 c). rewrite Hhstlen. lia.
    - intros a c Hac2 Hann2. unfold alpha2 in Hac2.
      destruct Hac2 as [[Hac [Ha Hc]] | [[Ha Hc] | [Ha Hc]]].
      + rewrite (Hread c ltac:(lia)), (Hdet_R c ltac:(lia)).
        rewrite (Hread c ltac:(lia)), (Hdet_R c ltac:(lia)) in Hann2.
        apply (Hcoin a c Hac). exact Hann2.
      + subst a c. exfalso. rewrite HmajP1fs, Hhst_bp1 in Hann2.
        destruct Hann2 as [H | H];
          [exact (redex_skip_not_annot l cpR sM HredcpR H)
          | exact (redex_skip_not_annot l cpR spR HredcpR H)].
      + subst a c. exfalso. rewrite HmajP2, Hhst_bp2 in Hann2.
        destruct Hann2 as [H | H];
          [exact (redex_out_not_annot l ccR tM2 loR eoR HredccR H)
          | exact (redex_out_not_annot l ccR tcR loR eoR HredccR H)]. }
  assert (Hmod2 : forall a c l' tk Phi, alpha2 a c ->
     (redex_of (cfg_at fs a) = Some (Cassume l' tk Phi) \/
      redex_of (cfg_at fs a) = Some (Cassert l' tk Phi)) ->
     lleq l' l -> models (cfg_state (cfg_at fs a)) (cfg_state (cfg_at hst c)) Phi).
  { intros a c l' tk Phi Hac2 Hred Hlel. unfold alpha2 in Hac2.
    destruct Hac2 as [[Hac [Ha Hc]] | [[Ha Hc] | [Ha Hc]]].
    - rewrite (Hread c ltac:(lia)), (Hdet_R c ltac:(lia)).
      apply (Hmod a c l' tk Phi Hac Hred Hlel).
    - subst a c. exfalso. rewrite HmajP1fs in Hred. simpl in Hred. rewrite HredcpR in Hred.
      destruct Hred as [Hr | Hr]; discriminate Hr.
    - subst a c. exfalso. rewrite HmajP2 in Hred. simpl in Hred. rewrite HredccR in Hred.
      destruct Hred as [Hr | Hr]; discriminate Hr. }
  assert (Halpha2_end : alpha2 (S (S ap)) (length hst - 1)).
  { unfold alpha2. right; right. split; [reflexivity | rewrite Hhstlen; reflexivity]. }
  assert (Houthst : redex_is_l_output l (cfg_at hst (length hst - 1))).
  { replace (length hst - 1) with (S (S bp)) by (rewrite Hhstlen; reflexivity).
    rewrite Hhst_bp2. unfold redex_is_l_output. simpl. rewrite HredccR. exact HleR. }
  assert (Hcase2 : (S (S ap) = 0 /\ length hst = 1) \/
                   redex_is_l_annotation l (cfg_at fs (S (S ap))) \/
                   (redex_is_l_output l (cfg_at fs (S (S ap))) /\
                    redex_is_l_output l (cfg_at hst (length hst - 1))))
    by (right; right; split; [exact Hout_major | exact Houthst]).
  assert (Hgap2 : forall m, S (S ap) < m -> m < length fs -> ~ redex_is_l_annotation l (cfg_at fs m))
    by (intros m Hm1 Hm2; apply Hgapfs; [lia | exact Hm2]).
  (* the rebased divergence source for hsR *)
  assert (HdivR : forall n, n >= length hsR -> exists hs' ih', length hs' = n /\ pr_inputs hs' ih' /\
                    list_prefix ihR ih' /\ list_prefix ih' ins /\
                    ~ redex_is_l_annotation l (last_cfg hs')).
  { intros n Hn. rewrite HhsRlen in Hn.
    destruct (Hdiv n ltac:(lia)) as [hs' [ih' [Hlen' [Hpr' [_ [Hpf' Hlast']]]]]].
    exists hs', ih'. split; [exact Hlen' | split; [exact Hpr' |
      split; [| split; [exact Hpf' | exact Hlast']]]].
    destruct Hpr' as [th' [Hath' Hih']].
    assert (Hpfth' : list_prefix (inputs th') ins) by (rewrite Hih'; exact Hpf').
    pose proof (prerun_trace_prefix ins hsR thR hs' th' Hinp HathR HpfthR Hath' Hpfth'
                  ltac:(lia)) as Htp.
    destruct Htp as [rest Hrest].
    rewrite <- HihR, <- Hih'. exists (filter is_input_b rest).
    unfold inputs. rewrite <- filter_app, Hrest. reflexivity. }
  assert (Hfam : diverge_family l ins hst ihst).
  { apply (diverge_family_build l ins hst ihst hsR ihR Hinp Hprehst Hprhst Hpf_ihst
             Hprehsr HprhsR HpfR ltac:(rewrite Hhstlen, HhsRlen; lia)).
    - intros q Hq1 Hq2. rewrite Hhstlen in Hq1. rewrite HhsRlen in Hq2.
      assert (Hqlt : q < length hs).
      { destruct (Nat.max_spec (length hs) (S (S (S bp)))) as [[_ Hm] | [_ Hm]];
          unfold Lr in Hq2; rewrite Hm in Hq2; lia. }
      rewrite (Hdet_R q Hqlt). apply Hgaphs; [lia | exact Hqlt].
    - exact HdivR.
    - right. rewrite Hhstlen. replace (S (S (S bp)) - 1) with (S (S bp)) by lia.
      rewrite HminP2. simpl. rewrite HredccR. discriminate.
    - rewrite Hhstlen. replace (S (S (S bp)) - 1) with (S (S bp)) by lia.
      intro Hem. rewrite HminP2 in Hem.
      destruct Hem as (lo' & eo' & cq' & s' & cp' & sp' & ev1' & cc' & sc' & ev2' & tk' &
                       Hca' & _ & Hredcq' & _).
      injection Hca' as Hcqeq _. subst cq'. rewrite HredccR in Hredcq'. discriminate Hredcq'. }
  destruct (conformance_extend_diverge_trunc l ins fs g hst alpha2 (S (S ap)) ihst
              Hinp Hap2lt Hpreg Hprehst Hproper2 Hcrng2 Hmod2 Hann Halpha2_end Hcase2 Hgap2
              Hcovi2 Hprhst Hpf_ihst Hfam) as [alpha' Hdf].
  exists hst, alpha'. exact Hdf.
Qed.

(* The divergence outcome of classify_step_annot, with the revised divergence_fiat:
   locate the major's last annotation (or origin), align it to the minor's last
   annotation, truncate, and build the divergence_fiat. *)
Lemma classify_diverge_case : forall l ins fs g hs alpha ih,
  Forall is_input ins ->
  pre_run (fs ++ [g]) ->
  conformance l ins fs hs alpha ->
  covers_dom fs alpha ->
  redex_is_l_annotation l g ->
  ~ redex_is_l_annotation l (cfg_at fs (length fs - 1)) ->
  ~ redex_is_l_annotation l (last_cfg hs) ->
  pr_inputs hs ih -> list_prefix ih ins ->
  (forall n, n >= length hs -> exists hs' ih', length hs' = n /\ pr_inputs hs' ih' /\
       list_prefix ih ih' /\ list_prefix ih' ins /\ ~ redex_is_l_annotation l (last_cfg hs')) ->
  exists hs' alpha',
    divergence_fiat l ins (fs ++ [g]) hs' alpha'.
Proof.
  intros l ins fs g hs alpha ih Hinp Hpreg Hconf Hcov Hann Hnotannfs Hnotannhs Hprih Hpleih Hdiv.
  destruct Hconf as [[Hprefs [Hprehs Hproper]] [_ [Hcrng [Hmod _]]]].
  pose proof Hproper as Hproper2.
  destruct Hproper2 as [[Hbound [Hmono [_ _]]] Hcoin].
  assert (Hfspos : 0 < length fs)
    by (destruct fs; [exfalso; apply (pre_run_nonempty _ Hprefs); reflexivity | simpl; lia]).
  assert (Hhspos : 0 < length hs)
    by (destruct hs; [exfalso; apply (pre_run_nonempty _ Hprehs); reflexivity | simpl; lia]).
  destruct (last_annot_or_none l fs) as [Hno_fs | [ap [Haplt [Hannfsap Hgapfs]]]].
  - (* fs has no l-annotation: origin case i = 0, b = 0 *)
    destruct (Hcov 0 ltac:(lia)) as [c0 Ha0c0].
    destruct (Hcrng 0 ltac:(lia)) as [a0 Haa0].
    assert (Halpha00 : alpha 0 0).
    { destruct (Nat.eq_dec a0 0) as [-> | Hne]; [exact Haa0 |].
      assert (Hc0le : c0 <= 0) by (apply (proj1 (Hmono 0 c0 a0 0 Ha0c0 Haa0)); lia).
      replace c0 with 0 in Ha0c0 by lia. exact Ha0c0. }
    assert (Hno_hs : forall q, q < length hs -> ~ redex_is_l_annotation l (cfg_at hs q)).
    { intros q Hq Hannq. destruct (Hcrng q Hq) as [a Haq].
      assert (Ha_lt : a < length fs) by (apply (Hbound a q Haq)).
      apply (Hno_fs a Ha_lt).
      assert (Hco : redex_of (cfg_at fs a) = redex_of (cfg_at hs q))
        by (apply Hcoin; [exact Haq | right; exact Hannq]).
      unfold redex_is_l_annotation in *. rewrite Hco. exact Hannq. }
    assert (Hdf : exists hs' alpha', divergence_fiat l ins (fs ++ [g]) hs' alpha').
    { apply (divergence_from_truncation l ins fs g hs alpha ih 0 0
               Hinp Hpreg Hprefs Hprehs Hproper Hcrng Hmod Hcov Hann Hprih Hpleih Hdiv
               Hfspos Hhspos Halpha00).
      + left. split; reflexivity.
      + intros m Hm1 Hm2. apply Hno_fs; exact Hm2.
      + intros q Hq1 Hq2. apply Hno_hs; exact Hq2.
      + left. reflexivity.
      + intro Hem.
        destruct Hem as (lo & eo & cq & s0 & cp & sp & ev1 & cc & sc & ev2 & _ & Hc & _).
        rewrite (prerun_head hs Hprehs) in Hc. discriminate Hc. }
    destruct Hdf as [hs' [alpha' Hd]]. exists hs', alpha'. exact Hd.
  - (* fs has a last annotation ap; align to the last minor annotation bp *)
    destruct (Hcov ap Haplt) as [b0 Hapb0].
    assert (Hb0_lt : b0 < length hs) by (apply (Hbound ap b0 Hapb0)).
    assert (Hannhsb0 : redex_is_l_annotation l (cfg_at hs b0)).
    { assert (Hco : redex_of (cfg_at fs ap) = redex_of (cfg_at hs b0))
        by (apply Hcoin; [exact Hapb0 | left; exact Hannfsap]).
      unfold redex_is_l_annotation in *. rewrite <- Hco. exact Hannfsap. }
    destruct (last_annot_or_none l hs) as [Hno_hs | [bp [Hbplt [Hannhsbp Hgaphs]]]].
    + exfalso. apply (Hno_hs b0 Hb0_lt). exact Hannhsb0.
    + destruct (Hcrng bp Hbplt) as [a' Ha'bp].
      assert (Hann_fsa' : redex_is_l_annotation l (cfg_at fs a')).
      { assert (Hco : redex_of (cfg_at fs a') = redex_of (cfg_at hs bp))
          by (apply Hcoin; [exact Ha'bp | right; exact Hannhsbp]).
        unfold redex_is_l_annotation in *. rewrite Hco. exact Hannhsbp. }
      assert (Ha'_lt : a' < length fs) by (apply (Hbound a' bp Ha'bp)).
      assert (Ha'le : a' <= ap).
      { destruct (le_lt_dec a' ap) as [Hle | Hgt];
          [exact Hle | exfalso; apply (Hgapfs a' Hgt Ha'_lt); exact Hann_fsa']. }
      assert (Hb0le : b0 <= bp).
      { destruct (le_lt_dec b0 bp) as [Hle | Hgt];
          [exact Hle | exfalso; apply (Hgaphs b0 Hgt Hb0_lt); exact Hannhsb0]. }
      assert (Halpha_apbp : alpha ap bp).
      { destruct (Nat.eq_dec a' ap) as [-> | Hne]; [exact Ha'bp |].
        assert (Hbple : bp <= b0) by (apply (proj1 (Hmono a' bp ap b0 Ha'bp Hapb0)); lia).
        assert (Hbpb0 : bp = b0) by lia. rewrite Hbpb0. exact Hapb0. }
      destruct (classic (emits_output_in_two l (cfg_at hs bp))) as [Hguard | Hnoguard].
      * (* the minor's last l-annotation is an output guard: the matched output is
           emitted at bp+2 in both runs; build the output-endpoint divergence_fiat. *)
        destruct (divergence_from_output_guard l ins fs g hs alpha ih ap bp
                    Hinp Hpreg Hprefs Hprehs Hproper Hcrng Hmod Hcov Hann Hprih Hpleih Hdiv
                    Haplt Hbplt Halpha_apbp Hannfsap Hgapfs Hgaphs Hguard) as [hs' [alpha' Hd]].
        exists hs', alpha'. exact Hd.
      * (* the minor's last l-annotation does not guard an l-output: genuine silent
           divergence (annotation endpoint at bp). *)
        assert (Hdf : exists hs' alpha', divergence_fiat l ins (fs ++ [g]) hs' alpha').
        { apply (divergence_from_truncation l ins fs g hs alpha ih ap bp
                   Hinp Hpreg Hprefs Hprehs Hproper Hcrng Hmod Hcov Hann Hprih Hpleih Hdiv
                   Haplt Hbplt Halpha_apbp).
          - right. exact Hannfsap.
          - exact Hgapfs.
          - exact Hgaphs.
          - right. exact Hannhsbp.
          - exact Hnoguard. }
        destruct Hdf as [hs' [alpha' Hd]]. exists hs', alpha'. exact Hd.
Qed.

Lemma classify_step_annot : forall l ins fs g hs alpha es ev,
  admits_trace fs es ->
  step (last_cfg fs) ev g ->
  pre_run fs ->
  pre_run (fs ++ [g]) ->
  conformance l ins fs hs alpha ->
  covers_dom fs alpha ->
  minor_phase_ok l fs hs ->
  redex_is_l_annotation l g ->
  exists hs' alpha',
    (conformance l ins (fs ++ [g]) hs' alpha' /\ minor_phase_ok l (fs ++ [g]) hs') \/
    assertion_failure l ins (fs ++ [g]) hs' alpha' \/
    alignment_failure l ins (fs ++ [g]) hs' alpha' \/
    assumption_fiat l ins (fs ++ [g]) hs' alpha' \/
    divergence_fiat l ins (fs ++ [g]) hs' alpha'.
Proof.
  intros l ins fs g hs alpha es ev Hat Hstep Hprefs Hpreg Hconf Hcov Hphase Hann.
  assert (Hinp : Forall is_input ins) by (apply (conformance_inputs l ins fs hs alpha); exact Hconf).
  assert (Hfsne : fs <> []) by (apply pre_run_nonempty; exact Hprefs).
  assert (Hlastg : last_cfg (fs ++ [g]) = g) by
    (unfold last_cfg; rewrite (last_app_nonempty config fs [g] (Receptive initState))
       by discriminate; reflexivity).
  assert (Hnotannlastfs : ~ redex_is_l_annotation l (last_cfg fs)) by
    (apply (step_to_annot_not_annot (last_cfg fs) ev g l Hstep Hann)).
  assert (Hnotannfs : ~ redex_is_l_annotation l (cfg_at fs (length fs - 1))) by
    (rewrite (last_eq_cfg_at fs Hfsne); exact Hnotannlastfs).
  assert (Hnotannhs : ~ redex_is_l_annotation l (last_cfg hs)) by
    (intro H; apply Hnotannlastfs; apply Hphase; exact H).
  assert (Hprehs : pre_run hs) by (destruct Hconf as [[_ [Hp _]] _]; exact Hp).
  assert (Hhspos : 0 < length hs) by
    (destruct hs; [exfalso; apply (pre_run_nonempty _ Hprehs); reflexivity | simpl; lia]).
  assert (Hihex : exists ih, pr_inputs hs ih /\ list_prefix ih ins).
  { destruct Hconf as [_ [[ih [Hp [Hl _]]] _]]. exists ih. split; [exact Hp | exact Hl]. }
  destruct Hihex as [ih [Hprih Hpleih]].
  destruct (grow_to_annotation l ins hs ih Hinp Hprehs Hprih Hpleih)
    as [[hs' [ih' [HpreHs [HprHs [HpleHs [Hann_lastHs Hnogrow]]]]]]
       | [[hs' [ih' [HpreHs [HprHs [Heq_ins [Hrec_Hs Hnogrow]]]]]]
         | Hdiv]].
  - (* outcome 1: annotation reached at hs ++ hs' *)
    assert (Hhsne' : hs' <> []) by
      (intro Hnil; subst hs'; rewrite app_nil_r in Hann_lastHs; apply Hnotannhs; exact Hann_lastHs).
    assert (Hstrict : length hs <= length (hs ++ hs') - 1) by
      (rewrite length_app; destruct hs'; [contradiction | simpl; lia]).
    assert (HHs2 : 1 < length (hs ++ hs')) by
      (rewrite length_app; destruct hs'; [contradiction | simpl; lia]).
    destruct (classic (redex_of g = redex_of (last_cfg (hs ++ hs')))) as [Hredeq | Hredneq].
    + (* redexes equal: decide the formula *)
      assert (Hex : exists c0, redex_of g = Some c0 /\ is_l_annotation l c0).
      { unfold redex_is_l_annotation in Hann. destruct (redex_of g) as [c0 |];
          [exists c0; split; [reflexivity | exact Hann] | contradiction]. }
      destruct Hex as [c0 [Eg Hannc]].
      unfold is_l_annotation in Hannc. destruct Hannc as [Hasm | Hast].
      * (* assume *)
        unfold is_l_assume in Hasm. destruct c0 as [ | | | | | | l0 tk Phi | l0 tk Phi ];
          try contradiction.
        destruct (classic (models_prerun (fs ++ [g]) (hs ++ hs') Phi)) as [Hmh | Hmf].
        -- (* gamma conformance *)
           exists (hs ++ hs'),
             (fun i j => alpha i j
                         \/ (i = length fs - 1 /\ length hs <= j /\ j < length (hs ++ hs') - 1)
                         \/ (i = length fs /\ j = length (hs ++ hs') - 1)).
           left. split.
           ++ apply (conformance_extend_annot l ins fs g hs (hs ++ hs') alpha
                       Hpreg Hconf Hcov Hnotannfs HpreHs).
              ** exists hs'. reflexivity.
              ** exists (ih ++ ih'). split; [exact HprHs | exact HpleHs].
              ** exact Hnogrow.
              ** exact Hredeq.
              ** intros l' tk' Phi' Hredg' Hle'. rewrite Eg in Hredg'.
                 destruct Hredg' as [Hr | Hr]; [injection Hr as Hl1 Hp1; subst | discriminate].
                 exact Hmh.
           ++ unfold minor_phase_ok. intro Hcontra. rewrite Hlastg.
              unfold redex_is_l_annotation. rewrite Eg. left. exact Hasm.
        -- (* assumption fiat *)
           exists (hs ++ hs'),
             (fun i j => alpha i j
                         \/ (i = length fs - 1 /\ length hs <= j /\ j < length (hs ++ hs') - 1)
                         \/ (i = length fs /\ j = length (hs ++ hs') - 1)).
           right; right; right; left.
           apply (conformance_extend_assumefail l ins fs g hs (hs ++ hs') alpha l0 tk Phi
                    Hpreg Hconf Hcov Hnotannfs HpreHs).
           ++ exists hs'. reflexivity.
           ++ exact HHs2.
           ++ exact Hstrict.
           ++ exists (ih ++ ih'). split; [exact HprHs | exact HpleHs].
           ++ exact Hnogrow.
           ++ exact Hredeq.
           ++ exact Eg.
           ++ exact Hasm.
           ++ exact Hmf.
      * (* assert *)
        unfold is_l_assert in Hast. destruct c0 as [ | | | | | | l0 tk Phi | l0 tk Phi ];
          try contradiction.
        destruct (classic (models_prerun (fs ++ [g]) (hs ++ hs') Phi)) as [Hmh | Hmf].
        -- (* gamma conformance *)
           exists (hs ++ hs'),
             (fun i j => alpha i j
                         \/ (i = length fs - 1 /\ length hs <= j /\ j < length (hs ++ hs') - 1)
                         \/ (i = length fs /\ j = length (hs ++ hs') - 1)).
           left. split.
           ++ apply (conformance_extend_annot l ins fs g hs (hs ++ hs') alpha
                       Hpreg Hconf Hcov Hnotannfs HpreHs).
              ** exists hs'. reflexivity.
              ** exists (ih ++ ih'). split; [exact HprHs | exact HpleHs].
              ** exact Hnogrow.
              ** exact Hredeq.
              ** intros l' tk' Phi' Hredg' Hle'. rewrite Eg in Hredg'.
                 destruct Hredg' as [Hr | Hr]; [discriminate | injection Hr as Hl1 Hp1; subst].
                 exact Hmh.
           ++ unfold minor_phase_ok. intro Hcontra. rewrite Hlastg.
              unfold redex_is_l_annotation. rewrite Eg. right. exact Hast.
        -- (* assertion failure *)
           exists (hs ++ hs'),
             (fun i j => alpha i j
                         \/ (i = length fs - 1 /\ length hs <= j /\ j < length (hs ++ hs') - 1)
                         \/ (i = length fs /\ j = length (hs ++ hs') - 1)).
           right; left.
           apply (conformance_extend_assertfail l ins fs g hs (hs ++ hs') alpha l0 tk Phi
                    Hpreg Hconf Hcov Hnotannfs HpreHs).
           ++ exists hs'. reflexivity.
           ++ exact HHs2.
           ++ exact Hstrict.
           ++ exists (ih ++ ih'). split; [exact HprHs | exact HpleHs].
           ++ exact Hnogrow.
           ++ exact Hredeq.
           ++ exact Eg.
           ++ exact Hast.
           ++ exact Hmf.
    + (* redexes differ: alignment failure *)
      exists (hs ++ hs'),
        (fun i j => alpha i j
                    \/ (i = length fs - 1 /\ length hs <= j /\ j < length (hs ++ hs') - 1)
                    \/ (i = length fs /\ j = length (hs ++ hs') - 1)).
      right; right; left.
      apply (conformance_extend_alignfail l ins fs g hs (hs ++ hs') alpha
               Hpreg Hconf Hcov Hnotannfs HpreHs).
      * exists hs'. reflexivity.
      * exact HHs2.
      * exact Hstrict.
      * exists (ih ++ ih'). split; [exact HprHs | exact HpleHs].
      * exact Hnogrow.
      * exact Hann.
      * exact Hann_lastHs.
      * intro H. apply Hredneq. symmetry. exact H.
  - (* outcome 2: exhausted, conformance *)
    exists (hs ++ hs'),
      (fun i j => alpha i j \/ (i = length fs - 1 /\ length hs <= j /\ j < length (hs ++ hs'))).
    left. split.
    + apply (conformance_extend_stutter l ins fs g hs (hs ++ hs') alpha
               Hpreg Hconf Hcov Hnotannfs HpreHs).
      * exists hs'. reflexivity.
      * rewrite <- Heq_ins. exact HprHs.
      * exact Hrec_Hs.
      * exact Hnogrow.
    + unfold minor_phase_ok. intro Hcontra. exfalso.
      destruct Hrec_Hs as [sHs HrecEq]. unfold redex_is_l_annotation in Hcontra.
      rewrite HrecEq in Hcontra. simpl in Hcontra. exact Hcontra.
  - (* outcome 3: divergence fiat *)
    destruct (classify_diverge_case l ins fs g hs alpha ih
                Hinp Hpreg Hconf Hcov Hann Hnotannfs Hnotannhs Hprih Hpleih Hdiv)
      as [hs' [alpha' Hdf]].
    exists hs', alpha'. right; right; right; right. exact Hdf.
Qed.

(* The hard kernel of the induction step: extend a conformance that COVERS fs by
   one step to g. Dispatch on whether redex(g) is an l-annotation: if not, the
   pair (g, last hs) extends the conformance directly (conformance_extend_pair);
   if so, defer to classify_step_annot (the grow_to_annotation dispatch). *)
Lemma classify_step_covered : forall l ins fs g hs alpha es ev,
  admits_trace fs es ->
  step (last_cfg fs) ev g ->
  pre_run fs ->
  pre_run (fs ++ [g]) ->
  conformance l ins fs hs alpha ->
  covers_dom fs alpha ->
  minor_phase_ok l fs hs ->
  exists hs' alpha',
    (conformance l ins (fs ++ [g]) hs' alpha' /\ minor_phase_ok l (fs ++ [g]) hs') \/
    assertion_failure l ins (fs ++ [g]) hs' alpha' \/
    alignment_failure l ins (fs ++ [g]) hs' alpha' \/
    assumption_fiat l ins (fs ++ [g]) hs' alpha' \/
    divergence_fiat l ins (fs ++ [g]) hs' alpha'.
Proof.
  intros l ins fs g hs alpha es ev Hat Hstep Hprefs Hpreg Hconf Hcovd Hphase.
  destruct (redex_is_l_annotation_dec l g) as [Hann | Hnann].
  - apply (classify_step_annot l ins fs g hs alpha es ev
             Hat Hstep Hprefs Hpreg Hconf Hcovd Hphase Hann).
  - destruct (redex_is_l_annotation_dec l (last_cfg hs)) as [Hlann | Hlnann].
    + (* last hs is a pending annotation: advance the minor one step *)
      destruct (conformance_extend_pair_advance l ins fs g hs alpha
                  Hpreg Hconf Hcovd Hnann Hlann) as [hs' [alpha' [Hc' Hnn']]].
      exists hs', alpha'. left. split; [exact Hc' |].
      unfold minor_phase_ok. intro Hcontra. exfalso. apply Hnn'. exact Hcontra.
    + (* last hs not an annotation: pair g with last hs directly *)
      exists hs, (fun i j => alpha i j \/ (i = length fs /\ j = length hs - 1)).
      left. split.
      * apply conformance_extend_pair; assumption.
      * unfold minor_phase_ok. intro Hcontra. exfalso. apply Hlnann. exact Hcontra.
Qed.

Lemma classification_exists : forall gs ins l,
  Forall is_input ins ->
  pre_run gs ->
  exists hs alpha,
    (conformance l ins gs hs alpha /\ minor_phase_ok l gs hs) \/
    assertion_failure l ins gs hs alpha \/
    alignment_failure l ins gs hs alpha \/
    assumption_fiat l ins gs hs alpha \/
    divergence_fiat l ins gs hs alpha.
Proof.
  intros gs ins l Hinp Hpre. destruct Hpre as [evs Hat].
  induction Hat as [| fs es ev g Hat' IH Hstep].
  - (* base: gs = [Receptive initState] *)
    exists [Receptive initState], (fun i j => i = 0 /\ j = 0).
    left. split; [apply classif_base; exact Hinp | unfold minor_phase_ok; intro H; exact H].
  - (* step: gs = fs ++ [g] *)
    assert (Hpref : pre_run fs) by (exists es; exact Hat').
    assert (Hpreg : pre_run (fs ++ [g])) by
      (exists (es ++ [ev]); apply AT_step; assumption).
    destruct IH as [hs [alpha Hclass]].
    destruct Hclass as [[Hconf Hphase] | [HassertF | [HalignF | [Hassum | Hdiv]]]].
    + (* conformance of fs: exhausted (receptive) vs covered (Case B) *)
      assert (Hcopy := Hconf).
      destruct Hcopy as [_ [Hex [_ _]]]. destruct Hex as [ih [Hpr [Hple Hdisj]]].
      destruct Hdisj as [Hcovd | [Hiheq Hrec]].
      * apply (classify_step_covered l ins fs g hs alpha es ev
                 Hat' Hstep Hpref Hpreg Hconf Hcovd Hphase).
      * exists hs, alpha. left. split.
        -- apply (conformance_extend_receptive l ins fs g hs alpha Hpreg Hconf).
           ++ exists ih. split; [exact Hpr | exact Hiheq].
           ++ exact Hrec.
        -- unfold minor_phase_ok. intro H. exfalso.
           destruct Hrec as [shs Hrec_eq]. unfold redex_is_l_annotation in H.
           rewrite Hrec_eq in H. simpl in H. exact H.
    + (* assertion_failure *)
      destruct HassertF as [i Hi]. exists hs, alpha. right; left. exists i.
      apply assertion_failure_at_extend; [exact Hpreg | exact Hi].
    + (* alignment_failure *)
      destruct HalignF as [i Hi]. exists hs, alpha. right; right; left. exists i.
      apply alignment_failure_at_extend; [exact Hpreg | exact Hi].
    + (* assumption_fiat *)
      destruct Hassum as [i Hi]. exists hs, alpha. right; right; right; left. exists i.
      apply assumption_fiat_at_extend; [exact Hpreg | exact Hi].
    + (* divergence_fiat *)
      destruct Hdiv as [i Hi]. exists hs, alpha. right; right; right; right. exists i.
      destruct Hi as [k Hik]. exists k.
      apply divergence_fiat_at_extend; [exact Hpreg | exact Hik].
Qed.

(* ---------------------------------------------------------- *) 
(* safety is backward closed 
   lem:contractSafe in paper *) 
(* ---------------------------------------------------------- *) 

Lemma contractSafe : forall l gs g,
  pre_run (gs ++ [g]) -> pre_run gs ->
  safe_for_level l (gs ++ [g]) -> safe_for_level l gs.
Proof.
  intros l gs g Hpre Hpregs Hsafe. unfold safe_for_level, safe_for in *.
  intros ins Hinp.
  destruct (classification_exists gs ins l Hinp Hpregs) as [hs [alpha Hclass]].
  destruct Hclass as [[Hconf _] | [HassertF | [HalignF | [Hassum | Hdiv]]]].
  - exists hs, alpha. left. exact Hconf.
  - exfalso. destruct HassertF as [i Hat].
    assert (HF : assertion_failure l ins (gs ++ [g]) hs alpha).
    { exists i. apply assertion_failure_at_extend; [exact Hpre | exact Hat]. }
    destruct (Hsafe ins Hinp) as [hs' [alpha' [Hc' | [Ha' | Hd']]]].
    + exact (conf_excl_assertF l ins (gs ++ [g]) hs' alpha' hs alpha Hc' HF).
    + exact (assumF_excl_assertF l ins (gs ++ [g]) hs' alpha' hs alpha Ha' HF).
    + exact (divF_excl_assertF l ins (gs ++ [g]) hs' alpha' hs alpha Hd' HF).
  - exfalso. destruct HalignF as [i Hat].
    assert (HF : alignment_failure l ins (gs ++ [g]) hs alpha).
    { exists i. apply alignment_failure_at_extend; [exact Hpre | exact Hat]. }
    destruct (Hsafe ins Hinp) as [hs' [alpha' [Hc' | [Ha' | Hd']]]].
    + exact (conf_excl_alignF l ins (gs ++ [g]) hs' alpha' hs alpha Hc' HF).
    + exact (assumF_excl_alignF l ins (gs ++ [g]) hs' alpha' hs alpha Ha' HF).
    + exact (divF_excl_alignF l ins (gs ++ [g]) hs' alpha' hs alpha Hd' HF).
  - exists hs, alpha. right. left. exact Hassum.
  - exists hs, alpha. right. right. exact Hdiv.
Qed.

Lemma safe_for_level_suffix : forall l zs gs',
  pre_run gs' -> pre_run (gs' ++ zs) ->
  safe_for_level l (gs' ++ zs) -> safe_for_level l gs'.
Proof.
  intros l zs. induction zs as [| c zs' IHzs] using rev_ind; intros gs' Hpregs' Hpre Hsafe.
  - rewrite app_nil_r in Hsafe. exact Hsafe.
  - rewrite app_assoc in Hpre, Hsafe.
    assert (Hne : gs' ++ zs' <> [])
      by (intro Hc2; apply app_eq_nil in Hc2; destruct Hc2 as [Hg _];
          apply (pre_run_nonempty gs' Hpregs'); exact Hg).
    assert (Hpre_xs : pre_run (gs' ++ zs'))
      by (apply (pre_run_snoc_inv (gs' ++ zs') c Hpre Hne)).
    assert (Hsafe' : safe_for_level l (gs' ++ zs'))
      by (apply (contractSafe l (gs' ++ zs') c Hpre Hpre_xs Hsafe)).
    apply (IHzs gs' Hpregs' Hpre_xs Hsafe').
Qed.

Lemma safe_for_level_prefix : forall l gs gs',
  list_prefix gs' gs -> pre_run gs' -> safe_for_level l gs -> safe_for_level l gs'.
Proof.
  intros l gs gs' [zs Hgs] Hpregs' Hsafe. subst gs.
  assert (Hpre : pre_run (gs' ++ zs)).
  { destruct (Hsafe [] (Forall_nil _)) as [hs0 [a0 [Hc | [Ha | Hd]]]].
    - destruct Hc as [[Hp _] _]. exact Hp.
    - destruct Ha as [i0 [[Hp _] _]]. exact Hp.
    - destruct Hd as [i0 [k0 [_ [_ [_ [[Hp _] _]]]]]]. exact Hp. }
  apply (safe_for_level_suffix l zs gs' Hpregs' Hpre Hsafe).
Qed.

(* ----------------------------------------------------------------------- *)
(* more technical results for main theorem *)
(* ----------------------------------------------------------------------- *)

(* Move 1 of the conformance-case argument: in [conformance]'s receptive
   disjunct (the minor [fs] consumed all of [ins] and halted receptive),
   progress knowledge [pknow l ts ins] forces [fs] to realize STRICTLY more than
   [|vis l ts|] l-visible events.  Reason: the [pknow] witness [W] runs on the
   same [ins] but cannot outrun [fs]'s receptive halt (every step out of a
   receptive config consumes an input, and [ins] is exhausted), so by
   determinacy [W]'s trace is a prefix of [fs]'s trace; [W] already reaches all
   of [vis l ts] plus a further l-visible event, hence so does [fs]. *)
Lemma pknow_minor_progress : forall l ins ts fs tf,
  Forall is_input ins ->
  admits_trace fs tf -> inputs tf = ins ->
  is_receptive (last_cfg fs) ->
  pknow l ts ins ->
  list_prefix (vis l ts) (vis l tf) /\ length (vis l ts) < length (vis l tf).
Proof.
  intros l ins ts fs tf Hforall Hattf Hinputs Hrecv Hpk.
  destruct Hpk as [W [us0 [ev0 [vs0 [Hvev [HatW [Hpre Hins]]]]]]].
  set (twW := us0 ++ [ev0] ++ vs0) in *.
  assert (Hpr_fs : pr_inputs fs ins) by (exists tf; split; [exact Hattf | exact Hinputs]).
  assert (Hpr_W : pr_inputs W ins) by (exists twW; split; [exact HatW | symmetry; exact Hins]).
  pose proof (prerun_exhausted_maximal ins fs ins W ins Hforall Hpr_fs eq_refl Hrecv Hpr_W
                (list_prefix_refl _ ins)) as Hlen.
  assert (HitwW : inputs twW = ins) by (symmetry; exact Hins).
  assert (Hpa : list_prefix (inputs twW) ins) by (rewrite HitwW; apply list_prefix_refl).
  assert (Hpb : list_prefix (inputs tf) ins) by (rewrite Hinputs; apply list_prefix_refl).
  pose proof (prerun_trace_prefix ins W twW fs tf Hforall HatW Hpa Hattf Hpb Hlen)
    as [zs Htf_eq].
  assert (Hle_ts : length (vis l ts) <= length (vis l us0))
    by (apply list_prefix_length; exact Hpre).
  assert (Htf_len : length (vis l tf) = length (vis l twW) + length (vis l zs))
    by (rewrite Htf_eq, vis_app, length_app; reflexivity).
  assert (HtwW_len : length (vis l twW) = length (vis l us0) + S (length (vis l vs0))).
  { unfold twW.
    replace (us0 ++ [ev0] ++ vs0) with (us0 ++ (ev0 :: vs0)) by reflexivity.
    rewrite vis_app, (vis_cons_visible l ev0 vs0 Hvev), length_app. simpl. reflexivity. }
  split; [| lia].
  apply (list_prefix_trans _ (vis l ts) (vis l us0) (vis l tf)); [exact Hpre |].
  exists (vis l (([ev0] ++ vs0) ++ zs)).
  rewrite Htf_eq. unfold twW. rewrite <- app_assoc, vis_app. reflexivity.
Qed.

(* vis_at depends only on the two local configs, so two runs agreeing there agree
   on the visible event. *)
Fact vis_at_cfg_local : forall l g1 g2 p,
  cfg_at g1 p = cfg_at g2 p -> cfg_at g1 (S p) = cfg_at g2 (S p) ->
  vis_at l g1 p = vis_at l g2 p.
Proof. intros l g1 g2 p H1 H2. unfold vis_at. rewrite H1, H2. reflexivity. Qed.

(* Indexing into the second part of an append. *)
Fact cfg_at_app_ge : forall a b q, length a <= q -> cfg_at (a ++ b) q = cfg_at b (q - length a).
Proof. intros a b q H. unfold cfg_at. rewrite app_nth2 by exact H. reflexivity. Qed.

(* Indexing into the first part of an append. *)
Fact cfg_at_app_lt : forall a b q, q < length a -> cfg_at (a ++ b) q = cfg_at a q.
Proof. intros a b q H. unfold cfg_at. rewrite app_nth1 by exact H. reflexivity. Qed.

(* l-annotation count is unaffected by extending a run past the counted prefix. *)
Fact annot_count_app_le : forall l a ex k,
  k <= length a -> annot_count l (a ++ ex) k = annot_count l a k.
Proof.
  intros l a ex k. induction k as [|k IH]; intros Hk; [reflexivity |].
  assert (Hklt : k < length a) by lia.
  destruct (redex_is_l_annotation_dec l (cfg_at a k)) as [Hann | Hnann].
  - rewrite (annot_count_annot_S l (a ++ ex) k), (annot_count_annot_S l a k Hann), IH by
      (try lia; rewrite (cfg_at_app_lt a ex k Hklt); exact Hann).
    reflexivity.
  - rewrite (annot_count_nonannot_S l (a ++ ex) k), (annot_count_nonannot_S l a k Hnann), IH by
      (try lia; rewrite (cfg_at_app_lt a ex k Hklt); exact Hnann).
    reflexivity.
Qed.

(* An annotation of a run whose rank is below the prefix's annotation count lies
   inside the prefix. *)
Fact annot_in_prefix : forall l fs ex r j,
  is_nth_annot l (fs ++ ex) r j -> r < annot_count l fs (length fs) -> j < length fs.
Proof.
  intros l fs ex r j [Hjlt [Hann Hcnt]] Hr.
  destruct (Nat.lt_ge_cases j (length fs)) as [H | Hge]; [exact H |].
  exfalso.
  pose proof (annot_count_mono l (fs ++ ex) (length fs) j Hge) as Hmono.
  rewrite (annot_count_app_le l fs ex (length fs) (Nat.le_refl _)) in Hmono.
  rewrite Hcnt in Hmono. lia.
Qed.

(* Firstn version of vis_length_positions: the visible count of a trace prefix
   equals the count of vis_at-firing positions below the cut. *)
Fact vis_length_positions_firstn : forall l gs ts N,
  admits_trace gs ts -> N <= length ts ->
  length (vis l (firstn N ts)) =
  length (filter (fun p => match vis_at l gs p with Some _ => true | None => false end)
                 (seq 0 N)).
Proof.
  intros l gs ts N Hat HN. unfold vis.
  rewrite (filter_eq_collect (visible_atb l) (firstn N ts) Etick), collect_opt_length.
  rewrite length_firstn, (Nat.min_l N (length ts) HN), filter_map_length.
  apply filter_seq_ext_length. intros i Hi.
  rewrite nth_firstn by exact Hi.
  rewrite (vis_at_char l gs ts i Hat ltac:(lia)).
  destruct (visible_atb l (nth i ts Etick)); reflexivity.
Qed.

(* Extending the trace prefix past an l-visible position increments the visible
   count by exactly one. *)
Fact vis_firstn_succ_visible : forall l gs tr i,
  admits_trace gs tr -> S i <= length tr -> vis_at l gs i <> None ->
  length (vis l (firstn (S i) tr)) = length (vis l (firstn i tr)) + 1.
Proof.
  intros l gs tr i Hat HSi Hvis.
  rewrite (vis_length_positions_firstn l gs tr (S i) Hat HSi).
  rewrite (vis_length_positions_firstn l gs tr i Hat ltac:(lia)).
  rewrite seq_S, filter_app, length_app. simpl.
  destruct (vis_at l gs i) eqn:Hva; [simpl; lia | contradiction].
Qed.

(* ====================================================================== *)
(* REVERSE BRIDGE (covers_dom branch): the MAJOR's visible trace is a prefix *)
(* of the MINOR's, when the minor runs maximally (ends receptive).  Mirrors  *)
(* the forward out/in_maps machinery with the roles of ds (major) and es     *)
(* (minor) swapped: matching uses major_minor_rank (covers_dom), and the     *)
(* realization on the minor side is free because a receptive-ending run never *)
(* halts at an Active config (active_succ_lt), so every paired assert reaches *)
(* its output.                                                               *)
(* ====================================================================== *)

(* In a run that ends receptive, an Active config is never the last one, so it
   has a successor inside the run. *)
Fact active_succ_lt : forall gs j c s,
  is_receptive (last_cfg gs) -> cfg_at gs j = Active c s -> S j < length gs.
Proof.
  intros gs j c s Hrecv Hcfg.
  pose proof (cfg_at_active_lt gs j c s Hcfg) as Hjlt.
  destruct (Nat.eq_dec (S j) (length gs)) as [Heq | Hne]; [| lia].
  exfalso.
  assert (Hne0 : gs <> []) by (intro H; rewrite H in Hjlt; simpl in Hjlt; lia).
  assert (Hj : j = length gs - 1) by lia.
  rewrite Hj, (last_eq_cfg_at gs Hne0) in Hcfg.
  destruct Hrecv as [sr Hsr]. rewrite Hsr in Hcfg. discriminate.
Qed.

(* A paired-assert config in a receptive-ending run reaches its output: the
   assert config is Active, its tick-successor (the post-assert) is Active, so
   neither is the last (receptive) config and S (S j) is in range. *)
Fact assert_succ_succ_lt : forall es j cq sj l' tk Phi,
  pre_run es -> is_receptive (last_cfg es) ->
  cfg_at es j = Active cq sj -> redex_cmd cq = Cassert l' tk Phi ->
  S (S j) < length es.
Proof.
  intros es j cq sj l' tk Phi Hpe Hrecv Hcfg Hred.
  pose proof (active_succ_lt es j cq sj Hrecv Hcfg) as HSj.
  destruct (pre_run_step_adj es j Hpe HSj) as [ev Hstep].
  rewrite Hcfg in Hstep.
  destruct (step_assert_event cq sj ev (cfg_at es (S j)) l' tk Phi Hred Hstep) as [_ [c' Hc']].
  apply (active_succ_lt es (S j) c' sj Hrecv Hc').
Qed.

(* Abstraction of the reverse rank-matching used by the reverse maps: every
   l-annotation of the MAJOR [ds] is matched, rank-preserving and same-command,
   by an l-annotation of the MINOR [es].  Provided by [covers_dom] (covers_dom
   disjunct, via major_minor_rank) OR by equal annotation counts (receptive
   equal-count sub-case, via minor_major_rank_rng + counting). *)
Definition reverse_matched (l : Lev) (ds es : list config)
                           (alpha : nat -> nat -> Prop) : Prop :=
  forall r i, is_nth_annot l ds r i ->
    exists j, alpha i j /\ is_nth_annot l es r j /\
              cfg_cmd (cfg_at ds i) = cfg_cmd (cfg_at es j).

Lemma covers_dom_reverse_matched : forall l ds es alpha,
  l_aligned_pair l ds es alpha -> covers_dom ds alpha -> covers_rng es alpha ->
  reverse_matched l ds es alpha.
Proof.
  intros l ds es alpha Hlap Hcd Hcr r i Hnth.
  apply (major_minor_rank l ds es alpha r i Hlap Hcd Hcr Hnth).
Qed.

Lemma eqcount_reverse_matched : forall l ds es alpha,
  l_aligned_pair l ds es alpha -> covers_rng es alpha ->
  annot_count l es (length es) = annot_count l ds (length ds) ->
  reverse_matched l ds es alpha.
Proof.
  intros l ds es alpha Hlap Hcr Heq r i Hnth.
  pose proof Hnth as [Hilt [Hanni Hcnti]].
  assert (Hrlt : r < annot_count l ds (length ds))
    by (rewrite <- Hcnti; apply (rank_lt_total l ds i Hilt Hanni)).
  assert (Hrles : r < annot_count l es (length es)) by (rewrite Heq; exact Hrlt).
  destruct (annot_count_gives_nth l es r (length es) Hrles) as [j [_ Hnthj]].
  destruct (minor_major_rank_rng l ds es alpha r j Hlap Hcr Hnthj)
    as [i' [Haij [Hnthi' Hcmd]]].
  assert (Hieq : i' = i) by (apply (is_nth_annot_unique l ds r i' i Hnthi' Hnth)).
  subst i'. exists j. split; [exact Haij | split; [exact Hnthj | exact Hcmd]].
Qed.

(* The reverse matcher lifts along a run extension: matches found in [fs] (whose
   annotations all lie in [fs]'s range) persist in [fs ++ ex]. *)
Lemma reverse_matched_ext : forall l ds fs ex alpha,
  reverse_matched l ds fs alpha -> reverse_matched l ds (fs ++ ex) alpha.
Proof.
  intros l ds fs ex alpha Hrm r i Hnth.
  destruct (Hrm r i Hnth) as [j [Haij [Hnthj Hcmd]]].
  pose proof Hnthj as [Hjlt [Hannj Hcntj]].
  exists j. split; [exact Haij | split].
  - unfold is_nth_annot. split; [rewrite length_app; lia | split].
    + rewrite (cfg_at_app_lt fs ex j Hjlt). exact Hannj.
    + rewrite (annot_count_app_le l fs ex j ltac:(lia)). exact Hcntj.
  - rewrite (cfg_at_app_lt fs ex j Hjlt). exact Hcmd.
Qed.

(* ----------------------------------------------------------------------- *)
(* covers_dom MIXED-BRIDGE ext-lemmas: the forward map machinery localized *)
(* to a run [fs ++ ex] (a maximal run on [ins] extending the conformance   *)
(* minor [fs]), matching annotations that lie inside [fs]'s range via       *)
(* [covers_rng fs] rather than [covers_rng (fs ++ ex)].                     *)
(* ----------------------------------------------------------------------- *)

(* The covers_rng-only reverse matcher localized to [fs]: an annotation of
   [fs ++ ex] that lies inside [fs]'s range is matched, rank-preserving and
   same-command, by an [ds] annotation, using only [covers_rng fs]. *)
Lemma minor_major_rank_rng_ext : forall l ds fs ex alpha r j,
  l_aligned_pair l ds fs alpha -> covers_rng fs alpha ->
  is_nth_annot l (fs ++ ex) r j -> j < length fs ->
  exists i, alpha i j /\ is_nth_annot l ds r i /\
            cfg_cmd (cfg_at ds i) = cfg_cmd (cfg_at (fs ++ ex) j).
Proof.
  intros l ds fs ex alpha r j Hlap Hcr Hnth Hjlt.
  destruct Hnth as [_ [Hann Hcnt]].
  assert (Hannfs : redex_is_l_annotation l (cfg_at fs j))
    by (rewrite <- (cfg_at_app_lt fs ex j Hjlt); exact Hann).
  assert (Hcntfs : annot_count l fs j = r)
    by (rewrite <- (annot_count_app_le l fs ex j ltac:(lia)); exact Hcnt).
  assert (Hnthfs : is_nth_annot l fs r j)
    by (unfold is_nth_annot; split; [exact Hjlt | split; [exact Hannfs | exact Hcntfs]]).
  destruct (minor_major_rank_rng l ds fs alpha r j Hlap Hcr Hnthfs)
    as [i [Haij [Hnthi Hcmd]]].
  exists i. split; [exact Haij | split; [exact Hnthi |]].
  rewrite (cfg_at_app_lt fs ex j Hjlt). exact Hcmd.
Qed.

(* out_maps_into_local localized to [fs ++ ex]: realization of an [fs ++ ex]
   output in [ds] via the local "next rank exists" bound, with the rank match
   found inside [fs] (the realizing assert index is below [length fs]). *)
Lemma out_maps_into_local_ext : forall l ds fs ex alpha tM tf p l' n,
  pre_run ds -> pre_run (fs ++ ex) ->
  l_aligned_pair l ds fs alpha -> covers_rng fs alpha ->
  admits_trace ds tM -> admits_trace (fs ++ ex) tf ->
  S (annot_count l (fs ++ ex) (p - 2)) < annot_count l ds (length ds) ->
  p - 2 < length fs ->
  p < length tf -> vis_at l (fs ++ ex) p = Some (Eout l' n) ->
  S (S (annot_idx l ds (annot_count l (fs ++ ex) (p - 2)))) < length tM /\
  (exists m, vis_at l ds (S (S (annot_idx l ds (annot_count l (fs ++ ex) (p - 2))))) = Some (Eout l' m)).
Proof.
  intros l ds fs ex alpha tM tf p l' n Hpd Hpe Hlap Hcr HatM Hatf Hr1Cin Hfsr Hp Hvis.
  pose proof (admits_trace_length ds tM HatM) as HdM.
  pose proof (admits_trace_length (fs ++ ex) tf Hatf) as HeM.
  destruct (vis_at_sound l (fs ++ ex) tf p (Eout l' n) Hatf Hp Hvis) as [Hnthp Hvev].
  assert (Hle : lleq l' l).
  { destruct Hvev as [Hin | Hout].
    - destruct Hin as [l0 [n0 [Heq _]]]; discriminate Heq.
    - destruct Hout as [l2 [n2 [Heq Hl2]]]; injection Heq as Hl Hnn; subst l2; exact Hl2. }
  destruct (trace_output_cfg (fs ++ ex) tf p l' n Hatf Hp Hnthp) as [cc [s [e [Hcfgp [Hredcc Hn]]]]].
  assert (Hples : p < length (fs ++ ex)) by lia.
  destruct (prerun_output_pair_struct (fs ++ ex) p cc s l' e Hpe Hples Hcfgp Hredcc)
    as [cq [cp [tq14 [Hp2 [Hesq [Hredq [Hesp1 Hredp]]]]]]].
  assert (Hannp2 : redex_is_l_annotation l (cfg_at (fs ++ ex) (p - 2))).
  { unfold redex_is_l_annotation. rewrite Hesq. simpl. rewrite Hredq.
    unfold is_l_annotation. right. simpl. exact Hle. }
  set (r := annot_count l (fs ++ ex) (p - 2)) in *.
  assert (Hp2lt : p - 2 < length (fs ++ ex)) by lia.
  assert (Hnth_es : is_nth_annot l (fs ++ ex) r (p - 2))
    by (unfold is_nth_annot, r; split; [exact Hp2lt | split; [exact Hannp2 | reflexivity]]).
  destruct (minor_major_rank_rng_ext l ds fs ex alpha r (p - 2) Hlap Hcr Hnth_es Hfsr)
    as [i [Haip [Hnth_ds Hcmdeq]]].
  assert (HrC : r < annot_count l ds (length ds)).
  { destruct Hnth_ds as [Hilt [Hannds Hcnt]].
    pose proof (annot_count_annot_S l ds i Hannds) as HS.
    pose proof (annot_count_mono l ds (S i) (length ds) ltac:(lia)) as Hm. lia. }
  assert (Hidx : i = annot_idx l ds r)
    by (apply (is_nth_annot_unique l ds r i (annot_idx l ds r) Hnth_ds (annot_idx_is_nth l ds r HrC))).
  rewrite <- Hidx.
  destruct Hnth_ds as [Hilt [Hannds Hcnt]].
  assert (Hr1C : S r < annot_count l ds (length ds)) by (unfold r in *; exact Hr1Cin).
  destruct (annot_idx_is_nth l ds (S r) Hr1C) as [Hi'lt [Hanni' Hcnti']].
  set (i' := annot_idx l ds (S r)) in *.
  assert (Hi'gt : i < i').
  { destruct (Nat.le_gt_cases i' i) as [Hle' | Hgt]; [| exact Hgt].
    pose proof (annot_count_mono l ds i' i Hle') as Hm.
    rewrite Hcnti', Hcnt in Hm. lia. }
  assert (HnSi : ~ redex_is_l_annotation l (cfg_at ds (S i)))
    by (intro H; exact (no_adj_annot l ds i Hpd H Hannds)).
  assert (Hi'neSi : i' <> S i) by (intro He; rewrite He in Hanni'; contradiction).
  assert (HSSi_ds : S (S i) < length ds) by lia.
  destruct (output_realize_cross ds (fs ++ ex) i p cc s l' e Hpd Hpe Hcfgp Hredcc Hples Hcmdeq HSSi_ds)
    as [Hpost Hout].
  assert (HnSSi : ~ redex_is_l_annotation l (cfg_at ds (S (S i)))).
  { unfold redex_is_l_annotation. rewrite Hout. simpl. unfold is_l_annotation. tauto. }
  assert (Hi'neSSi : i' <> S (S i)) by (intro He; rewrite He in Hanni'; contradiction).
  split.
  - lia.
  - exists (eval_expr (cfg_state (cfg_at ds (S (S i)))) e).
    apply (vis_at_out_some l ds (S (S i)) l' e Hout Hle).
Qed.

(* in_maps_into_rng localized to [fs ++ ex]: realization of an [fs ++ ex] input
   in [ds], rank-matched inside [fs]. *)
Lemma in_maps_into_rng_ext : forall l ds fs ex alpha tM tf p l' n,
  pre_run ds -> pre_run (fs ++ ex) ->
  l_aligned_pair l ds fs alpha -> covers_rng fs alpha ->
  admits_trace ds tM -> admits_trace (fs ++ ex) tf ->
  S p < length fs ->
  p < length tf -> vis_at l (fs ++ ex) p = Some (Ein l' n) ->
  annot_idx l ds (annot_count l (fs ++ ex) (S p)) - 1 < length tM /\
  (exists m, vis_at l ds (annot_idx l ds (annot_count l (fs ++ ex) (S p)) - 1) = Some (Ein l' m)).
Proof.
  intros l ds fs ex alpha tM tf p l' n Hpd Hpe Hlap Hcr HatM Hatf Hfsr Hp Hvis.
  pose proof (admits_trace_length ds tM HatM) as HdM.
  destruct (vis_at_sound l (fs ++ ex) tf p (Ein l' n) Hatf Hp Hvis) as [Hnthp Hvev].
  assert (Hle : lleq l' l).
  { destruct Hvev as [Hin | Hout].
    - destruct Hin as [l2 [n2 [Heq Hl2]]]; injection Heq as Hl Hnn; subst l2; exact Hl2.
    - destruct Hout as [l0 [n0 [Heq _]]]; discriminate Heq. }
  destruct (trace_input_cfg (fs ++ ex) tf p l' n Hatf Hp Hnthp) as [s [Hcfgp HcfgSp]].
  destruct (prog_well_specified l') as [wtag [d [Hwb Hd]]].
  assert (HannSp : redex_is_l_annotation l (cfg_at (fs ++ ex) (S p))).
  { unfold redex_is_l_annotation. rewrite HcfgSp. simpl. rewrite Hwb. simpl.
    unfold is_l_annotation. left. simpl. exact Hle. }
  assert (HSplt : S p < length (fs ++ ex))
    by (apply (cfg_at_active_lt (fs ++ ex) (S p) (h_body (prog l')) _ HcfgSp)).
  set (r := annot_count l (fs ++ ex) (S p)) in *.
  assert (Hnth_es : is_nth_annot l (fs ++ ex) r (S p))
    by (unfold is_nth_annot, r; split; [exact HSplt | split; [exact HannSp | reflexivity]]).
  destruct (minor_major_rank_rng_ext l ds fs ex alpha r (S p) Hlap Hcr Hnth_es Hfsr)
    as [i [Haip [Hnth_ds Hcmdeq]]].
  assert (HrC : r < annot_count l ds (length ds)).
  { destruct Hnth_ds as [Hilt [Hannds Hcnt]].
    pose proof (annot_count_annot_S l ds i Hannds) as HS.
    pose proof (annot_count_mono l ds (S i) (length ds) ltac:(lia)) as Hm. lia. }
  assert (Hidx : i = annot_idx l ds r)
    by (apply (is_nth_annot_unique l ds r i (annot_idx l ds r) Hnth_ds (annot_idx_is_nth l ds r HrC))).
  rewrite <- Hidx.
  destruct Hnth_ds as [Hilt [Hannds Hcnt]].
  rewrite HcfgSp in Hcmdeq. simpl in Hcmdeq.
  destruct (cfg_at ds i) as [sr | dci dsi] eqn:Hdci; [discriminate Hcmdeq |].
  simpl in Hcmdeq. injection Hcmdeq as Hdcicq. subst dci.
  pose proof (input_realize_ds l ds tM i l' dsi HatM Hdci Hilt Hle) as Hvisi.
  destruct (handler_entry_dispatched_lem ds tM i l' dsi HatM Hilt Hdci) as [Hipos _].
  split.
  - lia.
  - exists (eval_expr dsi (EVar (h_var (prog l')))). exact Hvisi.
Qed.

(* vmap_rrank_local localized to [fs ++ ex]: the forward map sends an [fs ++ ex]
   visible position whose realizer rank is below [count fs] (so its realizing
   annotation lies in [fs]) to a [ds] visible position of the same rank.  The
   matching is done inside [fs] (out/in_maps_into_*_ext); the major rank total
   equals [fs]'s (equal-count under covers_dom). *)
Lemma vmap_rrank_local_ext : forall l ds fs ex alpha tM tf p e,
  pre_run ds -> pre_run (fs ++ ex) ->
  l_aligned_pair l ds fs alpha -> covers_rng fs alpha ->
  annot_count l ds (length ds) = annot_count l fs (length fs) ->
  admits_trace ds tM -> admits_trace (fs ++ ex) tf ->
  p < length tf -> vis_at l (fs ++ ex) p = Some e ->
  (match e with Eout _ _ => annot_count l (fs ++ ex) (p - 2)
             | Ein _ _ => annot_count l (fs ++ ex) (S p) | Etick => 0 end)
    < annot_count l fs (length fs) ->
  (forall lo no, e = Eout lo no -> S (annot_count l (fs ++ ex) (p - 2)) < annot_count l ds (length ds)) ->
  vmap l ds (fs ++ ex) p < length tM /\
  exists e', vis_at l ds (vmap l ds (fs ++ ex) p) = Some e' /\
    (match e' with Eout _ _ => annot_count l ds (vmap l ds (fs ++ ex) p - 2)
                | Ein _ _ => annot_count l ds (S (vmap l ds (fs ++ ex) p))
                | Etick => 0 end)
    = (match e with Eout _ _ => annot_count l (fs ++ ex) (p - 2)
                | Ein _ _ => annot_count l (fs ++ ex) (S p) | Etick => 0 end).
Proof.
  intros l ds fs ex alpha tM tf p e Hpd Hpe Hlap Hcr Hcount HatM Hatf Hp Hvis Hrho Hbound.
  destruct e as [l' n | l' n | ].
  - (* Ein *)
    destruct (vis_in_struct l (fs ++ ex) tf p l' n Hatf Hp Hvis) as [Hle [_ [[sb HcfgSp] [tkh Hredh]]]].
    assert (HannSp : redex_is_l_annotation l (cfg_at (fs ++ ex) (S p))).
    { unfold redex_is_l_annotation. rewrite HcfgSp. simpl. rewrite Hredh.
      unfold is_l_annotation. left. simpl. exact Hle. }
    assert (HSplt : S p < length (fs ++ ex))
      by (apply (cfg_at_active_lt (fs ++ ex) (S p) (h_body (prog l')) sb HcfgSp)).
    assert (Hnth_es : is_nth_annot l (fs ++ ex) (annot_count l (fs ++ ex) (S p)) (S p))
      by (unfold is_nth_annot; split; [exact HSplt | split; [exact HannSp | reflexivity]]).
    assert (Hfsr : S p < length fs)
      by (apply (annot_in_prefix l fs ex (annot_count l (fs ++ ex) (S p)) (S p) Hnth_es Hrho)).
    assert (Hr_ds : annot_count l (fs ++ ex) (S p) < annot_count l ds (length ds))
      by (rewrite Hcount; exact Hrho).
    destruct (in_maps_into_rng_ext l ds fs ex alpha tM tf p l' n Hpd Hpe Hlap Hcr HatM Hatf Hfsr Hp Hvis)
      as [Hlt [m Hsome]].
    assert (Hvmap : vmap l ds (fs ++ ex) p = annot_idx l ds (annot_count l (fs ++ ex) (S p)) - 1)
      by (unfold vmap; rewrite Hvis; reflexivity).
    pose proof (annot_idx_is_nth l ds (annot_count l (fs ++ ex) (S p)) Hr_ds) as [_ [_ Hcnti]].
    pose proof (annot_idx_pos l ds (annot_count l (fs ++ ex) (S p)) Hpd Hr_ds) as Hipos.
    set (i := annot_idx l ds (annot_count l (fs ++ ex) (S p))) in *.
    rewrite Hvmap. split; [exact Hlt |].
    exists (Ein l' m). split; [exact Hsome |].
    replace (S (i - 1)) with i by lia. exact Hcnti.
  - (* Eout *)
    destruct (vis_out_struct l (fs ++ ex) tf p l' n Hpe Hatf Hp Hvis)
      as [Hp2 [Hle [[cq [sq [e0 [tq0 [Hcfgq Hredq]]]]] _]]].
    assert (Hannp2 : redex_is_l_annotation l (cfg_at (fs ++ ex) (p - 2))).
    { unfold redex_is_l_annotation. rewrite Hcfgq. simpl. rewrite Hredq.
      unfold is_l_annotation. right. simpl. exact Hle. }
    assert (Hp2lt : p - 2 < length (fs ++ ex))
      by (pose proof (admits_trace_length (fs ++ ex) tf Hatf) as HeM; lia).
    assert (Hnth_es : is_nth_annot l (fs ++ ex) (annot_count l (fs ++ ex) (p - 2)) (p - 2))
      by (unfold is_nth_annot; split; [exact Hp2lt | split; [exact Hannp2 | reflexivity]]).
    assert (Hfsr : p - 2 < length fs)
      by (apply (annot_in_prefix l fs ex (annot_count l (fs ++ ex) (p - 2)) (p - 2) Hnth_es Hrho)).
    assert (Hbnd : S (annot_count l (fs ++ ex) (p - 2)) < annot_count l ds (length ds))
      by (apply (Hbound l' n); reflexivity).
    assert (Hr_ds : annot_count l (fs ++ ex) (p - 2) < annot_count l ds (length ds)) by lia.
    destruct (out_maps_into_local_ext l ds fs ex alpha tM tf p l' n Hpd Hpe Hlap Hcr HatM Hatf Hbnd Hfsr Hp Hvis)
      as [Hlt [m Hsome]].
    assert (Hvmap : vmap l ds (fs ++ ex) p = S (S (annot_idx l ds (annot_count l (fs ++ ex) (p - 2)))))
      by (unfold vmap; rewrite Hvis; reflexivity).
    pose proof (annot_idx_is_nth l ds (annot_count l (fs ++ ex) (p - 2)) Hr_ds) as [_ [_ Hcnti]].
    set (i := annot_idx l ds (annot_count l (fs ++ ex) (p - 2))) in *.
    rewrite Hvmap. split; [exact Hlt |].
    exists (Eout l' m). split; [exact Hsome |].
    replace (S (S i) - 2) with i by lia. exact Hcnti.
  - (* Etick *)
    exfalso. destruct (vis_at_sound l (fs ++ ex) tf p Etick Hatf Hp Hvis) as [_ Hvev].
    destruct Hvev as [[? [? [Hc _]]] | [? [? [Hc _]]]]; discriminate Hc.
Qed.

(* An l-aligned pair survives extending the minor by a suffix: every aligned
   minor index lies in [fs] (alignment range bound), so the configs seen there
   are unchanged. *)
Lemma l_aligned_pair_app_rng : forall l ds fs ex alpha,
  l_aligned_pair l ds fs alpha -> pre_run (fs ++ ex) ->
  l_aligned_pair l ds (fs ++ ex) alpha.
Proof.
  intros l ds fs ex alpha [Hpd [Hpf [Halgn Hcoin]]] Hpfe.
  split; [exact Hpd | split; [exact Hpfe |]].
  split.
  - destruct Halgn as [Hbound [Hmono [Hpdom Hprng]]].
    split.
    + intros i j Haij. destruct (Hbound i j Haij) as [Hi Hj].
      split; [exact Hi | rewrite length_app; lia].
    + split; [exact Hmono | split; [exact Hpdom | exact Hprng]].
  - intros i j Haij Hdisj.
    assert (Hjlt : j < length fs)
      by (destruct Halgn as [Hbound _]; exact (proj2 (Hbound i j Haij))).
    rewrite (cfg_at_app_lt fs ex j Hjlt) in Hdisj |- *.
    apply (Hcoin i j Haij). exact Hdisj.
Qed.

(* The realization condition that the reverse bridge needs of the minor [es],
   abstracting [is_receptive (last_cfg es)]: every l-visible OUTPUT of the major
   [ds] has its [es]-side Cout (two configs after the matched assert) inside [es]'s
   trace.  Provided by a receptive-ending [es] (assert_succ_succ_lt) OR by an [es]
   long enough that all of [ds]'s matched asserts reach their Couts. *)
Definition rev_outputs_realized (l : Lev) (ds es : list config) (tM tf : list event) : Prop :=
  forall p l' n, p < length tM -> vis_at l ds p = Some (Eout l' n) ->
    S (S (annot_idx l es (annot_count l ds (p - 2)))) < length tf.

(* Value agreement at aligned value-bearing annotations, abstracting the
   conformance models clause (conf_annot_value): the two runs evaluate the agreed
   expression equally.  Provided by a conformance [(ds, es)] OR transported from a
   conformance [(ds, fs)] when [es = fs ++ ex] (aligned indices lie in [fs]). *)
Definition annot_value_agree (l : Lev) (ds es : list config) (alpha : nat -> nat -> Prop) : Prop :=
  forall i j l' tk e, alpha i j ->
    (redex_of (cfg_at ds i) = Some (Cassume l' tk (Ragr e)) \/
     redex_of (cfg_at ds i) = Some (Cassert l' tk (Ragr e))) ->
    lleq l' l ->
    eval_expr (cfg_state (cfg_at ds i)) e = eval_expr (cfg_state (cfg_at es j)) e.

(* The forward-map realization the no-gap (downward-closure) argument needs,
   abstracting [covers_rng es] (vmap_rrank_local): an [es] visible position whose
   realizer rank is below the major's total (and, for an output, has the local
   "next rank exists" bound) is sent by the forward map to a [ds] visible position
   of the same realizer rank.  Provided by [covers_rng es] (vmap_rrank_local) OR,
   when [es = fs ++ ex], by [covers_rng fs] (vmap_rrank_local_ext). *)
Definition fwd_realizes (l : Lev) (ds es : list config) (tM tf : list event) : Prop :=
  forall q eq, q < length tf -> vis_at l es q = Some eq ->
    (match eq with Eout _ _ => annot_count l es (q - 2)
                | Ein _ _ => annot_count l es (S q) | Etick => 0 end)
      < annot_count l ds (length ds) ->
    (forall lo no, eq = Eout lo no -> S (annot_count l es (q - 2)) < annot_count l ds (length ds)) ->
    vmap l ds es q < length tM /\
    (exists e', vis_at l ds (vmap l ds es q) = Some e' /\
      (match e' with Eout _ _ => annot_count l ds (vmap l ds es q - 2)
                  | Ein _ _ => annot_count l ds (S (vmap l ds es q)) | Etick => 0 end)
      = (match eq with Eout _ _ => annot_count l es (q - 2)
                  | Ein _ _ => annot_count l es (S q) | Etick => 0 end)).

(* Reverse of out_maps_into_rng: an l-visible OUTPUT of the MAJOR [ds] is realized
   by the MINOR [es].  Its rank-r paired assert matches (reverse_matched) es's
   rank-r annotation at j = annot_idx es r; the realization at S (S j) is in range
   by the [rev_outputs_realized] hypothesis (formerly receptive-ending es). *)
Lemma out_maps_into_rev : forall l ds es alpha tM tf p l' n,
  l_aligned_pair l ds es alpha -> reverse_matched l ds es alpha ->
  admits_trace ds tM -> admits_trace es tf ->
  rev_outputs_realized l ds es tM tf ->
  p < length tM -> vis_at l ds p = Some (Eout l' n) ->
  S (S (annot_idx l es (annot_count l ds (p - 2)))) < length tf /\
  (exists m, vis_at l es (S (S (annot_idx l es (annot_count l ds (p - 2))))) = Some (Eout l' m)).
Proof.
  intros l ds es alpha tM tf p l' n Hlap Hrm HatM Hatf Hrz Hp Hvis.
  pose proof (Hrz p l' n Hp Hvis) as Htf.
  assert (Hpd : pre_run ds) by (destruct Hlap as [H _]; exact H).
  assert (Hpe : pre_run es) by (destruct Hlap as [_ [H _]]; exact H).
  pose proof (admits_trace_length ds tM HatM) as HdM.
  pose proof (admits_trace_length es tf Hatf) as HeM.
  destruct (vis_at_sound l ds tM p (Eout l' n) HatM Hp Hvis) as [Hnthp Hvev].
  assert (Hle : lleq l' l).
  { destruct Hvev as [Hin | Hout].
    - destruct Hin as [l0 [n0 [Heq _]]]; discriminate Heq.
    - destruct Hout as [l2 [n2 [Heq Hl2]]]; injection Heq as Hl Hnn; subst l2; exact Hl2. }
  destruct (trace_output_cfg ds tM p l' n HatM Hp Hnthp) as [cc [s [e [Hcfgp [Hredcc Hn]]]]].
  assert (Hpds : p < length ds) by lia.
  destruct (prerun_output_pair_struct ds p cc s l' e Hpd Hpds Hcfgp Hredcc)
    as [cq [cp [tq15 [Hp2 [Hdsq [Hredq [Hdsp1 Hredp]]]]]]].
  assert (Hannp2 : redex_is_l_annotation l (cfg_at ds (p - 2))).
  { unfold redex_is_l_annotation. rewrite Hdsq. simpl. rewrite Hredq.
    unfold is_l_annotation. right. simpl. exact Hle. }
  set (r := annot_count l ds (p - 2)) in *.
  assert (Hp2lt : p - 2 < length ds) by lia.
  assert (Hnth_ds : is_nth_annot l ds r (p - 2))
    by (unfold is_nth_annot, r; split; [exact Hp2lt | split; [exact Hannp2 | reflexivity]]).
  destruct (Hrm r (p - 2) Hnth_ds) as [j [Haij [Hnth_es Hcmdeq]]].
  assert (HrC : r < annot_count l es (length es)).
  { destruct Hnth_es as [Hjlt [Hannj Hcnt]].
    pose proof (annot_count_annot_S l es j Hannj) as HS.
    pose proof (annot_count_mono l es (S j) (length es) ltac:(lia)) as Hm. lia. }
  assert (Hidx : j = annot_idx l es r)
    by (apply (is_nth_annot_unique l es r j (annot_idx l es r) Hnth_es (annot_idx_is_nth l es r HrC))).
  rewrite <- Hidx in Htf.
  rewrite <- Hidx.
  rewrite Hdsq in Hcmdeq. simpl in Hcmdeq.
  destruct (cfg_at es j) as [sr | ej sj] eqn:Hesj; [discriminate Hcmdeq |].
  simpl in Hcmdeq. injection Hcmdeq as Hejcq. subst ej.
  assert (HSSj : S (S j) < length es) by lia.
  pose proof (output_realize_cross es ds j p cc s l' e Hpe Hpd Hcfgp Hredcc Hpds
                ltac:(rewrite Hesj, Hdsq; reflexivity) HSSj) as [Hpost Hout].
  destruct (cfg_at es (S (S j))) as [sr2 | cz sz] eqn:HcfgSSj; simpl in Hout; [discriminate Hout |].
  injection Hout as Houtr.
  split.
  - exact Htf.
  - exists (eval_expr (cfg_state (cfg_at es (S (S j)))) e).
    apply (vis_at_out_some l es (S (S j)) l' e);
      [rewrite HcfgSSj; simpl; rewrite Houtr; reflexivity | exact Hle].
Qed.

(* Reverse of in_maps_into_rng: an l-visible INPUT of the MAJOR [ds] is realized
   by the MINOR [es].  Its handler-entry assume (at S p) matches (covers_dom,
   major_minor_rank) es's rank-r annotation at j = annot_idx es r, whose command
   is the same handler body; that body arose by input dispatch
   (handler_entry_dispatched, via input_realize_ds), exposing the input at j-1. *)
Lemma in_maps_into_rev : forall l ds es alpha tM tf p l' n,
  l_aligned_pair l ds es alpha -> reverse_matched l ds es alpha ->
  admits_trace ds tM -> admits_trace es tf ->
  p < length tM -> vis_at l ds p = Some (Ein l' n) ->
  annot_idx l es (annot_count l ds (S p)) - 1 < length tf /\
  (exists m, vis_at l es (annot_idx l es (annot_count l ds (S p)) - 1) = Some (Ein l' m)).
Proof.
  intros l ds es alpha tM tf p l' n Hlap Hrm HatM Hatf Hp Hvis.
  assert (Hpd : pre_run ds) by (destruct Hlap as [H _]; exact H).
  assert (Hpe : pre_run es) by (destruct Hlap as [_ [H _]]; exact H).
  pose proof (admits_trace_length es tf Hatf) as HeM.
  destruct (vis_at_sound l ds tM p (Ein l' n) HatM Hp Hvis) as [Hnthp Hvev].
  assert (Hle : lleq l' l).
  { destruct Hvev as [Hin | Hout].
    - destruct Hin as [l2 [n2 [Heq Hl2]]]; injection Heq as Hl Hnn; subst l2; exact Hl2.
    - destruct Hout as [l0 [n0 [Heq _]]]; discriminate Heq. }
  destruct (trace_input_cfg ds tM p l' n HatM Hp Hnthp) as [s [Hcfgp HcfgSp]].
  destruct (prog_well_specified l') as [wtag [d [Hwb Hd]]].
  assert (HannSp : redex_is_l_annotation l (cfg_at ds (S p))).
  { unfold redex_is_l_annotation. rewrite HcfgSp. simpl. rewrite Hwb. simpl.
    unfold is_l_annotation. left. simpl. exact Hle. }
  assert (HSplt : S p < length ds)
    by (apply (cfg_at_active_lt ds (S p) (h_body (prog l')) _ HcfgSp)).
  set (r := annot_count l ds (S p)) in *.
  assert (Hnth_ds : is_nth_annot l ds r (S p))
    by (unfold is_nth_annot, r; split; [exact HSplt | split; [exact HannSp | reflexivity]]).
  destruct (Hrm r (S p) Hnth_ds) as [j [Haij [Hnth_es Hcmdeq]]].
  assert (HrC : r < annot_count l es (length es)).
  { destruct Hnth_es as [Hjlt [Hannj Hcnt]].
    pose proof (annot_count_annot_S l es j Hannj) as HS.
    pose proof (annot_count_mono l es (S j) (length es) ltac:(lia)) as Hm. lia. }
  assert (Hidx : j = annot_idx l es r)
    by (apply (is_nth_annot_unique l es r j (annot_idx l es r) Hnth_es (annot_idx_is_nth l es r HrC))).
  rewrite <- Hidx.
  rewrite HcfgSp in Hcmdeq. simpl in Hcmdeq.
  destruct (cfg_at es j) as [sr | ej sj] eqn:Hesj; [discriminate Hcmdeq |].
  simpl in Hcmdeq. injection Hcmdeq as Hejcq. subst ej.
  destruct Hnth_es as [Hjlt _].
  pose proof (input_realize_ds l es tf j l' sj Hatf Hesj Hjlt Hle) as Hvisj.
  destruct (handler_entry_dispatched_lem es tf j l' sj Hatf Hjlt Hesj) as [Hjpos _].
  split.
  - lia.
  - exists (eval_expr sj (EVar (h_var (prog l')))). exact Hvisj.
Qed.

(* REVERSE rrank: the reverse image [vmap l es ds p] (es position realizing the
   MAJOR's visible event at p) is an es visible position whose realizer rank
   equals the major's realizer rank at p.  Mirror of vmap_rrank_strict with
   ds/es swapped; realization via out/in_maps_into_rev (receptive-ending es). *)
Lemma vmapR_rrank : forall l ds es alpha tM tf p e,
  l_aligned_pair l ds es alpha -> reverse_matched l ds es alpha ->
  admits_trace ds tM -> admits_trace es tf ->
  rev_outputs_realized l ds es tM tf ->
  p < length tM -> vis_at l ds p = Some e ->
  vmap l es ds p < length tf /\
  exists e', vis_at l es (vmap l es ds p) = Some e' /\
    (match e' with Eout _ _ => annot_count l es (vmap l es ds p - 2)
                | Ein _ _ => annot_count l es (S (vmap l es ds p))
                | Etick => 0 end)
    = (match e with Eout _ _ => annot_count l ds (p - 2)
                | Ein _ _ => annot_count l ds (S p)
                | Etick => 0 end).
Proof.
  intros l ds es alpha tM tf p e Hlap Hrm HatM Hatf Hrz Hp Hvis.
  assert (Hpd : pre_run ds) by (destruct Hlap as [H _]; exact H).
  assert (Hpe : pre_run es) by (destruct Hlap as [_ [H _]]; exact H).
  destruct e as [l' n | l' n | ].
  - (* Ein *)
    destruct (vis_in_struct l ds tM p l' n HatM Hp Hvis) as [Hle [_ [[sb HcfgSp] [tkh Hredh]]]].
    assert (HannSp : redex_is_l_annotation l (cfg_at ds (S p))).
    { unfold redex_is_l_annotation. rewrite HcfgSp. simpl. rewrite Hredh.
      unfold is_l_annotation. left. simpl. exact Hle. }
    assert (HSplt : S p < length ds)
      by (apply (cfg_at_active_lt ds (S p) (h_body (prog l')) sb HcfgSp)).
    assert (Hnth_ds : is_nth_annot l ds (annot_count l ds (S p)) (S p))
      by (unfold is_nth_annot; split; [exact HSplt | split; [exact HannSp | reflexivity]]).
    destruct (Hrm (annot_count l ds (S p)) (S p) Hnth_ds) as [j0 [_ [Hnth_es0 _]]].
    assert (Hr_es : annot_count l ds (S p) < annot_count l es (length es)).
    { destruct Hnth_es0 as [Hjlt [Hannj Hcnt]].
      pose proof (annot_count_annot_S l es j0 Hannj) as HS.
      pose proof (annot_count_mono l es (S j0) (length es) ltac:(lia)) as Hm. lia. }
    destruct (in_maps_into_rev l ds es alpha tM tf p l' n Hlap Hrm HatM Hatf Hp Hvis)
      as [Hlt [m Hsome]].
    assert (Hvmap : vmap l es ds p = annot_idx l es (annot_count l ds (S p)) - 1)
      by (unfold vmap; rewrite Hvis; reflexivity).
    pose proof (annot_idx_is_nth l es (annot_count l ds (S p)) Hr_es) as [_ [_ Hcnti]].
    pose proof (annot_idx_pos l es (annot_count l ds (S p)) Hpe Hr_es) as Hipos.
    set (i := annot_idx l es (annot_count l ds (S p))) in *.
    rewrite Hvmap. split; [exact Hlt |].
    exists (Ein l' m). split; [exact Hsome |].
    replace (S (i - 1)) with i by lia. exact Hcnti.
  - (* Eout *)
    destruct (vis_out_struct l ds tM p l' n Hpd HatM Hp Hvis)
      as [Hp2 [Hle [[cq [sq [e0 [tq0 [Hcfgq Hredq]]]]] _]]].
    assert (Hannp2 : redex_is_l_annotation l (cfg_at ds (p - 2))).
    { unfold redex_is_l_annotation. rewrite Hcfgq. simpl. rewrite Hredq.
      unfold is_l_annotation. right. simpl. exact Hle. }
    assert (Hp2lt : p - 2 < length ds)
      by (pose proof (admits_trace_length ds tM HatM) as HdM; lia).
    assert (Hnth_ds : is_nth_annot l ds (annot_count l ds (p - 2)) (p - 2))
      by (unfold is_nth_annot; split; [lia | split; [exact Hannp2 | reflexivity]]).
    destruct (Hrm (annot_count l ds (p - 2)) (p - 2) Hnth_ds) as [j0 [_ [Hnth_es0 _]]].
    assert (Hr_es : annot_count l ds (p - 2) < annot_count l es (length es)).
    { destruct Hnth_es0 as [Hjlt [Hannj Hcnt]].
      pose proof (annot_count_annot_S l es j0 Hannj) as HS.
      pose proof (annot_count_mono l es (S j0) (length es) ltac:(lia)) as Hm. lia. }
    destruct (out_maps_into_rev l ds es alpha tM tf p l' n Hlap Hrm HatM Hatf Hrz Hp Hvis)
      as [Hlt [m Hsome]].
    assert (Hvmap : vmap l es ds p = S (S (annot_idx l es (annot_count l ds (p - 2)))))
      by (unfold vmap; rewrite Hvis; reflexivity).
    pose proof (annot_idx_is_nth l es (annot_count l ds (p - 2)) Hr_es) as [_ [_ Hcnti]].
    set (i := annot_idx l es (annot_count l ds (p - 2))) in *.
    rewrite Hvmap. split; [exact Hlt |].
    exists (Eout l' m). split; [exact Hsome |].
    replace (S (S i) - 2) with i by lia. exact Hcnti.
  - (* Etick *)
    exfalso. destruct (vis_at_sound l ds tM p Etick HatM Hp Hvis) as [_ Hvev].
    destruct Hvev as [[? [? [Hc _]]] | [? [? [Hc _]]]]; discriminate Hc.
Qed.

(* REVERSE monotonicity: [vmap l es ds] is order-preserving on ds's visible
   positions.  Mirror of vmap_mono_strict (vis_rrank_mono on ds for the source
   order, on es for the image order). *)
Lemma vmapR_mono : forall l ds es alpha tM tf p1 p2 e1 e2,
  l_aligned_pair l ds es alpha -> reverse_matched l ds es alpha ->
  admits_trace ds tM -> admits_trace es tf ->
  rev_outputs_realized l ds es tM tf ->
  p1 < length tM -> p2 < length tM ->
  vis_at l ds p1 = Some e1 -> vis_at l ds p2 = Some e2 -> p1 < p2 ->
  vmap l es ds p1 < vmap l es ds p2.
Proof.
  intros l ds es alpha tM tf p1 p2 e1 e2 Hlap Hrm HatM Hatf Hrz Hp1 Hp2 Hv1 Hv2 Hlt.
  assert (Hpe : pre_run es) by (destruct Hlap as [_ [H _]]; exact H).
  assert (Hpd : pre_run ds) by (destruct Hlap as [H _]; exact H).
  destruct (vmapR_rrank l ds es alpha tM tf p1 e1 Hlap Hrm HatM Hatf Hrz Hp1 Hv1)
    as [Hq1lt [e1' [Hq1vis Hrr1]]].
  destruct (vmapR_rrank l ds es alpha tM tf p2 e2 Hlap Hrm HatM Hatf Hrz Hp2 Hv2)
    as [Hq2lt [e2' [Hq2vis Hrr2]]].
  pose proof (vis_rrank_mono l ds tM p1 p2 e1 e2 Hpd HatM Hp1 Hp2 Hv1 Hv2 Hlt) as Hrrmono.
  set (q1 := vmap l es ds p1) in *. set (q2 := vmap l es ds p2) in *.
  destruct (Nat.lt_trichotomy q1 q2) as [Hlt' | [Heq | Hgt']].
  - exact Hlt'.
  - exfalso.
    rewrite Heq in Hq1vis, Hrr1.
    rewrite Hq1vis in Hq2vis. injection Hq2vis as He. subst e1'.
    rewrite Hrr2 in Hrr1. lia.
  - exfalso.
    pose proof (vis_rrank_mono l es tf q2 q1 e2' e1' Hpe Hatf Hq2lt Hq1lt Hq2vis Hq1vis Hgt')
      as Hcontra.
    lia.
Qed.

(* REVERSE event preservation: the es-event at the reverse image equals the
   ds-event at p.  Mirror of vmap_event_eq; value agreement via conf_annot_value
   at the matched assert/entry-assume (the ds annotation is now the source). *)
Lemma vmapR_event_eq : forall l ds es alpha tM tf p e,
  l_aligned_pair l ds es alpha -> reverse_matched l ds es alpha ->
  annot_value_agree l ds es alpha ->
  admits_trace ds tM -> admits_trace es tf ->
  rev_outputs_realized l ds es tM tf ->
  p < length tM -> vis_at l ds p = Some e ->
  vis_at l es (vmap l es ds p) = Some e.
Proof.
  intros l ds es alpha tM tf p e Hlap Hrm Hval HatM Hatf Hrz Hp Hvis.
  assert (Hpd : pre_run ds) by (destruct Hlap as [H _]; exact H).
  assert (Hpe : pre_run es) by (destruct Hlap as [_ [H _]]; exact H).
  destruct e as [l' n | l' n | ].
  - (* Ein l' n : input on ds, realized on es *)
    destruct (vis_at_sound l ds tM p (Ein l' n) HatM Hp Hvis) as [Hnthp Hvev].
    assert (Hle : lleq l' l).
    { destruct Hvev as [Hin | Hout];
        [destruct Hin as [l2 [n2 [Heq Hl2]]]; injection Heq as Hl Hnn; subst l2; exact Hl2
        | destruct Hout as [? [? [Hc _]]]; discriminate Hc]. }
    destruct (trace_input_cfg ds tM p l' n HatM Hp Hnthp) as [s [Hcfgp HcfgSp]].
    destruct (prog_well_specified l') as [wtag [d [Hwb _]]].
    assert (HredhS : redex_cmd (h_body (prog l')) = Cassume l' wtag (Ragr (EVar (h_var (prog l')))))
      by (rewrite Hwb; reflexivity).
    assert (HannSp : redex_is_l_annotation l (cfg_at ds (S p)))
      by (unfold redex_is_l_annotation; rewrite HcfgSp; simpl; rewrite HredhS;
          unfold is_l_annotation; left; simpl; exact Hle).
    assert (HSplt : S p < length ds)
      by (apply (cfg_at_active_lt ds (S p) (h_body (prog l')) _ HcfgSp)).
    assert (Hnth_ds : is_nth_annot l ds (annot_count l ds (S p)) (S p))
      by (unfold is_nth_annot; split; [exact HSplt | split; [exact HannSp | reflexivity]]).
    destruct (Hrm (annot_count l ds (S p)) (S p) Hnth_ds) as [j [Haij [Hnthes Hcmdeq]]].
    pose proof Hnthes as [Hjlt [Hannes Hcnt]].
    assert (HrC : annot_count l ds (S p) < annot_count l es (length es))
      by (pose proof (annot_count_annot_S l es j Hannes);
          pose proof (annot_count_mono l es (S j) (length es) ltac:(lia)); lia).
    assert (Hidx : j = annot_idx l es (annot_count l ds (S p)))
      by (apply (is_nth_annot_unique l es (annot_count l ds (S p)) j _ Hnthes
                   (annot_idx_is_nth l es _ HrC))).
    assert (Hjpos : 1 <= j) by (rewrite Hidx; apply (annot_idx_pos l es _ Hpe HrC)).
    assert (Hvmap : vmap l es ds p = j - 1) by (unfold vmap; rewrite Hvis, <- Hidx; reflexivity).
    rewrite HcfgSp in Hcmdeq. simpl in Hcmdeq.
    destruct (cfg_at es j) as [srE | ccE sE] eqn:Hesj; [simpl in Hcmdeq; discriminate Hcmdeq |].
    simpl in Hcmdeq. injection Hcmdeq as Hcce. subst ccE.
    pose proof (input_realize_ds l es tf j l' sE Hatf Hesj Hjlt Hle) as Hvisj.
    assert (HredE_j : redex_of (cfg_at ds (S p)) = Some (Cassume l' wtag (Ragr (EVar (h_var (prog l'))))))
      by (rewrite HcfgSp; unfold redex_of; rewrite HredhS; reflexivity).
    pose proof (Hval (S p) j l' wtag (EVar (h_var (prog l')))
                  Haij (or_introl HredE_j) Hle) as Hvaleq.
    rewrite Hvmap, Hvisj. f_equal. f_equal.
    rewrite HcfgSp, Hesj in Hvaleq. simpl in Hvaleq.
    simpl. rewrite <- Hvaleq. apply update_eq.
  - (* Eout l' n : output on ds, realized on es *)
    destruct (vis_at_sound l ds tM p (Eout l' n) HatM Hp Hvis) as [Hnthp Hvev].
    assert (Hle : lleq l' l).
    { destruct Hvev as [Hin | Hout];
        [destruct Hin as [? [? [Hc _]]]; discriminate Hc
        | destruct Hout as [l2 [n2 [Heq Hl2]]]; injection Heq as Hl Hnn; subst l2; exact Hl2]. }
    destruct (trace_output_cfg ds tM p l' n HatM Hp Hnthp) as [cc [s [e [Hcfgp [Hredc Hn]]]]].
    assert (Hples : p < length ds) by (pose proof (admits_trace_length ds tM HatM); lia).
    destruct (prerun_output_pair_struct ds p cc s l' e Hpd Hples Hcfgp Hredc)
      as [cq [cp [tq16 [Hp2 [Hcfgq [Hredq [_ _]]]]]]].
    assert (Hannp2 : redex_is_l_annotation l (cfg_at ds (p - 2)))
      by (unfold redex_is_l_annotation; rewrite Hcfgq; simpl; rewrite Hredq;
          unfold is_l_annotation; right; simpl; exact Hle).
    assert (Hnth_ds : is_nth_annot l ds (annot_count l ds (p - 2)) (p - 2))
      by (unfold is_nth_annot; split; [lia | split; [exact Hannp2 | reflexivity]]).
    destruct (Hrm (annot_count l ds (p - 2)) (p - 2) Hnth_ds) as [j [Haij [Hnthes Hcmdeq]]].
    pose proof Hnthes as [Hjlt [Hannes Hcnt]].
    assert (HrC : annot_count l ds (p - 2) < annot_count l es (length es))
      by (pose proof (annot_count_annot_S l es j Hannes);
          pose proof (annot_count_mono l es (S j) (length es) ltac:(lia)); lia).
    assert (Hidx : j = annot_idx l es (annot_count l ds (p - 2)))
      by (apply (is_nth_annot_unique l es (annot_count l ds (p - 2)) j _ Hnthes
                   (annot_idx_is_nth l es _ HrC))).
    assert (Hvmap : vmap l es ds p = S (S j)) by (unfold vmap; rewrite Hvis, <- Hidx; reflexivity).
    rewrite Hcfgq in Hcmdeq. simpl in Hcmdeq.
    destruct (cfg_at es j) as [srE | ccE sE] eqn:Hesj; [simpl in Hcmdeq; discriminate Hcmdeq |].
    simpl in Hcmdeq. injection Hcmdeq as Hcce. subst ccE.
    pose proof (Hrz p l' n Hp Hvis) as Htf.
    rewrite <- Hidx in Htf.
    pose proof (admits_trace_length es tf Hatf) as HeM.
    assert (HSSjlt : S (S j) < length es) by lia.
    pose proof (output_realize_cross es ds j p cc s l' e Hpe Hpd Hcfgp Hredc Hples
                  ltac:(rewrite Hesj, Hcfgq; reflexivity) HSSjlt) as [_ Hout].
    destruct (cfg_at es (S (S j))) as [srE2 | ccE2 sE2] eqn:HcfgSSj;
      [simpl in Hout; discriminate Hout |].
    assert (HredcE : redex_cmd ccE2 = Cout l' e)
      by (simpl in Hout; injection Hout as Hrc; exact Hrc).
    rewrite <- HcfgSSj in Hout.
    destruct (prerun_output_pair_struct es (S (S j)) ccE2 sE2 l' e Hpe HSSjlt HcfgSSj HredcE)
      as [cqE [cpE [tq17 [_ [HcfgqE [HredqE [_ _]]]]]]].
    assert (Hj2 : S (S j) - 2 = j) by lia. rewrite Hj2 in HcfgqE.
    rewrite Hesj in HcfgqE. injection HcfgqE as HcqE HsE. subst sE2.
    assert (HredE_j : redex_of (cfg_at ds (p - 2)) = Some (Cassert l' tq16 (Ragr e)))
      by (rewrite Hcfgq; unfold redex_of; rewrite Hredq; reflexivity).
    pose proof (Hval (p - 2) j l' tq16 e
                  Haij (or_intror HredE_j) Hle) as Hvaleq.
    pose proof (vis_at_out_some l es (S (S j)) l' e Hout Hle) as Hvisout.
    rewrite Hvmap, Hvisout, HcfgSSj. simpl.
    rewrite Hcfgq, Hesj in Hvaleq. simpl in Hvaleq.
    rewrite <- Hvaleq, <- Hn. reflexivity.
  - (* Etick: impossible *)
    exfalso. destruct (vis_at_sound l ds tM p Etick HatM Hp Hvis) as [_ Hvev].
    destruct Hvev as [[? [? [Hc _]]] | [? [? [Hc _]]]]; discriminate Hc.
Qed.

(* REVERSE count bound: the MAJOR's l-visible count is no larger than the
   receptive-ending MINOR's.  [vmap l es ds] injects ds's visible positions into
   es's (out/in_maps_into_rev), injective by vmapR_mono. *)
Lemma minor_vis_le_rev : forall l ds es alpha tM tf,
  l_aligned_pair l ds es alpha -> reverse_matched l ds es alpha ->
  admits_trace ds tM -> admits_trace es tf ->
  rev_outputs_realized l ds es tM tf ->
  length (vis l tM) <= length (vis l tf).
Proof.
  intros l ds es alpha tM tf Hlap Hrm HatM Hatf Hrz.
  rewrite (vis_length_positions l ds tM HatM), (vis_length_positions l es tf Hatf).
  apply (length_le_via_inj (vmap l es ds)).
  - apply NoDup_filter, seq_NoDup.
  - intros p Hpin.
    apply (in_filter_seq_isSome _ (vis_at l ds) (length tM) p) in Hpin.
    destruct Hpin as [Hp [ev Hev]].
    apply (in_filter_seq_isSome _ (vis_at l es) (length tf) (vmap l es ds p)).
    destruct ev as [l' n | l' n | ].
    + unfold vmap; rewrite Hev.
      destruct (in_maps_into_rev l ds es alpha tM tf p l' n Hlap Hrm HatM Hatf Hp Hev)
        as [Hlt [m Hsome]].
      split; [exact Hlt | exists (Ein l' m); exact Hsome].
    + unfold vmap; rewrite Hev.
      destruct (out_maps_into_rev l ds es alpha tM tf p l' n Hlap Hrm HatM Hatf Hrz Hp Hev)
        as [Hlt [m Hsome]].
      split; [exact Hlt | exists (Eout l' m); exact Hsome].
    + exfalso. destruct (vis_at_sound l ds tM p Etick HatM Hp Hev) as [_ Hvev].
      destruct Hvev as [[? [? [Hc _]]] | [? [? [Hc _]]]]; discriminate Hc.
  - intros p1 p2 Hp1in Hp2in Hfeq.
    apply (in_filter_seq_isSome _ (vis_at l ds) (length tM) p1) in Hp1in.
    apply (in_filter_seq_isSome _ (vis_at l ds) (length tM) p2) in Hp2in.
    destruct Hp1in as [Hp1 [e1 Hev1]]. destruct Hp2in as [Hp2 [e2 Hev2]].
    destruct (Nat.lt_trichotomy p1 p2) as [Hlt | [Heq | Hgt]].
    + exfalso. pose proof (vmapR_mono l ds es alpha tM tf p1 p2 e1 e2 Hlap Hrm HatM Hatf Hrz
                             Hp1 Hp2 Hev1 Hev2 Hlt). lia.
    + exact Heq.
    + exfalso. pose proof (vmapR_mono l ds es alpha tM tf p2 p1 e2 e1 Hlap Hrm HatM Hatf Hrz
                             Hp2 Hp1 Hev2 Hev1 Hgt). lia.
Qed.

(* Generic: an ascending list [A] included in an ascending list [B] and
   DOWNWARD-CLOSED in it (anything in B below an element of A is itself in A) is
   exactly B's initial segment of length |A|. *)
Lemma ascending_down_firstn : forall B A,
  ascending A -> ascending B -> incl A B -> length A <= length B ->
  (forall b a, In b B -> In a A -> b < a -> In b A) ->
  A = firstn (length A) B.
Proof.
  induction B as [|b0 B' IH]; intros A HascA HascB Hincl Hlen Hdown.
  - destruct A as [|a0 A']; [reflexivity |].
    exfalso. destruct (Hincl a0 (or_introl eq_refl)).
  - destruct A as [|a0 A']; [reflexivity |].
    assert (Ha0eq : a0 = b0).
    { assert (Ha0B : In a0 (b0 :: B')) by (apply Hincl; left; reflexivity).
      destruct Ha0B as [He | Hin']; [symmetry; exact He |].
      destruct HascB as [Hhd _]. pose proof (Hhd a0 Hin') as Hb0a0.
      assert (Hb0A : In b0 (a0 :: A'))
        by (apply (Hdown b0 a0); [left; reflexivity | left; reflexivity | exact Hb0a0]).
      destruct Hb0A as [He | Hb0A']; [exfalso; lia |].
      destruct HascA as [HhdA _]. pose proof (HhdA b0 Hb0A') as Ha0b0. exfalso; lia. }
    subst a0. simpl. f_equal.
    apply IH.
    + destruct HascA as [_ Htl]; exact Htl.
    + destruct HascB as [_ Htl]; exact Htl.
    + intros x Hx.
      assert (HxB : In x (b0 :: B')) by (apply Hincl; right; exact Hx).
      destruct HxB as [He | Hx']; [| exact Hx'].
      exfalso. subst x. destruct HascA as [HhdA _]. pose proof (HhdA b0 Hx) as Hc. lia.
    + simpl in Hlen. lia.
    + intros b a Hb Ha Hba.
      assert (HbB : In b (b0 :: B')) by (right; exact Hb).
      assert (HaA : In a (b0 :: A')) by (right; exact Ha).
      assert (HbA : In b (b0 :: A')) by (apply (Hdown b a); [exact HbB | exact HaA | exact Hba]).
      destruct HbA as [He | Hb']; [| exact Hb'].
      exfalso. subst b. destruct HascB as [HhdB _]. pose proof (HhdB b0 Hb) as Hc. lia.
Qed.

(* DOWNWARD CLOSURE (the no-gap core): an es visible position [q] strictly below
   an image [vmap l es ds p1] is itself an image of some ds visible position.
   Hence the reverse map's image is downward-closed in es's visible positions, so
   it is an INITIAL SEGMENT.  Proof: rrank_es q < rrank_es(vmap p1) = rrank_ds p1
   < count_ds, so the forward map [vmap l ds es] realizes [q] in ds (vmap_rrank_local,
   the "next rank exists" bound holding because rrank_es q < rrank_ds p1); that
   ds position [p'] maps back (vmapR_rrank) to an es visible position of rank
   rrank_es q, which is [q] by rrank-injectivity (vis_rrank_mono). *)
Lemma vmapR_image_down : forall l ds es alpha tM tf p1 e1 q eq,
  l_aligned_pair l ds es alpha -> reverse_matched l ds es alpha -> fwd_realizes l ds es tM tf ->
  admits_trace ds tM -> admits_trace es tf -> rev_outputs_realized l ds es tM tf ->
  p1 < length tM -> vis_at l ds p1 = Some e1 ->
  q < length tf -> vis_at l es q = Some eq ->
  q < vmap l es ds p1 ->
  exists p', p' < length tM /\ (exists e', vis_at l ds p' = Some e') /\ vmap l es ds p' = q.
Proof.
  intros l ds es alpha tM tf p1 e1 q eq Hlap Hrm Hfwd HatM Hatf Hrz Hp1 Hv1 Hq Hvq Hlt.
  assert (Hpe : pre_run es) by (destruct Hlap as [_ [H _]]; exact H).
  assert (Hpd : pre_run ds) by (destruct Hlap as [H _]; exact H).
  destruct (vmapR_rrank l ds es alpha tM tf p1 e1 Hlap Hrm HatM Hatf Hrz Hp1 Hv1)
    as [Hvp1lt [e1' [Hvp1vis Hrr1]]].
  pose proof (vis_rrank_mono l es tf q (vmap l es ds p1) eq e1' Hpe Hatf Hq Hvp1lt Hvq Hvp1vis Hlt)
    as Hrrlt.
  (* rrank_ds p1 < count_ds *)
  assert (Hrho1 : (match e1 with Eout _ _ => annot_count l ds (p1 - 2)
                              | Ein _ _ => annot_count l ds (S p1) | Etick => 0 end)
                  < annot_count l ds (length ds)).
  { destruct e1 as [la na | la na | ].
    - destruct (vis_in_struct l ds tM p1 la na HatM Hp1 Hv1) as [Hle [_ [[sb HcfgSp] [tkh Hredh]]]].
      assert (HannSp : redex_is_l_annotation l (cfg_at ds (S p1)))
        by (unfold redex_is_l_annotation; rewrite HcfgSp; simpl; rewrite Hredh;
            unfold is_l_annotation; left; simpl; exact Hle).
      assert (HSplt : S p1 < length ds)
        by (apply (cfg_at_active_lt ds (S p1) (h_body (prog la)) sb HcfgSp)).
      apply (rank_lt_total l ds (S p1) HSplt HannSp).
    - destruct (vis_out_struct l ds tM p1 la na Hpd HatM Hp1 Hv1)
        as [Hp12 [Hle [[cq [sq [e0 [tq0 [Hcfgq Hredq]]]]] _]]].
      assert (Hannp2 : redex_is_l_annotation l (cfg_at ds (p1 - 2)))
        by (unfold redex_is_l_annotation; rewrite Hcfgq; simpl; rewrite Hredq;
            unfold is_l_annotation; right; simpl; exact Hle).
      assert (Hp2lt : p1 - 2 < length ds)
        by (pose proof (admits_trace_length ds tM HatM); lia).
      apply (rank_lt_total l ds (p1 - 2) Hp2lt Hannp2).
    - exfalso. destruct (vis_at_sound l ds tM p1 Etick HatM Hp1 Hv1) as [_ Hvev].
      destruct Hvev as [[? [? [Hc _]]] | [? [? [Hc _]]]]; discriminate Hc. }
  assert (Hq_lt_rho1 : (match eq with Eout _ _ => annot_count l es (q - 2)
                                   | Ein _ _ => annot_count l es (S q) | Etick => 0 end)
                       < (match e1 with Eout _ _ => annot_count l ds (p1 - 2)
                                     | Ein _ _ => annot_count l ds (S p1) | Etick => 0 end))
    by (rewrite <- Hrr1; exact Hrrlt).
  assert (Hbq : forall lo no, eq = Eout lo no ->
                S (annot_count l es (q - 2)) < annot_count l ds (length ds)).
  { intros lo no Heq.
    assert (Hq2 : annot_count l es (q - 2)
                  < (match e1 with Eout _ _ => annot_count l ds (p1 - 2)
                                | Ein _ _ => annot_count l ds (S p1) | Etick => 0 end)).
    { rewrite Heq in Hq_lt_rho1. exact Hq_lt_rho1. }
    lia. }
  assert (Hrank : (match eq with Eout _ _ => annot_count l es (q - 2)
                              | Ein _ _ => annot_count l es (S q) | Etick => 0 end)
                  < annot_count l ds (length ds)) by lia.
  destruct (Hfwd q eq Hq Hvq Hrank Hbq)
    as [Hp'lt [e' [Hp'vis Hrrp']]].
  set (p' := vmap l ds es q) in *.
  destruct (vmapR_rrank l ds es alpha tM tf p' e' Hlap Hrm HatM Hatf Hrz Hp'lt Hp'vis)
    as [Hp''lt [e'' [Hp''vis Hrrp'']]].
  exists p'. split; [exact Hp'lt | split; [exists e'; exact Hp'vis |]].
  (* show vmap l es ds p' = q via rrank injectivity on es-visible positions *)
  assert (Hrreq : (match e'' with Eout _ _ => annot_count l es (vmap l es ds p' - 2)
                               | Ein _ _ => annot_count l es (S (vmap l es ds p')) | Etick => 0 end)
                = (match eq with Eout _ _ => annot_count l es (q - 2)
                              | Ein _ _ => annot_count l es (S q) | Etick => 0 end))
    by (rewrite Hrrp''; exact Hrrp').
  destruct (Nat.lt_trichotomy (vmap l es ds p') q) as [Hlt' | [Heq' | Hgt']].
  - exfalso.
    pose proof (vis_rrank_mono l es tf (vmap l es ds p') q e'' eq Hpe Hatf Hp''lt Hq Hp''vis Hvq Hlt')
      as Hc. lia.
  - exact Heq'.
  - exfalso.
    pose proof (vis_rrank_mono l es tf q (vmap l es ds p') eq e'' Hpe Hatf Hq Hp''lt Hvq Hp''vis Hgt')
      as Hc. lia.
Qed.

(* THE REVERSE BRIDGE (prefix form): the receptive-ending minor reproduces the
   major's WHOLE visible trace as a PREFIX.  The reverse map's image is an initial
   segment of es's visible positions (downward-closed by vmapR_image_down), so the
   major's visible events are es's first [|vis tM|] visible events. *)
Lemma vis_bridge_rev_prefix : forall l ds es alpha tM tf,
  l_aligned_pair l ds es alpha -> reverse_matched l ds es alpha ->
  fwd_realizes l ds es tM tf -> annot_value_agree l ds es alpha ->
  admits_trace ds tM -> admits_trace es tf -> rev_outputs_realized l ds es tM tf ->
  list_prefix (vis l tM) (vis l tf).
Proof.
  intros l ds es alpha tM tf Hlap Hrm Hfwd Hval HatM Hatf Hrz.
  set (PA := filter (fun p => match vis_at l ds p with Some _ => true | None => false end)
                    (seq 0 (length tM))).
  set (PB := filter (fun p => match vis_at l es p with Some _ => true | None => false end)
                    (seq 0 (length tf))).
  assert (HmapAB : map (vmap l es ds) PA = firstn (length PA) PB).
  { assert (Hlm : length (map (vmap l es ds) PA) = length PA) by (apply length_map).
    rewrite <- Hlm. apply ascending_down_firstn.
    - apply ascending_map_mono; [apply ascending_filter, seq_ascending |].
      intros x y Hx Hy Hxy.
      apply (in_filter_seq_isSome event (vis_at l ds) (length tM) x) in Hx.
      apply (in_filter_seq_isSome event (vis_at l ds) (length tM) y) in Hy.
      destruct Hx as [Hxlt [ex Hex]]. destruct Hy as [Hylt [ey Hey]].
      exact (vmapR_mono l ds es alpha tM tf x y ex ey Hlap Hrm HatM Hatf Hrz Hxlt Hylt Hex Hey Hxy).
    - apply ascending_filter, seq_ascending.
    - intros z Hz. apply in_map_iff in Hz. destruct Hz as [a [Hva Ha]]. subst z.
      apply (in_filter_seq_isSome event (vis_at l ds) (length tM) a) in Ha.
      destruct Ha as [Halt [ea Hea]].
      apply (in_filter_seq_isSome event (vis_at l es) (length tf) (vmap l es ds a)).
      destruct (vmapR_rrank l ds es alpha tM tf a ea Hlap Hrm HatM Hatf Hrz Halt Hea)
        as [Hvlt [e' [Hvis' _]]].
      split; [exact Hvlt | exists e'; exact Hvis'].
    - rewrite length_map. unfold PA, PB.
      rewrite <- (vis_length_positions l ds tM HatM), <- (vis_length_positions l es tf Hatf).
      apply (minor_vis_le_rev l ds es alpha tM tf Hlap Hrm HatM Hatf Hrz).
    - intros b a Hb Ha Hba.
      apply in_map_iff in Ha. destruct Ha as [pa [Hpa Hpain]]. subst a.
      apply (in_filter_seq_isSome event (vis_at l ds) (length tM) pa) in Hpain.
      destruct Hpain as [Hpalt [epa Hepa]].
      apply (in_filter_seq_isSome event (vis_at l es) (length tf) b) in Hb.
      destruct Hb as [Hblt [eb Heb]].
      destruct (vmapR_image_down l ds es alpha tM tf pa epa b eb
                  Hlap Hrm Hfwd HatM Hatf Hrz Hpalt Hepa Hblt Heb Hba)
        as [p' [Hp'lt [[e' Hp'vis] Hp'eq]]].
      apply in_map_iff. exists p'. split; [exact Hp'eq |].
      apply (in_filter_seq_isSome event (vis_at l ds) (length tM) p').
      split; [exact Hp'lt | exists e'; exact Hp'vis]. }
  assert (Hkey : vis l tM = firstn (length PA) (vis l tf)).
  { rewrite (vis_eq_collect l ds tM HatM),
            (collect_opt_filter event (vis_at l ds) Etick (seq 0 (length tM))).
    rewrite (vis_eq_collect l es tf Hatf),
            (collect_opt_filter event (vis_at l es) Etick (seq 0 (length tf))).
    fold PA. fold PB.
    rewrite <- ga_firstn_map, <- HmapAB, map_map.
    apply map_ext_in. intros a Ha.
    apply (in_filter_seq_isSome event (vis_at l ds) (length tM) a) in Ha.
    destruct Ha as [Halt [ea Hea]].
    pose proof (vmapR_event_eq l ds es alpha tM tf a ea Hlap Hrm Hval HatM Hatf Hrz Halt Hea) as Hev.
    rewrite Hea, Hev. reflexivity. }
  rewrite Hkey. exists (skipn (length PA) (vis l tf)). symmetry. apply firstn_skipn.
Qed.

(* Providers of the abstracted reverse-bridge hypotheses for a genuine
   conformance with a receptive-ending minor (the receptive disjunct). *)

(* covers_rng of the minor supplies the forward-map realization (vmap_rrank_local). *)
Lemma fwd_realizes_covers_rng : forall l ds es alpha tM tf,
  l_aligned_pair l ds es alpha -> covers_rng es alpha ->
  admits_trace ds tM -> admits_trace es tf ->
  fwd_realizes l ds es tM tf.
Proof.
  intros l ds es alpha tM tf Hlap Hcr HatM Hatf q eq Hq Hvq Hrank Hbq.
  apply (vmap_rrank_local l ds es alpha tM tf q eq Hlap Hcr HatM Hatf Hq Hvq Hbq).
Qed.

(* The conformance models clause supplies value agreement (conf_annot_value). *)
Lemma annot_value_agree_from_conf : forall l ins ds es alpha,
  conformance l ins ds es alpha -> annot_value_agree l ds es alpha.
Proof.
  intros l ins ds es alpha Hconf i j l' tk e Haij Hred Hle.
  apply (conf_annot_value l ins ds es alpha i j l' tk e Hconf Haij Hred Hle).
Qed.

(* A receptive-ending minor realizes every matched output: the matched assert is
   Active so it reaches its Cout (assert_succ_succ_lt), whose successor is Active
   (active_succ_lt) so the Cout is a valid trace position. *)
Lemma rev_outputs_realized_receptive : forall l ds es alpha tM tf,
  l_aligned_pair l ds es alpha -> reverse_matched l ds es alpha ->
  admits_trace ds tM -> admits_trace es tf -> is_receptive (last_cfg es) ->
  rev_outputs_realized l ds es tM tf.
Proof.
  intros l ds es alpha tM tf Hlap Hrm HatM Hatf Hrecv p l' n Hp Hvis.
  assert (Hpd : pre_run ds) by (destruct Hlap as [H _]; exact H).
  assert (Hpe : pre_run es) by (destruct Hlap as [_ [H _]]; exact H).
  pose proof (admits_trace_length ds tM HatM) as HdM.
  pose proof (admits_trace_length es tf Hatf) as HeM.
  destruct (vis_at_sound l ds tM p (Eout l' n) HatM Hp Hvis) as [Hnthp Hvev].
  assert (Hle : lleq l' l).
  { destruct Hvev as [Hin | Hout].
    - destruct Hin as [l0 [n0 [Heq _]]]; discriminate Heq.
    - destruct Hout as [l2 [n2 [Heq Hl2]]]; injection Heq as Hl Hnn; subst l2; exact Hl2. }
  destruct (trace_output_cfg ds tM p l' n HatM Hp Hnthp) as [cc [s [e [Hcfgp [Hredcc Hn]]]]].
  assert (Hpds : p < length ds) by lia.
  destruct (prerun_output_pair_struct ds p cc s l' e Hpd Hpds Hcfgp Hredcc)
    as [cq [cp [tq18 [Hp2 [Hdsq [Hredq [Hdsp1 Hredp]]]]]]].
  assert (Hannp2 : redex_is_l_annotation l (cfg_at ds (p - 2))).
  { unfold redex_is_l_annotation. rewrite Hdsq. simpl. rewrite Hredq.
    unfold is_l_annotation. right. simpl. exact Hle. }
  set (r := annot_count l ds (p - 2)) in *.
  assert (Hp2lt : p - 2 < length ds) by lia.
  assert (Hnth_ds : is_nth_annot l ds r (p - 2))
    by (unfold is_nth_annot, r; split; [exact Hp2lt | split; [exact Hannp2 | reflexivity]]).
  destruct (Hrm r (p - 2) Hnth_ds) as [j [Haij [Hnth_es Hcmdeq]]].
  assert (HrC : r < annot_count l es (length es)).
  { destruct Hnth_es as [Hjlt [Hannj Hcnt]].
    pose proof (annot_count_annot_S l es j Hannj) as HS.
    pose proof (annot_count_mono l es (S j) (length es) ltac:(lia)) as Hm. lia. }
  assert (Hidx : j = annot_idx l es r)
    by (apply (is_nth_annot_unique l es r j (annot_idx l es r) Hnth_es (annot_idx_is_nth l es r HrC))).
  rewrite <- Hidx.
  rewrite Hdsq in Hcmdeq. simpl in Hcmdeq.
  destruct (cfg_at es j) as [sr | ej sj] eqn:Hesj; [discriminate Hcmdeq |].
  simpl in Hcmdeq. injection Hcmdeq as Hejcq. subst ej.
  pose proof (assert_succ_succ_lt es j cq sj l' tq18 (Ragr e) Hpe Hrecv Hesj Hredq) as HSSj.
  pose proof (output_realize_cross es ds j p cc s l' e Hpe Hpd Hcfgp Hredcc Hpds
                ltac:(rewrite Hesj, Hdsq; reflexivity) HSSj) as [Hpost Hout].
  destruct (cfg_at es (S (S j))) as [sr2 | cz sz] eqn:HcfgSSj; simpl in Hout; [discriminate Hout |].
  pose proof (active_succ_lt es (S (S j)) cz sz Hrecv HcfgSSj) as HSSSj.
  lia.
Qed.

(* ----------------------------------------------------------------------- *)
(* covers_dom MIXED-BRIDGE providers + witness construction.  The minor of  *)
(* the conformance, [fs], is extended to a maximal run [fs ++ ex] on [ins]   *)
(* that either ends receptive or is long enough that all of [ds]'s matched   *)
(* asserts reach their Couts.  All reverse-bridge hypotheses are supplied for *)
(* [(ds, fs ++ ex)] from the conformance for [(ds, fs)].                      *)
(* ----------------------------------------------------------------------- *)

(* [covers_rng fs] + equal annotation counts supply the forward-map realization
   for the EXTENDED minor [fs ++ ex] (vmap_rrank_local_ext, fs-restricted match). *)
Lemma fwd_realizes_ext : forall l ds fs ex alpha tM tf,
  pre_run ds -> pre_run (fs ++ ex) ->
  l_aligned_pair l ds fs alpha -> covers_rng fs alpha ->
  annot_count l ds (length ds) = annot_count l fs (length fs) ->
  admits_trace ds tM -> admits_trace (fs ++ ex) tf ->
  fwd_realizes l ds (fs ++ ex) tM tf.
Proof.
  intros l ds fs ex alpha tM tf Hpd Hpe Hlap Hcr Hcount HatM Hatf q eq Hq Hvq Hrank Hbq.
  assert (Hrho : (match eq with Eout _ _ => annot_count l (fs ++ ex) (q - 2)
                            | Ein _ _ => annot_count l (fs ++ ex) (S q) | Etick => 0 end)
                 < annot_count l fs (length fs)) by (rewrite <- Hcount; exact Hrank).
  apply (vmap_rrank_local_ext l ds fs ex alpha tM tf q eq Hpd Hpe Hlap Hcr Hcount HatM Hatf Hq Hvq Hrho Hbq).
Qed.

(* Value agreement transports to the extended minor: aligned minor indices lie in
   [fs] (alignment range bound), where [fs ++ ex] agrees with [fs] config-for-config. *)
Lemma annot_value_agree_ext : forall l ds fs ex alpha,
  l_aligned_pair l ds fs alpha -> annot_value_agree l ds fs alpha ->
  annot_value_agree l ds (fs ++ ex) alpha.
Proof.
  intros l ds fs ex alpha Hlap Hval i j l' tk e Haij Hred Hle.
  assert (Hjlt : j < length fs)
    by (destruct Hlap as [_ [_ [[Hbound _] _]]]; exact (proj2 (Hbound i j Haij))).
  rewrite (cfg_at_app_lt fs ex j Hjlt).
  apply (Hval i j l' tk e Haij Hred Hle).
Qed.

(* A maximal extended minor realizes every matched major output: either it is long
   enough (matched assert index < length fs, so its Cout at +2 is within range) or
   it ends receptive (assert_succ_succ_lt). *)
Lemma rev_outputs_realized_ext : forall l ds fs ex alpha tM tf,
  pre_run ds -> pre_run (fs ++ ex) ->
  l_aligned_pair l ds fs alpha ->
  annot_count l ds (length ds) = annot_count l fs (length fs) ->
  reverse_matched l ds (fs ++ ex) alpha ->
  admits_trace ds tM -> admits_trace (fs ++ ex) tf ->
  (length fs + 2 <= length tf \/ is_receptive (last_cfg (fs ++ ex))) ->
  rev_outputs_realized l ds (fs ++ ex) tM tf.
Proof.
  intros l ds fs ex alpha tM tf Hpd Hpe Hlap Hcount Hrm HatM Hatf Hlen.
  destruct Hlen as [Hlong | Hrecv].
  - intros p l' n Hp Hvis.
    pose proof (admits_trace_length ds tM HatM) as HdM.
    pose proof (admits_trace_length (fs ++ ex) tf Hatf) as HeM.
    destruct (vis_at_sound l ds tM p (Eout l' n) HatM Hp Hvis) as [Hnthp Hvev].
    assert (Hle : lleq l' l).
    { destruct Hvev as [Hin | Hout].
      - destruct Hin as [l0 [n0 [Heq _]]]; discriminate Heq.
      - destruct Hout as [l2 [n2 [Heq Hl2]]]; injection Heq as Hl Hnn; subst l2; exact Hl2. }
    destruct (trace_output_cfg ds tM p l' n HatM Hp Hnthp) as [cc [s [e [Hcfgp [Hredcc Hn]]]]].
    assert (Hpds : p < length ds) by lia.
    destruct (prerun_output_pair_struct ds p cc s l' e Hpd Hpds Hcfgp Hredcc)
      as [cq [cp [tq19 [Hp2 [Hdsq [Hredq [Hdsp1 Hredp]]]]]]].
    assert (Hannp2 : redex_is_l_annotation l (cfg_at ds (p - 2))).
    { unfold redex_is_l_annotation. rewrite Hdsq. simpl. rewrite Hredq.
      unfold is_l_annotation. right. simpl. exact Hle. }
    set (r := annot_count l ds (p - 2)) in *.
    assert (Hp2lt : p - 2 < length ds) by lia.
    assert (Hnth_ds : is_nth_annot l ds r (p - 2))
      by (unfold is_nth_annot, r; split; [exact Hp2lt | split; [exact Hannp2 | reflexivity]]).
    assert (HrcountD : r < annot_count l ds (length ds))
      by (apply (rank_lt_total l ds (p - 2) Hp2lt Hannp2)).
    assert (Hrcount : r < annot_count l fs (length fs)) by (rewrite <- Hcount; exact HrcountD).
    destruct (Hrm r (p - 2) Hnth_ds) as [j [Haij [Hnth_es Hcmdeq]]].
    assert (Hfsr : j < length fs) by (apply (annot_in_prefix l fs ex r j Hnth_es Hrcount)).
    assert (HrC : r < annot_count l (fs ++ ex) (length (fs ++ ex))).
    { destruct Hnth_es as [Hjlt [Hannj Hcnt]].
      pose proof (annot_count_annot_S l (fs ++ ex) j Hannj) as HS.
      pose proof (annot_count_mono l (fs ++ ex) (S j) (length (fs ++ ex)) ltac:(lia)) as Hm. lia. }
    assert (Hidx : j = annot_idx l (fs ++ ex) r)
      by (apply (is_nth_annot_unique l (fs ++ ex) r j (annot_idx l (fs ++ ex) r) Hnth_es
                   (annot_idx_is_nth l (fs ++ ex) r HrC))).
    rewrite <- Hidx. lia.
  - pose proof (l_aligned_pair_app_rng l ds fs ex alpha Hlap Hpe) as HlapR.
    apply (rev_outputs_realized_receptive l ds (fs ++ ex) alpha tM tf HlapR Hrm HatM Hatf Hrecv).
Qed.

(* Extend a run on [ins] by annotation-free Active steps (frun with no remaining
   input): the result still has inputs [ins] and is either at least [k] long or
   ends receptive. *)
Lemma extend_to_realize : forall ins base tbase k,
  Forall is_input ins ->
  admits_trace base tbase -> inputs tbase = ins ->
  exists ext tf,
    admits_trace (base ++ ext) tf /\ inputs tf = ins /\
    (k <= length (base ++ ext) \/ is_receptive (last_cfg (base ++ ext))).
Proof.
  intros ins base tbase k Hforall Hat Hins.
  exists (map snd (frun (last_cfg base) [] k)),
         (tbase ++ map fst (frun (last_cfg base) [] k)).
  split; [apply frun_admits; exact Hat |].
  assert (Hnil : inputs (map fst (frun (last_cfg base) [] k)) = []).
  { pose proof (frun_inputs_prefix k (last_cfg base) []) as [zs Hzs].
    symmetry in Hzs. apply app_eq_nil in Hzs. destruct Hzs as [HX _]. exact HX. }
  split.
  - rewrite inputs_app, Hins, Hnil, app_nil_r. reflexivity.
  - destruct (Nat.lt_ge_cases (length (frun (last_cfg base) [] k)) k) as [Hlt | Hge].
    + right. rewrite (frcfg_last base [] k).
      apply (frun_halt_receptive k (last_cfg base) [] (Forall_nil _) Hlt).
    + left. rewrite length_app, length_map.
      pose proof (frun_length k (last_cfg base) []) as Hub. lia.
Qed.

(* Witness construction for the covers_dom branch: the conformance minor [fs]
   extends to a run [fs ++ ex] on exactly [ins] that is realization-ready
   (long enough OR receptive).  [pknow] guarantees a finite run consuming all of
   [ins] exists; the longer of it and [fs] is the canonical base, extended by
   annotation-free steps. *)
Lemma covers_dom_witness_run : forall l ins fs ih ts,
  Forall is_input ins ->
  pr_inputs fs ih -> list_prefix ih ins ->
  pknow l ts ins ->
  exists ex tf,
    admits_trace (fs ++ ex) tf /\ inputs tf = ins /\
    (length fs + 2 <= length tf \/ is_receptive (last_cfg (fs ++ ex))).
Proof.
  intros l ins fs ih ts Hforall Hpri Hihins Hpk.
  destruct Hpk as [W [us0 [ev0 [vs0 [Hvev [HatW [Hpre Hins]]]]]]].
  set (twW := us0 ++ [ev0] ++ vs0) in *.
  assert (HitwW : inputs twW = ins) by (symmetry; exact Hins).
  destruct Hpri as [efs [Hatfs Hihefs]].
  assert (Hpa_fs : list_prefix (inputs efs) ins) by (rewrite Hihefs; exact Hihins).
  assert (Hpa_W : list_prefix (inputs twW) ins) by (rewrite HitwW; apply list_prefix_refl).
  assert (Hbase : exists base tbase ex0,
            admits_trace base tbase /\ inputs tbase = ins /\ base = fs ++ ex0).
  { destruct (Nat.le_ge_cases (length fs) (length W)) as [Hle | Hge].
    - destruct (prerun_config_prefix ins fs efs W twW Hforall Hatfs Hpa_fs HatW Hpa_W Hle) as [ex0 HW].
      exists W, twW, ex0. split; [exact HatW | split; [exact HitwW | exact HW]].
    - pose proof (prerun_trace_prefix ins W twW fs efs Hforall HatW Hpa_W Hatfs Hpa_fs Hge) as [zs Hzs].
      assert (Hef_ins : inputs efs = ins ++ inputs zs)
        by (rewrite Hzs, inputs_app, HitwW; reflexivity).
      assert (Hizs : inputs zs = []).
      { destruct Hihins as [c Hc].
        pose proof (f_equal (@length event) Hc) as L1.
        assert (L2 : length ih = length ins + length (inputs zs))
          by (rewrite <- Hihefs, Hef_ins, length_app; reflexivity).
        rewrite length_app in L1.
        apply length_zero_iff_nil. lia. }
      assert (Hieq : inputs efs = ins) by (rewrite Hef_ins, Hizs, app_nil_r; reflexivity).
      exists fs, efs, []. rewrite app_nil_r.
      split; [exact Hatfs | split; [exact Hieq | reflexivity]]. }
  destruct Hbase as [base [tbase [ex0 [Hatbase [Hinbase Hbaseeq]]]]].
  destruct (extend_to_realize ins base tbase (length fs + 3) Hforall Hatbase Hinbase)
    as [ext [tf [HatR [HinR Hdisj]]]].
  exists (ex0 ++ ext), tf.
  rewrite Hbaseeq, <- app_assoc in HatR.
  split; [exact HatR | split; [exact HinR |]].
  pose proof (admits_trace_length (fs ++ ex0 ++ ext) tf HatR) as HRlen.
  rewrite Hbaseeq, <- app_assoc in Hdisj.
  destruct Hdisj as [Hlong | Hrecv]; [left; lia | right; exact Hrecv].
Qed.

(* Receptive branch, STRICT-count sub-case of the conformance case.  When the
   minor [es] consumed all of [ins] and halted receptive, progress knowledge
   [pknow l ts ins] forces [es] to realize strictly more than [|vis l ts|]
   l-visible events (pknow_minor_progress); and when the major has strictly more
   l-annotations than the minor (so [t]'s paired assert is an extra, uncovered
   major annotation), the strict bridge [vis_bridge_strict] forces the minor's
   visible trace to reproduce the major's whole visible trace [vis l ts ++ [t]].
   Hence [es] (which runs on exactly [ins]) witnesses [know l (ts ++ [t]) ins]. *)
Lemma know_extend_strict_receptive : forall l ins ds es alpha tM ts t tf,
  Forall is_input ins ->
  conformance l ins ds es alpha ->
  admits_trace ds tM -> tM = ts ++ [t] -> Vev l t ->
  admits_trace es tf -> inputs tf = ins -> is_receptive (last_cfg es) ->
  annot_count l es (length es) < annot_count l ds (length ds) ->
  pknow l ts ins ->
  know l (ts ++ [t]) ins.
Proof.
  intros l ins ds es alpha tM ts t tf Hforall Hconf HatM HtM HVO Hatf Hinputs Hrecv Hstrict Hpk.
  assert (Hvt : Vev l t) by exact HVO.
  assert (HvistM : vis l tM = vis l ts ++ [t]).
  { rewrite HtM, vis_app, (vis_cons_visible l t [] Hvt), vis_nil. reflexivity. }
  destruct (pknow_minor_progress l ins ts es tf Hforall Hatf Hinputs Hrecv Hpk)
    as [Hpre Hlt].
  assert (Hge : length (vis l tM) <= length (vis l tf)).
  { rewrite HvistM, length_app. simpl. lia. }
  pose proof (vis_bridge_strict l ins ds es alpha tM tf Hconf HatM Hatf Hstrict Hge) as Hbridge.
  exists es, tf. split; [exact Hatf | split].
  - assert (Hvistt : vis l (ts ++ [t]) = vis l ts ++ [t])
      by (rewrite vis_app, (vis_cons_visible l t [] Hvt), vis_nil; reflexivity).
    rewrite Hvistt. rewrite HvistM in Hbridge. rewrite Hbridge. apply list_prefix_refl.
  - symmetry. exact Hinputs.
Qed.

(* Receptive branch, EQUAL-count sub-case.  Here [t]'s assert is matched in [es],
   so the major's annotation count equals the minor's; [eqcount_reverse_matched]
   then supplies the reverse matcher and [vis_bridge_rev_prefix] gives the minor's
   visible trace as a prefix-extension of the major's [vis l ts ++ [t]].  The
   minor [es] runs on exactly [ins], so it witnesses [know l (ts ++ [t]) ins]. *)
Lemma know_extend_equal_receptive : forall l ins ds es alpha ts t tf,
  conformance l ins ds es alpha ->
  admits_trace ds (ts ++ [t]) -> Vev l t ->
  admits_trace es tf -> inputs tf = ins -> is_receptive (last_cfg es) ->
  annot_count l es (length es) = annot_count l ds (length ds) ->
  know l (ts ++ [t]) ins.
Proof.
  intros l ins ds es alpha ts t tf Hconf HatM HVO Hatf Hinputs Hrecv Heq.
  assert (Hlap : l_aligned_pair l ds es alpha) by (destruct Hconf as [H _]; exact H).
  assert (Hcr : covers_rng es alpha) by (destruct Hconf as [_ [_ [H _]]]; exact H).
  pose proof (eqcount_reverse_matched l ds es alpha Hlap Hcr Heq) as Hrm.
  pose proof (fwd_realizes_covers_rng l ds es alpha (ts ++ [t]) tf Hlap Hcr HatM Hatf) as Hfwd.
  pose proof (annot_value_agree_from_conf l ins ds es alpha Hconf) as Hval.
  pose proof (rev_outputs_realized_receptive l ds es alpha (ts ++ [t]) tf
                Hlap Hrm HatM Hatf Hrecv) as Hrz.
  pose proof (vis_bridge_rev_prefix l ds es alpha (ts ++ [t]) tf
                Hlap Hrm Hfwd Hval HatM Hatf Hrz) as Hpre.
  exists es, tf. split; [exact Hatf | split; [exact Hpre | symmetry; exact Hinputs]].
Qed.

(* ---------------------------------------------------------------------------- *)
(* Safety implies security.  
   The main lemmas, sec_conf_case, sec_assumF_case, and sec_divF_case cover the 
   three classes allowed by safety.  They are used to prove safe_implies_secure 
   along the lines of the proof sketch in the paper:
   conformance constructs the knowledge witness; assumption fiat refutes the
   release policy; divergence fiat refutes progress knowledge except in a 
   special case where there is a knowledge witness. *)
(* ---------------------------------------------------------------------------- *)

Lemma sec_conf_case : forall l hs g ts t ins fs alpha,
  admits_trace hs ts -> admits_trace (hs ++ [g]) (ts ++ [t]) -> Vev l t ->
  pknow l ts ins -> conformance l ins (hs ++ [g]) fs alpha ->
  know l (ts ++ [t]) ins.
Proof.
  intros l hs g ts t ins fs alpha Hts Htst HVO Hpkn Hconf.
  assert (Hinp : Forall is_input ins)
    by (apply (conformance_inputs l ins (hs ++ [g]) fs alpha); exact Hconf).
  pose proof Hconf as Hconf'.
  destruct Hconf' as [Hlap [[ih [Hpri [Hihins Hdisj]]] [Hcrng [Hmod Hinp2]]]].
  destruct Hdisj as [Hcovdom | [Hiheq Hrecv]].
  - (* covers_dom disjunct: extend fs to a realization-ready run on ins and run
       the reverse prefix bridge (covers_dom matches every major annotation). *)
    destruct (covers_dom_witness_run l ins fs ih ts Hinp Hpri Hihins Hpkn)
      as [ex [tf [HatR [HinR HdisjR]]]].
    set (ds := hs ++ [g]) in *.
    assert (Hpd : pre_run ds) by (destruct Hlap as [H _]; exact H).
    assert (HpeR : pre_run (fs ++ ex)) by (exists tf; exact HatR).
    assert (Hcount : annot_count l ds (length ds) = annot_count l fs (length fs))
      by (apply (equal_count l ds fs alpha Hlap Hcovdom Hcrng)).
    pose proof (covers_dom_reverse_matched l ds fs alpha Hlap Hcovdom Hcrng) as Hrm0.
    pose proof (reverse_matched_ext l ds fs ex alpha Hrm0) as HrmR.
    pose proof (l_aligned_pair_app_rng l ds fs ex alpha Hlap HpeR) as HlapR.
    pose proof (fwd_realizes_ext l ds fs ex alpha (ts ++ [t]) tf
                  Hpd HpeR Hlap Hcrng Hcount Htst HatR) as Hfwd.
    pose proof (annot_value_agree_from_conf l ins ds fs alpha Hconf) as Hval0.
    pose proof (annot_value_agree_ext l ds fs ex alpha Hlap Hval0) as HvalR.
    pose proof (rev_outputs_realized_ext l ds fs ex alpha (ts ++ [t]) tf
                  Hpd HpeR Hlap Hcount HrmR Htst HatR HdisjR) as Hrz.
    pose proof (vis_bridge_rev_prefix l ds (fs ++ ex) alpha (ts ++ [t]) tf
                  HlapR HrmR Hfwd HvalR Htst HatR Hrz) as Hpre.
    exists (fs ++ ex), tf. split; [exact HatR | split; [exact Hpre | symmetry; exact HinR]].
  - (* receptive disjunct: minor fs runs on all of ins and halts receptive *)
    destruct Hpri as [tf [Hatf Hinputs]].
    rewrite Hiheq in Hinputs.
    pose proof (annot_count_le_rng l (hs ++ [g]) fs alpha Hlap Hcrng) as Hle_count.
    destruct (Nat.lt_ge_cases (annot_count l fs (length fs))
                              (annot_count l (hs ++ [g]) (length (hs ++ [g])))) as [Hstrict | Hge].
    + apply (know_extend_strict_receptive l ins (hs ++ [g]) fs alpha (ts ++ [t]) ts t tf
               Hinp Hconf Htst eq_refl HVO Hatf Hinputs Hrecv Hstrict Hpkn).
    + assert (Heq : annot_count l fs (length fs)
                  = annot_count l (hs ++ [g]) (length (hs ++ [g]))) by lia.
      apply (know_extend_equal_receptive l ins (hs ++ [g]) fs alpha ts t tf
               Hconf Htst HVO Hatf Hinputs Hrecv Heq).
Qed.

(* A proper l-aligned pair is in particular semi-proper. *)
Lemma l_aligned_pair_semi : forall l gs hs alpha,
  l_aligned_pair l gs hs alpha -> semi_l_aligned_pair l gs hs alpha.
Proof.
  intros l gs hs alpha [Hpg [Hph [Halgn Hcoin]]].
  split; [exact Hpg | split; [exact Hph |]].
  split; [exact Halgn |].
  intros a b Hab Hdisj. apply (Hcoin a b Hab).
  destruct Hdisj as [H | H]; [left | right]; apply redex_assume_annotation; exact H.
Qed.

(* ====================================================================== *)
(* Generic marker-rank layer: the rank-faithfulness argument behind        *)
(* minor_annot_cfg_det, abstracted over a decidable redex-predicate Q that *)
(* (i) depends only on the redex, (ii) is false at a redex-free config,    *)
(* (iii) is never held by two step-adjacent configs (no_q_adj). Below it   *)
(* is instantiated at l-ASSUME (under semi-proper alignments) to give    *)
(* minor_assume_cfg_det; the l-ANNOTATION instantiation already exists     *)
(* concretely (annot_align_rank etc.).                                     *)
(* ====================================================================== *)
Section MarkRank.
Variable Q : config -> Prop.
Variable Qdec : forall g, {Q g} + {~ Q g}.
Hypothesis Qredex : forall g g', redex_of g = redex_of g' -> Q g -> Q g'.
Hypothesis Qnone : forall g, redex_of g = None -> ~ Q g.
Hypothesis Qstep : forall c0 ev g, step c0 ev g -> Q g -> ~ Q c0.

Fixpoint qcount (gs : list config) (k : nat) : nat :=
  match k with
  | 0 => 0
  | S k' => qcount gs k' + (if Qdec (cfg_at gs k') then 1 else 0)
  end.

Definition is_nth_q (gs : list config) (n i : nat) : Prop :=
  i < length gs /\ Q (cfg_at gs i) /\ qcount gs i = n.

Definition q_aligned (gs hs : list config) (alpha : nat -> nat -> Prop) : Prop :=
  pre_run gs /\ pre_run hs /\ alignment gs hs alpha /\
  (forall i j, alpha i j -> Q (cfg_at gs i) \/ Q (cfg_at hs j) ->
     redex_of (cfg_at gs i) = redex_of (cfg_at hs j)).

Lemma qcount_q_S : forall gs k, Q (cfg_at gs k) -> qcount gs (S k) = S (qcount gs k).
Proof. intros gs k Hq. simpl. destruct (Qdec (cfg_at gs k)); [lia | contradiction]. Qed.

Lemma qcount_nq_S : forall gs k, ~ Q (cfg_at gs k) -> qcount gs (S k) = qcount gs k.
Proof. intros gs k Hn. simpl. destruct (Qdec (cfg_at gs k)); [contradiction | lia]. Qed.

Lemma qcount_mono : forall gs k1 k2, k1 <= k2 -> qcount gs k1 <= qcount gs k2.
Proof. intros gs k1 k2 H. induction H; [lia |]. simpl. destruct (Qdec (cfg_at gs m)); lia. Qed.

Lemma qcount_ext : forall g1 g2 k,
  (forall m, m < k -> cfg_at g1 m = cfg_at g2 m) -> qcount g1 k = qcount g2 k.
Proof. intros g1 g2 k. induction k as [|k IH]; intros Hext; [reflexivity |]. simpl.
  rewrite IH by (intros m Hm; apply Hext; lia). rewrite (Hext k ltac:(lia)). reflexivity. Qed.

Lemma q_index_lt_length : forall gs m, Q (cfg_at gs m) -> m < length gs.
Proof. intros gs m H. destruct (Nat.lt_ge_cases m (length gs)) as [Hlt | Hge]; [exact Hlt |].
  exfalso. unfold cfg_at in H. rewrite nth_overflow in H by exact Hge.
  apply (Qnone (Receptive initState)); [reflexivity | exact H]. Qed.

Lemma is_nth_q_unique : forall gs n i i', is_nth_q gs n i -> is_nth_q gs n i' -> i = i'.
Proof.
  intros gs n i i' [Hi [Hai Hci]] [Hi' [Hai' Hci']].
  destruct (Nat.lt_trichotomy i i') as [Hlt | [Heq | Hgt]]; [| exact Heq |].
  - exfalso. assert (Hle : qcount gs (S i) <= qcount gs i') by (apply qcount_mono; lia).
    rewrite (qcount_q_S gs i Hai) in Hle. lia.
  - exfalso. assert (Hle : qcount gs (S i') <= qcount gs i) by (apply qcount_mono; lia).
    rewrite (qcount_q_S gs i' Hai') in Hle. lia.
Qed.

Lemma qcount_gives_nth : forall gs c m, c < qcount gs m -> exists i, i < m /\ is_nth_q gs c i.
Proof.
  intros gs c m. induction m as [|m IH]; intros Hc; [simpl in Hc; lia |].
  destruct (Qdec (cfg_at gs m)) as [Hann | Hnann].
  - rewrite (qcount_q_S gs m Hann) in Hc.
    destruct (Nat.lt_ge_cases c (qcount gs m)) as [Hlt | Hge].
    + destruct (IH Hlt) as [i [Him Hnth]]. exists i. split; [lia | exact Hnth].
    + exists m. split; [lia |]. unfold is_nth_q.
      split; [apply (q_index_lt_length gs m Hann) | split; [exact Hann | lia]].
  - rewrite (qcount_nq_S gs m Hnann) in Hc.
    destruct (IH Hc) as [i [Him Hnth]]. exists i. split; [lia | exact Hnth].
Qed.

Lemma no_q_between : forall xs m p q r,
  is_nth_q xs m p -> is_nth_q xs (S m) q -> Q (cfg_at xs r) -> p < r -> r < q -> False.
Proof.
  intros xs m p q r [_ [Hap Hcp]] [_ [_ Hcq]] Har Hpr Hrq.
  assert (HSp : qcount xs (S p) = S m) by (rewrite (qcount_q_S xs p Hap); rewrite Hcp; reflexivity).
  assert (HSr : qcount xs (S r) = S (qcount xs r)) by (apply (qcount_q_S xs r Har)).
  assert (H1 : qcount xs (S p) <= qcount xs r) by (apply qcount_mono; lia).
  assert (H2 : qcount xs (S r) <= qcount xs q) by (apply qcount_mono; lia).
  rewrite HSp in H1. rewrite HSr in H2. rewrite Hcq in H2. lia.
Qed.

Lemma q_both : forall gs hs alpha a b,
  q_aligned gs hs alpha -> alpha a b -> Q (cfg_at gs a) -> Q (cfg_at hs b).
Proof.
  intros gs hs alpha a b [_ [_ [_ Hcoin]]] Hab Hqa.
  apply (Qredex (cfg_at gs a) (cfg_at hs b)); [apply (Hcoin a b Hab); left; exact Hqa | exact Hqa].
Qed.

Lemma q_rev : forall gs hs alpha a b,
  q_aligned gs hs alpha -> alpha a b -> Q (cfg_at hs b) -> Q (cfg_at gs a).
Proof.
  intros gs hs alpha a b [_ [_ [_ Hcoin]]] Hab Hqb.
  apply (Qredex (cfg_at hs b) (cfg_at gs a)); [symmetry; apply (Hcoin a b Hab); right; exact Hqb | exact Hqb].
Qed.

Lemma no_q_adj : forall gs k, pre_run gs -> Q (cfg_at gs (S k)) -> ~ Q (cfg_at gs k).
Proof.
  intros gs k Hpre HqS Hqk. assert (HSk : S k < length gs) by (apply (q_index_lt_length gs (S k) HqS)).
  destruct (pre_run_step_adj gs k Hpre HSk) as [ev Hstep].
  apply (Qstep (cfg_at gs k) ev (cfg_at gs (S k)) Hstep HqS). exact Hqk.
Qed.

Lemma q_img_unique : forall gs hs alpha a b1 b2,
  q_aligned gs hs alpha -> covers_rng hs alpha ->
  alpha a b1 -> alpha a b2 -> Q (cfg_at gs a) -> b1 = b2.
Proof.
  intros gs hs alpha a b1 b2 Hqal Hcrng Hab1 Hab2 Hann.
  pose proof Hqal as Hqal2. destruct Hqal2 as [Hpregs [Hprehs [Halgn Hcoin]]].
  assert (Hbound : forall i j, alpha i j -> i < length gs /\ j < length hs)
    by (destruct Halgn as [Hb _]; exact Hb).
  assert (Hmono : forall i j k m, alpha i j -> alpha k m -> (i<k -> j<=m) /\ (j<m -> i<=k))
    by (destruct Halgn as [_ [Hm _]]; exact Hm).
  assert (Hkey : forall c d, alpha a c -> alpha a d -> c < d -> False).
  { intros c d Hac Had Hcd.
    assert (Hannc : Q (cfg_at hs c)) by (apply (q_both gs hs alpha a c Hqal Hac Hann)).
    assert (HaSc : alpha a (S c)).
    { destruct (Nat.eq_dec (S c) d) as [Heq | Hne]; [ rewrite Heq; exact Had |].
      assert (HScd : S c < d) by lia.
      assert (HScl : S c < length hs) by (destruct (Hbound a d Had); lia).
      destruct (Hcrng (S c) HScl) as [a' Ha'].
      assert (Ha_le : a <= a') by (apply (proj2 (Hmono a c a' (S c) Hac Ha')); lia).
      assert (Ha'_le : a' <= a) by (apply (proj2 (Hmono a' (S c) a d Ha' Had)); lia).
      assert (Heqa : a' = a) by lia; subst a'; exact Ha'. }
    assert (HannSc : Q (cfg_at hs (S c))) by (apply (q_both gs hs alpha a (S c) Hqal HaSc Hann)).
    apply (no_q_adj hs c Hprehs HannSc); exact Hannc. }
  destruct (Nat.lt_trichotomy b1 b2) as [Hlt | [Heq | Hgt]];
    [ exfalso; apply (Hkey b1 b2 Hab1 Hab2 Hlt) | exact Heq | exfalso; apply (Hkey b2 b1 Hab2 Hab1 Hgt) ].
Qed.

Lemma q_align_rank : forall gs es alpha n i j,
  q_aligned gs es alpha -> covers_rng es alpha ->
  is_nth_q gs n i -> alpha i j -> is_nth_q es n j.
Proof.
  intros gs es alpha n i j Hqal Hcrng.
  pose proof Hqal as Hqal2. destruct Hqal2 as [Hpregs [Hpres [Halgn Hqcoin]]].
  destruct Halgn as [Hbound [Hmono [Hpcdom Hpcrng]]].
  revert i j; induction n as [|m IH]; intros i j Hnth Halpha.
  - destruct Hnth as [Hilt [Hanni Hci]].
    assert (Hannj : Q (cfg_at es j)) by (apply (q_both gs es alpha i j Hqal Halpha Hanni)).
    destruct (Hbound i j Halpha) as [_ Hjlt].
    split; [exact Hjlt | split; [exact Hannj |]].
    destruct (Nat.eq_dec (qcount es j) 0) as [H0 | Hpos]; [exact H0 | exfalso].
    assert (Hp : 0 < qcount es j) by lia.
    destruct (qcount_gives_nth es 0 j Hp) as [j0 [Hj0j Hnth0]].
    destruct Hnth0 as [_ [Hannj0 _]].
    assert (Hj0lt : j0 < length es) by lia.
    destruct (Hcrng j0 Hj0lt) as [a0 Ha0].
    assert (Hanna0 : Q (cfg_at gs a0)) by (apply (q_rev gs es alpha a0 j0 Hqal Ha0 Hannj0)).
    assert (Ha0i : a0 <= i) by (apply (proj2 (Hmono a0 j0 i j Ha0 Halpha)); lia).
    assert (Ha0eq : a0 = i).
    { destruct (Nat.eq_dec a0 i) as [Heq | Hne]; [exact Heq | exfalso].
      assert (Hc : qcount gs (S a0) <= qcount gs i) by (apply qcount_mono; lia).
      rewrite (qcount_q_S gs a0 Hanna0) in Hc. rewrite Hci in Hc. lia. }
    subst a0.
    assert (Hj0eq : j0 = j) by (apply (q_img_unique gs es alpha i j0 j Hqal Hcrng Ha0 Halpha Hanni)).
    lia.
  - destruct Hnth as [Hilt [Hanni Hci]].
    assert (Hannj : Q (cfg_at es j)) by (apply (q_both gs es alpha i j Hqal Halpha Hanni)).
    destruct (Hbound i j Halpha) as [_ Hjlt].
    assert (Hmltci : m < qcount gs i) by lia.
    destruct (qcount_gives_nth gs m i Hmltci) as [i' [Hi'i Hnthi']].
    assert (Hdomi : align_dom alpha i) by (exists j; exact Halpha).
    destruct (Hpcdom i i' Hdomi Hi'i) as [j' Hj'].
    assert (Hnthesj' : is_nth_q es m j') by (apply (IH i' j' Hnthi' Hj')).
    pose proof Hnthesj' as Hnthesj'2. destruct Hnthesj'2 as [Hj'lt [Hannj' Hcj']].
    assert (Hnthi : is_nth_q gs (S m) i) by (split; [exact Hilt | split; [exact Hanni | exact Hci]]).
    assert (Hj'lej : j' <= j) by (apply (proj1 (Hmono i' j' i j Hj' Halpha)); lia).
    assert (Hj'ltj : j' < j).
    { destruct (Nat.eq_dec j' j) as [Hjeq | Hjne]; [exfalso; subst j' | lia].
      destruct (Nat.eq_dec (S i') i) as [HSi | HnSi].
      - apply (no_q_adj gs i' Hpregs);
          [rewrite HSi; exact Hanni | destruct Hnthi' as [_ [Ha _]]; exact Ha].
      - assert (Hki : S i' < i) by lia.
        destruct (Hpcdom i (S i') Hdomi Hki) as [jk Hjk].
        assert (Hjk_ge : j <= jk) by (apply (proj1 (Hmono i' j (S i') jk Hj' Hjk)); lia).
        assert (Hjk_le : jk <= j) by (apply (proj1 (Hmono (S i') jk i j Hjk Halpha)); lia).
        assert (Hjkj : jk = j) by lia. subst jk.
        assert (Hnannk : ~ Q (cfg_at gs (S i')))
          by (intro Hck; apply (no_q_between gs m i' i (S i') Hnthi' Hnthi Hck); lia).
        apply Hnannk.
        assert (Hredeq : redex_of (cfg_at gs (S i')) = redex_of (cfg_at es j))
          by (apply (Hqcoin (S i') j Hjk); right; exact Hannj).
        apply (Qredex (cfg_at es j) (cfg_at gs (S i')) (eq_sym Hredeq)); exact Hannj. }
    split; [exact Hjlt | split; [exact Hannj |]].
    assert (Hnoann : forall t, j' < t -> t < j -> ~ Q (cfg_at es t)).
    { intros t Ht1 Ht2 Hannt. assert (Htlt : t < length es) by lia.
      destruct (Hcrng t Htlt) as [a Ha].
      assert (Hanna : Q (cfg_at gs a)) by (apply (q_rev gs es alpha a t Hqal Ha Hannt)).
      assert (Hi'a : i' <= a) by (apply (proj2 (Hmono i' j' a t Hj' Ha)); lia).
      assert (Hai : a <= i) by (apply (proj2 (Hmono a t i j Ha Halpha)); lia).
      destruct (Nat.eq_dec a i') as [Eq1|Ne1];
        [subst a; assert (Htj' : t = j') by (apply (q_img_unique gs es alpha i' t j' Hqal Hcrng Ha Hj' Hanna)); lia | ].
      destruct (Nat.eq_dec a i) as [Eq2|Ne2];
        [subst a; assert (Htj : t = j) by (apply (q_img_unique gs es alpha i t j Hqal Hcrng Ha Halpha Hanni)); lia
        | apply (no_q_between gs m i' i a Hnthi' Hnthi Hanna); lia]. }
    assert (HcSj' : qcount es (S j') = S m) by (rewrite (qcount_q_S es j' Hannj'); rewrite Hcj'; reflexivity).
    assert (Hgen : forall k, S j' <= k -> k <= j -> qcount es k = S m).
    { intro k; induction k as [|k IHk]; intros Hlo Hhi; [lia | ].
      destruct (Nat.eq_dec (S j') (S k)) as [He|Hne]; [injection He as He2; subst k; exact HcSj' | ].
      assert (Hnk : ~ Q (cfg_at es k)) by (apply Hnoann; lia).
      rewrite (qcount_nq_S es k Hnk). apply IHk; lia. }
    apply (Hgen j); lia.
Qed.

Lemma nth_q_det : forall ins es1 es2 ih1 ih2 n j1 j2,
  Forall is_input ins ->
  pr_inputs es1 ih1 -> list_prefix ih1 ins -> pr_inputs es2 ih2 -> list_prefix ih2 ins ->
  is_nth_q es1 n j1 -> is_nth_q es2 n j2 -> j1 = j2.
Proof.
  intros ins es1 es2 ih1 ih2 n j1 j2 Hins Hpr1 Hpf1 Hpr2 Hpf2 Hn1 Hn2.
  assert (Hkey : forall (a b:list config) iha ihb pa pb,
            pr_inputs a iha -> list_prefix iha ins -> pr_inputs b ihb -> list_prefix ihb ins ->
            is_nth_q a n pa -> is_nth_q b n pb -> pa < pb -> False).
  { intros a b iha ihb pa pb Hpra Hpfa Hprb Hpfb Hpaa Hpbb Hlt.
    destruct Hpaa as [Hpalt [Hannpa Hcpa]]. pose proof Hpbb as Hpbb2.
    destruct Hpbb2 as [Hpblt [Hannpb Hcpb]].
    assert (Hagree : forall k, k <= pa -> cfg_at a k = cfg_at b k)
      by (intros k Hk; apply (prerun_index_det ins a b iha ihb k Hins Hpra Hpfa Hprb Hpfb); lia).
    assert (Hannpa_b : Q (cfg_at b pa)) by (rewrite <- (Hagree pa (Nat.le_refl pa)); exact Hannpa).
    assert (Hcnt : qcount b pa = qcount a pa)
      by (apply qcount_ext; intros mm Hm; symmetry; apply Hagree; lia).
    assert (Hnthb_pa : is_nth_q b n pa)
      by (split; [lia | split; [exact Hannpa_b | rewrite Hcnt, Hcpa; reflexivity]]).
    assert (Hpaeq : pa = pb) by (apply (is_nth_q_unique b n pa pb Hnthb_pa Hpbb)). lia. }
  destruct (Nat.lt_trichotomy j1 j2) as [Hlt|[Heq|Hgt]];
    [ exfalso; apply (Hkey es1 es2 ih1 ih2 j1 j2 Hpr1 Hpf1 Hpr2 Hpf2 Hn1 Hn2 Hlt)
    | exact Heq
    | exfalso; apply (Hkey es2 es1 ih2 ih1 j2 j1 Hpr2 Hpf2 Hpr1 Hpf1 Hn2 Hn1 Hgt) ].
Qed.

End MarkRank.

(* l-ASSUME instantiation of the generic marker-rank layer. *)
Lemma Qredex_assume : forall l g g', redex_of g = redex_of g' ->
  redex_is_l_assume l g -> redex_is_l_assume l g'.
Proof. intros l g g' Heq H. unfold redex_is_l_assume in *. rewrite <- Heq. exact H. Qed.

Lemma Qnone_assume : forall l g, redex_of g = None -> ~ redex_is_l_assume l g.
Proof. intros l g H. unfold redex_is_l_assume. rewrite H. intro Hf; exact Hf. Qed.

Lemma Qstep_assume : forall l c0 ev g, step c0 ev g ->
  redex_is_l_assume l g -> ~ redex_is_l_assume l c0.
Proof.
  intros l c0 ev g Hstep Hg Hc0.
  apply (step_to_annot_not_annot c0 ev g l Hstep (redex_assume_annotation l g Hg)).
  apply (redex_assume_annotation l c0 Hc0).
Qed.

Lemma semi_l_aligned_q : forall l ds es alpha,
  semi_l_aligned_pair l ds es alpha ->
  q_aligned (redex_is_l_assume l) ds es alpha.
Proof.
  intros l ds es alpha [Hpd [Hpe [Halgn Hco]]].
  split; [exact Hpd | split; [exact Hpe | split; [exact Halgn | exact Hco]]].
Qed.

Definition assume_count (l : Lev) := qcount (redex_is_l_assume l) (redex_is_l_assume_dec l).
Definition is_nth_assume (l : Lev) := is_nth_q (redex_is_l_assume l) (redex_is_l_assume_dec l).

Lemma assume_align_rank : forall l gs es alpha n i j,
  semi_l_aligned_pair l gs es alpha -> covers_rng es alpha ->
  is_nth_assume l gs n i -> alpha i j -> is_nth_assume l es n j.
Proof.
  intros l gs es alpha n i j Hwlap Hcrng Hnth Halpha.
  apply (q_align_rank (redex_is_l_assume l) (redex_is_l_assume_dec l)
           (Qredex_assume l) (Qnone_assume l) (Qstep_assume l)
           gs es alpha n i j (semi_l_aligned_q l gs es alpha Hwlap) Hcrng Hnth Halpha).
Qed.

(* Determinacy (sibling of minor_annot_cfg_det, for an l-ASSUME under semi-proper
   alignments): the major assume at i, aligned by two semi-proper scenarios over
   same-rank, same-config majors to minors realizing inputs <= ins, lands on the
   same minor config. (Hypotheses strengthened exactly as minor_annot_cfg_det:
   covers_rng on each minor + assume-rank agreement of the two majors; both
   supplied at the call site where ds1 = ds2 = gs.) *)
Lemma minor_assume_cfg_det : forall l ins ds1 ds2 es1 es2 alpha1 alpha2 i j1 j2,
  semi_l_aligned_pair l ds1 es1 alpha1 ->
  semi_l_aligned_pair l ds2 es2 alpha2 ->
  covers_rng es1 alpha1 ->
  covers_rng es2 alpha2 ->
  (exists ih, pr_inputs es1 ih /\ list_prefix ih ins) ->
  (exists ih, pr_inputs es2 ih /\ list_prefix ih ins) ->
  Forall is_input ins ->
  cfg_at ds1 i = cfg_at ds2 i ->
  assume_count l ds1 i = assume_count l ds2 i ->
  redex_is_l_assume l (cfg_at ds1 i) ->
  alpha1 i j1 -> alpha2 i j2 ->
  cfg_at es1 j1 = cfg_at es2 j2.
Proof.
  intros l ins ds1 ds2 es1 es2 alpha1 alpha2 i j1 j2 Hwlap1 Hwlap2 Hcrng1 Hcrng2 Hih1 Hih2 Hins Hcfg Hrank Hass1 Ha1 Ha2.
  assert (Hi1 : i < length ds1)
    by (destruct Hwlap1 as [_ [_ [[Hb _] _]]]; apply (proj1 (Hb i j1 Ha1))).
  assert (Hi2 : i < length ds2)
    by (destruct Hwlap2 as [_ [_ [[Hb _] _]]]; apply (proj1 (Hb i j2 Ha2))).
  assert (Hass2 : redex_is_l_assume l (cfg_at ds2 i)) by (rewrite <- Hcfg; exact Hass1).
  assert (Hnth1 : is_nth_assume l ds1 (assume_count l ds1 i) i)
    by (split; [exact Hi1 | split; [exact Hass1 | reflexivity]]).
  assert (Hnth2 : is_nth_assume l ds2 (assume_count l ds1 i) i)
    by (split; [exact Hi2 | split; [exact Hass2 | symmetry; exact Hrank]]).
  assert (Hes1 : is_nth_assume l es1 (assume_count l ds1 i) j1)
    by (apply (assume_align_rank l ds1 es1 alpha1 (assume_count l ds1 i) i j1 Hwlap1 Hcrng1 Hnth1 Ha1)).
  assert (Hes2 : is_nth_assume l es2 (assume_count l ds1 i) j2)
    by (apply (assume_align_rank l ds2 es2 alpha2 (assume_count l ds1 i) i j2 Hwlap2 Hcrng2 Hnth2 Ha2)).
  destruct Hih1 as [ih1 [Hpr1 Hpf1]]. destruct Hih2 as [ih2 [Hpr2 Hpf2]].
  assert (Hjeq : j1 = j2)
    by (apply (nth_q_det (redex_is_l_assume l) (redex_is_l_assume_dec l)
                 ins es1 es2 ih1 ih2 (assume_count l ds1 i) j1 j2 Hins Hpr1 Hpf1 Hpr2 Hpf2 Hes1 Hes2)).
  subst j2. destruct Hes1 as [Hj1lt1 _]. destruct Hes2 as [Hj1lt2 _].
  apply (prerun_index_det ins es1 es2 ih1 ih2 j1 Hins Hpr1 Hpf1 Hpr2 Hpf2 Hj1lt1 Hj1lt2).
Qed.

(* Cross-run determinacy crux of the assumption-fiat case: the policy run's
   config aligned (by the semi-conformance) to the major l-assume at i equals the
   fiat run's config aligned to it. Both runs realize inputs <= ins; the major
   assume's coincidence + run determinacy pin the aligned minor config
   (minor_assume_cfg_det). *)
Lemma policy_fiat_assume_agree : forall l gs fs hsR alpha alphaR i j jR l' tk Phi ins ihf,
  Forall is_input ins ->
  l_aligned_pair l gs fs alpha -> covers_rng fs alpha ->
  conformance_below l ins gs fs alpha i j ->
  semi_conformance l gs hsR alphaR ->
  pr_inputs fs ihf -> list_prefix ihf ins -> pr_inputs hsR ins ->
  i < length gs -> alpha i j -> j = length fs - 1 -> alphaR i jR ->
  redex_of (cfg_at gs i) = Some (Cassume l' tk Phi) -> lleq l' l ->
  cfg_at hsR jR = cfg_at fs j.
Proof.
  intros l gs fs hsR alpha alphaR i j jR l' tk Phi ins ihf
         Hinp Hlap Hcrng Hcb Hwc Hpr_fs Hpf HprR HiLt Haij Hjeq HaijR Hredi Hle.
  symmetry.
  apply (minor_assume_cfg_det l ins gs gs fs hsR alpha alphaR i j jR).
  - apply l_aligned_pair_semi; exact Hlap.
  - destruct Hwc as [Hwlap _]; exact Hwlap.
  - exact Hcrng.
  - destruct Hwc as [_ [_ [Hwcrng _]]]; exact Hwcrng.
  - exists ihf; split; [exact Hpr_fs | exact Hpf].
  - exists ins; split; [exact HprR | apply list_prefix_refl].
  - exact Hinp.
  - reflexivity.
  - reflexivity.
  - unfold redex_is_l_assume; rewrite Hredi; simpl; exact Hle.
  - exact Haij.
  - exact HaijR.
Qed.

Lemma sec_assumF_case : forall l hs g ts t ins fs alpha,
  admits_trace hs ts -> admits_trace (hs ++ [g]) (ts ++ [t]) -> Vev l t ->
  pknow l ts ins -> release_policy l (hs ++ [g]) ins ->
  assumption_fiat l ins (hs ++ [g]) fs alpha ->
  know l (ts ++ [t]) ins.
Proof.
  intros l hs g ts t ins fs alpha Hts Htst HVO Hpkn Hrp Hassum. exfalso.
  destruct Hassum as [i Hfiat].
  destruct Hfiat as [Hlap [Hihf [Hcrngf [Hex Hinp]]]].
  destruct Hex as [j [l' [tk [Phi [HiLt [Hjeq [Haij [Hredi [Hle [Hnmod Hcbelow]]]]]]]]]].
  destruct Hrp as [hsR [alphaR [usR [Hwc [HatR HinsR]]]]].
  pose proof Hwc as Hwc'. destruct Hwc' as [Hwlap [Hwcovd [Hwcrng Hwmod]]].
  destruct (Hwcovd i HiLt) as [jR HaijR].
  assert (HprhsR : pr_inputs hsR ins)
    by (exists usR; split; [exact HatR | symmetry; exact HinsR]).
  destruct Hihf as [ihf [Hprfs Hpreih]].
  assert (Hmod_R : models (cfg_state (cfg_at (hs ++ [g]) i)) (cfg_state (cfg_at hsR jR)) Phi)
    by (apply (Hwmod i jR l' tk Phi HaijR Hredi Hle)).
  assert (Hcfg : cfg_at hsR jR = cfg_at fs j)
    by (apply (policy_fiat_assume_agree l (hs ++ [g]) fs hsR alpha alphaR i j jR l' tk Phi ins ihf
                 Hinp Hlap Hcrngf Hcbelow Hwc Hprfs Hpreih HprhsR HiLt Haij Hjeq HaijR Hredi Hle)).
  rewrite Hcfg in Hmod_R. apply Hnmod. exact Hmod_R.
Qed.

(* An l-annotation config is not an l-output config (assume/assert vs Cout). *)
Lemma annot_not_output : forall l g, redex_is_l_annotation l g -> ~ redex_is_l_output l g.
Proof.
  intros l g Hann Hout. unfold redex_is_l_output in Hout.
  destruct (redex_of g) as [c | ] eqn:Hr; [| exact Hout].
  destruct c; try exact Hout.
  unfold redex_is_l_annotation in Hann. rewrite Hr in Hann.
  destruct Hann as [Hc | Hc]; exact Hc.
Qed.

(* The (S n)-config prefix of a run admits the n-event prefix of its trace. *)
(* Divergence-fiat case (thm:safesecure). The earlier formulation manufactured an
   alignment_failure (paraphrasing a loose paper comment, "its progress to an
   output would result in alignment failure not divergence"). The PRECISE fact is
   simpler: in this case the hypotheses are jointly UNSATISFIABLE. Progress
   knowledge [pknow l ts ins] witnesses that the inputs ins drive a run to a
   visible event, whereas [divergence_fiat l ins (hs++[g]) fs alpha] exhibits an
   unbounded annotation-free continuation of the minor on the SAME inputs ins. By
   run determinacy these describe the one canonical run on ins, which cannot both
   reach a visible event (hence, by well-specification, an l-annotation) and stay
   annotation-free. So the divergence-output case is vacuous -- no alignment
   failure need be constructed.
   PROVED. The pknow witness W and the family-extended minor [fs ++ Hfun n] are
   both pre-runs on the same inputs ins, hence agree config-by-config
   (prerun_index_det), and vis_at depends only on the two local configs
   (vis_at_cfg_local). Let N = |us| be the position of the predicted visible event
   ev in W. If N >= |fs|-1 the canonical run is l-silent there (the divergence
   family forbids both l-annotations and l-outputs, and fs's last config -- an
   annotation or the initial receptive config -- is itself not an l-output), so
   vis_at W N = None, contradicting ev's visibility. If N < |fs|-1, ev lies inside
   fs's region, so |vis ts| < |vis(us++[ev])| = |vis(firstn (N+1) of fs's trace)|
   <= |vis(fs)| <= |vis(M)| <= |vis ts| (the conformance length bound conf_vis_le
   plus vis_firstn_le), a contradiction. *)
Lemma divF_excl_pknow : forall l ins hs g ts t fs alpha i k,
  Forall is_input ins ->
  admits_trace hs ts -> admits_trace (hs ++ [g]) (ts ++ [t]) -> Vev l t ->
  ~ (redex_is_l_output l (cfg_at (hs ++ [g]) i) /\ i = length ts) ->
  pknow l ts ins -> divergence_fiat_at i k l ins (hs ++ [g]) fs alpha ->
  False.
Proof.
  intros l ins hs g ts t fs alpha i k Hinp Hts Htst HVO Hnotbad Hpkn Hdf0.
  pose proof (divergence_fiat_at_cover i k l ins (hs ++ [g]) fs alpha Hdf0) as [Hcovdom Hcovrng].
  destruct Hdf0 as [_ [Hik [Hklt [Hlap_gs [Hannk Hex_j]]]]].
  destruct Hex_j as [jj [Hjeq [Haij [Hibase [Hnoann [Hconf Hex_ih]]]]]].
  destruct Hex_ih as [ih0 [Hpr0 [Hpf0 [Hfun Hfunspec]]]].
  assert (Hprefs : pre_run fs) by (destruct Hlap_gs as [_ [H _]]; exact H).
  assert (Hproper_gs : proper l (hs ++ [g]) fs alpha) by (destruct Hlap_gs as [_ [_ H]]; exact H).
  pose proof Hprefs as Hprefs_c. destruct Hprefs_c as [tf Hatf].
  assert (Hfs1 : 1 <= length fs)
    by (pose proof (pre_run_nonempty fs Hprefs) as Hne; destruct fs; [contradiction | simpl; lia]).
  pose proof (admits_trace_length fs tf Hatf) as Hlentf.
  pose proof (admits_trace_length hs ts Hts) as Hlents.
  assert (Hlapp : length (hs ++ [g]) = length hs + 1) by (rewrite length_app; simpl; lia).
  assert (Hilt_gs : i < length (hs ++ [g])) by lia.
  assert (Hile : i <= length ts) by lia.
  pose proof (admits_trace_firstn_full (hs ++ [g]) (ts ++ [t]) i Htst Hilt_gs) as HatM.
  replace (S i) with (i + 1) in HatM by lia.
  assert (Hlap_M : l_aligned_pair l (firstn (i + 1) (hs ++ [g])) fs alpha)
    by (destruct Hconf as [H _]; exact H).
  assert (HvisM_le : length (vis l (firstn i (ts ++ [t]))) <= length (vis l ts))
    by (rewrite (firstn_app1 event ts t i Hile); apply vis_firstn_le).
  (* At the boundary index length fs-1 the minor is EITHER not a low output (origin /
     annotation endpoint) OR a low output with i < length ts -- whose emission is
     realized at the major's aligned output index i (inside ts), giving the strict
     bound |vis tf| + 1 <= |vis ts|.  (The excluded case i = length ts is the one where
     the matched output IS t; that is handled by sec_divF_case proving [know] directly.) *)
  assert (Hboundary : ~ redex_is_l_output l (cfg_at fs (length fs - 1)) \/
                      length (vis l tf) + 1 <= length (vis l ts)).
  { destruct Hibase as [[Hi0 Hjj0] | [Hanngi | [Houtgsi Houtfs]]].
    - left. assert (Hlf0 : length fs - 1 = 0) by (rewrite Hjeq in Hjj0; lia).
      rewrite Hlf0, (prerun_head fs Hprefs). unfold redex_is_l_output. simpl. tauto.
    - left. assert (Hannfsjj : redex_is_l_annotation l (cfg_at fs jj)).
      { destruct Hproper_gs as [_ Hcoin].
        assert (Hco : redex_of (cfg_at (hs ++ [g]) i) = redex_of (cfg_at fs jj))
          by (apply (Hcoin i jj Haij); left; exact Hanngi).
        unfold redex_is_l_annotation in *. rewrite <- Hco. exact Hanngi. }
      rewrite Hjeq in Hannfsjj. apply annot_not_output. exact Hannfsjj.
    - right.
      assert (Hilts : i < length ts).
      { assert (i <> length ts) by (intro He; apply Hnotbad; split; [exact Houtgsi | exact He]).
        lia. }
      rewrite Hjeq in Houtfs.
      pose proof (conf_vis_le_out l (firstn (i + 1) (hs ++ [g])) fs alpha
                    (firstn i (ts ++ [t])) tf Hlap_M Hcovdom Hcovrng HatM Hatf Houtfs) as Hb.
      assert (HivisM : vis_at l (hs ++ [g]) i <> None)
        by (apply (l_output_vis_at_some l (hs ++ [g]) i); exact Houtgsi).
      assert (Hinc : length (vis l (firstn (S i) (ts ++ [t]))) =
                     length (vis l (firstn i (ts ++ [t]))) + 1)
        by (apply (vis_firstn_succ_visible l (hs ++ [g]) (ts ++ [t]) i Htst);
            [rewrite length_app; simpl; lia | exact HivisM]).
      assert (Hfi1 : length (vis l (firstn (S i) (ts ++ [t]))) <= length (vis l ts))
        by (rewrite (firstn_app1 event ts t (S i) ltac:(lia)); apply vis_firstn_le).
      lia. }
  assert (Hvisfs_le : length (vis l tf) <= length (vis l ts)).
  { destruct Hibase as [[Hi0 Hjj0] | [Hanngi | Houtgi]].
    - assert (Htf0 : tf = []).
      { assert (length fs = 1) by (rewrite Hjeq in Hjj0; lia).
        destruct tf; [reflexivity | simpl in Hlentf; lia]. }
      rewrite Htf0. simpl. lia.
    - assert (Hannfs : redex_is_l_annotation l (cfg_at fs (length fs - 1))).
      { destruct Hproper_gs as [_ Hcoin].
        assert (Hco : redex_of (cfg_at (hs ++ [g]) i) = redex_of (cfg_at fs jj))
          by (apply (Hcoin i jj Haij); left; exact Hanngi).
        rewrite <- Hjeq. unfold redex_is_l_annotation in *. rewrite <- Hco. exact Hanngi. }
      pose proof (conf_vis_le l (firstn (i + 1) (hs ++ [g])) fs alpha
                    (firstn i (ts ++ [t])) tf Hlap_M Hcovdom Hcovrng HatM Hatf Hannfs) as Hb.
      lia.
    - (* OUTPUT ENDPOINT: the minor fs ends at a low output; conf_vis_le_out bounds
         |vis tf| by |vis (firstn i (ts++[t]))| <= |vis ts|. *)
      destruct Houtgi as [_ Houtfs]. rewrite Hjeq in Houtfs.
      pose proof (conf_vis_le_out l (firstn (i + 1) (hs ++ [g])) fs alpha
                    (firstn i (ts ++ [t])) tf Hlap_M Hcovdom Hcovrng HatM Hatf Houtfs) as Hb.
      lia. }
  destruct Hpkn as [W [us [ev [vs [Hev [HatW [Hpre Hinseq]]]]]]].
  remember (us ++ [ev] ++ vs) as tW eqn:HtWeq.
  remember (length us) as N eqn:HNeq.
  assert (HprW : pr_inputs W ins) by (exists tW; split; [exact HatW | symmetry; exact Hinseq]).
  pose proof (admits_trace_length W tW HatW) as HlenW.
  assert (HlentW : length tW = N + 1 + length vs)
    by (rewrite HtWeq, HNeq; rewrite !length_app; simpl; lia).
  assert (Hnth : nth N tW Etick = ev)
    by (rewrite HtWeq, HNeq; rewrite app_nth2 by lia; rewrite Nat.sub_diag; reflexivity).
  assert (HNltW : N < length tW) by lia.
  assert (HvisW : vis_at l W N = Some ev).
  { rewrite <- Hnth. apply vis_at_complete; [exact HatW | exact HNltW |]. rewrite Hnth. exact Hev. }
  destruct (Nat.lt_ge_cases N (length fs - 1)) as [HNlt | HNge].
  - (* CASE B: counting *)
    assert (Hagree : forall q, q <= N -> vis_at l W q = vis_at l fs q).
    { intros q Hq. apply vis_at_cfg_local.
      - apply (prerun_index_det ins W fs ins ih0 q Hinp HprW (list_prefix_refl _ ins) Hpr0 Hpf0); lia.
      - apply (prerun_index_det ins W fs ins ih0 (S q) Hinp HprW (list_prefix_refl _ ins) Hpr0 Hpf0); lia. }
    assert (HNtf : N + 1 <= length tf) by lia.
    assert (HNtW : N + 1 <= length tW) by lia.
    pose proof (vis_length_positions_firstn l W tW (N + 1) HatW HNtW) as HeqW.
    pose proof (vis_length_positions_firstn l fs tf (N + 1) Hatf HNtf) as Heqf.
    assert (Hfilter_eq :
      length (filter (fun p => match vis_at l W p with Some _ => true | None => false end) (seq 0 (N + 1)))
      = length (filter (fun p => match vis_at l fs p with Some _ => true | None => false end) (seq 0 (N + 1))))
      by (apply filter_seq_ext_length; intros q Hq; rewrite (Hagree q ltac:(lia)); reflexivity).
    assert (HfW : firstn (N + 1) tW = us ++ [ev]).
    { rewrite HtWeq, HNeq. rewrite firstn_app, firstn_all2 by lia.
      replace (length us + 1 - length us) with 1 by lia. reflexivity. }
    rewrite HfW in HeqW.
    assert (Hvisuse : length (vis l (us ++ [ev])) = length (vis l us) + 1).
    { rewrite vis_app, length_app. f_equal. unfold vis. simpl.
      rewrite (proj2 (visible_atb_spec l ev) Hev). reflexivity. }
    assert (Htsus : length (vis l ts) <= length (vis l us))
      by (apply list_prefix_length; exact Hpre).
    pose proof (vis_firstn_le l (N + 1) tf) as Hfftf.
    lia.
  - (* CASE A: N >= length fs - 1 *)
    destruct (Nat.eq_dec N (length fs - 1)) as [HNe | HNgt].
    + (* N = length fs - 1: the boundary index *)
      destruct Hboundary as [Hnoout | Hstrict].
      * (* not a low output there: l-silent, contradicting HvisW *)
        pose proof (Hfunspec (N + 2)) as [HlenH [HfamH [ih' [Hpr' Hpf']]]].
        assert (HlenF : length (fs ++ Hfun (N + 2)) = length fs + (N + 2))
          by (rewrite length_app, HlenH; reflexivity).
        assert (HsilN : vis_at l (fs ++ Hfun (N + 2)) N = None).
        { apply vis_at_silent.
          - rewrite (cfg_at_app_lt fs (Hfun (N + 2)) N ltac:(lia)). rewrite HNe. exact Hnoout.
          - rewrite (cfg_at_app_ge fs (Hfun (N + 2)) (S N) ltac:(lia)).
            apply (proj1 (HfamH (S N - length fs) ltac:(lia))). }
        assert (HcfgN : cfg_at W N = cfg_at (fs ++ Hfun (N + 2)) N)
          by (apply (prerun_index_det ins W (fs ++ Hfun (N + 2)) ins ih' N Hinp HprW
                       (list_prefix_refl _ ins) Hpr' Hpf'); lia).
        assert (HcfgSN : cfg_at W (S N) = cfg_at (fs ++ Hfun (N + 2)) (S N))
          by (apply (prerun_index_det ins W (fs ++ Hfun (N + 2)) ins ih' (S N) Hinp HprW
                       (list_prefix_refl _ ins) Hpr' Hpf'); lia).
        pose proof (vis_at_cfg_local l W (fs ++ Hfun (N + 2)) N HcfgN HcfgSN) as Hloc.
        rewrite Hloc, HsilN in HvisW. discriminate HvisW.
      * (* low output there: |vis us| = |vis tf|, and |vis tf| + 1 <= |vis ts| <= |vis us|
           is a contradiction *)
        assert (Hagree : forall q, q < N -> vis_at l W q = vis_at l fs q).
        { intros q Hq. apply vis_at_cfg_local.
          - apply (prerun_index_det ins W fs ins ih0 q Hinp HprW (list_prefix_refl _ ins) Hpr0 Hpf0); lia.
          - apply (prerun_index_det ins W fs ins ih0 (S q) Hinp HprW (list_prefix_refl _ ins) Hpr0 Hpf0); lia. }
        assert (Hus : firstn N tW = us).
        { rewrite HtWeq, HNeq. rewrite firstn_app, firstn_all2 by lia.
          rewrite Nat.sub_diag. simpl. rewrite app_nil_r. reflexivity. }
        assert (Htf_full : firstn N tf = tf) by (apply firstn_all2; lia).
        assert (Hus_tf : length (vis l us) = length (vis l tf)).
        { rewrite <- Hus, <- Htf_full.
          rewrite (vis_length_positions_firstn l W tW N HatW ltac:(lia)).
          rewrite (vis_length_positions_firstn l fs tf N Hatf ltac:(lia)).
          apply filter_seq_ext_length. intros q Hq. rewrite (Hagree q Hq). reflexivity. }
        assert (Htsus : length (vis l ts) <= length (vis l us))
          by (apply list_prefix_length; exact Hpre).
        lia.
    + (* N >= length fs: l-silent (family is output-free + annotation-free) *)
      pose proof (Hfunspec (N + 2)) as [HlenH [HfamH [ih' [Hpr' Hpf']]]].
      assert (HlenF : length (fs ++ Hfun (N + 2)) = length fs + (N + 2))
        by (rewrite length_app, HlenH; reflexivity).
      assert (HsilN : vis_at l (fs ++ Hfun (N + 2)) N = None).
      { apply vis_at_silent.
        - rewrite (cfg_at_app_ge fs (Hfun (N + 2)) N ltac:(lia)).
          apply (proj2 (HfamH (N - length fs) ltac:(lia))).
        - rewrite (cfg_at_app_ge fs (Hfun (N + 2)) (S N) ltac:(lia)).
          apply (proj1 (HfamH (S N - length fs) ltac:(lia))). }
      assert (HcfgN : cfg_at W N = cfg_at (fs ++ Hfun (N + 2)) N)
        by (apply (prerun_index_det ins W (fs ++ Hfun (N + 2)) ins ih' N Hinp HprW
                     (list_prefix_refl _ ins) Hpr' Hpf'); lia).
      assert (HcfgSN : cfg_at W (S N) = cfg_at (fs ++ Hfun (N + 2)) (S N))
        by (apply (prerun_index_det ins W (fs ++ Hfun (N + 2)) ins ih' (S N) Hinp HprW
                     (list_prefix_refl _ ins) Hpr' Hpf'); lia).
      pose proof (vis_at_cfg_local l W (fs ++ Hfun (N + 2)) N HcfgN HcfgSN) as Hloc.
      rewrite Hloc, HsilN in HvisW. discriminate HvisW.
Qed.

(* Two prefixes of the same list with equal length are equal. *)
Lemma list_prefix_eq_length : forall (A : Type) (a b c : list A),
  list_prefix a c -> list_prefix b c -> length a = length b -> a = b.
Proof.
  intros A a b c [ra Ha] [rb Hb] Hlen.
  assert (Heq : a ++ ra = b ++ rb) by (rewrite <- Ha, <- Hb; reflexivity).
  clear Ha Hb c. revert b Hlen Heq.
  induction a as [| x a' IH]; intros [| y b'] Hlen Heq; simpl in *; try discriminate Hlen.
  - reflexivity.
  - injection Heq as Hxy Hrest. injection Hlen as Hlen'.
    f_equal; [exact Hxy | apply IH; assumption].
Qed.

(* TODO: Dave thinks the first case below can be simplified.  The situation where position i (last of hs)
   is an output would require k = i+1 but the redex after an output is skip so there can't be 
   an annotation at i+1, so this scenario does not arise with divergence fiat.
   So I'm going to refrain to mention the corner case using progress knowledge in the proof sketch.
*)
Lemma sec_divF_case : forall l hs g ts t ins fs alpha,
  admits_trace hs ts -> admits_trace (hs ++ [g]) (ts ++ [t]) -> Vev l t ->
  pknow l ts ins -> divergence_fiat l ins (hs ++ [g]) fs alpha ->
  know l (ts ++ [t]) ins.
Proof.
  intros l hs g ts t ins fs alpha Hts Htst HVO Hpkn Hdiv.
  assert (Hinp : Forall is_input ins)
    by (destruct Hpkn as [hs0 [us [ev [vs [_ [_ [_ Heq]]]]]]]; subst ins; apply Forall_is_input_inputs).
  destruct Hdiv as [i [k Hdf0]].
  destruct (classic (redex_is_l_output l (cfg_at (hs ++ [g]) i) /\ i = length ts)) as [Hbad | Hgood].
  - (* output endpoint with i = length ts: the matched output IS t; the divergence
       minor reaches t, so knowledge is established directly. *)
    destruct Hbad as [Houtgsi Hieq].
    pose proof (divergence_fiat_at_cover i k l ins (hs ++ [g]) fs alpha Hdf0) as [Hcovdom Hcovrng].
    destruct Hdf0 as [_ [Hik [Hklt [Hlap_gs [Hannk Hex_j]]]]].
    destruct Hex_j as [jj [Hjeq [Haij [Hibase [Hnoann [Hconf Hex_ih]]]]]].
    destruct Hex_ih as [ih0 [Hpr0 [Hpf0 [Hfun Hfunspec]]]].
    destruct Hpr0 as [tf [Hatf Hihtf]].
    assert (Houtfs : redex_is_l_output l (cfg_at fs jj)).
    { destruct Hibase as [[Hi0 _] | [Hann | [_ Ho]]].
      - exfalso. rewrite Hi0 in Houtgsi.
        rewrite (prerun_head (hs ++ [g]) (ex_intro _ (ts ++ [t]) Htst)) in Houtgsi.
        unfold redex_is_l_output in Houtgsi. simpl in Houtgsi. exact Houtgsi.
      - exfalso. exact (annot_not_output l (cfg_at (hs ++ [g]) i) Hann Houtgsi).
      - exact Ho. }
    pose proof (admits_trace_length fs tf Hatf) as Hlentf.
    pose proof (admits_trace_length hs ts Hts) as Hlents.
    assert (Hfs1 : 1 <= length fs)
      by (pose proof (pre_run_nonempty fs (ex_intro _ tf Hatf)) as Hne;
          destruct fs; [contradiction | simpl; lia]).
    assert (Hlapp : length (hs ++ [g]) = length hs + 1) by (rewrite length_app; simpl; lia).
    assert (Hilt_gs : i < length (hs ++ [g])) by lia.
    assert (Hile : i <= length ts) by lia.
    pose proof (admits_trace_firstn_full (hs ++ [g]) (ts ++ [t]) i Htst Hilt_gs) as HatM0.
    replace (S i) with (i + 1) in HatM0 by lia.
    assert (HfirstnTs : firstn i (ts ++ [t]) = ts)
      by (rewrite Hieq, (firstn_app1 event ts t (length ts) ltac:(lia)); apply firstn_all).
    rewrite HfirstnTs in HatM0.
    set (ds := firstn (i + 1) (hs ++ [g])) in *.
    assert (Hdslen : length ds = i + 1)
      by (unfold ds; rewrite firstn_length_le; [reflexivity | rewrite length_app; simpl; lia]).
    assert (Hcfgdsi : cfg_at ds i = cfg_at (hs ++ [g]) i)
      by (unfold ds; apply cfg_at_firstn; lia).
    assert (Houtds : redex_is_l_output l (cfg_at ds (length ds - 1)))
      by (rewrite Hdslen; replace (i + 1 - 1) with i by lia; rewrite Hcfgdsi; exact Houtgsi).
    assert (Houtfs' : redex_is_l_output l (cfg_at fs (length fs - 1)))
      by (rewrite <- Hjeq; exact Houtfs).
    assert (Hlapds : l_aligned_pair l ds fs alpha) by (destruct Hconf as [H _]; exact H).
    (* N1: |vis tf| = |vis ts| *)
    pose proof (conf_vis_le_out l ds fs alpha ts tf Hlapds Hcovdom Hcovrng HatM0 Hatf Houtfs') as Hle1.
    pose proof (conf_vis_ge_out l ds fs alpha ts tf Hlapds Hcovdom Hcovrng HatM0 Hatf Houtds) as Hge1.
    assert (Hviseq : length (vis l tf) = length (vis l ts)) by lia.
    (* N2: the minor's output endpoint emits t *)
    assert (Halast : alpha (length ds - 1) (length fs - 1))
      by (rewrite Hdslen; replace (i + 1 - 1) with i by lia; rewrite <- Hjeq; exact Haij).
    pose proof (aligned_last_output_event l ins ds fs alpha Hconf Hcovdom Hcovrng
                  Houtds Houtfs' Halast) as Hva0.
    assert (Hvist : Vev l t) by exact HVO.
    assert (Hnthi : nth i (ts ++ [t]) Etick = t) by (rewrite Hieq; apply nth_middle).
    assert (HvisgsI : vis_at l (hs ++ [g]) i = Some t).
    { rewrite (vis_at_complete l (hs ++ [g]) (ts ++ [t]) i Htst
                 ltac:(rewrite length_app; simpl; lia)
                 ltac:(rewrite Hnthi; exact Hvist)).
      rewrite Hnthi. reflexivity. }
    assert (Hvatfs : vis_at l fs (length fs - 1) = Some t).
    { rewrite <- Hva0, Hdslen. replace (i + 1 - 1) with i by lia.
      assert (Hroi : redex_of (cfg_at ds i) = redex_of (cfg_at (hs ++ [g]) i))
        by (rewrite Hcfgdsi; reflexivity).
      unfold redex_is_l_output in Houtgsi.
      destruct (redex_of (cfg_at (hs ++ [g]) i)) as [c |] eqn:Hro; [| contradiction].
      destruct c as [ | | lo eo | | | | | ]; try contradiction.
      rewrite (vis_at_out_some l ds i lo eo Hroi Houtgsi).
      rewrite Hcfgdsi.
      rewrite (vis_at_out_some l (hs ++ [g]) i lo eo Hro Houtgsi) in HvisgsI.
      exact HvisgsI. }
    (* the pknow witness W reaches a visible event beyond vis ts *)
    destruct Hpkn as [W [us [ev [vs [Hev [HatW [Hpre Hinseq]]]]]]].
    remember (us ++ [ev] ++ vs) as tW eqn:HtWeq.
    assert (HprW : pr_inputs W ins) by (exists tW; split; [exact HatW | symmetry; exact Hinseq]).
    pose proof (admits_trace_length W tW HatW) as HlenW.
    assert (HlentW : length tW = length us + 1 + length vs)
      by (rewrite HtWeq; rewrite !length_app; simpl; lia).
    assert (HfirstnUs : firstn (length us) tW = us)
      by (rewrite HtWeq, firstn_app, firstn_all, Nat.sub_diag; simpl; apply app_nil_r).
    assert (HnthN : nth (length us) tW Etick = ev)
      by (rewrite HtWeq, app_nth2 by lia; rewrite Nat.sub_diag; reflexivity).
    assert (HvisW : vis_at l W (length us) = Some ev)
      by (rewrite <- HnthN; apply vis_at_complete;
          [exact HatW | lia | rewrite HnthN; exact Hev]).
    assert (Hprog : length (vis l ts) < length (vis l tW)).
    { pose proof (vis_firstn_succ_visible l W tW (length us) HatW ltac:(lia)
                    ltac:(rewrite HvisW; discriminate)) as Hsucc.
      rewrite HfirstnUs in Hsucc.
      pose proof (list_prefix_length _ _ _ Hpre) as Htsus.
      pose proof (vis_firstn_le l (S (length us)) tW) as Hfle. lia. }
    (* length fs < length W *)
    assert (HpftfIns : list_prefix (inputs tf) ins) by (rewrite Hihtf; exact Hpf0).
    assert (HpftW : list_prefix (inputs tW) ins) by (rewrite <- Hinseq; apply list_prefix_refl).
    assert (HlenfsW : length fs < length W).
    { destruct (le_lt_dec (length W) (length fs)) as [Hle | Hgt]; [exfalso | exact Hgt].
      pose proof (prerun_trace_prefix ins W tW fs tf Hinp HatW HpftW Hatf HpftfIns Hle) as Hpwf.
      assert (Hvle : length (vis l tW) <= length (vis l tf)).
      { destruct Hpwf as [z Hz]. rewrite Hz, vis_app, length_app. lia. }
      lia. }
    (* the minor reaches t: tf ++ [t] is a prefix of tW *)
    pose proof (prerun_trace_prefix ins fs tf W tW Hinp Hatf HpftfIns HatW HpftW
                  ltac:(lia)) as Hpft.
    assert (Hcfgeq : cfg_at W (length fs - 1) = cfg_at fs (length fs - 1))
      by (apply (prerun_index_det ins W fs ins ih0 (length fs - 1) Hinp HprW
                   (list_prefix_refl _ ins) (ex_intro _ tf (conj Hatf Hihtf)) Hpf0); lia).
    assert (HnthT : nth (length tf) tW Etick = t).
    { unfold redex_is_l_output in Houtfs'.
      destruct (redex_of (cfg_at fs (length fs - 1))) as [c |] eqn:Hrof; [| contradiction].
      destruct c as [ | | lom eom | | | | | ]; try contradiction.
      assert (HroW : redex_of (cfg_at W (length fs - 1)) = Some (Cout lom eom))
        by (rewrite Hcfgeq; exact Hrof).
      assert (HvatW : vis_at l W (length fs - 1) = Some t).
      { rewrite (vis_at_out_some l W (length fs - 1) lom eom HroW Houtfs'). rewrite Hcfgeq.
        rewrite (vis_at_out_some l fs (length fs - 1) lom eom Hrof Houtfs') in Hvatfs.
        exact Hvatfs. }
      pose proof (vis_at_sound l W tW (length fs - 1) t HatW ltac:(lia) HvatW) as [Hnth _].
      replace (length tf) with (length fs - 1) by lia. exact Hnth. }
    assert (HpftT : list_prefix (tf ++ [t]) tW).
    { destruct Hpft as [suf Hsuf].
      destruct suf as [| s0 stl].
      - exfalso. rewrite app_nil_r in Hsuf. rewrite Hsuf in HnthT.
        assert (HoE : nth (length tf) tf Etick = Etick) by (apply nth_overflow; lia).
        rewrite HoE in HnthT.
        rewrite <- HnthT in Hvist.
        destruct Hvist as [[? [? [Hc _]]] | [? [? [Hc _]]]]; discriminate Hc.
      - assert (Hs0 : s0 = t).
        { rewrite Hsuf in HnthT. rewrite app_nth2 in HnthT by lia.
          rewrite Nat.sub_diag in HnthT. simpl in HnthT. exact HnthT. }
        subst s0. exists stl. rewrite Hsuf, <- app_assoc. reflexivity. }
    (* assemble the knowledge witness *)
    assert (HvistfW : list_prefix (vis l tf) (vis l tW)).
    { apply (list_prefix_app_weaken _ (vis l tf) (vis l [t])).
      destruct HpftT as [z Hz]. exists (vis l z).
      rewrite Hz, vis_app, vis_app. reflexivity. }
    assert (HvistsW : list_prefix (vis l ts) (vis l tW)).
    { apply (list_prefix_trans _ (vis l ts) (vis l us) (vis l tW)); [exact Hpre |].
      exists (vis l (skipn (length us) tW)). rewrite <- vis_app.
      rewrite <- HfirstnUs at 1. rewrite firstn_skipn. reflexivity. }
    assert (Hvists_tf : vis l ts = vis l tf)
      by (apply (list_prefix_eq_length _ (vis l ts) (vis l tf) (vis l tW)
                   HvistsW HvistfW); symmetry; exact Hviseq).
    exists W, tW. split; [exact HatW |]. split; [| exact Hinseq].
    rewrite vis_app, (vis_cons_visible l t [] Hvist), vis_nil, Hvists_tf.
    destruct HpftT as [z Hz]. exists (vis l z).
    rewrite Hz, vis_app, vis_app, (vis_cons_visible l t [] Hvist), vis_nil. reflexivity.
  - exfalso.
    exact (divF_excl_pknow l ins hs g ts t fs alpha i k Hinp Hts Htst HVO Hgood Hpkn Hdf0).
Qed.

Theorem safe_implies_secure l gs:
  safe_for_level l gs -> secure_for_level l gs.
Proof.
  intros Hsafe hs g Hne Hpref ts t Hts Htst ins Hpkn Hrp.
  destruct (classic (Vev l t)) as [HVO | HnVev].
  - (* visible event: dispatch on the safety classification of hs ++ [g] *)
    assert (Hpre_hsg : pre_run (hs ++ [g])) by (exists (ts ++ [t]); exact Htst).
    assert (Hinpins : Forall is_input ins).
    { destruct Hpkn as [hsx [us [ev [vs [_ [_ [_ Heq]]]]]]]. subst ins. apply Forall_is_input_inputs. }
    assert (Hsafe_hsg : safe_for l ins (hs ++ [g]))
      by (apply (safe_for_level_prefix l gs (hs ++ [g]) Hpref Hpre_hsg Hsafe ins Hinpins)).
    destruct Hsafe_hsg as [fs [alpha [Hconf | [Hassum | Hdiv]]]].
    + exact (sec_conf_case l hs g ts t ins fs alpha Hts Htst HVO Hpkn Hconf).
    + exact (sec_assumF_case l hs g ts t ins fs alpha Hts Htst HVO Hpkn Hrp Hassum).
    + exact (sec_divF_case l hs g ts t ins fs alpha Hts Htst HVO Hpkn Hdiv).
  - (* invisible event: knowledge is unchanged, so progress knowledge suffices *)
    apply (proj2 (knowlSame_a l ts t HnVev ins)).
    apply (knowPknow_a l ts ins Hpkn).
Qed.



End Entire_development_for_now.
