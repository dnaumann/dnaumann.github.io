from lark import (
    Lark,
    Transformer,
    lexer,
    UnexpectedToken,
    UnexpectedCharacters,
    ParseError,
    tree as ast,
)
from random import randint
from mido import Message, MidiFile, MidiTrack, open_output, MetaMessage, bpm2tempo
import sf2_loader as sf
import json

# limit for the number of times random_repeat can repeat
RANDOM_REPEAT_LIM = 5

# define grammar
grammar = r"""
    ?start: expr
    ?expr: term
        | term "||" expr -> parallel
    ?term: factor
        | factor "+" term -> random
    ?factor: "(" expr ")" 
        | atom
        | factor ";" factor -> seq
        | "[" NUMBER "]*" expr -> repeat
        | "*" expr -> rand_repeat
    ?atom: NAME "[" NUMBER "]"
        | NAME
    %import common.CNAME -> NAME
    %import common.NUMBER
    %import common.WS_INLINE
    %ignore WS_INLINE
"""

# Create the parser
parser = Lark(grammar, parser="lalr", transformer=Transformer())


# NEW INTERPRETER
def interpreter(tree, list_type, random_number):
    notes = []
    # base case: return a list of a note on  event when you encounter an atom
    if tree.data == "atom":
        # child 0 is the instrument, child 1 is the midi number
        if list_type == "note":
            notes.append([int(tree.children[1].value)])
        elif list_type == "instrument":
            notes.append([tree.children[0].value])
        return notes
    elif isinstance(tree, ast.Tree):
        if tree.data == "seq":
            # call interpreter on both children and return the concatenation of the two lists
            left_tree = interpreter(tree.children[0], list_type, random_number)
            right_tree = interpreter(tree.children[1], list_type, random_number)
            return left_tree + right_tree
        if tree.data == "repeat":
            # call interpreter on the right child only, since the left child is always the number of
            # repetitions
            right_tree = interpreter(tree.children[1], list_type, random_number)
            # use list multiplication to duplicate the list n amount of times
            n = tree.children[0].value
            concated_lists = right_tree * int(n)
            return concated_lists
        if tree.data == "rand_repeat":
            # generate a random number between 1 and random_repeat_limit to repeat the expression
            random_num = randint(1, RANDOM_REPEAT_LIM)
            # same process as normal repeat
            right_tree = interpreter(tree.children[0], list_type, random_number)
            concated_lists = right_tree * random_num
            return concated_lists
        if tree.data == "random":
            # generate random number between 1 and 20, if greater than 10 return left child,
            # else return right child
            if random_number > 10:
                return interpreter(tree.children[0], list_type, random_number)
            else:
                return interpreter(tree.children[1], list_type, random_number)
        if tree.data == "parallel":
            left_tree = interpreter(tree.children[0], list_type, random_number)
            right_tree = interpreter(tree.children[1], list_type, random_number)
            return merge_lists(left_tree, right_tree)


# helper function for replace_names, checks if token type is NAME and then if it exists in dictionary, parse it
def token_replace(token):
    full_expr = None
    if token.type == "NAME":
        with open("userSettings.json", "r") as json_file:
            userSettings = json.load(json_file)
        for i in range(len(userSettings["data"])):
            if userSettings["data"][i][2] == token.value:
                full_expr = userSettings["data"][i][0]
        if full_expr:
            parsed_expr = parser.parse(full_expr)
            return parsed_expr
    return token


# traverses the parsed tree and replaces shortened names with appropriate expressions
def replace_names(node):
    if isinstance(node, ast.Tree):
        for i, child in enumerate(node.children):
            if isinstance(child, lexer.Token):
                node.children[i] = token_replace(child)
            else:
                replace_names(child)
    elif isinstance(node, lexer.Token):
        node = token_replace(node)
    return node


# function to merge the noteOns in the parallel case of the interpreter
def merge_lists(list1, list2):
    merged = []
    min_length = min(len(list1), len(list2))

    for i in range(min_length):
        merged.extend([list1[i] + list2[i]])

    if len(list1) > len(list2):
        merged.extend([list1[j] for j in range(min_length, len(list1))])
    else:
        merged.extend([list2[j] for j in range(min_length, len(list2))])

    return merged


# parses expression and creates a tree, then generates list of noteon/noteoff events
# through inorder traversal
def parse_expression(expr):
    try:
        tree = parser.parse(expr)
    except UnexpectedToken as e:
        error_instance = UnexpectedToken(e.token, e.expected, e.considered_rules)
        raise ParseError(
            "Error: '{}' is not an expression.".format(error_instance.token)
        ) from None
    except UnexpectedCharacters as e:
        raise ParseError(
            "Error: '{}' is not a valid operator.".format(e.char)
        ) from None
    new_tree = replace_names(tree)
    # generate random number for interp
    num = randint(1, 20)
    try:
        notes = interpreter(new_tree, "note", num)
        instruments = interpreter(new_tree, "instrument", num)
    except Exception as e:
        raise Exception("Error: Invalid Note") from None
    return notes, instruments


# converts list of lists of note_on events into sequential midi events,
# plays resulting file using mido
def midi_convert(notes, instruments, bpm):
    channel_mappings = "channel_mappings.json"
    with open(channel_mappings, "r") as json_file:
        instrument_mapping = json.load(json_file)
    mid = MidiFile()
    track = MidiTrack()
    mid.tracks.append(track)
    track.append(MetaMessage("set_tempo", tempo=bpm2tempo(bpm)))
    for i in range(len(notes)):
        for j in range(len(notes[i])):
            instrument = instruments[i][j]
            channel = int(instrument_mapping[instrument])
            track.append(
                Message(
                    "note_on", channel=channel, note=notes[i][j], velocity=127, time=0
                )
            )
        for j in range(len(notes[i])):
            instrument = instruments[i][j]
            channel = int(instrument_mapping[instrument])
            track.append(
                Message(
                    "note_off",
                    channel=channel,
                    note=notes[i][j],
                    velocity=127,
                    time=(480 if j == 0 else 0),
                )
            )

    mid.save("new_song.mid")


def play_notes(expression, tempo):
    notes = parse_expression(expression)
    if notes is not None:
        try:
            midi_convert(notes[0], notes[1], tempo)
        except Exception as e:
            raise Exception("Invalid instrument {}".format(e))
    else:
        raise Exception("Error: could not parse expression.")


# Testing stuff:
# expression1 = "[2]*(piano[67]+(guitar[73];guitar[80]))||(piano[85];piano[95])"
# expression2 = "([4]*(guitar[53];guitar[57];guitar[60]));([4]*(piano[52];piano[57];piano[60]))"
# expression3 = "[4]*(drums[60];drums[61];drums[64]||piano[53];piano[57];piano[60])"
# expression4 = "[3]*piano[60];bass[70]"
# expression5 = "[2]*piano_bass_riff;guitar[57]"
# expression6 = "name1"
# expression7 = "ljd*kajs"
# expression8 = "sads"

"""notes = parse_expression(expression6)

if notes is not None:
    print(notes)
    midi_convert(notes[0], notes[1])"""
