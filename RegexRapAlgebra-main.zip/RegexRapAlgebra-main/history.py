# modified from https://github.com/PySimpleGUI/PySimpleGUI/blob/master/DemoPrograms/Demo_Chat_With_History.py

import PySimpleGUI as sg
from datetime import datetime


def History():  # creates the window
    sg.theme("GreenTan")

    layout = [
        [
            sg.Text("Search:"),
            sg.Input(
                size=(20, 1), key="search", do_not_clear=False, enable_events=True
            ),
        ],  # enable_events triggers an event for any keyboard input
        [sg.Text("Command History"), sg.Text("", size=(50, 10), key="history")],
        [sg.Button("PREVIOUS"), sg.Button("NEXT")],
        [
            sg.ML(size=(50, 1), enter_submits=True, key="query", do_not_clear=False),
            sg.Button(
                "SEND", button_color=(sg.YELLOWS[0], sg.BLUES[0]), bind_return_key=True
            ),
        ],
    ]

    window = sg.Window(
        "History",
        layout,
        default_element_size=(30, 2),
        font=("Helvetica", " 13"),
        default_button_element_size=(8, 2),
        return_keyboard_events=True,
    )

    command_history = []
    history_page = 0
    searching = False

    while True:
        event, value = window.read()

        if event == "SEND":
            dt_obj = datetime.now()
            ts_am_pm = dt_obj.strftime("%I:%M %p")

            query = value["query"].rstrip()
            command_history.append(query + " " + ts_am_pm)

            window["query"].update(
                ""
            )  # manually clear input because keyboard events block a clear
            window["history"].update(
                "\n".join(command_history[10 * history_page : 10 * (history_page + 1)])
            )
            history_page = len(command_history) // 10

        elif event == "PREVIOUS":
            if not searching and history_page != 0:
                history_page -= 1
                window["history"].update(
                    "\n".join(
                        command_history[10 * history_page : 10 * (history_page + 1)]
                    )
                )
            elif searching and search_page != 0:
                search_page -= 1
                window["history"].update(
                    "\n".join(search_matches[10 * search_page : 10 * (search_page + 1)])
                )

        elif event == "NEXT":
            if not searching and history_page != len(command_history) // 10:
                history_page += 1
                window["history"].update(
                    "\n".join(
                        command_history[10 * history_page : 10 * (history_page + 1)]
                    )
                )
            elif searching and search_page != len(search_matches) // 10:
                search_page += 1
                window["history"].update(
                    "\n".join(search_matches[10 * search_page : 10 * (search_page + 1)])
                )

        elif event == "search":
            search = value["search"].rstrip()
            search_page = 0
            search_matches = []
            if search == "":
                searching = False
                window["history"].update("\n".join(command_history[:10]))
            else:
                searching = True
                for command in command_history:
                    if search in command[:-9]:  # not including timestamp
                        search_matches.append(command)
                if len(search_matches) == 0:
                    window["history"].update("\nNo results.")
                else:
                    window["history"].update("\n".join(search_matches[:10]))

        elif event == sg.WIN_CLOSED:
            break


History()
