import os
import PySimpleGUI as psg
from datetime import datetime
from parsing import play_notes
import sf2_loader as sf
import json

# Load user settings
user_settings = psg.UserSettings(filename="userSettings.json", path=".")

# Load saved data from user settings
data = user_settings.get("data", [])
savedSounds = user_settings.get("soundfonts", [])

loader = sf.sf2_loader()


def load_soundfonts(sounds_list):
    for i in range(len(sounds_list)):
        absolute_path = os.path.abspath(sounds_list[i][0])
        loader.load(absolute_path)
        loader.change_soundfont(absolute_path, i)


def add_soundfont_to_channel_mapping(new_sound):
    with open("channel_mappings.json", "r") as json_file:
        channel_mapping = json.load(json_file)

    # Step 2: Add the new instrument
    next_value = len(channel_mapping)
    channel_mapping[new_sound] = next_value

    # Step 3: Write the updated dictionary back to the JSON file
    with open("channel_mappings.json", "w") as json_file:
        json.dump(channel_mapping, json_file)


# add soundfont to listbox
def add_soundfont(listbox):
    if len(savedSounds) > 16:
        psg.popup(
            "You cannot load more than 16 soundfonts at once. Please delete a soundfont to add another.",
            title="Error",
        )
    else:
        # Open file dialog to choose a soundfont file
        file = psg.popup_get_file("Choose a soundfont file")
        if file and os.path.isfile(file):  # check if file exists
            # Add the selected soundfont file to the listbox element
            filename = os.path.basename(file)
            file = "./soundfonts/" + filename

            loaded = False
            for l in savedSounds:
                if l[0] == file:
                    loaded = True

            if not loaded:  # avoid duplicates
                name = ""
                while name == "":
                    name = psg.popup_get_text(
                        "What would you like to call this soundfont?",
                        title="Choose a name",
                    )
                if name is None:  # cancel was pressed
                    name = filename[:-4] # assign base name (file name without extension)

                listbox_names.append(name)
                listbox.update(listbox_names)
                savedSounds.append([file, name])
                add_soundfont_to_channel_mapping(name)
                load_soundfonts(savedSounds)
                # print(listbox_data)
                user_settings["soundfonts"] = savedSounds
            else:
                psg.popup("This soundfont is already loaded.", title="Error")
        else:
            psg.popup("Invalid file path.", title="Error")


# edit comment on click
def edit_cell(window, key, row, col, justify="left"):
    global textvariable, edit
    edit = False  # Initialize the 'edit' variable

    def callback(event, row, col, text, key):
        global edit
        global table_data
        widget = event.widget
        if key == "Return":
            text = widget.get()
            print(text)
            values = list(table.item(row, "values"))
            text2 = values[0]
            if col == 1:
                comment = text
                nickname = values[2]
            else:
                comment = values[1]
                nickname = text

            # replace data in table in place
            index = table_data.index([text2, values[1], values[2]])
            data[index] = [text2, comment, nickname]

            table_data[index] = [text2, comment, nickname]
            window["-TABLE-"].update(table_data)
            # Save updated data to user settings
            user_settings["data"] = data

        widget.destroy()
        widget.master.destroy()
        values = list(table.item(row, "values"))
        values[col] = text
        table.item(row, values=values)
        edit = False

    if edit or row <= 0:
        return

    edit = True
    root = window.TKroot
    table = window[key].Widget

    text = table.item(row, "values")[col]
    x, y, width, height = table.bbox(row, col)

    frame = psg.tk.Frame(root)
    frame.place(x=x + 10, y=y + 138, anchor="nw", width=width, height=height)
    textvariable = psg.tk.StringVar()
    textvariable.set(text)
    entry = psg.tk.Entry(frame, textvariable=textvariable, justify=justify)
    entry.pack()
    entry.select_range(0, psg.tk.END)
    entry.icursor(psg.tk.END)
    entry.focus_force()
    entry.bind(
        "<Return>", lambda e, r=row, c=col, t=text, k="Return": callback(e, r, c, t, k)
    )
    entry.bind(
        "<Escape>", lambda e, r=row, c=col, t=text, k="Escape": callback(e, r, c, t, k)
    )


# Create table layout
header = ["Expressions", "Comment", "Nickname"]
table_data = [[row[0], row[1], row[2]] for row in data]
table = psg.Table(
    table_data,
    headings=header,
    num_rows=10,
    auto_size_columns=False,
    col_widths=[40, 30, 30],
    justification="left",
    key="-TABLE-",
    # alternating_row_color=psg.theme_button_color()[1],
    enable_click_events=True,
)

psg.set_options(dpi_awareness=True)

listbox_names = [os.path.splitext(i[1])[0] for i in savedSounds]

history_column = [
    [psg.Text("History", font=("Arial Bold", 14), justification="center")],
    [
        psg.Text("Search:"),
        psg.Input(size=(20, 1), key="search", do_not_clear=False, enable_events=True),
    ],  # enable_events triggers an event for any keyboard input
    [psg.Text("", size=(50, 10), key="history")],
    [psg.Button("PREVIOUS"), psg.Button("NEXT")],
]

left_column = [
    [
        psg.Text("Saved Expressions", font=("Arial Bold", 14)),
        psg.Button("Delete Expression"),
        psg.Button("Add to Focus"),
        psg.Button("Save from Focus"),
    ],
    [table],
    [psg.Text("", key="-MSG-", font=("Arial Bold", 14), justification="center")],
    [
        psg.Text(
            "Loaded Soundfonts:",
            font=("Arial Bold", 14),
            justification="center",
        )
    ],
    [psg.Listbox(listbox_names, key="-SOUNDFONT-", size=(30, 6))],
    [psg.Button("Add Soundfont", key="-ADD-"), psg.Button("Delete Soundfont")],
    [psg.Button("Edit Soundfont Name")]
]

# Create page layout
layout = [
    [
        psg.Input(size=(20, 1), font=("Arial Bold", 14), expand_x=True, key="-INPUT-"),
        psg.Button("Play Sound", bind_return_key=True),
    ],
    [
        psg.Push(),
        psg.Text("Tempo: "),
        psg.Input(size=(5, 1), key="-TEMPO-"),
        psg.Text("bpm"),
        psg.Button("Set Tempo"),
    ],
    [
        psg.Column(left_column, expand_x=True, expand_y=True),
        psg.Column(history_column, expand_x=True, expand_y=True),
    ],
]


window = psg.Window(
    "Regex to Rap Algebra",
    layout,
    size=(1900, 1000),
    resizable=True,
    finalize=True,
    return_keyboard_events=True,
)


table.bind("<Double-Button-1>", "Double")

command_history = []
history_page = 0
searching = False
tempo = 120

try:
    load_soundfonts(savedSounds)
except Exception as e:
    psg.popup(
        "Unexpected error loading soundfonts. Please check that all entries in userSettings.json are valid.",
        title="Error",
    )

while True:
    event, values = window.read()
    print(event, values)
    # window.refresh()
    if event in (psg.WIN_CLOSED, "Exit"):
        break

    # Saving data
    if event == "Save from Focus":
        text = values["-INPUT-"]
        comment = "double click to edit"
        nickname = "name{}".format(len(data) + 1)
        for i in range(len(data)):
            if data[i][2] == nickname:
                new_num = int(data[i][2][-1]) + 1
                nickname = "name{}".format(str(new_num))
        data.append([text, comment, nickname])
        table_data.append([text, comment, nickname])
        window["-TABLE-"].update(table_data)

        # Save updated data to user settings
        user_settings["data"] = data

    # Add text to input field
    if event == "Add to Focus":
        if len(table.SelectedRows) < 1:
            psg.popup("You must select a row before adding to focus.", title="Error")
        else:
            selected_row = table_data[table.SelectedRows[0]]
            window["-INPUT-"].update(selected_row[0])

    # Delete selected row
    if event == "Delete Expression":
        if len(table.SelectedRows) < 1:
            psg.popup("You must select a row before removing.", title="Error")
        else:
            selected_row_index = table.SelectedRows[0]
            selected_row = table_data[selected_row_index]
            modal = psg.popup_yes_no(
                f"Are you sure you would like to delete the entry: {selected_row[0]}?",
                title="Confirm",
            )
            if modal == "Yes":
                del data[selected_row_index]
                del table_data[selected_row_index]
                window["-TABLE-"].update(table_data)

                # Save updated data to user settings
                user_settings["data"] = data

    if event == "Delete Soundfont":
        if values["-SOUNDFONT-"] == []:
            psg.popup("You must select a row before removing.", title="Error")
        else:
            modal = psg.popup_yes_no(
                f"Are you sure you would like to delete the entry: {values['-SOUNDFONT-']}?",
                title="Confirm",
            )
            if modal == "Yes":
                listbox_names.remove(values["-SOUNDFONT-"][0])
                window["-SOUNDFONT-"].update(listbox_names)

                for i in range(len(savedSounds)):
                    if savedSounds[i][1] == values["-SOUNDFONT-"][0]:
                        del savedSounds[i]
                        break  # avoid out of range error

                # update json file with channel mappings
                with open("channel_mappings.json", "r") as json_file:
                    channel_mapping = json.load(json_file)
                base_name = os.path.splitext(values["-SOUNDFONT-"][0])[0]
                del channel_mapping[base_name]
                for i, (instrument, value) in enumerate(channel_mapping.items()):
                    channel_mapping[instrument] = i
                with open("channel_mappings.json", "w") as json_file:
                    json.dump(channel_mapping, json_file)
                load_soundfonts(savedSounds)
                # Save updated data to user settings
                user_settings["soundfonts"] = savedSounds

    if event == "Edit Soundfont Name":
        if values["-SOUNDFONT-"] == []:
            psg.popup("You must select a row to edit its name.", title="Error")
        else:
            new_name = ""
            while new_name == "":
                new_name = psg.popup_get_text(
                    "What should the selected soundfont be called?",
                    title="New Name",
                )
            if new_name is not None:
                listbox_names = [new_name if x == values["-SOUNDFONT-"][0] else x for x in listbox_names]
                window["-SOUNDFONT-"].update(listbox_names)

                for i in range(len(savedSounds)):
                    if savedSounds[i][1] == values["-SOUNDFONT-"][0]:
                        savedSounds[i][1] = new_name
                        break  # avoid out of range error

                # update json file with channel mappings
                with open("channel_mappings.json", "r") as json_file:
                    channel_mapping = json.load(json_file)
                base_name = os.path.splitext(values["-SOUNDFONT-"][0])[0]
                channel_mapping[new_name] = channel_mapping[base_name]
                del channel_mapping[base_name]
                with open("channel_mappings.json", "w") as json_file:
                    json.dump(channel_mapping, json_file)
                load_soundfonts(savedSounds)
                # Save updated data to user settings
                user_settings["soundfonts"] = savedSounds


    # double click to edit table comment
    if event == "-TABLE-Double":
        # getting row and column from click
        e = table.user_bind_event
        region = table.Widget.identify("region", e.x, e.y)
        if region == "heading":
            row = 0
        elif region == "cell":
            row = int(table.Widget.identify_row(e.y))
        elif region == "separator":
            continue
        else:
            continue
        column = int(table.Widget.identify_column(e.x)[1:])
        if column != 1:
            edit_cell(window, "-TABLE-", row, column - 1, justify="right")
    # add soundfont
    if event == "-ADD-":
        add_soundfont(window["-SOUNDFONT-"])

    if event == "Set Tempo":
        if not values["-TEMPO-"].isdigit() or int(values["-TEMPO-"]) < 1:
            psg.popup("Tempo must be a positive integer.", title="Error")
        else:
            tempo = int(values["-TEMPO-"])

    # HISTORY STUFF-------------------------------------------------------------------------------------
    if event == "Play Sound":
        query = values["-INPUT-"].rstrip()
        if len(query) > 0:
            try:
                # use perform_long_operation so the window doesnt stop responding? issue with errors
                # window.perform_long_operation(lambda: play_notes(query), "-END KEY-")
                play_notes(query, tempo)
                loader.play_midi_file("new_song.mid", wait=True)
            except Exception as e:
                psg.popup(e, title="Error")

        dt_obj = datetime.now()
        ts_am_pm = dt_obj.strftime("%I:%M %p")

        command_history.append(query + " " + ts_am_pm)

        # removed by julian for now, not sure if we should clear input or not
        """window["-INPUT-"].update(
            ""
        ) """  # manually clear input because keyboard events block a clear
        window["history"].update(
            "\n".join(command_history[10 * history_page : 10 * (history_page + 1)])
        )
        history_page = len(command_history) // 10

    elif event == "PREVIOUS":
        if not searching and history_page != 0:
            history_page -= 1
            window["history"].update(
                "\n".join(command_history[10 * history_page : 10 * (history_page + 1)])
            )
        elif searching and search_page != 0:
            search_page -= 1
            window["history"].update(
                "\n".join(search_matches[10 * search_page : 10 * (search_page + 1)])
            )

    elif event == "NEXT":
        if not searching and history_page != len(command_history) // 10:
            history_page += 1
            window["history"].update(
                "\n".join(command_history[10 * history_page : 10 * (history_page + 1)])
            )
        elif searching and search_page != len(search_matches) // 10:
            search_page += 1
            window["history"].update(
                "\n".join(search_matches[10 * search_page : 10 * (search_page + 1)])
            )

    elif event == "search":
        search = values["search"].rstrip()
        search_page = 0
        search_matches = []
        if search == "":
            searching = False
            window["history"].update("\n".join(command_history[:10]))
        else:
            searching = True
            for command in command_history:
                if search in command[:-9]:  # not including timestamp
                    search_matches.append(command)
            if len(search_matches) == 0:
                window["history"].update("\nNo results.")
            else:
                window["history"].update("\n".join(search_matches[:10]))


window.close()
