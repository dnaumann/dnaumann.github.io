# RegexRapAlgebra
Educational tool using music to demonstrate algebraic views of strings and programs.

# Installation:
1. In the directory of the project, run ```pip install -r requirements.txt```
2. Then run ```ffdl install --add-path```
3. Run the RegexRapAlegbra.py file.

# Usage:
5 main operators:
- "a;b" plays a and b in sequence
- "a||b" plays a and b at the same time
- "a+b" plays either a or b
- "[N]*b" plays b N times
- "*b" plays b a random number of times from 1-5
  
Expressions can be written with any combination of these operators.<br>
An atom looks like "piano[60]" where "piano" is the instrument being played, and "[60]" is the MIDI note number.<br>
Tempo of the expression can be set in the tempo box below the input bar.<br>
Naming expressions can be done by saving an expression, then double clicking on the default name and editing it. These names can be used in expressions as abbreviations of expressions.<br>
Soundfonts can be added and named to be used in expressions.<br>
To download more soundfonts, [Musical Artifacts](https://musical-artifacts.com/) is a good website to find them.<br>
To create your own soundfont, here is a link to download [Polyphone](https://www.polyphone-soundfonts.com/), a soundfont creation program.<br>
