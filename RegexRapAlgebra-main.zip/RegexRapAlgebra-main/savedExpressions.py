import os
import PySimpleGUI as psg

# Load user settings
user_settings = psg.UserSettings(filename="userSettings.json", path=".")

# Load saved data from user settings
data = user_settings.get("data", [])
savedSounds = user_settings.get("soundfonts", [])


# add soundfont to listbox
def add_soundfont(listbox):
    # Open file dialog to choose a soundfont file
    file = psg.popup_get_file("Choose a soundfont file")
    if file:
        # Add the selected soundfont file to the listbox element
        filename = os.path.basename(file)
        listbox_names.append(filename)
        listbox.update(listbox_names)
    savedSounds.append([file, filename])
    # print(listbox_data)
    user_settings["soundfonts"] = savedSounds


# edit comment on click
def edit_cell(window, key, row, col, justify="left"):
    global textvariable, edit
    edit = False  # Initialize the 'edit' variable

    def callback(event, row, col, text, key):
        global edit
        global table_data
        widget = event.widget
        if key == "Return":
            text = widget.get()
            print(text)
            values = list(table.item(row, "values"))
            text2 = values[0]
            comment = text
            data.append([text2, comment])
            data.remove([text2, values[1]])
            # print(table_data)
            index = table_data.index([text2, values[1]])
            table_data = (
                table_data[:index] + [[text2, comment]] + table_data[index + 1 :]
            )
            window["-TABLE-"].update(table_data)
            # Save updated data to user settings
            user_settings["data"] = data

        widget.destroy()
        widget.master.destroy()
        values = list(table.item(row, "values"))
        values[col] = text
        table.item(row, values=values)
        edit = False

    if edit or row <= 0:
        return

    edit = True
    root = window.TKroot
    table = window[key].Widget

    text = table.item(row, "values")[col]
    x, y, width, height = table.bbox(row, col)

    frame = psg.tk.Frame(root)
    frame.place(x=x, y=y + 90, anchor="nw", width=width, height=height)
    textvariable = psg.tk.StringVar()
    textvariable.set(text)
    entry = psg.tk.Entry(frame, textvariable=textvariable, justify=justify)
    entry.pack()
    entry.select_range(0, psg.tk.END)
    entry.icursor(psg.tk.END)
    entry.focus_force()
    entry.bind(
        "<Return>", lambda e, r=row, c=col, t=text, k="Return": callback(e, r, c, t, k)
    )
    entry.bind(
        "<Escape>", lambda e, r=row, c=col, t=text, k="Escape": callback(e, r, c, t, k)
    )


# Create table layout
header = ["Expressions", "Comment"]
table_data = [[row[0], row[1]] for row in data]
table = psg.Table(
    table_data,
    headings=header,
    num_rows=10,
    auto_size_columns=False,
    col_widths=[30, 40],
    justification="left",
    key="-TABLE-",
    # alternating_row_color=psg.theme_button_color()[1],
    enable_click_events=True,
)

psg.set_options(dpi_awareness=True)

listbox_names = [i[1] for i in savedSounds]

# Create page layout
layout = [
    [
        psg.Input(size=(20, 1), font=("Arial Bold", 14), expand_x=True, key="-INPUT-"),
        psg.Button("Save"),
        psg.Button("Delete"),
        psg.Button("Add to Focus"),
    ],
    [psg.Text("Saved Expressions", font=("Arial Bold", 14))],
    [table],
    [psg.Text("", key="-MSG-", font=("Arial Bold", 14), justification="center")],
    [psg.Text("Cell Clicked:"), psg.T(k="-CLICKED-")],
    [psg.Text("Select Soundfont:", font=("Arial Bold", 14), justification="center")],
    [psg.Listbox(listbox_names, key="-SOUNDFONT-", size=(30, 6))],
    [psg.Button("Add a Soundfont", key="-ADD-", size=(15, 1))],
    [psg.Button("Play Sound", key="-PLAY-", size=(15, 1))],
]

window = psg.Window(
    "Table Example", layout, size=(1000, 1000), resizable=True, finalize=True
)

table.bind("<Double-Button-1>", "Double")

while True:
    event, values = window.read()
    print(event, values)
    # window.refresh()
    if event in (psg.WIN_CLOSED, "Exit"):
        break

    # Saving data
    if event == "Save":
        text = values["-INPUT-"]
        comment = "comment here"
        data.append([text, comment])
        table_data.append([text, comment])
        window["-TABLE-"].update(table_data)

        # Save updated data to user settings
        user_settings["data"] = data

    # Add text to input field
    if event == "Add to Focus":
        if len(table.SelectedRows) < 1:
            psg.popup("You must select a row before adding to focus.")
        else:
            selected_row = table_data[table.SelectedRows[0]]
            window["-INPUT-"].update(selected_row[0])

    # Delete selected row
    if event == "Delete":
        if len(table.SelectedRows) < 1:
            psg.popup("You must select a row before removing.")
        else:
            selected_row_index = table.SelectedRows[0]
            selected_row = table_data[selected_row_index]
            modal = psg.popup_yes_no(
                f"Are you sure you would like to delete the entry: {selected_row[0]}?"
            )
            if modal == "Yes":
                del data[selected_row_index]
                del table_data[selected_row_index]
                window["-TABLE-"].update(table_data)

                # Save updated data to user settings
                user_settings["data"] = data

    # double click to edit table comment
    if event == "-TABLE-Double":
        row = table.SelectedRows[0]
        col = 1
        cell = (row, col)

        window["-CLICKED-"].update(cell)
        if type(row) == type(None):
            pass
        else:
            edit_cell(window, "-TABLE-", row + 1, col, justify="right")

    # add soundfont
    if event == "-ADD-":
        add_soundfont(window["-SOUNDFONT-"])

    # play soundfont (well, just print it for now)
    if event == "-PLAY-":
        selected_soundfonts = values["-SOUNDFONT-"]
        for filepath in user_settings["soundfonts"]:
            if selected_soundfonts[0] in filepath:
                print(filepath[0])
                break


window.close()
