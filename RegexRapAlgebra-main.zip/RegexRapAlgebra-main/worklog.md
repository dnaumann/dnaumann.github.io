# group meeting log

## May 18 kickoff meeting

first steps 
- wiki page about Kleene algebra
- coordination plan 
  + slack
  + weekly meeting with Dave, Wed at 2
- dates - start right away
- implementation language - python 
- audio processing - near-term to do 
- parsing expressions
- eventually/optionally: checking equivalence 
- weekly meeting - Wed 2pm 
- daily report log 

## May 24

Discussed mido library and midi especially how time/pauses work. 


palette:

ping   //some sample
pong 
ding
~ping  //the audio reverse of that sample 
~pong 
~ding


  ~ (ping ; pong ; ding)
= ~ding ; ~pong ; ~ping       using law ~(x;y) = ~y;~x 

~((ping;ping|pong;pong);ding)
= 
~(ping;ping|pong;pong) ; ~ding
= 
~(ping;ping)|~(pong;pong) ; ~ding 
=
~ping;~ping|~pong;~pong ; ~ding 

gnid ; gnop ; gnip 



ping ; pong ; ding  --> audio --> reversed audio


## June 7

polyphone - standalone program to create sound fonts from samples

fluidsynth - plays midi based on sound fonts, has python API
complicated build/install 
https://github.com/nwhitehead/pyfluidsynth
https://github.com/FluidSynth/fluidsynth
https://www.polyphone-soundfonts.com/download includes Windows 

Reversing a sample (or other processing of samples) isn't a requirement.
It would be fine to play with reverse expressions but where the primitives don't get reversed.
The reverse of the string "abc" is "cba", no backward letters.

## June 14  

Julian playing with polyphone and fluidsynth.
Easy to make sample and create instrument from a sample.
Decided to just use polyphone standalone to create sounds.
Decided not to worry about audio processing like reversing an individual sounds.

Matt exploring fluidsynth's python API 

Discussed use cases and sketched GUI 

## June 28 
Both working on UI etc 

## July 12

Julian saved expressions, playing 
Matt playing sequence, abbrev table 

discussed parsing 

need installation instructions 

## July 19 

Julian looking into parsing; so far parse tree is nested list; better to have object structure
We discussed generation of midi from expressions; still not clear how timing works in a midi file 
Matt looking at a different parsing package 

## July 26 

Julian has working parser and interpreter written using traversal skeleton.  
Discussed design of grammar

Matt exloring timing in fluidsynth sequencer 
The sequencer has API that lets you specify times, but seeming not work. 

Look for other options for playing midi files - py-meltysynth 

Our evaluator could generate a list of midi events.
That means alternative is chosen randomly at interpretation-time, not at play time.  That's fine.

## Aug 2

Julian has working interp.
Discussed that interp needs to return list of events, so merge can be done in parallel case. 
Matt has working time-handling.

Alert: following needs to be viewed in monospace font 

a note on 
A note off


a     [a,A]

ab    [a,A,b,B] 

a|b   [a,A] [b,B] --> [a,b,A,B]

(a|b) c   [a,b,A,B]  [c,C] ------>  [a,b,A,B,c,C] 

a|b | c  [a,b,A,B] [c,C]  -----> [a,b,c,A,B,C]



[a,b,A,B,c,C,d,e,f,D,E,F] [g,h,i,G,H,I,j,J]  ---> 
 - -                       - - -
         -                             -
             - - - 
[a,b,g,h,i,A,B,G,H,I,c,j,C,J,d,e,f,D,E,F] 

## Aug 9 

Revisiting merge


a;b | c  [a,b] [c] ---> [a,b,A1,B,c,C1]



[a,b,g,h,i,*,c,j,*,d,e,f]



To generate, interpreter generates a list of lists, like

[[a,b,g,h,i], [c,j], [d,e,f]]    using only note-on.  

meant to be at successive times.  This seems amenable to merge.

Then post-process by adding note-offs

a    [a]
a;b  [[a],[b]]

[[a,b,g,h,i], [c,j], [d,e,f]]    using only note-on.  

Interpreter just produces lists of lists of note-ons.

for parallel, 
merge [[a,b,g,h,i], [c,j], [d,e,f]] with [[k],[m,n]]

merge [[a,b,g,h,i], [c,j], [d,e,f]]
      [[k],[m,n]] 
[[a,b,g,h,i, k], [c,j, m,n], [d,e,f]]


From the list-of-lists-of-note-ons 
-->  compute note-offs 
[[A1,B0,G0,H0,I0,K0],
 [C1,J0,M0,N0],
 [D1,E0,F0] 
]
--->  combine note-ons and note-offs
[[a,b,g,h,i, k], [A1,B0,G0,H0,I0,K0],
 [c,j, m,n], [C1,J0,M0,N0],
 [d,e,f], [D1,E0,F0]] 
---> flatten into single list 
[a,b,g,h,i, k, A1,B0,G0,H0,i0,k0,
 c,j, m,n, C1,J0,M0,N0,
d,e,f, D1,E0,F0 
]


## Aug 17 

Parsing, interp, play all working.

To do:
- in GUI, defining named instruments and notes based on those, e.g., piano[23] or maybe piano{23} if we get grammar conflicts.
  GUI will have list of 16 channels, each of which the user can enter (a) a name and (b) select a soundfont file out of our folder holding soundfonts.

- using those things in expressions
- generating the setup to map channel numbers to instruments
  That's fluidsynth, it's not in the midi datastream 


- instructions how to build the system 
- brief user guide 


## Aug 31
To do:
- rudimentary input validation  
- user ability to set tempo
- ability to give names to expressions, possibly restricted to naming primitive expressions like piano[61]
  Parser handle both forms with and without bracketed numbers.
  After parsing, check for each primitive node:
  + if it has a number, like piano[61], check that the name is one of the loaded sounds
  + if no number, look it up in the list of defined names, and replace it by the defined value
  + otherwise error message 
- delete loaded sound font
- error message if attempt to load a 17th sound font (since only 16 channels) 

## Sept 6
Note: * binds weakly, e.g., [4]*(pi;pi);drum repeats the drum too
  Can write ([4]*pi;pi);drum 

Names are implemented.
Some error handling is implemented.
Single thread, so while playing the GUI is disabled; ok for now. 
Tempo implemented.
Implemented deletion for sound fonts. 

To do 
- handle errors: too many sound fonts; nonexistent font file; invalid tempo; 
- build instructions

## Sept 13 

To do: 
Names for expressions - add column, editable, with auto-generated default name 
Make it possible to have soundfonts at relative paths (from the default folder).


# EXPRESSIONS

ping          (atom)
drum[C#]      atom that indicates instrument+note (also indicate octave?)

e*(n)         repeat e n times 
e*            repeat some number of times 
e ; e'        sequence
e + e'        alternative (for playing, use random?)
e || e'       in parallel 

e ::= atom 
      | *e      repeat e some randomly chosen number of times 
      | e ; e'  e followed by e'
      | e + e'  either e or e' (selected randomly) 
      | [n]*e   n repetitions of e   (short hand for e;e;e;...;e )
      | e || e' both e and e' simultaneously 

without comments:
e ::= atom 
      | *e      
      | e ; e'  
      | e + e'  
      | [n]*e   
      | e || e' 

Binding power: ; tighter than + which binds tighter than || 

to get precedence by pure grammar:

exp ::= term  |  term||exp
term ::= factor  |  factor + term
factor ::= (exp) | atom  |  factor;factor  |  *(exp)  |  [n]*(exp)  




parser should produce objects like

   (star e)
   (seq e e')
   (plus e e') 

Evaluator defined by recursion over syntax tree; here's psuedocode written with pattern matching:

eval is a function from expressions to lists of midi events

eval | *e    => let n = random(1..20) in
                catenate_copies n (eval e) 
     | e ; e' => eval e ++ eval e'     
     | e + e' => if random(0,1) then eval(e) else eval(e')
     | [n]*e  => catenate_copies n (eval e) 
     | e || e' => TODO
where ++ means catenate two lists of midi events 


# USE CASES

## set tempo
Atoms take one 'beat'.  User can set beats per min.
Input validation (integer within sensiblev range)

## listen to an expression

User writes an expression like
   ping ; pong
and then plays the sound of that expression.
The 'focused expression'.

The available atoms are displayed somehow. 
- from an instrument we created by sample 
- regular midi instrument notes: choose instrument and note 


## load instrument 

record a brief sound and save it with a name ---> just use polyphone

load an instrument from a soundfont file, give it a name

## save the focused expression, load an expression

- maintain a list of expressions (This persists between sessions running the program)
- add the focused expression to the list
- select an expression from the list (make it the focused one) 
- saved expressions can be accompanied by a comment (use this for examples of the operators)

(Useful to ask is A equal to B, e.g. 
A := ping; (pong|ding)
B := ping;pong | ping;ding
)

## manipulate a list of abbreviations
To avoid cluttered expressions with atoms like piano[C3].
Map a name to an expression.
Ideally make this persistent (add, delete entry), save upon quit.



## persistent saved expressions versus history of current session
TODO
- whole history in session? 
- search through session for match of an expression or partial expression 

## eventually deploy on chromebooks? Julian and Matt are developing on windows, stick to that for now 













# Matt log







# Julian 