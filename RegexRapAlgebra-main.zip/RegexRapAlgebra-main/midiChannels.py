from mido import Message, MidiFile, MidiTrack
import fluidsynth


def note_to_midi(note):
    notes = {
        "C": 0,
        "C#": 1,
        "Db": 1,
        "D": 2,
        "D#": 3,
        "Eb": 3,
        "E": 4,
        "F": 5,
        "F#": 6,
        "Gb": 6,
        "G": 7,
        "G#": 8,
        "Ab": 8,
        "A": 9,
        "A#": 10,
        "Bb": 10,
        "B": 11,
    }
    note_name = note[:-1]
    octave = int(note[-1])
    midi_number = (octave + 1) * 12 + notes[note_name]
    return midi_number


# notes = input("Enter a musical note sequence: ")


def play_notes(notes, soundfont):
    # convert notes into midi numbers
    note_list = notes.split(";")
    midi_numbers = []
    for note in note_list:
        note = note.strip()
        midi_numbers.append(note_to_midi(note))

    # using mido, create midi file with notes and rhythms
    mid = MidiFile()
    track = MidiTrack()
    mid.tracks.append(track)
    for midi_note in midi_numbers:
        track.append(
            Message("note_on", note=midi_note, velocity=127, time=0)
        )  # play this note immediately after the last message
        track.append(
            Message("note_off", note=midi_note, velocity=127, time=480)
        )  # wait midi_time ticks to stop this note
    mid.save("new_song.mid")

    # using fluidsynth, play midi file with selected soundfont
    fs = fluidsynth.Synth()
    fs.start()
    sfid = fs.sfload(soundfont)
    fs.program_select(0, sfid, 0, 0)
    fs.play_midi_file("new_song.mid")
    # do not delete the synth! otherwise, this won't play
